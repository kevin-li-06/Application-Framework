var expect = require("chai").expect;
var _ = require("underscore");
var pg = require("pg");

var pgClient = require("../../../../lib/db/postgres/client");

const dbConnectionParams = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postgres",
    database: "aof",
    max: 10
};

describe("db-postgres-client", () => {
    const oPool = new pg.Pool(dbConnectionParams);
    var oDB;

    beforeEach(() => {
        return Promise.resolve().then(() => {
            return oPool.connect();
        }).then((oDBClient) => {
            oDB = oDBClient;
            return oDB.query('DROP TABLE IF EXISTS "t_test"');
        }).then(() => {
            return oDB.query('CREATE TABLE "t_test" (ID integer PRIMARY KEY, A_VARCHAR varchar(50), "A_CamelCaseVarChar" varchar(50), A_NVARCHAR varchar(50), A_SMALLINT smallint, A_INT integer, A_BIGINT bigint, A_DECIMAL decimal, A_REAL real, A_DOUBLE double precision, A_CLOB text, A_BLOB bytea, A_NCLOB text, A_DATE DATE, A_TIME time, A_TIMESTAMP timestamp, A_BOOLEAN boolean, A_JSON json, A_JSONB jsonb)')
        });
    });

    afterEach(() => {
        if (oDB) {
            oDB.release();
        }
    });

    it("provides table read access", () => {
        var oClient = new pgClient(oDB);
        var oTable = oClient.table('t_test');
        expect(oTable).to.be.ok;

        return oDB.query('INSERT INTO "t_test" (ID, A_VARCHAR, A_NVARCHAR) VALUES (42,\'X\', \'Y\')')
            .then(() => {
                return oTable.read()
                    .then((aResult) => {
                        expect(_.omit(aResult[0], _.isNull)).to.eql({"id": 42, "a_varchar": "X", "a_nvarchar": "Y"});
                    })
                    .then(() => {
                        return oTable.read();
                    })
                    .then((aResult) => {
                        expect(_.omit(aResult[0], _.isNull)).to.eql({"id": 42, "a_varchar": "X", "a_nvarchar": "Y"});
                    });
            });
    });

    describe("fills table content", () => {
        var oTable;

        beforeEach(() => {
            var oClient = new pgClient(oDB);
            oTable = oClient.table('t_test');
            expect(oTable).to.be.ok;
        });

        it("inserts undefined and null without exception", () => {
            return oTable.insert({
                id: 123,
                a_varchar: null,
                a_nvarchar: undefined,
            });
        });

        it("inserts characters", () => {
            return oTable.insert({
                id: 1234,
                a_varchar: "ABC",
                a_nvarchar: "Müller",
                A_CamelCaseVarChar: "Camel",
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].a_varchar).to.eql("ABC");
                    expect(aContent[0].a_nvarchar).to.eql("Müller");
                    expect(aContent[0].A_CamelCaseVarChar).to.eql("Camel");
                });
            });
        });

        it("inserts numerics", () => {
            return oTable.insert({
                id: 12345,
                a_smallint: 31000,
                a_int: 1000000000,
                a_bigint: 100000000000,
                a_decimal: 1.13,
                a_real: 3.14,
                a_double: 0.12345
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].a_smallint).to.eql(31000);
                    expect(aContent[0].a_int).to.eql(1000000000);
                    expect(aContent[0].a_bigint.toString()).to.eql("100000000000");

                    expect(aContent[0].a_decimal).to.eql("1.13");
                    expect(Math.round((aContent[0].a_real * 100)) / 100).to.eql(3.14);
                    expect(aContent[0].a_double).to.eql(0.12345);
                });
            });
        });

        it("inserts blobs", () => {
            return oTable.insert({
                id: 4711,
                a_clob: "ABC",
                a_nclob: "検索BuscaSök搜尋TìmkiếmبحثІздеу",
                a_blob: "MyString"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].a_clob).to.eql("ABC");
                    expect(aContent[0].a_nclob).to.eql("検索BuscaSök搜尋TìmkiếmبحثІздеу");
                    expect(aContent[0].a_blob.toString('utf8')).to.eql("MyString");
                });
            });
        });

        it("inserts dates", () => {
            return oTable.insert({
                id: 4713,
                a_date: "2009-01-02",
                a_time: "8:00",
                a_timestamp: "2009-01-02T08:00:12.100Z"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].a_date).to.eql("2009-01-02");
                    expect(aContent[0].a_time).to.eql("08:00:00");
                    expect(aContent[0].a_timestamp).to.eql("2009-01-02T08:00:12.100Z");
                });
            });
        });

        it("inserts json(b)", () => {
            var oJSON = {
                A: 1,
                B: "Hello World",
                C: [{
                    D: 2,
                    E: "Test"
                }],
                F: {
                    G: 3,
                    H: "Test2"
                }
            };
            return oTable.insert({
                id: 4713,
                a_json: oJSON,
                a_jsonb: oJSON
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].a_json).to.eql(oJSON);
                    expect(aContent[0].a_jsonb).to.eql(oJSON);
                });
            });
        });

        it("inserts bulk data", () => {
            return oTable.insert([{
                id: 1244,
                a_int: 4711,
                a_timestamp: "2009-01-02T08:00:12.123Z",
                a_nvarchar: "ABC",
            }, {
                id: 1245,
                a_int: 4712,
                a_nvarchar: "DEF",
                a_varchar: "XYZ",
                a_timestamp: "2010-01-02T08:00:12.123Z"
            }]).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent.length).to.eql(2);
                    var oContent = _.findWhere(aContent, {a_nvarchar: "ABC"});
                    expect(oContent.a_int).to.eql(4711);
                    expect(oContent.a_timestamp).to.eql("2009-01-02T08:00:12.123Z");

                    var oContent = _.findWhere(aContent, {a_nvarchar: "DEF"});
                    expect(oContent.a_int).to.eql(4712);
                    expect(oContent.a_timestamp).to.eql("2010-01-02T08:00:12.123Z");
                    expect(oContent.a_varchar).to.eql("XYZ");
                });
            });
        });
    });

    describe("modifies table content", () => {
        var oTable;

        beforeEach(() => {
            var oClient = new pgClient(oDB);
            oTable = oClient.table('t_test');
            expect(oTable).to.be.ok;
        });

        it("upsert = insert", () => {
            return oTable.upsert({
                id: 42,
                a_varchar: "Insert"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].id).to.eql(42);
                    expect(aContent[0].a_varchar).to.eql("Insert");
                });
            });
        });

        it("upsert = update", () => {
            return oTable.insert({
                id: 43,
                a_varchar: "My Insert"
            }).then(() => {
                return oTable.read();
            }).then((aContent) => {
                expect(aContent[0].a_varchar).to.eql("My Insert");
            }).then(() => {
                return oTable.upsert([{
                    id: 43,
                    a_varchar: "My Upsert"
                }]);
            }).then(() => {
                return oTable.read();
            }).then((aContent) => {
                expect(aContent.length).to.eql(1);
                expect(aContent[0].a_varchar).to.eql("My Upsert");
            });
        });

        it("update", () => {
            return oTable.insert([{
                id: 43,
                a_varchar: "Insert 1"
            }, {
                id: 44,
                a_varchar: "Insert 2"
            }, {
                id: 45,
                a_varchar: "Insert 3"
            }]).then(() => {
                return oTable.read();
            }).then((aContent) => {
                expect(aContent[0].a_varchar).to.eql("Insert 1");
                expect(aContent[1].a_varchar).to.eql("Insert 2");
                expect(aContent[2].a_varchar).to.eql("Insert 3");
            }).then(() => {
                return oTable.update([{
                    id: 43,
                    a_varchar: "Update 1"
                }, {
                    id: 44,
                    a_varchar: "Update 2"
                }, {
                    id: 45,
                    a_varchar: "Update 3"
                }]);
            }).then(() => {
                return oTable.read();
            }).then((aContent) => {
                expect(aContent.length).to.eql(3);
                expect(aContent[0].a_varchar).to.eql("Update 1");
                expect(aContent[1].a_varchar).to.eql("Update 2");
                expect(aContent[2].a_varchar).to.eql("Update 3");
            });
        });

    });

    describe("execute a prepared statement", () => {
        it("execute a prepared statement with some parameters [1,2]", () => {
            var oClient = new pgClient(oDB);
            return Promise.resolve().then(() => {
                return oDB.query("DROP TABLE IF EXISTS dummy");
            }).then(() => {
                return oDB.query("CREATE TABLE dummy (DUMMY CHAR(1))");
            }).then(() => {
                return oDB.query("INSERT INTO dummy (DUMMY) VALUES ('X')")
            }).then(() => {
                return oClient.statement([
                    "select * from (",
                    "    select 1 as N from dummy union all",
                    "    select 2 as N from dummy union all",
                    "    select 3 as N from dummy",
                    ") as sub where",
                    "    n >= ? and n <= ?"
                ].join(" ")).execute([1, 2])
            }).then((aResult) => {
                expect(aResult).to.eql([{"n": 1}, {"n": 2}]);
                return oClient.statement("select * from dummy where DUMMY = ?").execute('X');
            }).then((aResult) => {
                expect(aResult).to.eql([{"dummy": "X"}]);
            });
        });
    });

    describe("execute a sequence", () => {
        it("call nextval on a sequence", () => {
            var oClient = new pgClient(oDB);
            return Promise.resolve().then(() => {
                return oDB.query('DROP SEQUENCE IF EXISTS "s_test"');
            }).then(() => {
                return oDB.query('CREATE SEQUENCE "s_test"');
            }).then(() => {
                return oClient.sequence("s_test").nextval();
            }).then((iNextVal) => {
                expect(iNextVal).to.eql(1);
                return oClient.sequence("s_test").nextval();
            }).then((iNextVal) => {
                expect(iNextVal).to.eql(2);
            });
        });
    });

    describe("transaction handling", () => {
        it("starts and commits a transaction", () => {
            var oClient = new pgClient(oDB);
            return Promise.resolve().then(() => {
                return oClient.startTransaction();
            }).then(() => {
                return oClient.statement('INSERT INTO "t_test"(ID, A_VARCHAR) VALUES (4711,\'Hello world\')').execute();
            }).then(() => {
                return oClient.commit();
            }).then(() => {
                return oClient.statement('SELECT id, a_varchar from t_test where id = ?').execute(4711);
            }).then((aResult) => {
                expect(aResult.length).to.eql(1);
                expect(aResult[0].id).to.eql(4711);
                expect(aResult[0].a_varchar).to.eql('Hello world');
            });
        });

        it("starts and rolls a transaction back", () => {
            var oClient = new pgClient(oDB);
            return Promise.resolve().then(() => {
                return oClient.startTransaction();
            }).then(() => {
                return oClient.statement('INSERT INTO "t_test"(ID, A_VARCHAR) VALUES (4711,\'Hello world\')').execute();
            }).then(() => {
                return oClient.rollback();
            }).then(() => {
                return oClient.statement('SELECT id, a_varchar from t_test where id = ?').execute(4711);
            }).then((aResult) => {
                expect(aResult.length).to.eql(0);
            });
        });
    });
});
