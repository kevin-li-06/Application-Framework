"use strict";
var tables = require("./lib/db/tables");

var express = require("express");
var pg = require("pg");
var onFinished = require("on-finished");

var aof = require("@sap/aof");

var xsodata = require("@sap/xsodata");

var PORT = process.env.PORT || 3000;

var app = express();

const dbConnectionParams = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postgres",
    database: "aof_example_todo"
};

const pgPool = new pg.Pool(dbConnectionParams);

tables.setUp(pgPool).then(function () {
    app.use('/', express.static('ui'));
    app.use(function (req, res, next) {
        req.user = {
            id: 42
        };

        pgPool.connect().then(function (oClient) {
            req.db = oClient;
            next();
        });

        onFinished(req, function (err, req) {
            if (req.db && req.db.release) {
                req.db.release();
            }
        });
    });

    aof.middleware(app, {
        metadata: "/todo/rest/metadata",
        odata: "/todo/odata",
        applicationObjects: {
            "lib.todo": "/todo/rest/Todo"
        },
        preload: false,
        extensions: {
            odata: {
                name: "@sap/xsodata",
                lib: xsodata,
                dbAdapter: aof.Adapter.postgresXSODataDbAdapter
            }
        }
    }, "postgres");

    app.listen(PORT, function () {
        console.log("ToDo AOF example running on port " + PORT);
    });

}).catch(function (e) {
    console.log(e);
});
