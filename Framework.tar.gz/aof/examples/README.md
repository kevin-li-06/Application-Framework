![aof](../docs/assets/aof_logo.png)

Easy, Fast and Holistic Development of Data Model Oriented Applications

> AOF (Application Object Framework) allows application developers to concentrate on business logic organized around a data model. It provides a feature set, proven in real-world applications and provides a holistic approach reaching from database to user interface. 

Examples
========

## HANA/XS

DB Access via WebIDE: 

http://inno-next.mo.sap.corp:8000/sap/hana/ide
    
### [Simple Comment application](comment-express-hanaxs) 

* Prerequisite (already prepared):
    * Create HDI Container 'SAP_AOF_EXAMPLE_COMMENT'
        ```
        examples/comment-express-hanaxs/db/hdi_container.sh 
        ```        

    * Deploy DB src in HDI Container 'SAP_AOF_EXAMPLE_COMMENT'
        ```
        examples/comment-express-hanaxs/db/hdi_sync.sh
        ```
        
    * Create user 'SAP_AOF_EXAMPLE_COMMENT_USER' with password 'Test1234'
        ```
        create user SAP_AOF_EXAMPLE_COMMENT_USER password Test1234;
        alter user SAP_AOF_EXAMPLE_COMMENT_USER disable password lifetime;
        grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_AOF_EXAMPLE_COMMENT_USER;
        grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_AOF_EXAMPLE_COMMENT_USER;
        ```

    * Grant schema privileges in HDI Container 'SAP_AOF_EXAMPLE_COMMENT'
        ```
        examples/comment-express-hanaxs/db/hdi_grant.sh
        ```

* Start application router
    ```
    cd examples/comment-express-hanaxs/web
    npm install
    npm start
    ```
    
* Start Node.js server
    ```
    cd examples/comment-express-hanaxs/js
    npm install
    npm start
    ```    

* Open URL
    ```
    http://localhost:5000
    ```

### [Sophisticated Todo application](todo-express-hanaxs)

* Prerequisite (already prepared):
    * Create HDI Container 'SAP_AOF_EXAMPLE_TODO'
        ```
        examples/todo-express-hanaxs/db/hdi_container.sh
        ```
         
    * Deploy DB src in HDI Container 'SAP_AOF_EXAMPLE_TODO'
        ```
        examples/todo-express-hanaxs/db/hdi_sync.sh
        ```
                   
    * Create user 'SAP_AOF_EXAMPLE_TODO_USER' with password 'Test1234'
        ```
        create user SAP_AOF_EXAMPLE_TODO_USER password Test1234;
        alter user SAP_AOF_EXAMPLE_TODO_USER disable password lifetime;
        grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_AOF_EXAMPLE_TODO_USER;
        grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_AOF_EXAMPLE_TODO_USER;
        ```
        
    * Grant schema privileges in HDI Container 'SAP_AOF_EXAMPLE_TODO'
        ```
        examples/todo-express-hanaxs/db/hdi_grant.sh
        ```
    
* Start application router
    ```
    cd examples/todo-express-hanaxs/web
    npm install
    npm start
    ```
    
* Start Node.js server
    ```
    cd examples/todo-express-hanaxs/js
    npm install
    npm start
    ```
    
* Open URL
    ```
    http://localhost:5000
    ```
    
### [CDS based Bookshop services](bookshop-cds-hanaxs) 

* Prerequisite (already prepared):
    * Create HDI Container (already prepared) 
    * Deploy DB src in HDI Container
        ```
        cd examples/bookshop-cds-hanaxs/db
        npm install
        npm run tunnel &
        npm start
        ```
    
* Start Node.js server
    ```
    cd examples/bookshop-cds-hanaxs/js
    npm install
    npm start
    ```    

* Open URL
    ```
    http://localhost:3000/catalog/$metadata
    ```

### [Chat supporting WebSockets](chat-socketio-hanaxs)

#### Socket.io

* Prerequisite (already prepared):
    * Create HDI Container 'SAP_AOF_EXAMPLE_CHAT'
        ```
        examples/chat-socketio-hanaxs/db/hdi_container.sh
        ```
                 
    * Deploy DB src in HDI Container 'SAP_AOF_EXAMPLE_CHAT'
        ```
        examples/chat-socketio-hanaxs/db/hdi_sync.sh
        ```
           
    * Create user 'SAP_AOF_EXAMPLE_CHAT_USER' with password 'Test1234'
        ```
        create user SAP_AOF_EXAMPLE_CHAT_USER password Test1234;
        alter user SAP_AOF_EXAMPLE_CHAT_USER disable password lifetime;
        grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_AOF_EXAMPLE_CHAT_USER;
        grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_AOF_EXAMPLE_CHAT_USER;
        ```
        
    * Grant schema privileges in HDI Container 'SAP_AOF_EXAMPLE_CHAT'
        ```
        examples/chat-socketio-hanaxs/db/hdi_grant.sh
        ```
            
* Start application router
    ```
    cd examples/chat-socketio-hanaxs/web
    npm install
    npm start
    ```
    
* Start Node.js server
    ```
    cd examples/chat-socketio-hanaxs/js
    npm install
    npm start
    ```
        
* Open URL
    ```
    http://localhost:5000
    ```
    
#### Socket.io (standalone)

* Prerequisite (like above)

* Start Node.js server
    ```
    cd examples/chat-socketio-hanaxs/js
    npm install
    node index_standalone
    ```
        
* Open URL
    ```
    http://localhost:3000
    ```
    
#### WS

* Prerequisite (already prepared):
    * Create HDI Container 'SAP_AOF_EXAMPLE_CHAT'
        ```
        examples/chat-socketio-hanaxs/db/hdi_container.sh
        ```
         
    * Deploy DB src in HDI Container 'SAP_AOF_EXAMPLE_CHAT'
        ```
        examples/chat-socketio-hanaxs/db/hdi_sync.sh
        ```
           
    * Create user 'SAP_AOF_EXAMPLE_CHAT_USER' with password 'Test1234'
        ```
        create user SAP_AOF_EXAMPLE_CHAT_USER password Test1234;
        alter user SAP_AOF_EXAMPLE_CHAT_USER disable password lifetime;
        grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_AOF_EXAMPLE_CHAT_USER;
        grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_AOF_EXAMPLE_CHAT_USER;
        ```

    * Grant schema privileges in HDI Container 'SAP_AOF_EXAMPLE_CHAT'
        ```
        examples/chat-socketio-hanaxs/db/hdi_grant.sh
        ```
    
* Start application router
    ```
    cd examples/chat-socketio-hanaxs/web
    npm install
    npm start
    ```
    
* Start Node.js server
    ```
    cd examples/chat-socketio-hanaxs/js
    npm install
    node index_ws
    ```
    
* Open URL
    ```
    http://localhost:5000/index_ws.html
    ```

#### WS (standalone) 

* Prerequisite (like above)

* Start Node.js server
    ```
    cd examples/chat-socketio-hanaxs/js
    npm install
    node index_standalone_ws
    ```

* Open URL
    ```
    http://localhost:3000
    ```

## SQLite

### [Simple Todo persistence with REST services (SQLite3)](todo-express-sqlite)

* Start Node.js server
    ```
    cd examples/todo-express-sqlite
    npm install
    npm start
    ``` 
    
* Get Metadata: 
    ```
    GET http://localhost:3000/todo/rest/metadata/todo/rest/Todo
    ```
    
* Create Todo Item: 
    ```
    POST http://localhost:3000/todo/rest/Todo
    {
        "ID" : -1,
        "TEXT" : "My Todo!"
    }
    ```
    
* Retrieve Todo Item: 
    ```
    GET http://localhost:3000/todo/rest/Todo/<ID>
    ```

## PostgreSQL

### [Simple Todo persistence with REST services (PostgeSQL)](todo-express-postgres)

* Start Node.js server
    ```
    cd examples/todo-express-postgres
    npm install
    npm start
    ``` 
    
* Get Metadata: 
    ```
    GET http://localhost:3000/todo/rest/metadata/todo/rest/Todo
    ```
    
* Create Todo Item: 
    ```
    POST http://localhost:3000/todo/rest/Todo
    {
        "ID" : -1,
        "TEXT" : "My Todo!"
    }
    ```
    
* Retrieve Todo Item: 
    ```
    GET http://localhost:3000/todo/rest/Todo/<ID>
    ```