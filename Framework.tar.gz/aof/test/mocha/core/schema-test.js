"use strict";

var expect = require("chai").expect;
var sinon = require("sinon");

var Promise = require("bluebird");
Promise.longStackTraces();

var schema = require("../../../lib/core/schema");
var auth = require("../../../lib/lib/authorization");
var check = require("../../../lib/lib/check");
var determine = require("../../../lib/lib/determination");

describe("core-schema", () => {

    var fnOnCreate = () => {
    };
    var fnOnUpdate = () => {
    };
    var fnOnModify = () => {
    };
    var fnCheckRoot = () => {
    };
    var fnCheckNode1 = () => {
    };
    var fnCheckNode2 = () => {
    };
    var fnCheckNode21 = () => {
    };
    var fnCheckAttr = () => {
    };

    var oObjectDefinition = {};

    beforeEach(() => {
        oObjectDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                determinations: {
                    onCreate: [fnOnCreate],
                    onUpdate: [fnOnUpdate],
                    onModify: [fnOnModify]
                },
                consistencyChecks: [fnCheckRoot],
                inputChecks: [fnCheckRoot],
                attributes: {
                    TITLE: {
                        consistencyChecks: [fnCheckAttr],
                        inputChecks: [fnCheckAttr]
                    }
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        sequence: "sap.aof.test.db.test::s_test_node_1",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnCheckNode1],
                        inputChecks: [fnCheckNode1]
                    },
                    Node2: {
                        table: "sap.aof.test.db.test::t_test_node_2",
                        sequence: "sap.aof.test.db.test::s_test_node_2",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnCheckNode2],
                        inputChecks: [fnCheckNode2],
                        nodes: {
                            Node21: {
                                table: "sap.aof.test.db.test::t_test_node_2_1",
                                sequence: "sap.aof.test.db.test::s_test_node_2_1",
                                parentKey: "PARENT_ID",
                                consistencyChecks: [fnCheckNode21],
                                inputChecks: [fnCheckNode21],
                                attributes: {
                                    SOMETEXT: {
                                        consistencyChecks: [fnCheckAttr],
                                        inputChecks: [fnCheckAttr],
                                        required: true
                                    }
                                }
                            }
                        }
                    },
                    Node3: {
                        table: "sap.aof.test.db.test::t_test_node_3",
                        sequence: "sap.aof.test.db.test::s_test_node_3",
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "AOF_TYPE"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "AOF_SUB_TYPE",
                                readOnly: true
                            }
                        }
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    }
                },
                update: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    }
                },
                del: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    }
                },
                read: {
                    authorizationCheck: () => {
                    }
                },
                customAction: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    },
                    execute: () => {
                    }
                }
            }
        };
    });

    it("validates correct application object using schema definition: test definition", () => {
        var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
        expect(aMessage).to.eql([]);
    });

    it("validates correct application object using schema definition: comment", () => {

        function createOwner(vKey, oWorkObject, oPersistedObject, fnMessage, fnNextHandle, oContext) {
        }

        var oCommentDefinition = {
            actions: {
                create: {
                    authorizationCheck: auth.parentInstanceAccessCheck(
                        "sap.ino.db.idea::v_auth_comment_create_x_username", "IDEA_ID", "IDENTITY_ID",
                        "IDEA_ID", "MSG_AUTH_MISSING_COMMENT_CREATE"),
                    historyEvent: "COMMENT_CREATED"
                },
                update: {
                    authorizationCheck: auth.instanceAccessCheck("sap.ino.db.idea::v_auth_comment_update",
                        "COMMENT_ID", "MSG_AUTH_MISSING_COMMENT_UPDATE"),
                    historyEvent: "COMMENT_UPDATED"
                },
                del: {
                    authorizationCheck: auth.instanceAccessCheck("sap.ino.db.idea::v_auth_comment_delete",
                        "COMMENT_ID", "MSG_AUTH_MISSING_COMMENT_DELETE"),
                    historyEvent: "COMMENT_DELETED"
                },
                read: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: "sap.ino.db.idea::t_comment",
                historyTable: "sap.ino.db.idea::t_comment_h",
                sequence: "sap.ino.db.idea::s_comment",
                determinations: {
                    onCreate: [createOwner],
                    onModify: [determine.systemAdminData]
                },
                nodes: {
                    Owner: {
                        table: "sap.ino.db.iam::t_object_identity_role",
                        historyTable: "sap.ino.db.iam::t_object_identity_role_h",
                        sequence: "sap.ino.db.iam::s_object_identity_role",
                        parentKey: "OBJECT_ID",
                        readOnly: true,
                        consistencyChecks: [check.duplicateCheck("IDENTITY_ID", "MSG_DUPLICATE_IDENTITY")],
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "COMMENT"
                            },
                            ROLE_CODE: {
                                constantKey: "COMMENT_OWNER"
                            },
                            IDENTITY: {
                                foreignKeyTo: "sap.ino.xs.object.iam.Identity.Root"
                            }
                        }
                    }
                },
                attributes: {
                    IDEA_ID: {
                        foreignKeyTo: "sap.ino.xs.idea.Idea"
                    },
                    CREATED_AT: {
                        readOnly: true
                    },
                    CREATED_BY: {
                        readOnly: true
                    },
                    CHANGED_AT: {
                        readOnly: true
                    },
                    CHANGED_BY: {
                        readOnly: true
                    }
                }
            }
        };

        var aMessage = schema.validateMetadataDefinition(oCommentDefinition);
        expect(aMessage).to.eql([]);
    });

    it("validates incorrect application object using schema definition: missing actions",
        () => {
            var oObjectDefinition = {
                actions: {
                    read: {}
                }
            };
            var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
            expect(aMessage)
                .to.eql(
                ['Schema property "Root" is missing in definition "{"actions":{"read":{}}}"', 'Schema property "authorizationCheck" is missing in property "read" with definition "{}"']);
        });

    it("validates incorrect application object using schema definition: wrong action", () => {
        var oObjectDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test"
            },
            actions: {
                read: {}
            }
        };
        var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
        expect(aMessage).to.eql(
            ['Schema property "authorizationCheck" is missing in property "read" with definition "{}"']);
    });

    it("validates incorrect application object using schema definition: wrong custom action",
        () => {
            var oObjectDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    sequence: "sap.aof.test.db.test::s_test"
                },
                actions: {
                    create: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    update: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    del: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    read: {
                        authorizationCheck: () => {
                        }
                    },
                    customAction: {}
                }
            };
            var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
            expect(aMessage)
                .to.eql(
                [
                    'Schema property "authorizationCheck" is missing in property "customAction" with definition "{}"',
                    'Schema property "execute" is missing in property "customAction" with definition "{}"']);
        });

    it("validates incorrect application object using schema definition: missing parent key",
        () => {
            var oObjectDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    sequence: "sap.aof.test.db.test::s_test",
                    nodes: {
                        Node1: {
                            table: "sap.aof.test.db.test::t_test_node_1",
                            sequence: "sap.aof.test.db.test::s_test_node_1"
                        }
                    }
                },
                actions: {
                    create: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    update: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    del: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    read: {
                        authorizationCheck: () => {
                        }
                    }
                }
            };
            var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
            expect(aMessage)
                .to.eql(
                ['Schema property "parentKey" is missing in property "Node1" with definition "{"table":"sap.aof.test.db.test::t_test_node_1","sequence":"sap.aof.test.db.test::s_test_node_1"}"']);
        });

    it("validates incorrect application object using schema definition: wrong type", () => {
        var oObjectDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                attributes: {
                    TITLE: {
                        consistencyChecks: true
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    }
                },
                update: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    }
                },
                del: {
                    authorizationCheck: () => {
                    },
                    enabledCheck: () => {
                    }
                },
                read: {
                    authorizationCheck: () => {
                    }
                }
            }
        };
        var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
        expect(aMessage).to.eql(
            ['Property "consistencyChecks" with definition "true" is not Array of Function']);
    });

    it(
        "validates incorrect application object using schema definition: properties protected",
        () => {
            var oObjectDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    sequence: "sap.aof.test.db.test::s_test"
                },
                actions: {
                    create: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    update: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    del: {
                        authorizationCheck: () => {
                        },
                        enabledCheck: () => {
                        }
                    },
                    read: {
                        authorizationCheck: () => {
                        }
                    },
                    properties: {}
                }
            };
            var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
            expect(aMessage)
                .to.eql(
                ['Property "properties" of property "actions" with definition "{"create":{},"update":{},"del":{},"read":{},"properties":{}}" is not allowed according to schema']);
        });

    it("validates extension properties", () => {
        var oObjectDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                explicitAttributeDefinition: true
            },
            actions: {},
            isExtensible: true
        };
        var aMessage = schema.validateMetadataDefinition(oObjectDefinition);
        expect(aMessage).to.eql([]);
    });

    it("validates correct extension application object using extension schema definition: comment", () => {

        function createOwner(vKey, oWorkObject, oPersistedObject, fnMessage, fnNextHandle, oContext) {
        }

        var oCommentDefinition = {
            actions: {
                create: {
                    enabledCheck: () => {
                    }
                },
                update: {
                    enabledCheck: () => {
                    }
                },
                del: {
                    enabledCheck: () => {
                    }
                },
                read: {
                    enabledCheck: () => {
                    }
                }
            },
            Root: {
                determinations: {
                    onCreate: [createOwner],
                    onModify: [determine.systemAdminData]
                },
                nodes: {},
                attributes: {
                    IDEA_ID: {
                        foreignKeyTo: "sap.ino.xs.idea.Idea"
                    },
                    CREATED_AT: {
                        readOnly: true,
                        required: true
                    },
                    CREATED_BY: {
                        readOnly: true
                    },
                    CHANGED_AT: {
                        readOnly: true
                    },
                    CHANGED_BY: {
                        readOnly: true
                    }
                }
            }
        };

        var aMessage = schema.validateExtensionMetadataDefinition(oCommentDefinition);
        expect(aMessage).to.eql([]);
    });

    it("validates test application object definitions", () => {
        expect(schema.validateMetadataDefinition(require("../../object/TestAO"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOAK"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOCKA"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOConcurrency"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOEK"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOExports").default)).to.eql([]);
        expect(schema.validateExtensionMetadataDefinition(require("../../object/TestAOExt"))).to.eql([]);
        expect(schema.validateExtensionMetadataDefinition(require("../../object/TestAOExt2"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOFK"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOJSON"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOM"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOName"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOROAction"))).to.eql([]);
        expect(schema.validateMetadataDefinition(require("../../object/TestAOUUID"))).to.eql([]);
    });
});
