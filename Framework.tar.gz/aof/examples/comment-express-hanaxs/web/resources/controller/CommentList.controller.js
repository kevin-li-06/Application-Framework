sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/aof/test/model/Comment",
    "sap/aof/ApplicationObjectChange",
    "sap/aof/ModelSynchronizer"
], function (Controller, Comment, ApplicationObjectChange, ModelSynchronizer) {
    "use strict";

    return Controller.extend("sap.ui.aof.test.controller.CommentList", {

        onInit: function () {
            var that = this;
            ApplicationObjectChange.attachChange(ApplicationObjectChange.Action.Del, function () {
                that.refresh();
            });
            ApplicationObjectChange.attachChange(ApplicationObjectChange.Action.Create, function () {
                that.refresh();
            });
        },

        refresh: function () {
            this.getView().byId("commentList").getBinding("items").refresh();
        },

        onPress: function (oEvent) {
            var oItem = oEvent.getSource();
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.navTo("detail", {
                id: oItem.getBindingContext("comment").getObject().ID
            });
        },

        onDetailPress: function (oEvent) {
            var oComponent = this.getOwnerComponent();

            var oItem = oEvent.getSource();
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            var iCommentId = oItem.getBindingContext("comment").getObject().ID;

            var oComment = new Comment(iCommentId, {
                actions : ["update"],
                nodes : ["Root"],
                continuousUse : true,
                concurrencyEnabled : true
            });

            var oCommentDialog = this.getOwnerComponent().commentDialog;
            oCommentDialog.setModel(oComment, "instance");
            oCommentDialog.open(this.getView(), function () {
                oComment.save();
            });
        },

        onDelete: function (oEvent) {
            var oItem = oEvent.getParameter("listItem");
            var iCommentId = oItem.getBindingContext("comment").getObject().ID;
            Comment.del(iCommentId);
        }
    });
});