#!/usr/bin/env bash

export HDI__HOST=inno-next.mo.sap.corp
export HDI__PORT=30015
export HDI___SYS_DI__USER=SYSTEM
export HDI___SYS_DI__PASSWORD=Toor1234

export HDI__SAP_APP_TODO__USER=DEPLOYMENT_USER
export HDI__SAP_APP_TODO__PASSWORD=Test1234

hdi delete -r SAP_APP_TODO src/
hdi write -r SAP_APP_TODO src/
hdi make SAP_APP_TODO @ src/