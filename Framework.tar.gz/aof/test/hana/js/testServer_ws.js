"use strict";

var http = require("http");
var express = require("express");
var ws = require("ws");
var aof = require("../../../");

var PORT = process.env.PORT || 3000;
var oOptions = require("./default-services.json").hana;

var app = express();
var server = http.Server(app);
var WebSocketServer = ws.Server;
var wss = new WebSocketServer({server: server});

aof.middleware(app, {
    applicationObjects: {
        "test.object.TestAO": "/test/object/TestAO"
    },
    extensions: {
        websocket: {
            name: "ws",
            lib: wss
        }
    }
}, {hana: oOptions});

/*server.listen(PORT, function () {
 console.log("Test server running on http://localhost:" + PORT);
 });*/

process.on('unhandledRejection', r => console.log(r));

module.exports = server;