"use strict";

module.exports.TEST_MESSAGE = "MSG_TEST_MESSAGE";