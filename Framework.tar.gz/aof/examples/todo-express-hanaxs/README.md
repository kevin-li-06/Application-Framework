AOF Example "TODO"
==================

The **TODO** application demonstrates major parts of the **Application Object Framework's (AOF)** functionality.
The example is based on the new **XS Advanced for HANA** technology stack.

[GitHub (xs2/aof)](https://github.wdf.sap.corp/xs2/aof)

General Structure
=================

- **Data Modeling** (package "db"):
    - Persistence modeling based on **HANA CDS views** for the Application Objects using **HDI** 

- **Object Modeling** (package "js"):
    - Modeling of applications objects and dependent nodes
    - Implementation of business logic and demonstration of Application Object interactions 
    - Application Objects:
        - **Todo**: 
            - Represents the data model for a single todo
            - Contains items which can have tag assignments 
            - Contains identity assignments to express owner and sharing information
        - **Tag**:
            - Represents the data model for a single tag
            - Contains identity assignments to express owner information
        - **Identity:**
            - Represents the data model for a single identity (user or group)
        - **User:**
            - Represents the read-only data model for the user login
    - Dependent Nodes:
        - **TagAssign**: 
            - Represents a re-use node to model a tag assignment based on a constant key constraint
            - Expresses, which tag is assigned to which object
        - **ObjectIdentityRole**:
            - Represents a re-use node to model a sharing assignment based on a constant key constraint
            - Expresses, which user has which role for which object 

- **User Interface** (package "web"):
    - UI5 code for user interface implementation based on Fiori concepts 

Covered AOF Features
====================

- **Deep node hierarchy**: 
    - AOF allows the modeling of deep-structures hierarchies
    - The example object "Todo" consists of the nested nodes "Root", "Items" and "Tags".
- **Dependent nodes**:
    - Dependent nodes, as listed above, are included into a host object using the concept of **Constant Keys** 
    - Host dependent object attributes are defaulted automatically during read and write operations with the constant key definitions 
- **Recursive Usage**:
    - The implementation of dependent node "TagAssign" recursively instantiates an instance of an AOF framework runtime for Application Object "Tag" 
    - This is used to realize an on-the-fly object instance creation of Tags during Tag assignments out of the Todo implementation
    - All changes to Application Objects live in the same transactional closure and are committed or rolled back together
- **Static Actions**:
    - The Application Object "User" offers the static action "login", to enable the on-the-fly creation of an identity based on the authentication information in the database
    - Furthermore it returns the user information back as action result, to be evaluated on the UI
- **Reuse Checks and Determinations**:
    - Re-use determination to fill the administrative data and re-use checks to validate data, like duplicates are used all across the example 
- **Backend Messages**:
    - Best practices of handling of backend messages are demonstrated in the Application Objects 
- **Transient Attributes**:
    - Reading Application Object nodes is based in some cases on a database view, that allows to include additional transient data, not coming from the primary node persistence table
- **Authentication**:
    - Authentication is demonstrated using the AppRouter module, validating against an UAA
    - Static action "login" of Application Object "User" demonstrates the access to JWT information to create an identity on-the-fly during login
- **Instance Authorization**:
    - Single "Todo" instances are protected by authorization checks on the CRUD operations
- **Object History**:
    - Each Application Object change is automatically replicated into a history table, which can be used to retrieve the exact change for a specific timepoint  
- **Business Logic**:
    - The object "Todo" shows how to register business logic callbacks (determinations), to handle "IsDone" propagation
    - Properties are calculated based on authorization and enabled checks
- **RESTful Services**:
    - The main Application Objects are exposed via the AOF express middleware as RESTFul (CRUD) services 
    - The services are used to read object instances and to retrieve static metadata and dynamic and static properties
- **OData Extension**:
    - The main Application Objects are exposed via XSOData as OData V2 (Read) services
- **Deep Fuzzy Search**: 
    - The OData protocol is extended by a deep fuzzy search implementation, to search for text-like strings in Todo, Todo Items and Tags
    - The user interface offers a search bar on top of the Todo list, which can therefore be used to search for Tags
- **Named Filters**:
    - The OData protocol is extended to support named filters searches (e.g. all Todos that are done more than 50% based on Todo item information). 
- **SAP UI5 AOF Lib**:
    - AOF offers a client side library UI5 library, that handles the interaction between user-interface and backend implementation under the hood.
    - The AOF UI5 library allows to model the backend Application Objects as bindable UI5 JSON models
    - Data of object "Todo" is transformed during read and write to fit to UI controls requirements  
- **Component and UI Base Controller**:
    - The example show-cases the introduction of a base controller, taking care of generic functionality while showing best practices on object model handling
    - The example component describes a basic component setup, especially handling the user login
- **Continuous edit**:
    - The library implementation takes care of all CRUD operations.
    - It automatically syncs the model after saving of changes, and in that way allows a continuous editing on a live object model
- **Concurrent edit**:
    - Furthermore the UI5 library detects concurrent changes, in case the Application Object has a attribute marked as **concurrencyControl**
    - In conflict cases it offers the possibility to automatically merge concurrent changes with the local changes 
- **Data Loss Handling**:
    - The Application Object UI model for a single object instance automatically tracks changes and detects, if pending changes exist
    - Binding change detection mechanism is used to dynamically control the save buttons properties.
- **Metadata Binding**:
    - Editable controls are bound to the static metadata of an Application Object, such as **maxLength** and **required**
- **Property Binding**:
    - Buttons and input fields are bound to the Application Object's dynamic properties, automatically handling the enabled and visibility properties based on the object's state or the user's authorizations
- **Model Synchronization**:
    - A list of Application Object instances are queried via an OData model, where single instances are modified by the Application Object JSON model
    - The **Model Synchronizer** automatically syncs all the models, that hold data from the same object instance, at the time of change  
- **Message Handling**:
    - Backend messages are automatically handled by the Application Object UI Model and propagated to the MessageParser, to be displayed on the UI bound to the messages model
- **Internationalization**:
    - Backend message keys and parameters are converted automatically into translatable text using the **i18n** concept of UI5 by the Application Object UI model
- **Web Sockets**:
    - The web sockets technology is used to leverage real-time change detection and synchronization on Application Object "Todo", between users sharing same instances 
- **Complex Application**:
    - "TODO" is a full-fledged responsive application allowing to maintain and to work on Todo items, that can also be shared with other users

Application Start
=================

    // Prerequisite (already prepared):
        // Create HDI Container 'SAP_AOF_EXAMPLE_TODO'
        examples/todo-express-hanaxs/db/hdi_container.sh
         
        // Deploy DB src in HDI Container 'SAP_AOF_EXAMPLE_TODO'
        examples/todo-express-hanaxs/db/hdi_sync.sh
           
        // Create user 'SAP_AOF_EXAMPLE_TODO_USER' with password 'Test1234'
        create user SAP_AOF_EXAMPLE_TODO_USER password Test1234;
        alter user SAP_AOF_EXAMPLE_TODO_USER disable password lifetime;
        grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_AOF_EXAMPLE_TODO_USER;
        grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_AOF_EXAMPLE_TODO_USER;

        // Grant schema privileges in HDI Container 'SAP_AOF_EXAMPLE_TODO'
        examples/todo-express-hanaxs/db/hdi_grant.sh
    
    // Start application router
    cd examples/todo-express-hanaxs/web
    npm start
    
    // Start Node.js server
    cd examples/todo-express-hanaxs/js
    npm start
    
    // Open URL
    http://localhost:5000