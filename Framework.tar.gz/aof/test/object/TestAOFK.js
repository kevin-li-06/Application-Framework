"use strict";

module.exports = {
    isExtensible: true,
    actions: {
        create: {
            authorizationCheck: false
        },
        copy: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test_node_3",
        sequence: "sap.aof.test.db.test::s_test_node_3",
        attributes: {
            OBJECT_ID: {
                foreignKeyTo: "test.object.TestAO.Root"
            }
        }
    }
};