"use strict";

/**
 * Central entry point into Application Object Framework Node.js module.<br>
 * Can be used as default AOF framework instance, or instantiated by calling it as function to create
 * a new framework instance (3rd example).
 *
 * @example
 * var aof = require("@sap/aof");
 *
 * aof.middleware(app, {
 *   metadata: "/rest/metadata",
 *   applicationObjects: {
 *     "object.Test": "/rest/object/Test"
 *   }
 * }, oStoreInfo);
 * @example
 * var aof = require("@sap/aof");
 *
 * aof.getApplicationObject("object.Test", oCallerContext).then(function (Object) {
 * });
 * @example
 * // Instantiate new AOF framework instance from the default instance
 * var AOF = require("@sap/aof");
 * var aof1 = AOF();
 * aof1.getApplicationObject("object.Test", oCallerContext).then(function (Object) {
 * });
 * var aof2 = AOF();
 * aof2.getApplicationObject("object.Test", oCallerContext).then(function (Object) {
 * });
 * @namespace AOF
 */
function AOF() {
}

/**
 * Returns the Application Object Framework middleware function, to be used to dispatch Express requests to framework implementation
 * @param oApp {Object} Express app
 * @param [oOptions] {Object} Application Object Framework options
 * @param [oOptions.metadata] {String} Metadata URL for all registered Application Objects
 * @param [oOptions.odata] {String} OData URL for all registered Application Objects (if OData extension is used)
 * @param [oOptions.applicationObjects] {Object} Application Object registration by key/value pairs (Application Object Name -> URL path)
 * @param [oOptions.urlPath] {String} URL Path prefix for express routes
 * @param [oOptions.rootPath] {String} Root path for Application Object module loading
 * @param [oOptions.extensionRootPath] {String} Extension root path for Extension Application Object module loading
 * @param [oOptions.autoRegister] {boolean} Auto registration of specified Application Objects in Application Object Framework
 * @param [oOptions.preload] {boolean} Should the Application Objects be pre-loaded at start (default is 'true'). Application Object definitions are validated at start.
 * @param [oOptions.schemaScope] {Schema.SchemaScope} Schema Scope to validate object definition against schema
 * @param [oOptions.disableModuleLoad] {boolean} Disables dynamical load of modules by Application Object Name or Path
 * @param [oOptions.disableExtensions] {boolean} Disables all extensions for the complete Application Object Framework
 * @param [oOptions.extensions] {Object} Middleware extension options
 * @param [oOptions.extensions.cds] {Object} Middleware CDS extension options
 * @param [oOptions.extensions.cds.name] {Object} CDS extension plugin name
 * @param [oOptions.extensions.cds.lib] {Object} CDS library
 * @param [oOptions.extensions.cds.startPath] {String} Explicit start path configuration, if different from project root
 * @param [oOptions.extensions.cds.disableEnrichMetadata] {boolean} Disable enrichment of AOF metadata from CDS metadata
 * @param [oOptions.extensions.cds.services] {Object} CDS Services Registration
 * @param [oOptions.extensions.cds.services.__any__] {String} CDS Service Route mapping to CDS service file (e.g. "/catalog": "./srv/cat-service")
 * @param [oOptions.extensions.odata] {Object} Middleware OData extension options
 * @param [oOptions.extensions.odata.name] {Object} OData extension plugin name
 * @param [oOptions.extensions.odata.lib] {Object} OData library
 * @param [oOptions.extensions.odata.startPath] {String} Explicit start path configuration, if different from project root
 * @param [oOptions.extensions.odata.endpoint] {Object} OData URL for all registered Application Objects (library specific alternative to oOptions.odata)
 * @param [oOptions.extensions.odata.dbAdapter] {Adapter} OData DB Adapter
 * @param [oOptions.extensions.odata.parameters] {Object} OData extension parameters
 * @param [oOptions.extensions.odata.parameters.limitResult] {Number} Reduce OData result to maximum number
 * @param [oOptions.extensions.odata.parameters.useNameAsNamespace] {boolean} Use Application Object name path as namespace
 * @param [oOptions.extensions.odata.parameters.useObjectAsRootName] {boolean} Use Application Object name last part as Root name
 * @param [oOptions.extensions.odata.parameters.search] {Object} OData search options
 * @param [oOptions.extensions.odata.parameters.search.name] {String} OData URL search attribute
 * @param [oOptions.extensions.odata.parameters.search.fuzzy] {Number} OData fuzzy search score (between 0.0 and 1.0 for most fuzzy to least fuzzy) or EXACT
 * @param [oOptions.extensions.odata.parameters.views] {Object} OData view definitions
 * @param [oOptions.extensions.odata.parameters.views._any_] {String} OData view definition for Application Object Node
 * @param [oOptions.extensions.odata.parameters.filters] {Object} OData filters definitions
 * @param [oOptions.extensions.odata.parameters.filters.filterName] {Object} OData named filters definitions
 * @param [oOptions.extensions.odata.parameters.filters.filterName._any_] {Object} OData filter definition (_any_ can be an arbitrary name)
 * @param [oOptions.extensions.odata.parameters.filters.filterName._any_.condition] {String} OData filter condition string, e.g. HANA view containing a "key" column
 * @param [oOptions.extensions.odata.parameters.filters.filterName._any_.nodes] {Array} Array of full qualified node names, the OData filter is applied to
 * @param [oOptions.extensions.odata.parameters.filters._any_] {Object} OData name/value filters definitions (_any_ can be an arbitrary name)
 * @param [oOptions.extensions.odata.parameters.filters._any_.condition] {String} OData filter condition string, e.g. HANA view containing a "key" and "value" column
 * @param [oOptions.extensions.odata.parameters.filters._any_.nodes] {Array} Array of full qualified node names, the OData filter is applied to
 * @param [oOptions.extensions.odata.parameters.filters._any_.compare] {String} Compare operator for value comparison. One of: "=", "!=", "<", ">", "<=", ">=", "like", "not like" or for multi-value filters: "in", "not in"
 * @param [oOptions.extensions.odata.parameters.filters._any_.match] {String} Match operator for multi-value comparison. One of: "any" or "all"
 * @param [oOptions.extensions.odata.parameters.filters._any_.fuzzy] {Number} OData fuzzy search score (between 0.0 and 1.0 for most fuzzy to least fuzzy) or EXACT
 * @param [oOptions.extensions.websocket] {Object} WebSocket extension extension options
 * @param [oOptions.extensions.websocket.name] {Object} WebSocket extension plugin name
 * @param [oOptions.extensions.websocket.lib] {Object} WebSocket library
 * @param [oOptions.extensions.websocket.checkAuth] {Object} Check instance authorization for application object instances
 * @param [oOptions.extensions.websocket.checkAuthDelete] {Object} Check instance authorization for deleted application object instances. One of "none", "key", "all"
 * @param [oOptions.extensions.websocket.middleware] {Array} Array of Express middleware instances to be applied to each web-socket request
 * @param [vStoreInfo] {(Object|String)} Store configuration object or store name (default is "hana")
 * @param [vStoreInfo._store_] {Object} Store configuration object (_store_ is the store name, e.g. "hana")
 * @param [vStoreInfo._store_.db] {Object} Database object including the configuration
 * @returns {Function}
 */
AOF.prototype.middleware = function (oApp, oOptions, vStoreInfo) {
    return function () {
    };
};

/**
 * @typedef EventTime
 * @property {String} BeforeCommit "BeforeCommit"
 * @property {String} AfterCommit "AfterCommit"
 */

/**
 * Enumeration for supported event time points
 * @enum {String}
 */
AOF.prototype.EventTime = {
    /**
     * BeforeCommit
     */
    BeforeCommit: "BeforeCommit",
    /**
     * AfterCommit
     */
    AfterCommit: "AfterCommit",
};

/**
 * @typedef ObjectType
 * @property {String} Standard "Standard"
 * @property {String} Configuration "Configuration"
 * @property {String} Stage "Stage"
 * @property {String} SystemConfiguration "SystemConfiguration"
 */

/**
 * Enumeration for supported Application Object types
 * @enum {String}
 */
AOF.prototype.ObjectType = {
    /**
     * Standard
     */
    Standard: "Standard",
    /**
     * Configuration
     */
    Configuration: "Configuration",
    /**
     * Stage
     */
    Stage: "Stage",
    /**
     * SystemConfiguration
     */
    SystemConfiguration: "SystemConfiguration"
};

/**
 * @typedef DataType
 * @property {String} Integer "Integer"
 * @property {String} Float "Float"
 * @property {String} String "String"
 * @property {String} Boolean "Boolean"
 * @property {String} Date "Date"
 * @property {String} Time "Time"
 * @property {String} DateTime "DateTime"
 * @property {String} Binary "Binary"
 * @property {String} JSON "JSON"
 * @property {String} UUID "UUID"
 * @property {String} Interval "Interval"
 * @property {String} Other "Other"
 */

/**
 * Enumeration for supported Application Object data types
 * @enum {String}
 */
AOF.prototype.DataType = {
    /**
     * Integer
     */
    Integer: "Integer",
    /**
     * Float
     */
    Float: "Float",
    /**
     * String
     */
    String: "String",
    /**
     * Boolean
     */
    Boolean: "Boolean",
    /**
     * Date
     */
    Date: "Date",
    /**
     * Time
     */
    Time: "Time",
    /**
     * DateTime
     */
    DateTime: "DateTime",
    /**
     * Binary
     */
    Binary: "Binary",
    /**
     * JSON
     */
    JSON: "JSON",
    /**
     * UUID
     */
    UUID: "UUID",
    /**
     * Interval
     */
    Interval: "Interval",
    /**
     * Other
     */
    Other: "Other"
};

/**
 * Enumeration for reserved Application Object Node names
 * @enum {String}
 */
AOF.prototype.Node = {
    /**
     * Root node name
     */
    Root: "Root"
};

/**
 * @typedef Action
 * @property {String} Create "create"
 * @property {String} Update "update"
 * @property {String} Del "del"
 * @property {String} Copy "copy"
 * @property {String} Exists "exists"
 * @property {String} ConvertKey "convertKey"
 * @property {String} Read "read"
 */

/**
 * Enumeration for reserved Application Object Action names
 * @enum {String}
 */

AOF.prototype.Action = {
    /**
     * Create action name
     */
    Create: "create",
    /**
     * Update action name
     */
    Update: "update",
    /**
     * Delete action name
     */
    Del: "del",
    /**
     * Copy action name
     */
    Copy: "copy",
    /**
     * Exists action name
     */
    Exists: "exists",
    /**
     * ConvertKey action name
     */
    ConvertKey: "convertKey",
    /**
     * Read action name
     */
    Read: "read",
    /**
     * CalculateConcurrencyToken action name
     */
    CalculateConcurrencyToken: "calculateConcurrencyToken",
    /**
     * Properties action name
     */
    Properties: "properties",
    /**
     * StaticProperties action name
     */
    StaticProperties: "staticProperties"
};

/**
 * @typedef MessageSeverity
 * @property {number} Fatal 1
 * @property {number} Error 2
 * @property {number} Warning 3
 * @property {number} Info 4
 * @property {number} Debug 5
 * @property {number} Success 6
 *
 */

/**
 * Enumeration for Message Severity
 * @enum {Number}
 */
AOF.prototype.MessageSeverity = {
    /**
     * 1: A fatal exception occurred. Processing is stop immediately
     */
    Fatal: 1,
    /**
     * 2: A error message occurred
     */
    Error: 2,
    /**
     * 3: A warning message occurred
     */
    Warning: 3,
    /**
     * 4: A info message occurred
     */
    Info: 4,
    /**
     * 5: A debug message occurred
     */
    Debug: 5,
    /**
     * 6: A success message occurred
     */
    Success: 6
};

/**
 * Core Messages of the Application Object runtime
 * @enum {String}
 */
AOF.prototype.CoreMessages = {
    /**
     * MSG_AOF_INVALID_FOREIGN_KEY
     */
    INVALID_FOREIGN_KEY: "MSG_AOF_INVALID_FOREIGN_KEY",
    /**
     * MSG_AOF_INVALID_BOOL_VALUE
     */
    INVALID_BOOL_VALUE: "MSG_AOF_INVALID_BOOL_VALUE",
    /**
     * MSG_AOF_INVALID_MIN_VALUE
     */
    INVALID_MIN_VALUE: "MSG_AOF_INVALID_MIN_VALUE",
    /**
     * MSG_AOF_INVALID_MAX_VALUE
     */
    INVALID_MAX_VALUE: "MSG_AOF_INVALID_MAX_VALUE",
    /**
     * MSG_AOF_INVALID_MAX_LENGTH
     */
    INVALID_MAX_LENGTH: "MSG_AOF_INVALID_MAX_LENGTH",
    /**
     * MSG_AOF_INVALID_OBJECT_TYPE
     */
    INVALID_OBJECT_TYPE: "MSG_AOF_INVALID_OBJECT_TYPE",
    /**
     * MSG_AOF_INVALID_OBJECT_REF
     */
    INVALID_OBJECT_REF: "MSG_AOF_INVALID_OBJECT_REF",
    /**
     * MSG_AOF_VALUE_NOT_A_NUMBER
     */
    NOT_A_VALID_NUMBER: "MSG_AOF_VALUE_NOT_A_NUMBER",
    /**
     * MSG_AOF_VALUE_NOT_A_STRING
     */
    NOT_A_VALID_STRING: "MSG_AOF_VALUE_NOT_A_STRING",
    /**
     * MSG_AOF_VALUE_NOT_A_DATE
     */
    NOT_A_VALID_DATE: "MSG_AOF_VALUE_NOT_A_DATE",
    /**
     * MSG_AOF_DUPLICATE_ALT_KEY
     */
    DUPLICATE_ALT_KEY: "MSG_AOF_DUPLICATE_ALT_KEY",
    /**
     * MSG_AOF_NODE_CARDINALITY_ONE_VIOLATION
     */
    NODE_CARDINALITY_ONE_VIOLATION: "MSG_AOF_NODE_CARDINALITY_ONE_VIOLATION"
};

/**
 *
 * @param vObject {String|Object} Name of the Application Object or Application Object definition module
 * @param oCallerContext {Object} Context object to provide additional runtime information (see above getApplicationObject)
 * @returns {Promise.<Metadata>} Promise resolving to the metadata object
 */
AOF.prototype.getMetadata = function (vObject, oCallerContext) {
    return Promise;
};

/**
 * Clear metadata cache for a single Application Object or clears complete cache if name is not provided
 * @param [sObjectName] {String} Name of the Application Object
 */
AOF.prototype.clearMetadataCache = function (sObjectName) {
};

/**
 * Returns an Application Object runtime object for the passed name
 * @param vObject {String|Object} Name of the Application Object or Application Object definition module
 * @param oCallerContext {Object} Context object to provide additional runtime information
 * @param [oCallerContext.db] {Object} Database object including the database configuration
 * @param [oCallerContext.forceCreateDB] {boolean} Force the creation of a new DB connection using store information
 * @param [oCallerContext.lazyCreateDB] {boolean} Lazyly create DB if not available on caller context
 * @param [oCallerContext.store] {Store} Store object holding DB connection
 * @param [oCallerContext.storeInfo] {(Object|String)} Store configuration object or store name
 * @param [oCallerContext.user] {Object} User information object
 * @param [oCallerContext.authInfo] {Object} Authorization information object
 * @param [oCallerContext.suppressNotifyEventListeners] {boolean} Suppress notification of event listeners in this caller context
 * @param [oCallerContext.headers] {Object} Request headers to derive e.g. the AOF Session UUID (x-aof-session-uuid)
 * @param [oCallerContext.requestTimestamp] {String} Request timestamp, valid for the current request (created lazily if undefined)
 * @param [oCallerContext.schemaScope] {Schema.SchemaScope} Schema Scope to validate object definition against schema
 * @param [bPrivilegedAuthMode] {boolean} Defines if runtime runs in privilege mode and thus performs not authorization checks
 * @returns {Promise.<ApplicationObject>} Promise resolving to the Application Object runtime object
 */
AOF.prototype.getApplicationObject = function (vObject, oCallerContext, bPrivilegedAuthMode) {
    return Promise;
};

/**
 * Adds an Application Object Extension for an Application Object at a specific layer index position
 * @param sObjectName {String} Name of the Application Object to be extended
 * @param vExtensionObject {String|Object} Name of the Extension Application Object or Extension Application Object definition
 * @param [iIndex] {Number} Layer index of the extension (lower indexed extensions are merged first). Extension is appended, if omitted
 */
AOF.prototype.setObjectExtension = function (sObjectName, vExtensionObject, iIndex) {
};

/**
 * Removes a defined Application Object Extension or all Application Object Extensions for an Application Object
 * @param sObjectName {String} Name of the Application Object to be extended
 * @param [vExtensionObject] {String|Object} Name of the Extension Application Object or Extension Application Object definition, to be removed. All extensions are removed for the specified Application Object, if omitted
 */
AOF.prototype.removeObjectExtension = function (sObjectName, vExtensionObject) {
};

/**
 * Disables all extensions for the complete Application Object Framework.
 * Needs to be called, before any Application Object metadata is retrieved.
 * @param bState {boolean} State of the disablement
 */
AOF.prototype.disableExtensions = function (bState) {
};

/**
 * Disables dynamical load of modules by Application Object Name or Path
 * Needs to be called, before any Application Object metadata is retrieved.
 * @param bState {boolean} State of the disablement
 */
AOF.prototype.disableModuleLoad = function (bState) {
};


/**
 * Message interface to create and add messages to the currently active message buffer
 * @type {Message}
 */
AOF.prototype.Message = {};

/**
 * Application Object Framework Schema and validation
 * @type {Schema}
 */
AOF.prototype.Schema = {};

/**
 * Authorization re-use library to be used for Application Object action authorizationCheck definitions
 * @type {Authorization}
 */
AOF.prototype.Authorization = {};

/**
 * Check re-use library to be used for Application Object consistency checks on node and attribute level
 * @type {Check}
 */
AOF.prototype.Check = {};

/**
 * Determination re-use library to be used as Application Object node determinations
 * @type {Determination}
 */
AOF.prototype.Determination = {};

/**
 * Store implementations
 * @type {Store}
 */
AOF.prototype.Store = {};

/**
 * Adapter implementations (e.g. OData DB adapter)
 * @type {Adapter}
 */
AOF.prototype.Adapter = {};

/**
 * Underscore.js access including AOF util mixins
 * @type {Object}
 */
AOF.prototype._ = {};

/**
 * Returns the exports of the application object module
 * @type {Object}
 */
AOF.prototype.exports = Object;

/**
 * This callback is called for each registered listener for an respective Application Object providing the event object
 * @callback AOF.listenerEvent
 * @param {Event} Event to be notified to registered listeners
 *
 */

/**
 * Attaches an listener to changes of the specified Application Object
 * @param fnListener {AOF.listenerEvent} Listener function to be called when changes occurs
 * @param [sObjectName] {String} Name of the Application Object (Pass "*" or null for all Application Objects)
 * @param [sEventTime] {EventTime} The point in time, the event is notified. Default is "AfterCommit"
 * @param [bBulk] {boolean} Events are received in bulk mode
 */
AOF.prototype.attachListener = function (fnListener, sObjectName, sEventTime, bBulk) {
};

/**
 * Detaches an listener from listening to changes of the specified Application Object
 * @param fnListener {AOF.listenerEvent} Listener function to be detached
 * @param [sObjectName] {String} Name of the Application Object (Pass "*" or null for all Application Objects)
 * @param [sEventTime] {EventTime} The point in time, the event is notified. Default is "AfterCommit"
 */
AOF.prototype.detachListener = function (fnListener, sObjectName, sEventTime) {
};

/**
 * Notify all register listeners about an Application Object Change event
 * @param vEvent {Event|Array.<Event>} Event or Array of Events (bulk listener mode) of the Application Object Change(s)
 * @param [sEventTime] {EventTime} The point in time, the event is notified. Default is "AfterCommit"
 */
AOF.prototype.notifyListeners = function (vEvent, sEventTime) {
};

/**
 * Get the root path for Application Object module loading
 * @returns {String} Root path for Application Object module loading
 */
AOF.prototype.getRootPath = function () {
};

/**
 * Set the root path for Application Object module loading
 * @param sNewRootPath {String} New root path for Application Object modules
 */
AOF.prototype.setRootPath = function (sNewRootPath) {
};

/**
 * Get the extension root path of Extension Application Object module loading
 * @returns {String} Extension root path for Extension Application Object module loading
 */
AOF.prototype.getExtensionRootPath = function () {
};

/**
 * Set the extension root path of Extension Application Object module loading
 * @param sNewExtensionRootPath {String} New extension root path for Extension Application Object modules
 */
AOF.prototype.setExtensionRootPath = function (sNewExtensionRootPath) {
};

/**
 * Register a specific module path or a Application Object definition module for an Application Object name
 * A metadata validation is performed, if a caller context with store or store info is provided (return value is then a promise)
 * @param [sObjectName] {String} Application Object name (if not provided name is derived from Application Object definition)
 * @param vObject {String|Object} Application Object module path or Application Object definition module
 * @param oCallerContext {Object} Context object to provide additional runtime information (see above getApplicationObject)
 * @returns {String|Promise<String>} Application Object name
 */
AOF.prototype.registerApplicationObject = function (sObjectName, vObject, oCallerContext) {
};

/**
 * Check if Application Object definition module or Application Object name is registered
 * @param vObject {String|Object} Name of the Application Object or Application Object definition module
 * @returns {boolean} Specified if Application Object is registered in framework
 */
AOF.prototype.isRegisteredApplicationObject = function (vObject) {
};