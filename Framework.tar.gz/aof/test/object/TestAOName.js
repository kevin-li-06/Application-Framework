"use strict";

module.exports = {
    name: "my.custom.name.TestAOName",
    actions: {
        create: {
            authorizationCheck: false,
        },
        del: {
            authorizationCheck: false,
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test"
    }
};
