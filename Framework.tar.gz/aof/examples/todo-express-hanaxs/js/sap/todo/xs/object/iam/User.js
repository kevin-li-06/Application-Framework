"use strict";

module.exports = {
    actions: {
        read: {
            authorizationCheck: false
        },
        login: {
            authorizationCheck: false,
            isStatic: true,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getApplicationObject("sap.todo.xs.object.iam.Identity").then(function (oIdentity) {
                    var oUserInfo = oContext.getUserInfo();
                    var sUserName = oUserInfo.id;
                    var sRealName = ((oUserInfo.name && oUserInfo.name.givenName || "") + " " + (oUserInfo.name && oUserInfo.name.familyName || "")).trim();
                    var sName = sRealName || sUserName;
                    var sEmail = (oUserInfo.emails && oUserInfo.emails.length > 0 && oUserInfo.emails[0].value) || sUserName;
                    return oIdentity.read(sUserName).then(function (oUser) {
                        if (!oUser) {
                            return oIdentity.create({
                                USER_NAME: sUserName,
                                NAME: sName,
                                EMAIL: sEmail
                            }).then(function (oResponse) {
                                addMessage(oResponse.messages);
                                return {
                                    "USER_NAME": sUserName,
                                    "NAME": sName
                                };
                            });
                        } else {
                            return oIdentity.update({
                                USER_NAME: sUserName,
                                NAME: sRealName || undefined,
                                EMAIL: sEmail || undefined
                            }).then(function (oResponse) {
                                addMessage(oResponse.messages);
                                return {
                                    "USER_NAME": oUser.USER_NAME,
                                    "NAME": oUser.NAME
                                };
                            });
                        }
                    });
                });
            }
        }
    },
    Root: {
        table: "sap.aof.example.db.iam::t_identity",
        readOnly: true
    }
};