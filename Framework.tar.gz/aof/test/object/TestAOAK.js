"use strict";

module.exports = {
    actions: {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test",
        attributes: {
            TITLE: {
                isAlternativeKey: true,
            }
        }
    }
};
