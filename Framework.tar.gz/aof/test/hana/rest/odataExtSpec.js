"use strict";

require("jasmine-before-all");

var supertestAsPromised = require("supertest");
var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");
var Server = require("../js/testServer.js");

var oRequest;

describe("SAP/AOF/ODATA", function () {

    beforeAll((done) => {
        oRequest = supertestAsPromised(Server);
        done();
    });

    afterAll((done) => {
        done();
    });

    function callWrite(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        oRequest = bUpdate ? oRequest.put(sPath) : oRequest.post(sPath);
        oRequest = oRequest.set("Content-Type", "application/json").send(oPayload);
        _.each(oHeaders || {}, (sValue, sKey) => {
            oRequest.set(sKey, sValue);
        });
        return oRequest;
    }

    function callRead(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        return oRequest.get(sPath).set("x-forwarded-host", "localhost:3000").then((oResponse) => {
            if (oResponse.status !== 200) {
                console.log(oResponse);
            }
            return oResponse;
        });
    }

    var iRefId;
    var iId;
    var iNode1Id;
    var iNode2Id;
    var iNode21_1Id;
    var iNode21_2Id;
    var iNode3;

    it("creates test entity instances with constant keys and auth", (done) => {
        callWrite(oRequest, "/test/object/TestAOCKA.js", {
            ID: -1,
            TITLE: "Test Title"
        }).then((oResponse) => {
            iRefId = oResponse.body.GENERATED_KEYS[-1];
            expect(iRefId).toBeDefined();
            return callWrite(oRequest, "/test/object/TestAOCKA.js", {
                "ID": -1,
                "TITLE": "OData Extension",
                "Node1": [{
                    "ID": -2
                }],
                "Node2": [{
                    "ID": -3,
                    "Node21": [{
                        "ID": -4
                    }, {
                        "ID": -5
                    }]
                }],
                "Node3": [{
                    "ID": -6,
                    "OBJECT_ID": iRefId
                }]
            });
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            iNode1Id = oResponse.body.GENERATED_KEYS[-2];
            expect(iNode1Id).toBeDefined();
            iNode2Id = oResponse.body.GENERATED_KEYS[-3];
            expect(iNode2Id).toBeDefined();
            iNode21_1Id = oResponse.body.GENERATED_KEYS[-4];
            expect(iNode21_1Id).toBeDefined();
            iNode21_2Id = oResponse.body.GENERATED_KEYS[-5];
            expect(iNode21_2Id).toBeDefined();
            iNode3 = oResponse.body.GENERATED_KEYS[-6];
            expect(iNode3).toBeDefined();
            return callRead(oRequest, "/test/object/TestAOCKA.js/" + iId).then((oResponse) => {
                expect(oResponse.statusCode).toBe(_.HTTP.OK);
                expect(oResponse.body).toEqual({
                    ID: iId,
                    TITLE: 'OData Extension (OnRead)',
                    DESCRIPTION: 'TEST_ROOT',
                    Node1: [{
                        ID: iNode1Id,
                        SOMETEXT: 'TEST_NODE1'
                    }],
                    Node2: [{
                        ID: iNode2Id,
                        SOMETEXT: 'TEST_NODE2',
                        Node21: [{
                            ID: iNode21_1Id,
                            SOMETEXT: 'TEST_NODE21_1',
                            ANOTHERONE: 'TEST_NODE21_2'
                        }, {
                            ID: iNode21_2Id,
                            SOMETEXT: 'TEST_NODE21_1',
                            ANOTHERONE: 'TEST_NODE21_2'
                        }]
                    }],
                    Node3: [{
                        ID: iNode3,
                        OBJECT_ID: iRefId,
                        SOMETEXT: 'TEST_NODE3'
                    }]
                });
            });
        }).then(function () {
            done();
        });
    });

    it("queries entity instances with constant keys and auth", (done) => {
        return callRead(oRequest, "/test/object/TestAOCKA.odata/Root(" + iId + ")?$format=json").then((oResponse) => {
            expect(oResponse.body.d).toEqual({
                __metadata: {
                    uri: 'http://localhost:3000/test/object/TestAOCKA.odata/Root(' + iId + ')',
                    type: 'test.object.testaocka.RootType'
                },
                ID: iId,
                TITLE: 'OData Extension (OnRead)',
                DESCRIPTION: 'TEST_ROOT',
                Node1: {__deferred: {uri: 'http://localhost:3000/test/object/TestAOCKA.odata/Root(' + iId + ')/Node1'}},
                Node2: {__deferred: {uri: 'http://localhost:3000/test/object/TestAOCKA.odata/Root(' + iId + ')/Node2'}},
                Node3: {__deferred: {uri: 'http://localhost:3000/test/object/TestAOCKA.odata/Root(' + iId + ')/Node3'}},
                Node3_OBJECT_ID: {__deferred: {uri: 'http://localhost:3000/test/object/TestAOCKA.odata/Root(' + iId + ')/Node3_OBJECT_ID'}}
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAOCKA.odata/Root(" + iId + ")?$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1"."ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iId,
                    "TEST_ROOT"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAOCKA.odata/Root(" + iId + ")/Node2?$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node22"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node22"."PARENT_ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iId,
                    "TEST_ROOT",
                    "TEST_NODE2"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAOCKA.odata/Root(" + iId + ")/Node2(" + iNode2Id + ")/Node21?$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node22"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node213"."ANOTHERONE" = ? and "Node213"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node213"."ID" in (select "_self"."ID" from "sap.aof.test.db.test::t_test_node_2_1" as "_self" inner join "sap.aof.test.db.test::t_test_node_2" as "_parent_0" on "_self"."PARENT_ID" = "_parent_0"."ID" inner join "sap.aof.test.db.test::t_test" as "_parent_1" on "_parent_0"."PARENT_ID" = "_parent_1"."ID" inner join "sap.aof.test.db.test::t_test" as "_auth" on "_auth"."ID" = "_parent_1"."ID"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iId,
                    "TEST_ROOT",
                    iNode2Id,
                    "TEST_NODE2",
                    "TEST_NODE21_2",
                    "TEST_NODE21_1"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAOCKA.odata/Root(" + iId + ")?$expand=Node2/Node21&$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(2);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.insertTmp[0].sql.indexOf('"Root1"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.insertTmp[0].sql.indexOf('"Root1"."ID" in (select "ID" from "sap.aof.test.db.test::t_test")') >= 0).toBe(true);
                expect(oResponse.body.SQL.insertTmp[0].parameters).toEqual([
                    iId,
                    "TEST_ROOT"
                ]);
                expect(oResponse.body.SQL.insertTmp[1].sql.indexOf('"Node22"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.insertTmp[1].parameters).toEqual([
                    "TEST_NODE2"
                ]);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node213"."ANOTHERONE" = ? and "Node213"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    "TEST_NODE21_2",
                    "TEST_NODE21_1"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/aof.odata/TestAOCKA_Node3(" + iNode3 + ")/TestAOCKA_Root?$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root2"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root2"."ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Node31"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Node31"."PARENT_ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iNode3,
                    "TEST_NODE3",
                    "TEST_ROOT"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/aof.odata/TestAOCKA_Node3(" + iNode3 + ")?&$expand=TestAOCKA_Root&$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(1);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.insertTmp[0].sql.indexOf('"TestAOCKA_Node31"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.insertTmp[0].sql.indexOf('"TestAOCKA_Node31"."PARENT_ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.insertTmp[0].parameters).toEqual([
                    iNode3,
                    "TEST_NODE3"
                ]);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root2"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root2"."ID" in (select "ID" from "sap.aof.test.db.test::t_test")') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    "TEST_ROOT"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/aof.odata/TestAOCKA_Node3(" + iNode3 + ")/TestAOCKA_Root/$count?sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root2"."DESCRIPTION" = ?') >= 0).toBe(true);
                // 'TestAOCKA_Root' is a FK-Node association (therefore a separate auth check)
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root2"."ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Node31"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Node31"."PARENT_ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iNode3,
                    "TEST_NODE3",
                    "TEST_ROOT"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/aof.odata/TestAOCKA_Root(" + iId + ")/Node3/$count?sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root1"."DESCRIPTION" = ?') >= 0).toBe(true);
                // 'Node3' is no FK-Node association (therefore no separate auth check)
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Root1"."ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(false);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Node32"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"TestAOCKA_Node32"."PARENT_ID" in (select "ID" from "sap.aof.test.db.test::t_test")') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iId,
                    "TEST_ROOT",
                    "TEST_NODE3"
                ]);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAOCKA.odata/Root(" + iId + ")/Node2?$inlinecount=allpages&$format=json&sap-ds-debug=json").then((oResponse) => {
                expect(oResponse.body.SQL).toBeDefined();
                expect(oResponse.body.SQL.insertTmp).toBeDefined();
                expect(oResponse.body.SQL.insertTmp.length).toBe(0);
                expect(oResponse.body.SQL.select).toBeDefined();
                expect(oResponse.body.SQL.select.length).toBe(1);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1"."DESCRIPTION" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node22"."SOMETEXT" = ?') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].sql.indexOf('"Node22"."PARENT_ID" in (select "ID" from "sap.aof.test.db.test::t_test"') >= 0).toBe(true);
                expect(oResponse.body.SQL.select[0].parameters).toEqual([
                    iId,
                    "TEST_ROOT",
                    "TEST_NODE2"
                ]);
            });
        }).then(function () {
            done();
        });
    });

    it("queries entity instances with fuzzy search", (done) => {
        return callRead(oRequest, "/test/object/TestAO.odata/Root?$top=1&searchText=Extension&$format=json&sap-ds-debug=json").then((oResponse) => {
            expect(oResponse.body.SQL).toBeDefined();
            expect(oResponse.body.SQL.insertTmp).toBeDefined();
            expect(oResponse.body.SQL.insertTmp.length).toBe(0);
            expect(oResponse.body.SQL.select).toBeDefined();
            expect(oResponse.body.SQL.select.length).toBe(1);
            expect(oResponse.body.SQL.select[0].sql.indexOf('contains(("Root1"."TITLE"), ?, fuzzy(0.8))') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].sql.indexOf(', SCORE() as "_SEARCH_SCORE"') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].sql.indexOf('order by  "_SEARCH_SCORE" DESC') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].parameters).toEqual([
                "Extension",
                1
            ]);
            done();
        });
    });

    it("queries entity instances with named filter", (done) => {
        return callRead(oRequest, "/test/object/TestAO.odata/Root?$top=1&filter=evenIds&$format=json&sap-ds-debug=json").then((oResponse) => {
            expect(oResponse.body.SQL).toBeDefined();
            expect(oResponse.body.SQL.insertTmp).toBeDefined();
            expect(oResponse.body.SQL.insertTmp.length).toBe(0);
            expect(oResponse.body.SQL.select).toBeDefined();
            expect(oResponse.body.SQL.select.length).toBe(1);
            expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1".ID in (select key from "sap.aof.test.db.test::v_test_even_id")') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].parameters).toEqual([
                1
            ]);
            done();
        });
    });

    it("queries entity instances ignoring for Node1 not relevant named filter", (done) => {
        return callRead(oRequest, "/test/object/TestAO.odata/Node1?$top=1&filter=evenIds&$format=json&sap-ds-debug=json").then((oResponse) => {
            expect(oResponse.body.SQL).toBeDefined();
            expect(oResponse.body.SQL.insertTmp).toBeDefined();
            expect(oResponse.body.SQL.insertTmp.length).toBe(0);
            expect(oResponse.body.SQL.select).toBeDefined();
            expect(oResponse.body.SQL.select.length).toBe(1);
            expect(oResponse.body.SQL.select[0].sql.indexOf('(select key from "sap.aof.test.db.test::v_test_even_id")') >= 0).toBe(false);
            expect(oResponse.body.SQL.select[0].parameters).toEqual([
                1
            ]);
            done();
        });
    });

    it("queries entity instances with named filter using single value", (done) => {
        return callRead(oRequest, "/test/object/TestAO.odata/Root?$top=1&filterTitleOccursNTimes=1&$format=json&sap-ds-debug=json").then((oResponse) => {
            expect(oResponse.body.SQL).toBeDefined();
            expect(oResponse.body.SQL.insertTmp).toBeDefined();
            expect(oResponse.body.SQL.insertTmp.length).toBe(0);
            expect(oResponse.body.SQL.select).toBeDefined();
            expect(oResponse.body.SQL.select.length).toBe(1);
            expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1".ID in (select key from "sap.aof.test.db.test::v_test_title_times" where value >= ?)') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].parameters).toEqual([
                "1",
                1
            ]);
            done();
        });
    });

    it("queries entity instances with named filter using multiple value contains all", (done) => {
        return callRead(oRequest, "/test/object/TestAO.odata/Root?$top=1&filterNode1ContainsSometexts=TEST_NODE2,TEST_NODE_21,TEST_NODE_22&$format=json&sap-ds-debug=json").then((oResponse) => {
            expect(oResponse.body.SQL).toBeDefined();
            expect(oResponse.body.SQL.insertTmp).toBeDefined();
            expect(oResponse.body.SQL.insertTmp.length).toBe(0);
            expect(oResponse.body.SQL.select).toBeDefined();
            expect(oResponse.body.SQL.select.length).toBe(1);
            expect(oResponse.body.SQL.select[0].sql.indexOf('"Root1".ID in (select key from "sap.aof.test.db.test::v_test_node1_sometexts" where value in (?,?,?) group by key having count(*) = ?)') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].parameters).toEqual([
                'TEST_NODE2',
                'TEST_NODE_21',
                'TEST_NODE_22',
                3,
                1
            ]);
            done();
        });
    });

    it("queries entity instances with named filter using single value search", (done) => {
        return callRead(oRequest, "/test/object/TestAO.odata/Root?$top=1&filterNode1SearchSometexts=TEST_NODE2&$format=json&sap-ds-debug=json").then((oResponse) => {
            expect(oResponse.body.SQL).toBeDefined();
            expect(oResponse.body.SQL.insertTmp).toBeDefined();
            expect(oResponse.body.SQL.insertTmp.length).toBe(0);
            expect(oResponse.body.SQL.select).toBeDefined();
            expect(oResponse.body.SQL.select.length).toBe(1);
            expect(oResponse.body.SQL.select[0].sql.indexOf(' "Root1".ID in (select key from "sap.aof.test.db.test::v_test_node1_sometexts" where contains(value, ?, fuzzy(0.2))') >= 0).toBe(true);
            expect(oResponse.body.SQL.select[0].parameters).toEqual([
                'TEST_NODE2',
                1
            ]);
            done();
        });
    });
});