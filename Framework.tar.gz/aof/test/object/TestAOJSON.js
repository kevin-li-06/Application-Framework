"use strict";

var jsonSchema = {
    required: ["A"],
    properties: {
        A: {
            type: "number",
        },
        B: {
            type: "string"
        },
        C: {
            type: "array",
            items: {
                properties: {
                    D: {
                        type: "number"
                    },
                    E: {
                        type: "string"
                    },
                    additionalProperties: false
                }
            }
        },
        F: {
            properties: {
                G: {
                    type: "number"
                },
                H: {
                    type: "string"
                },
                additionalProperties: true
            }
        },
        additionalProperties: false
    },
};

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
        },
        update: {
            authorizationCheck: false,
        },
        del: {
            authorizationCheck: false,
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "t_test_json",
        sequence: "s_test_json",
        attributes: {
            a_json: {
                dataType: "JSON",
                jsonSchema: jsonSchema
            },
            a_jsonb: {
                dataType: "JSON",
                jsonSchema: jsonSchema
            }
        },
        nodes: {
            Items: {
                table: "t_test_item_json",
                sequence: "s_test_item_json",
                parentKey: "parent_id",
                attributes: {
                    a_json: {
                        dataType: "JSON",
                        jsonSchema: jsonSchema
                    },
                    a_jsonb: {
                        dataType: "JSON",
                        jsonSchema: jsonSchema
                    }
                },
            }
        }
    }
};
