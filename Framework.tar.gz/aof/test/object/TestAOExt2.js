"use strict";

module.exports = {
    actions: {
        extCustomAction: {
            authorizationCheck: false,
            execute: () => {
            }
        }
    },
    Root: {
        determinations: {
            onCreate: [(vKey, oWorkObject) => {
                oWorkObject.TITLE2 = "Hello Extensibility!";
                oWorkObject.Node3 = [{
                    OBJECT_ID: 1,
                    SOMETEXT: "Hello Extensibility!"
                }];
            }]
        },
        attributes: {
            DESCRIPTION: {
                required: true
            }
        },
        nodes: {
            Node3: {
                table: "sap.aof.test.db.test::t_test_node_5",
                sequence: "sap.aof.test.db.test::s_test_node_5",
                parentKey: "PARENT_ID",
                attributes: {
                    OBJECT_ID: {
                        required: true
                    },
                    SOMETEXT: {
                        constantKey: "TEST_NODE3",
                        readOnly: true
                    }
                }
            }
        }
    }
};
