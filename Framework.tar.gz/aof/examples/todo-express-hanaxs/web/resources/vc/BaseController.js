sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/core/MessageType"
], function (Controller, JSONModel, MessageBox, MessageType) {
    "use strict";

    var mMessageTypeIcons = {};
    mMessageTypeIcons[MessageType.Error] = "message-error";
    mMessageTypeIcons[MessageType.Warning] = "message-warning";
    mMessageTypeIcons[MessageType.Success] = "message-success";
    mMessageTypeIcons[MessageType.Information] = "message-information";

    var mMessageTypePriority = {};
    mMessageTypePriority[MessageType.Error] = 1;
    mMessageTypePriority[MessageType.Warning] = 2;
    mMessageTypePriority[MessageType.Success] = 3;
    mMessageTypePriority[MessageType.Information] = 4;

    function mostSevereMessageType(aMessages) {
        if (aMessages.length === 0) {
            return MessageType.Information;
        }
        return aMessages.reduce(function (sMostSevereMessageType, oMessage) {
            if (mMessageTypePriority[oMessage.type] === undefined) {
                return sMostSevereMessageType;
            }
            if (mMessageTypePriority[oMessage.type] < mMessageTypePriority[sMostSevereMessageType]) {
                return oMessage.type;
            } else {
                return sMostSevereMessageType;
            }
        }, MessageType.Information);
    }

    return Controller.extend("sap.todo.aof.example.vc.BaseController", {

        baseFormatter: {
            mostSevereMessageTypeIcon: function (aMessage) {
                var sMessageType = mostSevereMessageType(aMessage);
                return "sap-icon://" + mMessageTypeIcons[sMessageType] || "";
            }
        },

        onInit: function () {
            if (Controller.prototype.onInit) {
                Controller.prototype.onInit.apply(this, arguments);
            }
            this.setModel(new JSONModel({}), "view");
        },

        onExit: function () {
            if (Controller.prototype.onExit) {
                Controller.prototype.onExit.apply(this, arguments);
            }
            this.releaseObjectModel();
        },

        getEventBus: function () {
            return this.getOwnerComponent().getEventBus();
        },

        getRouter: function () {
            return sap.ui.core.UIComponent.getRouterFor(this);
        },

        attachRoutes: function (routes, fnRouteMatched) {
            var that = this;
            if (routes) {
                var oRouter = this.getRouter();
                if (jQuery.type(routes) === "array") {
                    jQuery.each(routes, function (iIndex, sRoute) {
                        oRouter.getRoute(sRoute).attachMatched(fnRouteMatched, that);
                    });
                } else if (jQuery.type(routes) === "string") {
                    oRouter.getRoute(routes).attachMatched(fnRouteMatched, that);
                }
            }
        },

        attachBypassed: function () {
            this.getRouter().attachBypassed(this.onBypassed, that);
        },

        onBypassed: function () {
        },

        navBack: function () {
            this.onNavBack();
        },

        getModel: function (sName) {
            return this.getView().getModel(sName);
        },

        getUserModel: function () {
            return this.getOwnerComponent().getModel("user");
        },

        getDataModel: function () {
            return this.getOwnerComponent().getModel("data");
        },

        getViewModel: function () {
            return this.getModel("view");
        },

        setViewData: function (oViewData) {
            this.getViewModel().setData(oViewData);
        },

        setViewProperty: function (sProperty, vValue) {
            return this.getViewModel().setProperty(sProperty, vValue);
        },

        getViewProperty: function (sProperty) {
            return this.getViewModel().getProperty(sProperty);
        },

        getObjectModel: function () {
            return this.getModel("object");
        },

        hasOwnModel: function(sModelName) {
            return !!this.getView().oModels[sModelName];
        },

        setObjectModel: function (oModel) {
            if (oModel !== this.getView().getModel("object") && this.hasOwnModel("object")) {
                this.releaseObjectModel();
            } else {
                this.getView().setModel(null, "object");
            }
            this.getView().setModel(oModel, "object");
            this.getView().bindElement({
                path: "object>/"
            });
            return oModel;
        },

        releaseObjectModel: function () {
            var oObjectModel = this.getObjectModel();
            if (oObjectModel) {
                oObjectModel.releaseFromSync();
                oObjectModel.destroy();
            }
        },

        hasPendingChanges: function () {
            var oModel = this.getObjectModel();
            if (oModel) {
                return oModel.hasPendingChanges();
            }
            return false;
        },

        resetPendingChanges: function () {
            var oModel = this.getObjectModel();
            if (oModel && oModel.hasPendingChanges()) {
                oModel.revertChanges();
            }
        },

        setModel: function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        getResourceBundle: function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        onNavBack: function (sRoute, mData) {
            var oHistory = sap.ui.core.routing.History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();
            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                var bReplace = true;
                this.getRouter().navTo(sRoute, mData, bReplace);
            }
        },

        showPage: function (oPageView) {
            var oAppView = this.getOwnerComponent().getAppView();
            if (!oAppView.getPage(oPageView.getId())) {
                oAppView.addPage(oPageView);
            }
            oAppView.to(oPageView.getId());
        },

        removePage: function (oPageView) {
            var oAppView = this.getOwnerComponent().getAppView();
            if (!oAppView.getPage(oPageView.getId())) {
                oAppView.removePage(oPageView);
            }
        },

        getTextModel: function () {
            if (!this._i18n) {
                this._i18n = this.getOwnerComponent().getModel("i18n");
            }
            return this._i18n;
        },

        getText: function (sText, aParameter) {
            return this.getTextModel().getResourceBundle().getText(sText, aParameter);
        },

        toggleFullScreen: function () {
            var oMShell = this.getOwnerComponent().getShell();
            oMShell.setAppWidthLimited(!oMShell.getAppWidthLimited());
        },

        setFullScreen: function (bState) {
            this.getOwnerComponent().getShell().setAppWidthLimited(!bState);
        },

        getFullScreen: function () {
            return !this.getOwnerComponent().getShell().getAppWidthLimited();
        },

        createView: function (sViewName) {
            var oView;
            this.getOwnerComponent().runAsOwner(function () {
                oView = sap.ui.xmlview(sViewName);
            });
            return oView;
        },

        createFragment: function (sFragmentName) {
            var oController = this;
            var oFragment;
            this.getOwnerComponent().runAsOwner(function () {
                oFragment = sap.ui.xmlfragment(sFragmentName, oController);
            });
            return oFragment;
        },

        showMessage: function (sIcon, sMessage, sTitle, onClose) {
            MessageBox.show(sMessage, {
                icon: sIcon || MessageBox.Icon.ERROR,
                title: sTitle,
                actions: [MessageBox.Action.OK],
                onClose: onClose || undefined
            });
        },

        showConfirmation: function (sIcon, sMessage, sTitle, onClose) {
            MessageBox.confirm(sMessage, {
                icon: sIcon || MessageBox.Icon.QUESTION,
                title: sTitle,
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                onClose: onClose || undefined
            });
        },

        setBusy: function (bBusy) {
            this.getView().setBusy(bBusy);
        },

        onShowMessages: function (oEvent) {
            this.byId("messagePopover").openBy(oEvent.getSource());
        },

        removeAllMessages: function () {
            sap.ui.getCore().getMessageManager().removeAllMessages();
        },

        onInputLiveChange: function (oEvent) {
            oEvent.getSource().setValue(oEvent.getParameter("newValue"));
        }
    });
});