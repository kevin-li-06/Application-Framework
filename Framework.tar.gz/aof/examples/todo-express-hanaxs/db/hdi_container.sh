#!/usr/bin/env bash

export HDI__HOST=inno-next.mo.sap.corp
export HDI__PORT=30015
export HDI___SYS_DI__USER=SYSTEM
export HDI___SYS_DI__PASSWORD=Toor1234

hdi drop-container --force SAP_AOF_EXAMPLE_TODO
hdi create-container -X DEPLOYMENT_USER SAP_AOF_EXAMPLE_TODO