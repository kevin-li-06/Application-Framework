"use strict";

require("jasmine-before-all");
var io = require("../js/node_modules/socket.io-client");
var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");

var PORT = 3002;
var oServer;

describe("SAP/AOF/SOCKET", function () {

    beforeAll((done) => {
        oServer = require("../js/testServer.js");
        oServer.listen(PORT, function () {
            done();
        });
    });

    afterAll((done) => {
        oServer.close();
        done();
    });

    var oSocket;

    beforeEach((done) => {
        oSocket = io.connect("http://localhost:" + PORT + "/test/object/TestAO");
        setTimeout(() => {
            done();
        }, 250)
    });

    afterEach((done) => {
        if (oSocket) {
            oSocket.disconnect();
        }
        done();
    });

    it("access application Object via web sockets", (done) => {
        oSocket.emit("create", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            Node2: [{
                ID: -2,
                SOMETEXT: "Blafasel"
            }]
        });
        oSocket.on("create", (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) => {
            expect(oResponse).toBeDefined();
            var iId = oResponse.generatedKeys[-1];
            var iNode2Id = oResponse.generatedKeys[-2];
            expect(oObject).toEqual({
                DESCRIPTION: 'Test Title',
                ID: iId,
                TITLE: 'Test Title',
                Node1: [],
                Node2: [{
                    ID: iNode2Id,
                    SOMETEXT: 'Blafasel',
                    Node21: []
                }]
            });
            oSocket.emit("update", {
                ID: iId,
                TITLE: "Test Title Update",
                DESCRIPTION: "Test Title Update",
                Node2: [{
                    ID: iNode2Id,
                    SOMETEXT: "Blafasel Update"
                }, {
                    ID: -3,
                    SOMETEXT: "Blafasel Test"
                }]
            });
            var iNode2_2Id;
            oSocket.on("update", (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) => {
                if (oResponse.action !== "instanceAction") {
                    iNode2_2Id = oResponse.generatedKeys[-3];
                    expect(oResponse).toBeDefined();
                    expect(oObject).toEqual({
                        DESCRIPTION: 'Test Title Update',
                        ID: iId,
                        TITLE: 'Test Title Update',
                        Node1: [],
                        Node2: [{
                            ID: iNode2Id,
                            SOMETEXT: 'Blafasel Update',
                            Node21: []
                        }, {
                            ID: iNode2_2Id,
                            SOMETEXT: 'Blafasel Test',
                            Node21: []
                        }]
                    });
                    oSocket.emit("instanceAction", iId, {
                        TEXT: " Action"
                    });
                } else {
                    expect(oObject).toEqual({
                        DESCRIPTION: 'Test Title Update',
                        ID: iId,
                        TITLE: 'Test Title Update Action',
                        Node1: [],
                        Node2: [{
                            ID: iNode2_2Id,
                            SOMETEXT: 'Blafasel Test',
                            Node21: []
                        }, {
                            ID: iNode2Id,
                            SOMETEXT: 'Blafasel Update',
                            Node21: []
                        }]
                    });
                    oSocket.emit("del", iId);
                    oSocket.on("del", (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) => {
                        expect(oObject).toEqual({
                            DESCRIPTION: 'Test Title Update',
                            ID: iId,
                            TITLE: 'Test Title Update Action',
                            Node1: [],
                            Node2: [{
                                ID: iNode2_2Id,
                                SOMETEXT: 'Blafasel Test',
                                Node21: []
                            }, {
                                ID: iNode2Id,
                                SOMETEXT: 'Blafasel Update',
                                Node21: []
                            }]
                        });
                        done();
                    });
                }
            });
        });
    });
});