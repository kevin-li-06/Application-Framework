"use strict";

/**
 * Check re-use library to be used for Application Object consistency checks on node and attribute level
 * @namespace Check
 */
function Check() {
}

/**
 * Enumeration for check messages
 * @enum {String}
 */

Check.prototype.Messages = {
    /**
     * MSG_AOF_INVALID_FOREIGN_KEY
     */
    INVALID_FOREIGN_KEY: "MSG_AOF_INVALID_FOREIGN_KEY",
    /**
     * MSG_AOF_INVALID_BOOL_VALUE
     */
    INVALID_BOOL_VALUE: "MSG_AOF_INVALID_BOOL_VALUE",
    /**
     * MSG_AOF_INVALID_ENUM_VALUE
     */
    INVALID_ENUM_VALUE: "MSG_AOF_INVALID_ENUM_VALUE",
    /**
     * MSG_AOF_INVALID_MIN_VALUE
     */
    INVALID_MIN_VALUE: "MSG_AOF_INVALID_MIN_VALUE",
    /**
     * MSG_AOF_INVALID_MAX_VALUE
     */
    INVALID_MAX_VALUE: "MSG_AOF_INVALID_MAX_VALUE",
    /**
     * MSG_AOF_INVALID_MAX_LENGTH
     */
    INVALID_MAX_LENGTH: "MSG_AOF_INVALID_MAX_LENGTH",
    /**
     * MSG_AOF_INVALID_OBJECT_TYPE
     */
    INVALID_OBJECT_TYPE: "MSG_AOF_INVALID_OBJECT_TYPE",
    /**
     * MSG_AOF_INVALID_OBJECT_REF
     */
    INVALID_OBJECT_REF: "MSG_AOF_INVALID_OBJECT_REF",
    /**
     * MSG_AOF_VALUE_NOT_A_NUMBER
     */
    NOT_A_VALID_NUMBER: "MSG_AOF_VALUE_NOT_A_NUMBER",
    /**
     * MSG_AOF_VALUE_NOT_A_STRING
     */
    NOT_A_VALID_STRING: "MSG_AOF_VALUE_NOT_A_STRING",
    /**
     * MSG_AOF_VALUE_NOT_A_DATE
     */
    NOT_A_VALID_DATE: "MSG_AOF_VALUE_NOT_A_DATE",
    /**
     * MSG_AOF_DUPLICATE_ALT_KEY
     */
    DUPLICATE_ALT_KEY: "MSG_AOF_DUPLICATE_ALT_KEY",
    /**
     * MSG_AOF_NODE_CARDINALITY_ONE_VIOLATION
     */
    NODE_CARDINALITY_ONE_VIOLATION: "MSG_AOF_NODE_CARDINALITY_ONE_VIOLATION"
};

/**
 * Checks for duplicates based on the value identified by the attribute name
 * @param sAttributeName {String} Attributed name to be checked for duplicate values
 * @param bIgnoreCase {Boolean} Flag to specific, that case si ignore when comparing strings
 * @param aWorkObjectNode {Array} Array of application object nodes
 * @returns {Array} Array of duplicate nodes
 */
Check.prototype.containsDuplicates = function (sAttributeName, bIgnoreCase, aWorkObjectNode) {
    return [];
};

/**
 * Generic attribute check, executing a check function and adding a message if check fails
 * @param fnPred {Function} Check function to be checked against attribute
 * @param sMsgKey
 * @returns {Promise}
 */
Check.prototype.attributeCheck = function (fnPred, sMsgKey) {
    return new Promise();
};

/**
 * Checks the attribute value for being a valid boolean (true or false)
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.booleanCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value for being a valid enum value
 * @param oEnum {Object|Array.<String>} Enumeration configuration
 * @returns {ImplementationExit.attributeConsistencyCheck} Returns the attribute consistency check validating the enumeration
 */
Check.prototype.enumCheck = function (oEnum) {
};

/**
 * Checks the attribute value for being a valid integer boolean (1 = true, 0 = false)
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.intBooleanCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value for being a valid string boolean ('X' and 'true' = true, '' and 'false' = false)
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.stringBooleanCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value for being a valid integer
 * Check is registered automatically by framework according to attribute data type.
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.integerCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value for being a valid float
 * Check is registered automatically by framework according to attribute data type.
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.floatCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value for being a valid string
 * Check is registered automatically by framework according to attribute data type.
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.stringCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value for being a valid date (ISO string)
 * Check is registered automatically by framework according to attribute data type.
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.dateCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value to conform to specified min value
 * Check is registered automatically by framework according to attribute data type and when a min value is specified
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.minValueCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value to conform to specified max value.
 * Check is registered automatically by framework according to attribute data type and when a max value is specified
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.maxValueCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value to conform to specified max length.
 * Check is registered automatically by framework according to attribute data type and when a max length is specified
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.maxLengthCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the attribute value to reference a valid Application Object Node instance according to specification (if value is not empty)
 * Check is registered automatically by framework according to foreign key specification
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.interObjectForeignKeyCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Duplicate primary key check on node level, across all application object instances (for create and copy action)
 * @param vKey {*}
 * @param oData {Object} Attribute data
 * @param oData.name {String} Attribute name
 * @param oData.value {*} Attribute value
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.duplicatePrimaryKeyCheck = function (vKey, oData, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Checks the node to reference a valid inner node instance according to specification (if value is not empty)
 * Check is registered automatically by framework according to foreign key and foreign key intra object specification
 * @param vKey {*}
 * @param oWorkObject {Object} Node currently processed
 * @param fnMessage {MessageBuffer.addMessage} Function to add a message to the message buffer
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {NodeMetadata}
 */
Check.prototype.intraObjectForeignKeyCheck = function (vKey, oWorkObject, fnMessage, oContext, oNodeMetadata) {
};

/**
 * Generator function for an object reference check
 * @param sObjectTypeAttribute {String} Attribute name in node data of referenced Application Object name
 * @param sObjectKeyAttribute {String} Attribute name in node data of referenced Application Object attribute
 * @param sRefNodeName {String} Node name of the referenced Application Object
 */
Check.prototype.objectReferenceCheck = function (sObjectTypeAttribute, sObjectKeyAttribute, sRefNodeName) {
};

/**
 * Generator function for an duplicate check
 * @param sAttributeName {String} Attribute name to be checked for duplicate values
 * @param sMsgKey {String} Message key to be used for message creation in case of duplicates
 * @param bIgnoreCase {Boolean} Flag to specific, that case si ignore when comparing strings
 * @param sMsgAttribute {String} Message attribute to be used as reference attribute during message creation
 */
Check.prototype.duplicateCheck = function (sAttributeName, sMsgKey, bIgnoreCase, sMsgAttribute) {
};

/**
 * Generator function for duplicate alternative key checks
 * @param sAltKeyName {String} Alternative key attribute name
 * @param sMsgKey {String} Message key to be used for message creation in case of duplicates
 * @param bIgnoreCase {Boolean} Flag to specific, that case si ignore when comparing strings
 */
Check.prototype.duplicateAlternativeKeyCheck = function (sAltKeyName, sMsgKey, bIgnoreCase) {
};

/**
 * Generator function for foreign key checks on DB
 * @param sForeignKeyName {String} Name of foreign key
 * @param sMsgKey {String} Message key to be used for message creation in case of duplicates
 * @param sEntity {String} DB entity to be used for foreign key check
 */
Check.prototype.dbForeignKeyCheck = function (sForeignKeyName, sMsgKey, sEntity) {
};

/**
 * Generator function for read-only after creation checks on node
 * @param sMsgKey {String} Message key to be used for message creation in case of node changes after creation
 */
Check.prototype.readOnlyAfterCreateCheck = function readOnlyAfterCreateCheck(sMsgKey) {
};

/**
 * Generator function for node cardinality to one check.
 * Nodes containing more than one node instance will result in an generic error message during runtime.
 */
Check.prototype.cardinalityOneCheck = function () {
};
