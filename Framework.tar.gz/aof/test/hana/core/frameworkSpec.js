"use strict";

require("jasmine-before-all");

var Promise = require("bluebird");
Promise.longStackTraces();

var aof = require("../../../index");
var HANAStore = require("../../../lib/db/hana/store");

var oContext;

describe("SAP/AOF/FRAMEWORK", () => {

    beforeAll((done) => {
        oContext = {
            storeInfo: {
                hana: require("../../hana/js/default-services.json").hana
            }
        };
        HANAStore.createDB(oContext.storeInfo.hana).then((oDB) => {
            oContext.db = oDB;
            done();
        });
    });

    afterAll((done) => {
        if (oContext.db) {
            oContext.db.close();
        }
        done();
    });

    it("loads application metadata from library", (done) => {
        aof.getMetadata("test.object.TestAO", oContext).then((oMetadata) => {
            expect(oMetadata).toBeDefined();
            done();
        })
    });

    it("error on invalid application metadata from library", (done) => {
        var oMetadata;
        aof.getMetadata("test.object.InvalidObject", oContext).then((done) => {
            this.fail(Error("metadata loading of invalid libarary shall fail"));
            done();
        }).catch((oException) => {
            expect(oException.toString().indexOf("Error: Application object definition 'test.object.InvalidObject' not valid. The following errors occurred:") >= 0).toBe(true);
            expect(oMetadata).not.toBeDefined();
            done();
        });
    });

    it("allows accessing application object from metadata", (done) => {
        aof.getMetadata("test.object.TestAO", oContext).then((oMetadata) => {
            expect(oMetadata).toBeDefined();
            oMetadata.getApplicationObject().then((oApplicationObjectMetadata) => {
                aof.getApplicationObject("test.object.TestAO", oContext).then((oApplicationObjectAOF) => {
                    expect(oApplicationObjectMetadata).not.toEqual(oApplicationObjectAOF);

                    oApplicationObjectMetadata.close();
                    oApplicationObjectAOF.close();
                    done();
                });
            });
        });
    });

    it("allows accessing metadata from application object", (done) => {
        aof.getApplicationObject("test.object.TestAO", oContext).then((oApplicationObject) => {
            expect(oApplicationObject).toBeDefined();
            var oMetadataObject = oApplicationObject.getMetadata();
            aof.getMetadata("test.object.TestAO", oContext).then((oMetadataAOF) => {
                expect(oMetadataObject).toBe(oMetadataAOF);

                oApplicationObject.close();
                done();
            });
        });
    });

    it("allows accessing an extended application object", (done) => {
        aof.setObjectExtension("test.object.TestAO", "test.object.TestAOExt");
        aof.setObjectExtension("test.object.TestAO", "test.object.TestAOExt2");

        var oExtensionDef = {
            actions: {
                extCustomAction2: {
                    authorizationCheck: false,
                    execute: () => {
                        return "Hello World"
                    }
                }
            }
        };
        aof.setObjectExtension("test.object.TestAO", oExtensionDef);
        aof.removeObjectExtension("test.object.TestAO", oExtensionDef);
        aof.setObjectExtension("test.object.TestAO", oExtensionDef, 0);

        aof.getApplicationObject("test.object.TestAO", oContext).then((oApplicationObject) => {
            expect(oApplicationObject).toBeDefined();
            expect(typeof oApplicationObject.extCustomAction).toBe("function");
            expect(typeof oApplicationObject.extCustomAction2).toBe("function");

            oApplicationObject.create({
                ID: -1,
                DESCRIPTION: "X"
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var vKey = oResponse.generatedKeys[-1];

                oApplicationObject.read(vKey).then((oObject) => {
                    expect(oObject.TITLE).toBe("Hello Extensibility!");
                    expect(oObject.Node3.length).toEqual(1);
                    expect(oObject.Node3[0].OBJECT_ID).toEqual(1);
                    expect(oObject.Node3[0].SOMETEXT).toEqual("TEST_NODE3");

                    return oApplicationObject.extCustomAction2(vKey);
                }).then((oResponse) => {
                    delete oResponse.object;
                    expect(oResponse).toEqual({
                        "messages": [],
                        "result": "Hello World",
                        "generatedKeys": {},
                        "concurrencyToken": "{\"TITLE\":\"Hello Extensibility!\"}",
                        "hasError": false,
                        "minMessageSeverity": 5
                    });

                    oApplicationObject.close();
                    done();
                });
            });
        });
    });

    it("allows accessing application object in privileged mode", (done) => {
        aof.getApplicationObject("test.object.TestAO", oContext).then((oApplicationObject) => {
            expect(oApplicationObject).toBeDefined();
            aof.getApplicationObject("test.object.TestAO", oContext, true).then((oApplicationObjectPrivileged) => {
                expect(oApplicationObjectPrivileged).toBeDefined();
                expect(oApplicationObjectPrivileged).not.toBe(oApplicationObject);
                aof.getApplicationObject("test.object.TestAO", oContext, true).then((oApplicationObjectPrivilegedCached) => {
                    expect(oApplicationObjectPrivileged).not.toBe(oApplicationObjectPrivilegedCached);

                    oApplicationObject.close();
                    oApplicationObjectPrivileged.close();
                    oApplicationObjectPrivilegedCached.close();

                    done();
                });
            });
        });
    });
});