#!/usr/bin/env bash
export HDI__HOST=inno-next.mo.sap.corp
export HDI__PORT=30015
export HDI___SYS_DI__USER=SYSTEM
export HDI___SYS_DI__PASSWORD=Toor1234

export HDI__SAP_AOF_TEST__USER=DEPLOYMENT_USER
export HDI__SAP_AOF_TEST__PASSWORD=Test1234

hdi grant-container-schema-privilege SAP_AOF_TEST EXECUTE SAP_AOF_TEST_USER
hdi grant-container-schema-privilege SAP_AOF_TEST SELECT SAP_AOF_TEST_USER
hdi grant-container-schema-privilege SAP_AOF_TEST INSERT SAP_AOF_TEST_USER
hdi grant-container-schema-privilege SAP_AOF_TEST UPDATE SAP_AOF_TEST_USER
hdi grant-container-schema-privilege SAP_AOF_TEST DELETE SAP_AOF_TEST_USER
hdi grant-container-schema-privilege SAP_AOF_TEST "CREATE ANY" SAP_AOF_TEST_USER