"use strict";

/**
 * Implementation exits to define the inner application logic for an Application Object
 * @namespace ImplementationExit
 */
function ImplementationExit() {
}

/**
 * Authorization is checked for the passed object instance and determines if the caller is authorized to execute the instance action
 * @callback ImplementationExit.authorizationCheck
 * @param vKey {*} Key of the object instance to be checked for authorization, undefined if in Create
 * @param oPersistedObject {Object} Javascript object of the application object instance before executing the façade service (action) call. In Create case the oCreateRequest object is passed in
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer. In case of authorization violation an error message has to be added via the add message function to stop the processing
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.authorizationCheck = function (vKey, oPersistedObject, addMessage, oContext) {
    return new Promise();
};

/**
 * Authorization is checked for the passed parameters and determines if the caller is authorized to execute the static action
 * @callback ImplementationExit.staticAuthorizationCheck
 * @param oParameters {Object} Javascript object of action parameters passed into the action execution call
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer. In case of authorization violation an error message has to be added via the add message function to stop the processing
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.staticAuthorizationCheck = function (oParameters, addMessage, oContext) {
    return new Promise();
};

/**
 * Check is called before execution for the passed object instance and determines if the action is enabled
 * @callback ImplementationExit.enabledCheck
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oPersistedObject {Object} Javascript object of the application object instance before executing the façade service (action) call. In Create case the oCreateRequest object is passed in.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.enabledCheck = function (vKey, oPersistedObject, addMessage, oContext) {
    return new Promise();
};

/**
 * Check is called before execution for given parameters and determines if the action is enabled
 * @callback ImplementationExit.staticEnabledCheck
 * @param oParameters {Object} Javascript object of action parameters passed into the action execution call
 * @param oReadOnlyBulkAccess {BulkAccess} Bulk access providing direct node update capabilities on DB. Only simulation possible in this context.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.staticEnabledCheck = function (oParameters, oReadOnlyBulkAccess, addMessage, oContext) {
    return new Promise();
};

/**
 * Check is called before execution for the passed object instance and determines, if the action can be executed with the request object
 * @callback ImplementationExit.executionCheck
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oRequestObject {Object} Request object passed into the call as parameter for the action execution. Undefined if in Delete
 * @param oWorkObject {Object} Javascript object of the application object instance the façade service call is currently working on.
 * @param oPersistedObject {Object} Javascript object of the application object instance persisted on the database
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.executionCheck = function (vKey, oRequestObject, oWorkObject, oPersistedObject, addMessage, oContext) {
    return new Promise();
};

/**
 * Execution is called for the custom action, to execute the custom action logic
 * @callback ImplementationExit.persistActionExecute
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oWorkObject {Object} Javascript object of the application object instance to be persisted
 * @param oDBAction {Object} DB action object, a wrapper around AOF store layer
 * @param oDBAction.create {Function} Execute create on store passing the object
 * @param oDBAction.update {Function} Execute update on store passing the object
 * @param oDBAction.del {Function} Execute delete on store passing the object
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.persistActionExecute = function (vKey, oWorkObject, oDBAction, addMessage, oContext) {
    return new Promise();
};

/**
 * Execution is called for the custom action, to execute the custom action logic
 * @callback ImplementationExit.actionExecute
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oParameters {Object} Javascript object of action parameters passed into the action execution call oWorkObject: Javascript object of the application object instance the façade service call is currently working on. Modifications shall be performed on this object.
 * @param oWorkObject {Object} Javascript object of the application object instance the façade service call is currently working on. Work Object cannot be modified when action is read-only.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param getNextHandle {Function} The get next handle function can be used to determine a handle key for the creation of a object instance
 * @param oContext {Context} Runtime context object
 * @param oMetadata {Metadata} Application object metadata
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.actionExecute = function (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) {
    return new Promise();
};

/**
 * Execution is called for static custom action, to execute the static custom action logic
 * @callback ImplementationExit.staticActionExecute
 * @param oParameters {Object} Javascript object of action parameters passed into the action execution call
 * @param oBulkAccess {BulkAccess} Bulk access providing direct node update on DB.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param getNextHandle {Function} The get next handle function can be used to determine a handle key for the creation of a object instance
 * @param oContext {Context} Runtime context object
 * @param oMetadata {Metadata} Application object metadata
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.staticActionExecute = function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
    return new Promise();
};

/**
 * Called to retrieve the custom properties for the node instance
 * @callback ImplementationExit.nodeCustomProperties
 * @param vKey {*} Key of the object instance to be properties to be retrieved from. Key must be valid for an object instance.
 * @param oPersistedObject {Object} Javascript object of the application object instance persisted on the database
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.nodeCustomProperties = function (vKey, oPersistedObject, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Called to retrieve the custom properties for a node instance attribute
 * @callback ImplementationExit.attributeCustomProperties
 * @param vKey {*} Key of the object instance to be properties to be retrieved from. Key must be valid for an object instance.
 * @param oPersistedObject {Object} Javascript object of the application object instance persisted on the database
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.attributeCustomProperties = function (vKey, oPersistedObject, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Called to retrieve the custom properties for the node instance
 * @callback ImplementationExit.actionCustomProperties
 * @param vKey {*} Key of the object instance to be properties to be retrieved from. Key must be valid for an object instance.
 * @param oParameters {Object} Javascript object of action parameters passed into the action execution call. Might be null if properties are requested without parameters.
 * @param oPersistedObject {Object} Javascript object of the application object instance persisted on the database
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oActionMetadata {Metadata.ActionMetadata} Metadata object for the current action
 * @param oMetadata {Metadata} Application object metadata
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.actionCustomProperties = function (vKey, oParameters, oPersistedObject, addMessage, oContext, oActionMetadata, oMetadata) {
    return new Promise();
};

/**
 * Called to retrieve the custom properties for the passed parameters
 * @callback ImplementationExit.staticActionCustomProperties
 * @param oParameters {Object} Javascript object of action parameters passed into the action execution call
 * @param oReadOnlyBulkAccess {BulkAccess} Bulk access providing direct node update capabilities on DB. Only simulation possible in this context.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oActionMetadata {Metadata.ActionMetadata} Metadata object for the current action
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.staticActionCustomProperties = function (oParameters, oReadOnlyBulkAccess, addMessage, oContext, oActionMetadata) {
    return new Promise();
};

/**
 * Check is called before execution for the passed object instance
 * @callback ImplementationExit.determination
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oWorkObject {Object} Javascript object of the application object instance the façade service call is currently working on. Modifications shall be performed on this object (current image). Object is Persisted Object, if in Delete.
 * @param oPersistedObject {Object} Javascript object of the application object instance before executing the façade service (action) call. Object is undefined if in Create case (before image). Object is original copy source for Copy case.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param getNextHandle {Function} The get next handle function can be used to determine a handle key for the creation of a object instance
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node, in determinations always the Root node
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.determination = function (vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Check is called after persisting the passed object instance
 * @callback ImplementationExit.onPersistDetermination
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oWorkObject {Object} Javascript object of the application object instance the façade service call is currently working on. Modifications shall be performed on this object (current image). Object is undefined if in Delete.
 * @param oPersistedObject {Object} Javascript object of the application object instance before executing the façade service (action) call. Object is undefined if in Create case (before image). Object is original copy source for Copy case.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param getNextHandle {Function} The get next handle function can be used to determine a handle key for the creation of a object instance
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node, in determinations always the Root node
 * @param oActionInfo {Object} Action information object
 * @param oActionInfo.originalKey {*} In case of copy action, the original key is added to the action information
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.onPersistDetermination = function (vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata, oActionInfo) {
    return new Promise();
};

/**
 * Determinations are called after action execution for the passed object instance
 * @callback ImplementationExit.readDetermination
 * @param vKey {*} Key of the object instance to be checked for execution, undefined if in Create
 * @param oReadObject {Object} Javascript object of the application object instance read for the key. Modifications can be performed on the object especially to calculate transient fields.
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node, in read determinations always the Root node
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.readDetermination = function (vKey, oReadObject, oNodeMetadata, oContext) {
    return new Promise();
};

/**
 * Consistency checks are called after execution for the passed object instance including sub-structure
 * @callback ImplementationExit.nodeConsistencyCheck
 * @param vKey {*} Key of the object root instance to be checked for consistency after execution, node key needs to be retrieved from oWorkObjectNode (which can be an array)
 * @param oWorkObjectNode {Object|Array} Javascript object of the application object node instance the façade service call is currently working on. If check is executed on Root node, oWorkObjectNode is a object, if check is executed on a sub-node, oWorkObjectNode is an array of objects, to allow for example a duplicate check on node instances
 * @param [oPersistedObjectNode] {Object|Array} Javascript object of the corresponding application object nodes currently persisted. Only available for updated nodes, otherwise 'null'
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node the consistency check is executed against
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.nodeConsistencyCheck = function (vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Input checks are called before execution for the passed object instance including sub-structure
 * @callback ImplementationExit.nodeInputCheck
 * @param vKey {*} Key of the object root instance to be checked for input before execution, node key needs to be retrieved from oWorkObjectNode (which can be an array)
 * @param oWorkObjectNode {Object|Array} Javascript object of the application object node instance the façade service call is currently working on. If check is executed on Root node, oWorkObjectNode is a object, if check is executed on a sub-node, oWorkObjectNode is an array of objects, to allow for example a duplicate check on node instances
 * @param [oPersistedObjectNode] {Object|Array} Javascript object of the corresponding application object nodes currently persisted. Only available for updated nodes, otherwise 'null'
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node the input check is executed against
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.nodeInputCheck = function (vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Consistency checks are called after execution for the passed object instance on attributes
 * @callback ImplementationExit.attributeConsistencyCheck
 * @param vKey {*} Key of the object node instance to be checked for consistency after execution
 * @param oAttribute {Object} Attribute object
 * @param oAttribute.name {Object} Name of the currently checked attribute
 * @param oAttribute.value {Object} Current value of the checked attribute
 * @param [oAttribute.persistedValue] {Object} Persisted value of the checked attribute. Only available for updated nodes.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node the consistency check is executed against
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.attributeConsistencyCheck = function (vKey, oAttribute, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Input checks are called before execution for the passed object instance on attributes
 * @callback ImplementationExit.attributeInputCheck
 * @param vKey {*} Key of the object node instance to be checked for input before execution
 * @param oAttribute {Object} Attribute object
 * @param oAttribute.name {Object} Name of the currently checked attribute
 * @param oAttribute.value {Object} Current value of the checked attribute
 * @param [oAttribute.persistedValue] {Object} Persisted value of the checked attribute. Only available for updated nodes.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer.
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node the input check is executed against
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.attributeInputCheck = function (vKey, oAttribute, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Read only check of node is called during merge of request and persisted object
 * @callback ImplementationExit.nodeReadOnlyCheck
 * @param vKey {*} Key of the object node instance to be checked for read-only before execution (undefined in Create node case)
 * @param oPersistedObjectNode {Object} Javascript object of the application object node instance before executing the façade service call (empty object '{}' in Create node case)
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer. The reason why a node is read-only can be expressed by adding a message
 * @param oContext {Context} Runtime context object
 * @param oActionMetadata {Metadata.ActionMetadata} Metadata object for the current action the read only check is executed against
 * @returns {(Promise.<Boolean>|Boolean)} Promise (async) or void (sync). Promise or boolean (true, if attribute is read only, otherwise false)
 */
ImplementationExit.prototype.nodeReadOnlyCheck = function (vKey, oPersistedObjectNode, addMessage, oContext, oActionMetadata) {
    return new Promise();
};

/**
 * Read only check of action is called at action execution to determine is action has side effects
 * @callback ImplementationExit.actionReadOnlyCheck
 * @param vKey {*} Key of the object node instance to be checked for read-only before execution (undefined in Create node case)
 * @param oPersistedObject {Object} Javascript object of the application object instance before executing the façade service call (empty object '{}' in Create node case)
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer. The reason why a node is read-only can be expressed by adding a message
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Metadata object for the current node the read only check is executed against
 * @returns {(Promise.<Boolean>|Boolean)} Promise (async) or void (sync). Promise or boolean (true, if attribute is read only, otherwise false)
 */
ImplementationExit.prototype.actionReadOnlyCheck = function (vKey, oPersistedObject, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Read only check of attributes is called during merge of request and persisted object
 * @callback ImplementationExit.attributeReadOnlyCheck
 * @param vKey {*} Key of the object node instance to be checked for read-only before execution (undefined in Create node case)
 * @param oPersistedObjectNode {Object} Javascript object of the application object node instance before executing the façade service call (empty object '{}' in **Create** node case)
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer. The reason why an attribute is read-only can be expressed by adding a message
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata}
 * @returns {(Promise.<Boolean>|Boolean)} Promise (async) or void (sync). Promise or boolean (true, if attribute is read only, otherwise false)
 */
ImplementationExit.prototype.attributeReadOnlyCheck = function (vKey, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) {
    return new Promise();
};

/**
 * Activation check before configuration content is activated, i.e. inserted into the configuration runtime table
 * @callback ImplementationExit.activationCheck
 * @param oConfiguration {Object} Javascript object of the currently active configuration. It is undefined for initial activation. The object is structured like the corresponding configuration object of the staging object.
 * @param oStage {Object} Javascript object of the configuration which will be activated in activation. The object is structured like the corresponding configuration object of the staging object.
 * @param addMessage {MessageBuffer.addMessage} Function to add a message to the message buffer. For avoiding activation an error message has to be added via the add message function.
 * @param oContext {Context} Runtime context object
 * @returns {(Promise|void)} Promise (async) or void (sync)
 */
ImplementationExit.prototype.activationCheck = function (oConfiguration, oStage, addMessage, oContext) {
    return new Promise();
};
