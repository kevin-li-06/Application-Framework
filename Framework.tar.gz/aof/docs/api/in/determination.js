"use strict";

/**
 * Determination re-use library to be used as Application Object node determinations
 * @namespace Determination
 */
function Determination() {
}

/**
 * Re-use determination to be used for filling the system administrative data (uppercase, underscore)
 * @param vKey {*} Key of the Application Object
 * @param oWorkObject {Object} Work Object to be modified
 * @param oPersistedObject {Object} Persisted Object read from the persistence (read-only)
 * @param fnMessage {MessageBuffer.addMessage} Function to add a new message to the message buffer
 * @param fnHandle {Function} Function to create next key handle
 * @param oContext {Context} Context runtime object
 */
Determination.prototype.systemAdminData = function (vKey, oWorkObject, oPersistedObject, fnMessage, fnHandle, oContext) {
};

/**
 * Generator function for creating a system admin data determination based on provided attriubutes
 * @param sCreatedByAttribute {String} Name of created by attribute
 * @param sCreatedAtAttribute {String} Name of created at attribute
 * @param sChangedByAttribute {String} Name of created by attribute
 * @param sChangedAtAttribute {String} Name of changed at attribute
 */
Determination.prototype.fnSystemAdminData = function (sCreatedByAttribute, sCreatedAtAttribute, sChangedByAttribute, sChangedAtAttribute) {
};