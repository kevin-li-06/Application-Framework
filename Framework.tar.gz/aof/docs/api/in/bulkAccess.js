"use strict";

/**
 * Bulk access API available for implementing internal static Application Object actions
 * @namespace BulkAccess
 */
function BulkAccess() {
}

/**
 * Updates all node instances on database which satisfy the filter condition. 
 * It optionally updates parent node instances. History tables will be written automatically as specified in AOF object. Does not commit.
 * @param oBulkChange {Object} Javascript object containing the node name and attributes and parent nodes which should be updated. Parent nodes are included in reverse order of the hierarchy. Only one leading node may be used.
 * @param oFilter {Object} Javascript object containing the filter condition
 * @param oFilter.condition {Object} SQL where condition as string. Attributes refer to the leading node of this bulk change. But in principle arbitrary SQL conditions and sub-selects can be used.
 * @param oFilter.conditionParameters {Array} Array of prepared parameters contained as "?" in condition. For each "?" in condition a value is expected here
 * @param oFilter.conditionNodeAlias {String} Optional name of node to be used as table alias in where condition, especially in correlated sub-queries.
 * @param bSimulate {Boolean} Optional indicator whether to only simulate the bulk change or not. Default is false. In simulation mode affected nodes in the oResponse are populated.
 * @returns oResponse {Object} Response object containing the operation result
 * @returns oResponse.messages {Array} Array of messages which occurred during execution
 * @returns oResponse.affectedNodes {Object} Object of node names containing per node the following information, e.g. { Root: { operation : "update", count: 121 } }
 * @returns oResponse.affectedNodes.operation {String} Bulk operation on node ("update" or "del")
 * @returns oResponse.affectedNodes.count {Number} Number of node instances affected by the operation
 */
BulkAccess.prototype.update = function (oBulkChange, oFilter, bSimulate) {
    return {messages: [], affectedNodes: {}};
};

/**
 * Deletes all nodes and their child nodes on database level. In addition it optionally updates parent node instances. 
 * History tables will be written automatically as specified in AOF object. Does not commit.
 * @param oBulkChange {Object} Javascript object containing the node name and attributes and parent nodes which should be updated. Parent nodes are included in reverse order of the hierarchy. Only one leading node may be used.
 * @param oFilter {Object} Javascript object containing the filter condition
 * @param oFilter.condition {Object} SQL where condition as string. Attributes refer to the leading node of this bulk change. But in principle arbitrary SQL conditions and sub-selects can be used.
 * @param oFilter.conditionParameters {Array} Array of prepared parameters contained as "?" in condition. For each "?" in condition a value is expected here
 * @param oFilter.conditionNodeAlias {String} Optional name of node to be used as table alias in where condition, especially in correlated sub-queries.
 * @param bSimulate {Boolean} Optional indicator whether to only simulate the bulk change or not. Default is false. In simulation mode affected nodes in the oResponse are populated.
 * @returns oResponse {Object} Response object containing the operation result
 * @returns oResponse.messages {Array} Array of messages which occurred during execution
 * @returns oResponse.affectedNodes {Object} Object of node names containing per node the following information, e.g. { Root: { operation : "update", count: 121 } }
 * @returns oResponse.affectedNodes.operation {String} Bulk operation on node ("update" or "del")
 * @returns oResponse.affectedNodes.count {Number} Number of node instances affected by the operation
 */
BulkAccess.prototype.del = function (oBulkChange, oFilter, bSimulate) {
    return {messages: [], affectedNodes: {}};
};

/**
 * Read node on database level
 * @param sNodeName {String} Node name to be read
 * @param oFilter {Object} Javascript object containing the filter condition
 * @param oFilter.condition {Object} SQL where condition as string. Attributes refer to the leading node of this bulk change. But in principle arbitrary SQL conditions and sub-selects can be used.
 * @param oFilter.conditionParameters {Array} Array of prepared parameters contained as "?" in condition. For each "?" in condition a value is expected here
 * @param oFilter.conditionNodeAlias {String} Optional name of node to be used as table alias in where condition, especially in correlated sub-queries.
 * @returns oResponse {Object} Response object containing the operation result
 * @returns oResponse.operationName {String} Bulk operation ("read")
 * @returns oResponse.messages {Array} Array of messages which occurred during execution
 * @returns oResponse.count {Number}  Number of node instances found by the operation
 * @returns oResponse.result {Array} Array of found node instances
 */
BulkAccess.prototype.read = function (sNodeName, oFilter) {
    return {messages: [], affectedNodes: {}};
};
