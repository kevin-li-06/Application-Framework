"use strict";

var expect = require("chai").expect;
var sinon = require("sinon");

var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");
var Metadata = require("../../../lib/core/metadata");

var sqlite;
try {
    sqlite = require("sqlite3").verbose();
} catch (ex) {
    console.log(ex);
    console.log("run?: sudo npm ln sqlite3");
    return;
}

var SQLiteStore = require("../../../lib/db/sqlite/store");

var oCallerContext = {
    store: {}
};

var oDB;

describe("core-metadata", () => {

    var TEST_TABLE = 'sap.aof.test.db.test::t_test';

    var oDummyActions = {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    };

    before(() => {
        return new Promise((resolve, reject) => {
            Promise.promisifyAll(sqlite.Database.prototype);
            oDB = new sqlite.Database(':memory:', (error) => {
                expect(error).to.be.null;
                oCallerContext.store = new SQLiteStore({db: oDB});
                oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test" (ID integer primary key, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))')
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_2" (ID integer primary key not null, INT_01 integer, DOUBLE_01 double, TEXT_01 nvarchar(5000), TEXT_02 nvarchar(100), BOOL_01 integer, TS_01 timestamp, DATE_01 date)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null, ANOTHERONE nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_3" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, ANOTHER_TYPE_CODE nvarchar(240) not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_ext_node" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, CUST1 nvarchar(240), CUST2 nvarchar(240), CUST3 nvarchar(240))');
                    })
                    .then(() => {
                        oDB.on('trace', (sql) => {
                            //console.log('SQLite: ' + sql);
                        });
                        resolve();
                    }).catch((e) => {
                    reject(e);
                });
            });
        });
    });

    it("retrieves node metadata from table", () => {
        return oCallerContext.store.getNodeMetadata({
            table: TEST_TABLE
        }).then((oMetadata) => {
            expect(oMetadata).to.eql({
                table: TEST_TABLE,
                primaryKeys: ['ID'],
                attributes: {
                    ID: {
                        name: 'ID',
                        dataType: Metadata.DataType.Integer,
                        dbDataType: "INTEGER",
                        required: true,
                        isPrimaryKey: true
                    },
                    TITLE: {
                        name: 'TITLE',
                        dataType: Metadata.DataType.String,
                        dbDataType: "NVARCHAR",
                        required: true,
                        maxLength: 240,
                        isPrimaryKey: false
                    },
                    DESCRIPTION: {
                        name: 'DESCRIPTION',
                        dataType: Metadata.DataType.String,
                        dbDataType: "NVARCHAR",
                        required: false,
                        maxLength: 1000,
                        isPrimaryKey: false
                    }
                }
            });
        });
    });


    it("builds application object metadata based on table metadata", () => {

        var fnOnCreate = () => {
        };
        var fnOnPrepareCopy = () => {
        };
        var fnOnCopy = () => {
        };
        var fnOnUpdate = () => {
        };
        var fnOnModify = () => {
        };
        var fnOnDelete = () => {
        };
        var fnOnRead = () => {
        };
        var fnOnPersist = () => {
        };

        var fnCheckRoot = () => {
        };
        var fnCheckNode1 = () => {
        };
        var fnCheckNode2 = () => {
        };
        var fnCheckNode21 = () => {
        };
        var fnCheckAttr = () => {
        };

        var fnCheckReadOnly = () => {
        };

        var oDefinition = {
            Root: {
                table: TEST_TABLE,
                sequence: "sap.aof.test.db.test::s_test",
                historyTable: "sap.aof.test.db.test::t_test_h",
                determinations: {
                    onCreate: [fnOnCreate],
                    onPrepareCopy: [fnOnPrepareCopy],
                    onCopy: [fnOnCopy],
                    onUpdate: [fnOnUpdate],
                    onModify: [fnOnModify],
                    onDelete: [fnOnDelete],
                    onRead: [fnOnRead],
                    onPersist: [fnOnPersist]
                },
                consistencyChecks: [fnCheckRoot],
                inputChecks: [fnCheckRoot],
                attributes: {
                    TITLE: {
                        consistencyChecks: [fnCheckAttr],
                        inputChecks: [fnCheckAttr]
                    },
                    DESCRIPTION: {
                        foreignKeyTo: "DummyDescriptionAO"
                    }
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnCheckNode1],
                        inputChecks: [fnCheckNode1],
                        attributes: {
                            ID: {
                                // this is redundant to table information, but should be allowed as well
                                isPrimaryKey: true
                            }
                        }
                    },
                    Node2: {
                        table: "sap.aof.test.db.test::t_test_node_2",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnCheckNode2],
                        inputChecks: [fnCheckNode2],
                        readOnly: fnCheckReadOnly,
                        nodes: {
                            Node21: {
                                table: "sap.aof.test.db.test::t_test_node_2_1",
                                parentKey: "PARENT_ID",
                                consistencyChecks: [fnCheckNode21],
                                inputChecks: [fnCheckNode21],
                                attributes: {
                                    SOMETEXT: {
                                        consistencyChecks: [fnCheckAttr],
                                        inputChecks: [fnCheckAttr],
                                        readOnly: fnCheckReadOnly
                                    },
                                    ANOTHERONE: {
                                        readOnly: true
                                    }
                                }
                            }
                        }
                    },
                    Node3: {
                        table: "sap.aof.test.db.test::t_test_node_3",
                        parentKey: "OBJECT_ID",
                        readOnly: true,
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "AOF_TYPE"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "AOF_SUB_TYPE",
                                readOnly: true
                            }
                        }
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    executionCheck: () => {

                    },
                    persist: () => {

                    },
                    historyEvent: "TEST_CREATED"
                },
                copy: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    executionCheck: () => {
                    },
                    persist: () => {
                    },
                    historyEvent: "TEST_COPIED"
                },

                update: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    historyEvent: "TEST_UPDATED"
                },
                del: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    historyEvent: "TEST_DELETED"
                },
                read: {
                    authorizationCheck: false
                },
                customAction: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    execute: () => {
                    },
                    historyEvent: "TEST_CUSTOM_ACTION_DONE"
                }
            }
        };

        return Metadata._getObjectMetadata("sap.aof.test.db.test.TestAO", oCallerContext, oDefinition)
            .then((oMetadata) => {
                var oExpectedMetadata = {
                    schemaScope: "",
                    type: Metadata.ObjectType.Standard,
                    name: "sap.aof.test.db.test.TestAO",
                    isExtensible: false,
                    isConcurrencyControlEnabled: false,
                    cascadeDelete: [],
                    label: "",
                    actions: {
                        create: {
                            name: Metadata.Action.Create,
                            authorizationCheck: oDefinition.actions.create.authorizationCheck,
                            enabledCheck: oDefinition.actions.create.enabledCheck,
                            executionCheck: oDefinition.actions.create.executionCheck,
                            persist: oDefinition.actions.create.persist,
                            isFrameworkAction: true,
                            isExposed: true,
                            label: "",
                            isStatic: true,
                            isInternal: false,
                            historyEvent: "TEST_CREATED",
                            readOnly: false
                        },
                        copy: {
                            name: Metadata.Action.Copy,
                            authorizationCheck: oDefinition.actions.copy.authorizationCheck,
                            enabledCheck: oDefinition.actions.copy.enabledCheck,
                            executionCheck: oDefinition.actions.copy.executionCheck,
                            persist: oDefinition.actions.copy.persist,
                            isFrameworkAction: true,
                            isExposed: true,
                            label: "",
                            isStatic: false,
                            isInternal: false,
                            historyEvent: "TEST_COPIED",
                            readOnly: false
                        },
                        update: {
                            name: Metadata.Action.Update,
                            authorizationCheck: oDefinition.actions.update.authorizationCheck,
                            enabledCheck: oDefinition.actions.update.enabledCheck,
                            isFrameworkAction: true,
                            isExposed: true,
                            label: "",
                            isStatic: false,
                            isInternal: false,
                            historyEvent: "TEST_UPDATED",
                            readOnly: false
                        },
                        del: {
                            name: Metadata.Action.Del,
                            authorizationCheck: oDefinition.actions.del.authorizationCheck,
                            enabledCheck: oDefinition.actions.del.enabledCheck,
                            isFrameworkAction: true,
                            isExposed: true,
                            label: "",
                            isStatic: false,
                            isInternal: false,
                            historyEvent: "TEST_DELETED",
                            readOnly: false
                        },
                        read: {
                            name: Metadata.Action.Read,
                            authorizationCheck: oDefinition.actions.read.authorizationCheck,
                            isFrameworkAction: true,
                            isExposed: true,
                            label: "",
                            isStatic: false,
                            isInternal: false,
                            readOnly: true
                        },
                        customAction: {
                            name: 'customAction',
                            authorizationCheck: oDefinition.actions.customAction.authorizationCheck,
                            enabledCheck: oDefinition.actions.customAction.enabledCheck,
                            execute: oDefinition.actions.customAction.execute,
                            isFrameworkAction: false,
                            isExposed: true,
                            label: "",
                            isStatic: false,
                            isInternal: false,
                            historyEvent: "TEST_CUSTOM_ACTION_DONE",
                            readOnly: false
                        }
                    },
                    nodes: {
                        Root: {
                            name: Metadata.Node.Root,
                            parentNode: undefined,
                            subNodes: ["Node1", "Node2", "Node3"],
                            table: "sap.aof.test.db.test::t_test",
                            historyTable: "sap.aof.test.db.test::t_test_h",
                            sequence: "sap.aof.test.db.test::s_test",
                            primaryKey: "ID",
                            isDatabasePrimaryKey: true,
                            externalKey: false,
                            persistedAttributes: ['ID', 'TITLE', 'DESCRIPTION'],
                            transientAttributes: [],
                            concurrencyControlAttributes: [],
                            hiddenAttributes: {},
                            label: "",
                            nameAttribute: null,
                            alternativeKeyAttribute: null,
                            constantKeys: {},
                            determinations: {
                                onCreate: [fnOnCreate],
                                onPrepareCopy: [fnOnPrepareCopy],
                                onCopy: [fnOnCopy],
                                onUpdate: [fnOnUpdate],
                                onModify: [fnOnModify],
                                onDelete: [fnOnDelete],
                                onRead: [fnOnRead],
                                onPersist: [fnOnPersist]
                            },
                            readOnly: false,
                            consistencyChecks: [fnCheckRoot],
                            inputChecks: [fnCheckRoot],
                            attributes: {
                                ID: {
                                    name: 'ID',
                                    dataType: Metadata.DataType.Integer,
                                    dbDataType: "INTEGER",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    isPrimaryKey: true,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                TITLE: {
                                    name: 'TITLE',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [fnCheckAttr],
                                    inputChecks: [fnCheckAttr],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                DESCRIPTION: {
                                    name: 'DESCRIPTION',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: false,
                                    maxLength: 1000,
                                    isPrimaryKey: false,
                                    readOnly: false,
                                    persisted: true,
                                    foreignKeyTo: "DummyDescriptionAO",
                                    foreignKeyIntraObject: false,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                }
                            }
                        },
                        Node1: {
                            name: 'Node1',
                            parentNode: "Root",
                            parentKey: "PARENT_ID",
                            subNodes: [],
                            primaryKey: "ID",
                            isDatabasePrimaryKey: true,
                            externalKey: false,
                            table: "sap.aof.test.db.test::t_test_node_1",
                            historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                            persistedAttributes: ['ID', 'PARENT_ID', 'SOMETEXT'],
                            transientAttributes: [],
                            concurrencyControlAttributes: [],
                            hiddenAttributes: {},
                            label: "",
                            nameAttribute: null,
                            alternativeKeyAttribute: null,
                            constantKeys: {},
                            consistencyChecks: [fnCheckNode1],
                            inputChecks: [fnCheckNode1],
                            readOnly: false,
                            attributes: {
                                ID: {
                                    name: 'ID',
                                    dataType: Metadata.DataType.Integer,
                                    dbDataType: "INTEGER",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    isPrimaryKey: true,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                SOMETEXT: {
                                    name: 'SOMETEXT',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                }
                            }
                        },
                        Node2: {
                            name: "Node2",
                            parentNode: "Root",
                            parentKey: "PARENT_ID",
                            subNodes: ["Node21"],
                            table: "sap.aof.test.db.test::t_test_node_2",
                            primaryKey: 'ID',
                            isDatabasePrimaryKey: true,
                            externalKey: false,
                            persistedAttributes: ['ID', 'PARENT_ID', 'SOMETEXT'],
                            transientAttributes: [],
                            concurrencyControlAttributes: [],
                            hiddenAttributes: {},
                            label: "",
                            nameAttribute: null,
                            alternativeKeyAttribute: null,
                            constantKeys: {},
                            consistencyChecks: [fnCheckNode2],
                            inputChecks: [fnCheckNode2],
                            readOnly: false,
                            checkReadOnly: fnCheckReadOnly,
                            attributes: {
                                ID: {
                                    name: 'ID',
                                    dataType: Metadata.DataType.Integer,
                                    dbDataType: "INTEGER",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    isPrimaryKey: true,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                SOMETEXT: {
                                    name: 'SOMETEXT',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                }
                            }
                        },
                        Node21: {
                            name: "Node21",
                            parentNode: "Node2",
                            parentKey: "PARENT_ID",
                            subNodes: [],
                            table: "sap.aof.test.db.test::t_test_node_2_1",
                            primaryKey: 'ID',
                            isDatabasePrimaryKey: true,
                            externalKey: false,
                            persistedAttributes: ['ID', 'PARENT_ID', 'SOMETEXT', 'ANOTHERONE'],
                            transientAttributes: [],
                            concurrencyControlAttributes: [],
                            hiddenAttributes: {},
                            label: "",
                            nameAttribute: null,
                            alternativeKeyAttribute: null,
                            constantKeys: {},
                            consistencyChecks: [fnCheckNode21],
                            inputChecks: [fnCheckNode21],
                            readOnly: false,
                            attributes: {
                                ID: {
                                    name: 'ID',
                                    dataType: Metadata.DataType.Integer,
                                    dbDataType: "INTEGER",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    isPrimaryKey: true,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                SOMETEXT: {
                                    name: 'SOMETEXT',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [fnCheckAttr],
                                    inputChecks: [fnCheckAttr],
                                    checkReadOnly: fnCheckReadOnly,
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                ANOTHERONE: {
                                    name: 'ANOTHERONE',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: false,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    readOnly: true,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                }
                            }
                        },
                        Node3: {
                            name: "Node3",
                            parentNode: "Root",
                            parentKey: "OBJECT_ID",
                            subNodes: [],
                            table: "sap.aof.test.db.test::t_test_node_3",
                            primaryKey: "ID",
                            isDatabasePrimaryKey: true,
                            externalKey: false,
                            persistedAttributes: ['ID', 'OBJECT_ID', 'OBJECT_TYPE_CODE', 'ANOTHER_TYPE_CODE', 'SOMETEXT'],
                            transientAttributes: [],
                            concurrencyControlAttributes: [],
                            hiddenAttributes: {},
                            label: "",
                            nameAttribute: null,
                            alternativeKeyAttribute: null,
                            constantKeys: {
                                OBJECT_TYPE_CODE: "AOF_TYPE",
                                ANOTHER_TYPE_CODE: "AOF_SUB_TYPE"
                            },
                            consistencyChecks: [],
                            inputChecks: [],
                            readOnly: true,
                            attributes: {
                                ID: {
                                    name: 'ID',
                                    dataType: Metadata.DataType.Integer,
                                    dbDataType: "INTEGER",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    isPrimaryKey: true,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                OBJECT_TYPE_CODE: {
                                    name: 'OBJECT_TYPE_CODE',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    constantKey: "AOF_TYPE",
                                    readOnly: true,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                ANOTHER_TYPE_CODE: {
                                    name: 'ANOTHER_TYPE_CODE',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: true,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    constantKey: "AOF_SUB_TYPE",
                                    readOnly: true,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                },
                                SOMETEXT: {
                                    name: 'SOMETEXT',
                                    dataType: Metadata.DataType.String,
                                    dbDataType: "NVARCHAR",
                                    isConstant: false,
                                    isAlternativeKey: false,
                                    required: true,
                                    maxLength: 240,
                                    isPrimaryKey: false,
                                    readOnly: false,
                                    persisted: true,
                                    consistencyChecks: [],
                                    inputChecks: [],
                                    label: "",
                                    isName: false,
                                    isDescription: false
                                }
                            }
                        }
                    }
                };
                _.sortByKeys(oMetadata);
                _.sortByKeys(oExpectedMetadata);
                expect(oMetadata).to.eql(oExpectedMetadata);
            });
    });

    it("allows overriding the primary key from the database", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        isPrimaryKey: true
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition)
            .then((oMetadata) => {
                expect(oMetadata.nodes.Root.primaryKey).to.equal("TITLE");
                expect(oMetadata.nodes.Root.isDatabasePrimaryKey).to.equal(false);
                expect(oMetadata.nodes.Root.attributes.TITLE.isPrimaryKey).to.equal(true);
                expect(oMetadata.nodes.Root.attributes.ID.isPrimaryKey).to.equal(false);
            });
    });

    it("allows definition of transient attributes", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    DESCRIPTION: {
                        required: true
                    },
                    TRANSIENT_ATTRIBUTE_1: {
                        required: true
                    },
                    TRANSIENT_ATTRIBUTE_2: {
                        required: false,
                        readOnly: true
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes).to.eql({
                ID: {
                    name: "ID",
                    dataType: Metadata.DataType.Integer,
                    dbDataType: "INTEGER",
                    isConstant: true,
                    isAlternativeKey: false,
                    required: true,
                    isPrimaryKey: true,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TITLE: {
                    name: "TITLE",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isConstant: false,
                    isAlternativeKey: false,
                    required: true,
                    maxLength: 240,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                DESCRIPTION: {
                    name: "DESCRIPTION",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isConstant: false,
                    isAlternativeKey: false,
                    required: true,
                    maxLength: 1000,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TRANSIENT_ATTRIBUTE_1: {
                    name: "TRANSIENT_ATTRIBUTE_1",
                    isConstant: false,
                    isPrimaryKey: false,
                    isAlternativeKey: false,
                    readOnly: false,
                    required: true,
                    persisted: false,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TRANSIENT_ATTRIBUTE_2: {
                    name: "TRANSIENT_ATTRIBUTE_2",
                    isConstant: false,
                    isPrimaryKey: false,
                    isAlternativeKey: false,
                    readOnly: true,
                    required: false,
                    persisted: false,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                }
            });

            expect(oMetadata.nodes.Root.persistedAttributes.sort()).to.eql(["DESCRIPTION", "ID", "TITLE"]);
            expect(oMetadata.nodes.Root.transientAttributes.sort()).to.eql(["TRANSIENT_ATTRIBUTE_1", "TRANSIENT_ATTRIBUTE_2"]);
        });
    });

    it("allows definition of concurrent attributes", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test_concurrency",
                attributes: {
                    CHANGED_AT: {
                        concurrencyControl: true
                    },
                    // Title is just used to test that multiple concurrency attributes can be used
                    TITLE: {
                        concurrencyControl: true
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.concurrencyControlAttributes).to.eql(["CHANGED_AT", "TITLE"]);
            expect(oMetadata.nodes.Root.attributes.CHANGED_AT.concurrencyControl).to.eql(true);
            expect(oMetadata.isConcurrencyControlEnabled).to.eql(true);
        });
    });

    it("authorization check needs to be explicitly set", () => {
        var oDefinition = {
            actions: {
                create: {},
                update: {},
                del: {},
                copy: {},
                customAction: {
                    execute: () => {
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).catch((e) => {
            expect(e.message).to.eql("Action 'create' needs authorizationCheck to be defined");
            return Promise.reject();
        }).then((oMetadata) => {
            expect(oMetadata).to.be.undefined; // as an error should be thrown
        }).catch((oError) => {
        });
    });

    it("handles custom action, node and attributes properties", () => {
        var oDefinition = {
            actions: {
                myAction: {
                    authorizationCheck: false,
                    execute: () => {
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.myAction.customProperties).to.eql(oDefinition.actions.myAction.customProperties);
            expect(oMetadata.nodes.Root.customProperties).to.eql(oDefinition.Root.customProperties);
            expect(oMetadata.nodes.Root.attributes.TITLE.customProperties).to.eql(oDefinition.Root.attributes.TITLE.customProperties);
        }).then(() => {
            var oDefinition = {
                actions: {
                    myAction: {
                        authorizationCheck: false,
                        execute: () => {
                        },
                        customProperties: () => {
                        }
                    }
                },
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    attributes: {
                        TITLE: {
                            customProperties: () => {
                            }
                        }
                    },
                    customProperties: () => {
                    }
                }
            };

            return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
                expect(oMetadata.actions.myAction.customProperties).to.eql(oDefinition.actions.myAction.customProperties);
                expect(oMetadata.nodes.Root.customProperties).to.eql(oDefinition.Root.customProperties);
                expect(oMetadata.nodes.Root.attributes.TITLE.customProperties).to.eql(oDefinition.Root.attributes.TITLE.customProperties);
            });
        });
    });


    it("returns activation check used for configuration activation", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                activationCheck: () => {
                }
            }
        };
        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.activationCheck).to.eql(oDefinition.Root.activationCheck);
        });
    });

    it("allows explicit attribute definition flag", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                explicitAttributeDefinition: true,
                attributes: {
                    TITLE: {}
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        parentKey: "PARENT_ID"
                    },
                    Node3: {
                        table: "sap.aof.test.db.test::t_test_node_3",
                        parentKey: "OBJECT_ID",
                        explicitAttributeDefinition: true,
                        attributes: {
                            SOMETEXT: {}
                        }
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.ID).to.be.ok;
            expect(oMetadata.nodes.Root.attributes.TITLE).to.be.ok;
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION === undefined).to.eql(true);

            expect(oMetadata.nodes.Node1.attributes.ID).to.be.ok;
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT).to.be.ok;

            expect(oMetadata.nodes.Node3.attributes.ID).to.be.ok;
            expect(oMetadata.nodes.Node3.attributes.SOMETEXT).to.be.ok;
            expect(oMetadata.nodes.Node3.attributes.OBJECT_TYPE_CODE === undefined).to.eql(true);
            expect(oMetadata.nodes.Node3.attributes.ANOTHER_TYPE_CODE === undefined).to.eql(true);
        });
    });

    it("allows to define an object as extensible", () => {
        var oDefinition = {
            isExtensible: true,
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.isExtensible).to.be.ok;
            expect(oMetadata.isExtensible).to.eql(true);
        });
    });

    it("allows to extend an object (multiple times)", () => {

        var fnCoreConsistencyCheckNode2 = () => {
        };

        var fnCoreInputCheckNode2 = () => {
        };

        var fnCoreAttrConsistencyCheckNode1 = () => {
        };

        var fnCoreAttrInputCheckNode1 = () => {
        };

        var fnCoreDetCreate = () => {
        };

        var fnCoreDetModify = () => {
        };

        var fnCoreDetDelete = () => {
        };

        var oCoreActionChecks = {
            updateEnabledCheck: () => {
            },
            customActionEnabledCheck: () => {
            },
            deleteEnabledCheck: () => {
            },
            updateExecutionCheck: () => {
            },
            deleteExecutionCheck: () => {
            }
        };

        var oCoreActionExecutes = {
            customActionExecute: () => {
            },
            customAction2Execute: () => {
            }
        };

        var oCoreReadOnly = {
            nodeReadOnly: () => {
                return false;
            },
            attributeReadOnly: () => {
                return true;
            }
        };

        var oCoreProperties = {
            nodeProperties: () => {
                return {
                    val1: "a",
                    val2: "b"
                };
            },
            actionProperties: () => {
                return {
                    val3: "c",
                    val4: "d"
                };
            },
            attributeProperties: () => {
                return {
                    val5: "e",
                    val6: "f"
                };
            }
        };

        sinon.spy(oCoreActionChecks, 'updateEnabledCheck');
        sinon.spy(oCoreActionChecks, 'customActionEnabledCheck');
        sinon.spy(oCoreActionChecks, 'deleteEnabledCheck');
        sinon.spy(oCoreActionChecks, 'updateExecutionCheck');
        sinon.spy(oCoreActionChecks, 'deleteExecutionCheck');
        sinon.spy(oCoreActionExecutes, 'customActionExecute');
        sinon.spy(oCoreActionExecutes, 'customAction2Execute');

        var oCoreDefinition = {
            isExtensible: true,
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    enabledCheck: oCoreActionChecks.updateEnabledCheck,
                    executionCheck: oCoreActionChecks.updateExecutionCheck,
                    authorizationCheck: false
                },
                del: {
                    enabledCheck: oCoreActionChecks.deleteEnabledCheck,
                    executionCheck: oCoreActionChecks.deleteExecutionCheck,
                    authorizationCheck: false
                },
                customAction: {
                    enabledCheck: oCoreActionChecks.customActionEnabledCheck,
                    execute: oCoreActionExecutes.customActionExecute,
                    authorizationCheck: false,
                    customProperties: {
                        x: 4712,
                        y: "DEF"
                    }
                },
                customAction2: {
                    execute: oCoreActionExecutes.customAction2Execute,
                    customProperties: oCoreProperties.actionProperties,
                    authorizationCheck: false
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                determinations: {
                    onCreate: [fnCoreDetCreate],
                    onModify: [fnCoreDetModify],
                    onDelete: [fnCoreDetDelete]
                },
                attributes: {
                    TITLE: {
                        readOnly: true,
                        customProperties: {
                            o: 4713,
                            p: "KLM"
                        }
                    }
                },
                customProperties: {
                    x: 4711,
                    y: "ABC"
                }
            },
            nodes: {
                Node1: {
                    table: "sap.aof.test.db.test::t_test_node_1",
                    parentKey: "PARENT_ID",
                    readOnly: true,
                    attributes: {
                        SOMETEXT: {
                            consistencyChecks: [fnCoreAttrConsistencyCheckNode1],
                            inputChecks: [fnCoreAttrInputCheckNode1],
                            readOnly: oCoreReadOnly.attributeReadOnly,
                            customProperties: oCoreProperties.attributeProperties
                        }
                    },
                    customProperties: oCoreProperties.nodeProperties
                },
                Node2: {
                    table: "sap.aof.test.db.test::t_test_node_2",
                    parentKey: "PARENT_ID",
                    readOnly: oCoreReadOnly.nodeReadOnly,
                    consistencyChecks: [fnCoreConsistencyCheckNode2],
                    inputChecks: [fnCoreInputCheckNode2]
                },
                Ext: {
                    table: "sap.aof.test.db.test::t_test_ext_node",
                    parentKey: "OBJECT_ID",
                    explicitAttributeDefinition: true,
                    attributes: {
                        OBJECT_TYPE_CODE: {
                            constantKey: "TEST_OBJECT"
                        }
                    }
                }
            }
        };

        var fnExtensionConsistencyCheckRoot = () => {
        };

        var fnExtensionConsistencyCheckNode2 = () => {
        };

        var fnExtensionAttrConsistencyCheckRoot = () => {
        };

        var fnExtensionAttrConsistencyCheckNode1 = () => {
        };

        var fnExtensionInputCheckRoot = () => {
        };

        var fnExtensionInputCheckNode2 = () => {
        };

        var fnExtensionAttrInputCheckRoot = () => {
        };

        var fnExtensionAttrInputCheckNode1 = () => {
        };

        var fnExtensionDetCreate = () => {
        };

        var fnExtensionDetPersist = () => {
        };

        var oExtActionChecks = {
            createEnabledCheck: () => {
            },
            updateEnabledCheck: () => {
            },
            customActionEnabledCheck: () => {
            },
            createExecutionCheck: () => {
            },
            updateExecutionCheck: () => {
            }
        };

        var oExtActionExecutes = {
            customActionExecute: () => {
            }
        };

        var oExtReadOnly = {
            nodeReadOnly: () => {
                return true;
            },
            attributeReadOnly: () => {
                return false;
            },
            attributeReadOnly2: () => {
                return true;
            }
        };

        var oExtProperties = {
            nodeProperties: () => {
                return {
                    extVal1: "z",
                    extVal2: "x"
                };
            },
            actionProperties: () => {
                return {
                    extVal3: "y",
                    extVal4: "w"
                };
            },
            attributeProperties: () => {
                return {
                    extVal5: "v",
                    extVal6: "q"
                };
            }
        };

        sinon.spy(oExtActionChecks, 'createEnabledCheck');
        sinon.spy(oExtActionChecks, 'updateEnabledCheck');
        sinon.spy(oExtActionChecks, 'customActionEnabledCheck');
        sinon.spy(oExtActionChecks, 'createExecutionCheck');
        sinon.spy(oExtActionChecks, 'updateExecutionCheck');
        sinon.spy(oExtActionExecutes, 'customActionExecute');

        var oExtensionDefinition = {
            actions: {
                create: {
                    enabledCheck: oExtActionChecks.createEnabledCheck,
                    executionCheck: oExtActionChecks.createExecutionCheck
                },
                update: {
                    enabledCheck: oExtActionChecks.updateEnabledCheck,
                    executionCheck: oExtActionChecks.updateExecutionCheck,
                    customProperties: oExtProperties.actionProperties
                },
                customAction: {
                    enabledCheck: oExtActionChecks.customActionEnabledCheck,
                    execute: oExtActionExecutes.customActionExecute,
                    customProperties: {
                        x: 4711,
                        extZ: 4712,
                        extW: "ZYX"
                    }
                }
            },
            Root: {
                consistencyChecks: [fnExtensionConsistencyCheckRoot],
                inputChecks: [fnExtensionInputCheckRoot],
                determinations: {
                    onCreate: [fnExtensionDetCreate],
                    onPersist: [fnExtensionDetPersist]
                },
                readOnly: true,
                attributes: {
                    DESCRIPTION: {
                        required: true,
                        readOnly: oExtReadOnly.attributeReadOnly2
                    },
                    TITLE: {
                        consistencyChecks: [fnExtensionAttrConsistencyCheckRoot],
                        inputChecks: [fnExtensionAttrInputCheckRoot],
                        customProperties: oExtProperties.attributeProperties
                    }
                },
                customProperties: oExtProperties.nodeProperties,
                nodes: {
                    Node1: {
                        readOnly: false,
                        attributes: {
                            SOMETEXT: {
                                required: true,
                                consistencyChecks: [fnExtensionAttrConsistencyCheckNode1],
                                inputChecks: [fnExtensionAttrInputCheckNode1],
                                readOnly: oExtReadOnly.attributeReadOnly,
                                customProperties: {
                                    extU: 4715,
                                    extB: "OK"
                                }
                            }
                        },
                        customProperties: {
                            extX: 4711,
                            extY: "ABC"
                        }
                    },
                    Node2: {
                        consistencyChecks: [fnExtensionConsistencyCheckNode2],
                        inputChecks: [fnExtensionInputCheckNode2],
                        readOnly: oExtReadOnly.nodeReadOnly,
                        attributes: {
                            SOMETEXT: {
                                readOnly: true
                            }
                        }
                    },
                    Ext: {
                        attributes: {
                            CUST1: {
                                foreignKeyTo: "sap.ino.xs.object.User.Root",
                                required: true,
                                readOnly: true,
                                maxLength: 200
                            }
                        }
                    }
                }
            }
        };

        var fnExtension2ConsistencyCheckRoot = () => {
        };

        var fnExtension2ConsistencyCheckNode2 = () => {
        };

        var fnExtension2AttrConsistencyCheckRoot = () => {
        };

        var fnExtension2AttrConsistencyCheckNode1 = () => {
        };

        var fnExtension2InputCheckRoot = () => {
        };

        var fnExtension2InputCheckNode2 = () => {
        };

        var fnExtension2AttrInputCheckRoot = () => {
        };

        var fnExtension2AttrInputCheckNode1 = () => {
        };

        var fnExtension2DetCreate = () => {
        };

        var fnExtension2DetPersist = () => {
        };

        var oExt2ActionChecks = {
            createEnabledCheck: () => {
            },
            updateEnabledCheck: () => {
            },
            customActionEnabledCheck: () => {
            },
            createExecutionCheck: () => {
            },
            updateExecutionCheck: () => {
            }
        };

        var oExt2ActionExecutes = {
            customActionExecute: () => {
            }
        };

        var oExt2ReadOnly = {
            nodeReadOnly: () => {
                return true;
            },
            attributeReadOnly: () => {
                return false;
            },
            attributeReadOnly2: () => {
                return true;
            }
        };

        var oExt2Properties = {
            nodeProperties: () => {
                return {
                    ext2Val1: "z2",
                    ext2Val2: "x2"
                };
            },
            actionProperties: () => {
                return {
                    ext2Val3: "y2",
                    ext2Val4: "w2"
                };
            },
            attributeProperties: () => {
                return {
                    ext2Val5: "v2",
                    ext2Val6: "q2"
                };
            }
        };

        sinon.spy(oExt2ActionChecks, 'createEnabledCheck');
        sinon.spy(oExt2ActionChecks, 'updateEnabledCheck');
        sinon.spy(oExt2ActionChecks, 'customActionEnabledCheck');
        sinon.spy(oExt2ActionChecks, 'createExecutionCheck');
        sinon.spy(oExt2ActionChecks, 'updateExecutionCheck');
        sinon.spy(oExt2ActionExecutes, 'customActionExecute');

        var oExtension2Definition = {
            actions: {
                create: {
                    enabledCheck: oExt2ActionChecks.createEnabledCheck,
                    executionCheck: oExt2ActionChecks.createExecutionCheck
                },
                update: {
                    enabledCheck: oExt2ActionChecks.updateEnabledCheck,
                    executionCheck: oExt2ActionChecks.updateExecutionCheck,
                    customProperties: oExt2Properties.actionProperties
                },
                customAction: {
                    enabledCheck: oExt2ActionChecks.customActionEnabledCheck,
                    execute: oExt2ActionExecutes.customActionExecute,
                    customProperties: {
                        x2: 47112,
                        ext2Z: 47122,
                        ext2W: "ZYX2"
                    }
                }
            },
            Root: {
                consistencyChecks: [fnExtension2ConsistencyCheckRoot],
                inputChecks: [fnExtension2InputCheckRoot],
                determinations: {
                    onCreate: [fnExtension2DetCreate],
                    onPersist: [fnExtension2DetPersist]
                },
                readOnly: true,
                attributes: {
                    DESCRIPTION: {
                        required: true,
                        readOnly: oExt2ReadOnly.attributeReadOnly2
                    },
                    TITLE: {
                        consistencyChecks: [fnExtension2AttrConsistencyCheckRoot],
                        inputChecks: [fnExtension2AttrInputCheckRoot],
                        customProperties: oExt2Properties.attributeProperties
                    }
                },
                customProperties: oExt2Properties.nodeProperties,
                nodes: {
                    Node1: {
                        readOnly: false,
                        attributes: {
                            SOMETEXT: {
                                required: true,
                                consistencyChecks: [fnExtension2AttrConsistencyCheckNode1],
                                inputChecks: [fnExtension2AttrInputCheckNode1],
                                readOnly: oExt2ReadOnly.attributeReadOnly,
                                customProperties: {
                                    ext2U: 47152,
                                    ext2B: "OK2"
                                }
                            }
                        },
                        customProperties: {
                            ext2X: 47112,
                            ext2Y: "ABC2"
                        }
                    },
                    Node2: {
                        consistencyChecks: [fnExtension2ConsistencyCheckNode2],
                        inputChecks: [fnExtension2InputCheckNode2],
                        readOnly: oExt2ReadOnly.nodeReadOnly,
                        attributes: {
                            SOMETEXT: {
                                readOnly: true
                            }
                        }
                    },
                    Ext: {
                        attributes: {
                            CUST2: {
                                foreignKeyTo: "sap.ino.xs.object.User.Root",
                                required: true,
                                readOnly: true,
                                maxLength: 200
                            }
                        }
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oCoreDefinition, [oExtensionDefinition, oExtension2Definition]).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION.required).to.eql(true);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.required).to.eql(true);

            expect(oMetadata.nodes.Root.consistencyChecks[0]).to.eql(fnExtensionConsistencyCheckRoot);
            expect(oMetadata.nodes.Root.consistencyChecks[1]).to.eql(fnExtension2ConsistencyCheckRoot);
            expect(oMetadata.nodes.Node2.consistencyChecks[0]).to.eql(fnCoreConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.consistencyChecks[1]).to.eql(fnExtensionConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.consistencyChecks[2]).to.eql(fnExtension2ConsistencyCheckNode2);

            expect(oMetadata.nodes.Root.inputChecks[0]).to.eql(fnExtensionInputCheckRoot);
            expect(oMetadata.nodes.Root.inputChecks[1]).to.eql(fnExtension2InputCheckRoot);
            expect(oMetadata.nodes.Node2.inputChecks[0]).to.eql(fnCoreInputCheckNode2);
            expect(oMetadata.nodes.Node2.inputChecks[1]).to.eql(fnExtensionInputCheckNode2);
            expect(oMetadata.nodes.Node2.inputChecks[2]).to.eql(fnExtension2InputCheckNode2);


            expect(oMetadata.nodes.Root.attributes.TITLE.consistencyChecks[0]).to.eql(fnExtensionAttrConsistencyCheckRoot);
            expect(oMetadata.nodes.Root.attributes.TITLE.consistencyChecks[1]).to.eql(fnExtension2AttrConsistencyCheckRoot);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.consistencyChecks[0]).to.eql(fnCoreAttrConsistencyCheckNode1);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.consistencyChecks[1]).to.eql(fnExtensionAttrConsistencyCheckNode1);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.consistencyChecks[2]).to.eql(fnExtension2AttrConsistencyCheckNode1);

            expect(oMetadata.nodes.Root.attributes.TITLE.inputChecks[0]).to.eql(fnExtensionAttrInputCheckRoot);
            expect(oMetadata.nodes.Root.attributes.TITLE.inputChecks[1]).to.eql(fnExtension2AttrInputCheckRoot);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.inputChecks[0]).to.eql(fnCoreAttrInputCheckNode1);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.inputChecks[1]).to.eql(fnExtensionAttrInputCheckNode1);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.inputChecks[2]).to.eql(fnExtension2AttrInputCheckNode1);

            expect(oMetadata.nodes.Root.determinations.onCreate[0]).to.eql(fnCoreDetCreate);
            expect(oMetadata.nodes.Root.determinations.onCreate[1]).to.eql(fnExtensionDetCreate);
            expect(oMetadata.nodes.Root.determinations.onCreate[2]).to.eql(fnExtension2DetCreate);
            expect(oMetadata.nodes.Root.determinations.onModify[0]).to.eql(fnCoreDetModify);
            expect(oMetadata.nodes.Root.determinations.onDelete[0]).to.eql(fnCoreDetDelete);
            expect(oMetadata.nodes.Root.determinations.onPersist[0]).to.eql(fnExtensionDetPersist);
            expect(oMetadata.nodes.Root.determinations.onPersist[1]).to.eql(fnExtension2DetPersist);

            // Enabled checks
            oMetadata.actions.create.enabledCheck();
            oMetadata.actions.update.enabledCheck();
            oMetadata.actions.del.enabledCheck();
            oMetadata.actions.customAction.enabledCheck();

            expect(oCoreActionChecks.updateEnabledCheck.called).to.be.ok;
            expect(oCoreActionChecks.deleteEnabledCheck.called).to.be.ok;
            expect(oCoreActionChecks.customActionEnabledCheck.called).to.be.ok;
            expect(oExtActionChecks.createEnabledCheck.called).to.be.ok;
            expect(oExtActionChecks.updateEnabledCheck.called).to.be.ok;
            expect(oExtActionChecks.customActionEnabledCheck.called).to.be.ok;
            expect(oExt2ActionChecks.createEnabledCheck.called).to.be.ok;
            expect(oExt2ActionChecks.updateEnabledCheck.called).to.be.ok;
            expect(oExt2ActionChecks.customActionEnabledCheck.called).to.be.ok;

            // Execution checks
            oMetadata.actions.create.executionCheck();
            oMetadata.actions.update.executionCheck();
            oMetadata.actions.del.executionCheck();

            expect(oCoreActionChecks.updateExecutionCheck.called).to.be.ok;
            expect(oCoreActionChecks.deleteExecutionCheck.called).to.be.ok;
            expect(oExtActionChecks.createExecutionCheck.called).to.be.ok;
            expect(oExtActionChecks.updateExecutionCheck.called).to.be.ok;
            expect(oExt2ActionChecks.createExecutionCheck.called).to.be.ok;
            expect(oExt2ActionChecks.updateExecutionCheck.called).to.be.ok;

            // Execute
            oMetadata.actions.customAction.execute();
            oMetadata.actions.customAction2.execute();

            expect(oCoreActionExecutes.customActionExecute.called).to.be.ok;
            expect(oCoreActionExecutes.customAction2Execute.called).to.be.ok;
            expect(oExtActionExecutes.customActionExecute.called).to.be.ok;
            expect(oExt2ActionExecutes.customActionExecute.called).to.be.ok;

            // Read Only on node
            expect(oMetadata.nodes.Root.readOnly).to.eql(true);
            expect(oMetadata.nodes.Node1.readOnly).to.eql(true);
            expect(oMetadata.nodes.Node2.checkReadOnly()).to.eql(true);

            // Read Only on attribute
            expect(oMetadata.nodes.Root.attributes.TITLE.readOnly).to.eql(true);
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION.checkReadOnly()).to.eql(true);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.checkReadOnly()).to.eql(true);
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.readOnly).to.eql(true);

            // Custom Properties on node
            expect(oMetadata.nodes.Root.customProperties()).to.eql({
                x: 4711,
                y: "ABC",
                extVal1: "z",
                extVal2: "x",
                ext2Val1: "z2",
                ext2Val2: "x2"
            });

            expect(oMetadata.nodes.Node1.customProperties()).to.eql({
                val1: "a",
                val2: "b",
                extX: 4711,
                extY: "ABC",
                ext2X: 47112,
                ext2Y: "ABC2"
            });

            // Custom Properties on action
            expect(oMetadata.actions.update.customProperties()).to.eql({
                extVal3: 'y',
                extVal4: 'w',
                ext2Val3: 'y2',
                ext2Val4: 'w2'
            });
            expect(oMetadata.actions.customAction.customProperties()).to.eql({
                x: 4712,
                x2: 47112,
                y: 'DEF',
                extZ: 4712,
                extW: 'ZYX',
                ext2Z: 47122,
                ext2W: 'ZYX2'
            });
            expect(oMetadata.actions.customAction2.customProperties()).to.eql({
                val3: 'c',
                val4: 'd'
            });

            // Custom Properties on attribute
            expect(oMetadata.nodes.Root.attributes.TITLE.customProperties()).to.eql({
                o: 4713,
                p: 'KLM',
                extVal5: 'v',
                extVal6: 'q',
                ext2Val5: 'v2',
                ext2Val6: 'q2'
            });
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.customProperties()).to.eql({
                val5: 'e',
                val6: 'f',
                extU: 4715,
                extB: 'OK',
                ext2U: 47152,
                ext2B: 'OK2'
            });

            // New attributes
            expect(oMetadata.nodes.Ext.attributes.CUST1).to.be.ok;
            expect(oMetadata.nodes.Ext.attributes.CUST1.foreignKeyTo).to.eql("sap.ino.xs.object.User.Root");
            expect(oMetadata.nodes.Ext.attributes.CUST1.required).to.eql(true);
            expect(oMetadata.nodes.Ext.attributes.CUST1.readOnly).to.eql(true);
            expect(oMetadata.nodes.Ext.attributes.CUST1.dataType).to.eql(Metadata.DataType.String);
            expect(oMetadata.nodes.Ext.attributes.CUST1.maxLength).to.eql(200);

            expect(oMetadata.nodes.Ext.attributes.CUST2).to.be.ok;
            expect(oMetadata.nodes.Ext.attributes.CUST2.foreignKeyTo).to.eql("sap.ino.xs.object.User.Root");
            expect(oMetadata.nodes.Ext.attributes.CUST2.required).to.eql(true);
            expect(oMetadata.nodes.Ext.attributes.CUST2.readOnly).to.eql(true);
            expect(oMetadata.nodes.Ext.attributes.CUST2.dataType).to.eql(Metadata.DataType.String);
            expect(oMetadata.nodes.Ext.attributes.CUST2.maxLength).to.eql(200);
        });
    });

    it("allows to define type for object", () => {
        var ObjectType = Metadata.ObjectType;
        var oDefinition = {
            type: ObjectType.Configuration,
            Root: {
                table: "sap.aof.test.db.test::t_test"
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.type).to.eql(ObjectType.Configuration);

            oDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test"
                }
            };

            return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
                expect(oMetadata.type).to.eql(ObjectType.Standard);
            });
        });
    });

    it("allows to define additional attribute constraints", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test_2",
                attributes: {
                    INT_01: {
                        minValue: 2,
                        maxValue: 3
                    },
                    DOUBLE_01: {
                        minValue: 2.3,
                        maxValue: 3.5
                    },
                    TEXT_01: {
                        maxLength: 444
                    },
                    TEXT_02: {
                        maxLength: 444
                    },
                    TS_01: {
                        minValue: 545
                    },
                    DATE_01: {
                        maxValue: 6565
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.INT_01.minValue).to.eql(2);
            expect(oMetadata.nodes.Root.attributes.INT_01.maxValue).to.eql(3);
            expect(oMetadata.nodes.Root.attributes.DOUBLE_01.minValue).to.eql(2.3);
            expect(oMetadata.nodes.Root.attributes.DOUBLE_01.maxValue).to.eql(3.5);
            expect(oMetadata.nodes.Root.attributes.TEXT_01.maxLength).to.eql(444);
            expect(oMetadata.nodes.Root.attributes.TEXT_02.maxLength).to.eql(100);
            expect(oMetadata.nodes.Root.attributes.TS_01.minValue === undefined).to.eql(true);
            expect(oMetadata.nodes.Root.attributes.DATE_01.minValue === undefined).to.eql(true);
        });
    });

    it("allows to define an object-internal foreign key reference", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                foreignKeyTo: "DummyDescriptionAO",
                                foreignKeyIntraObject: true,
                            }
                        }
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition)
            .then((oMetadata) => {
                expect(oMetadata.nodes.Node1.attributes.SOMETEXT.foreignKeyIntraObject).to.eql(true);
            });
    });

    it("allows to define cascade delete objects", () => {
        var oDefinition = {
            cascadeDelete: ["sap.ino.xs.object.ObjectA", "sap.ino.xs.object.ObjectB"],
            Root: {
                table: "sap.aof.test.db.test::t_test"
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.cascadeDelete).to.eql(["sap.ino.xs.object.ObjectA", "sap.ino.xs.object.ObjectB"]);
        });
    });

    it("allows to define static custom actions", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test"
            },
            actions: {
                myStaticAction: {
                    isStatic: true,
                    historyEvent: "STATIC_ACTION_DONE",
                    authorizationCheck: (oParameters, addMessage, oContext) => {
                    },
                    enabledCheck: (oParameters, addMessage, oContext) => {
                    },
                    execute: (oParameters, addMessage, oContext) => {
                    },
                    customProperties: (oParameters, addMessage, oContext) => {
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.myStaticAction.isStatic).to.eql(true);
            expect(oMetadata.actions.myStaticAction.historyEvent).to.eql("STATIC_ACTION_DONE");
            expect(oMetadata.actions.myStaticAction.authorizationCheck).to.eql(oDefinition.actions.myStaticAction.authorizationCheck);
            expect(oMetadata.actions.myStaticAction.enabledCheck).to.eql(oDefinition.actions.myStaticAction.enabledCheck);
            expect(oMetadata.actions.myStaticAction.execute).to.eql(oDefinition.actions.myStaticAction.execute);
            expect(oMetadata.actions.myStaticAction.customProperties).to.eql(oDefinition.actions.myStaticAction.customProperties);
        });
    });

    it("allows to define actions as internal", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test"
            },
            actions: {
                create: {
                    authorizationCheck: false,
                    isInternal: true
                },
                myInternalAction: {
                    authorizationCheck: false,
                    isInternal: true,
                    execute: () => {
                    }
                },
                myAction: {
                    authorizationCheck: false,
                    execute: () => {
                    }
                },
                myStaticAction: {
                    authorizationCheck: false,
                    isStatic: true,
                    execute: () => {
                    }
                },
                myInternalStaticAction: {
                    authorizationCheck: false,
                    isStatic: true,
                    isInternal: true,
                    execute: () => {
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.create.isInternal).to.eql(true);
            expect(oMetadata.actions.myInternalAction.isInternal).to.eql(true);
            expect(oMetadata.actions.myInternalStaticAction.isInternal).to.eql(true);
            expect(oMetadata.actions.myAction.isInternal).to.eql(false);
            expect(oMetadata.actions.myStaticAction.isInternal).to.eql(false);
        });

    });

    it("allows to define a isName property for at max one attribute on any node", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        isName: true
                    }
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                isName: true
                            }
                        }
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.TITLE.isName).to.eql(true);
            expect(oMetadata.nodes.Root.nameAttribute).to.eql("TITLE");
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.isName).to.eql(true);
            expect(oMetadata.nodes.Node1.nameAttribute).to.eql("SOMETEXT");

            oDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    attributes: {
                        TITLE: {
                            isName: true
                        },
                        DESCRIPTION: {
                            isName: true
                        }
                    }
                },
                actions: {
                    create: {
                        authorizationCheck: false
                    }
                }
            };

            return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).catch((e) => {
                expect(e.toString()).to.eql("Error: Define only one name attribute for node 'Root'");
                return Promise.reject();
            }).then((oMetadata) => {
                expect(oMetadata).to.be.undefined; // as an error should be thrown
            }).catch((oError) => {
            });
        });
    });

    it("defines objects to be invalidated by custom actions", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test"
            },
            actions: {
                customAction: {
                    enabledCheck: (oParameters, addMessage, oContext) => {
                    },
                    execute: (oParameters, addMessage, oContext) => {
                    },
                    authorizationCheck: false,
                    impacts: ["sap.ino.xs.object.idea.Idea"]
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.customAction.impacts).to.eql(["sap.ino.xs.object.idea.Idea"]);
        });
    });

    it("handles mass-enabled custom action", () => {
        var oDefinition = {
            actions: {
                myAction: {
                    massActionName: "myMassAction",
                    impacts: ["sap.ino.xs.object.idea.Idea"],
                    historyEvent: "COACH_ASSIGNED",
                    authorizationCheck: false,
                    execute: () => {
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.myAction.massActionName).to.eql("myMassAction");
            expect(_.size(oMetadata.actions)).to.eql(_.size(oDefinition.actions) + 1);
            expect(oMetadata.actions.myMassAction.name).to.eql("myMassAction");
            expect(oMetadata.actions.myMassAction.isFrameworkAction).to.eql(false);
            expect(oMetadata.actions.myMassAction.isInternal).to.eql(false);
            expect(oMetadata.actions.myMassAction.isStatic).to.eql(true);
            expect(oMetadata.actions.myMassAction.isMassAction).to.eql(true);
            expect(oMetadata.actions.myMassAction.historyEvent).to.eql("COACH_ASSIGNED");
            expect(oMetadata.actions.myMassAction.authorizationCheck).to.eql(false);
            expect(oMetadata.actions.myMassAction.impacts).to.eql(oMetadata.actions.myAction.impacts);
            expect(_.isPlainObject(oMetadata.actions.myMassAction.customProperties)).to.eql(true);
            expect(oMetadata.actions.myAction.customProperties).to.eql(oMetadata.actions.myMassAction.customProperties);
            expect(_.isFunction(oMetadata.actions.myMassAction.execute)).to.eql(true);

            var oDefinition2 = {
                actions: {
                    myAction: {
                        massActionName: "myMassAction",
                        authorizationCheck: false,
                        execute: () => {
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    },
                    myMassAction: {
                        authorizationCheck: false,
                        execute: () => {
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    attributes: {
                        TITLE: {
                            customProperties: {
                                prop1: "val1",
                                prop2: "val2"
                            }
                        }
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                }
            };

            return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition2).catch((e) => {
                expect(e.message).to.eql("Mass action 'myMassAction' conflicts with standard action");

                var oDefinition3 = {
                    actions: {
                        myAction: {
                            isStatic: true,
                            massActionName: "myMassAction",
                            authorizationCheck: false,
                            execute: () => {
                            },
                            customProperties: {
                                prop1: "val1",
                                prop2: "val2"
                            }
                        }
                    },
                    Root: {
                        table: "sap.aof.test.db.test::t_test",
                        attributes: {
                            TITLE: {
                                customProperties: {
                                    prop1: "val1",
                                    prop2: "val2"
                                }
                            }
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                };

                return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition3).catch((e) => {
                    expect(e.message).to.eql("Mass action 'myMassAction' is not allowed for static action");
                }).then((oMetadata) => {
                    expect(oMetadata).to.be.undefined; // as an error should be thrown
                }).catch((oError) => {
                });
            });
        })
    });

    it("allows definition of read view resulting in transient attributes", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                view: "sap.aof.test.db.test::v_test"
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(_.sortByKeys(oMetadata.nodes.Root.attributes)).to.eql(_.sortByKeys({
                ID: {
                    name: "ID",
                    dataType: Metadata.DataType.Integer,
                    dbDataType: "INTEGER",
                    isConstant: true,
                    isAlternativeKey: false,
                    required: true,
                    isPrimaryKey: true,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TITLE: {
                    name: "TITLE",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isConstant: false,
                    isAlternativeKey: false,
                    required: true,
                    maxLength: 240,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                DESCRIPTION: {
                    name: "DESCRIPTION",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isConstant: false,
                    isAlternativeKey: false,
                    required: false,
                    maxLength: 1000,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                }
            }));
            expect(oMetadata.nodes.Root.persistedAttributes.sort()).to.eql(["DESCRIPTION", "ID", "TITLE"]);
        });
    });

    it("allows to define labels", () => {
        var oDefinition = {
            label: "Object",
            Root: {
                table: "sap.aof.test.db.test::t_test",
                label: "Node",
                attributes: {
                    "ID": {
                        label: "Attribute"
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false,
                    label: "Action"
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.label).to.eql("Object");
            expect(oMetadata.nodes.Root.label).to.eql("Node");
            expect(oMetadata.nodes.Root.attributes.ID.label).to.eql("Attribute");
            expect(oMetadata.actions.create.label).to.eql("Action");
        });
    });

    it("supports custom extension nodes", () => {
        var oCoreDefinition = {
            isExtensible: true,
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test"
            },
            nodes: {
                Node1: {
                    table: "sap.aof.test.db.test::t_test_node_1",
                    sequence: "sap.aof.test.db.test::s_test_node_1",
                    parentKey: "PARENT_ID"
                }
            }
        };

        var fnExtensionConsistencyCheckNode2 = () => {
        };

        var fnExtensionInputCheckNode2 = () => {
        };

        var fnExtensionAttrConsistencyCheckNode2 = () => {
        };

        var fnExtensionAttrInputCheckNode2 = () => {
        };

        var oExtReadOnly = {
            nodeReadOnly: () => {
                return true;
            },
            attributeReadOnly: () => {
                return true;
            }
        };

        var oExtProperties = {
            nodeProperties: () => {
                return {
                    extVal1: "z",
                    extVal2: "x"
                };
            },
            attributeProperties: () => {
                return {
                    extVal3: "v",
                    extVal4: "q"
                };
            }
        };

        var oExtensionDefinition = {
            Root: {
                nodes: {
                    Node2: {
                        table: "sap.aof.test.db.test::t_test_node_2_1",
                        sequence: "sap.aof.test.db.test::s_test_node_2_1",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnExtensionConsistencyCheckNode2],
                        inputChecks: [fnExtensionInputCheckNode2],
                        readOnly: oExtReadOnly.nodeReadOnly,
                        customProperties: oExtProperties.nodeProperties,
                        attributes: {
                            SOMETEXT: {
                                required: true,
                                consistencyChecks: [fnExtensionAttrConsistencyCheckNode2],
                                inputChecks: [fnExtensionAttrInputCheckNode2],
                                readOnly: oExtReadOnly.attributeReadOnly,
                                customProperties: {
                                    x: 4711,
                                    y: "OK"
                                }
                            },
                            "ANOTHERONE": {
                                readOnly: true,
                                customProperties: oExtProperties.attributeProperties,
                                foreignKeyTo: "sap.ino.xs.object.User.Root"
                            }
                        }
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oCoreDefinition, [oExtensionDefinition]).then((oMetadata) => {
            expect(oMetadata.nodes.Node2).to.be.ok;
            expect(oMetadata.nodes.Node2.table).to.eql("sap.aof.test.db.test::t_test_node_2_1");
            expect(oMetadata.nodes.Node2.primaryKey).to.eql("ID");
            expect(oMetadata.nodes.Node2.sequence).to.eql("sap.aof.test.db.test::s_test_node_2_1");
            expect(oMetadata.nodes.Node2.consistencyChecks[0]).to.eql(fnExtensionConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.inputChecks[0]).to.eql(fnExtensionInputCheckNode2);

            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.consistencyChecks[0]).to.eql(fnExtensionAttrConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.consistencyChecks).to.eql([]);
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.inputChecks[0]).to.eql(fnExtensionAttrInputCheckNode2);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.inputChecks).to.eql([]);

            // Read Only on node
            expect(oMetadata.nodes.Node2.checkReadOnly()).to.eql(true);

            // Read Only on attribute
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.checkReadOnly()).to.eql(true);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.readOnly).to.eql(true);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.foreignKeyTo).to.eql("sap.ino.xs.object.User.Root");

            // Custom Properties on node
            expect(oMetadata.nodes.Node2.customProperties()).to.eql({
                extVal1: "z",
                extVal2: "x"
            });

            // Custom Properties on attribute
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.customProperties).to.eql({
                x: 4711,
                y: "OK"
            });

            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.customProperties()).to.eql({
                extVal3: "v",
                extVal4: "q"
            });
        });
    });

    it("supports custom extension actions", () => {
        var oCoreDefinition = {
            isExtensible: true,
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                customAction: {
                    authorizationCheck: false,
                    execute: () => {
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
            }
        };

        var oExtActionChecks = {
            customAction2EnabledCheck: () => {
            }
        };

        var oExtActionExecutes = {
            customAction2Execute: () => {
            }
        };

        var oExtProperties = {
            actionProperties: () => {
                return {
                    extVal3: "y",
                    extVal4: "w"
                };
            }
        };

        sinon.spy(oExtActionChecks, 'customAction2EnabledCheck');
        sinon.spy(oExtActionExecutes, 'customAction2Execute');

        var oExtensionDefinition = {
            actions: {
                customAction2: {
                    authorizationCheck: false,
                    enabledCheck: oExtActionChecks.customAction2EnabledCheck,
                    execute: oExtActionExecutes.customAction2Execute,
                    customProperties: oExtProperties.actionProperties
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oCoreDefinition, [oExtensionDefinition]).then((oMetadata) => {
            expect(oMetadata.actions.customAction2).to.be.ok;

            // Enabled checks
            oMetadata.actions.customAction2.enabledCheck();

            expect(oExtActionChecks.customAction2EnabledCheck.called).to.be.ok;

            // Execute
            oMetadata.actions.customAction2.execute();

            expect(oExtActionExecutes.customAction2Execute.called).to.be.ok;

            // Custom Properties on action
            expect(oMetadata.actions.customAction2.customProperties()).to.eql({
                extVal3: "y",
                extVal4: "w"
            });
        });
    });

    it("allows to define read-only custom actions", () => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
            },
            actions: {
                create: {
                    authorizationCheck: false
                },
                customAction1: {
                    authorizationCheck: false,
                    execute: () => {
                    },
                    readOnly: true
                },
                customAction2: {
                    authorizationCheck: false,
                    execute: () => {
                    },
                    readOnly: () => {
                        return true;
                    }
                }
            }
        };

        return Metadata._getObjectMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.customAction1.readOnly).to.eql(true);
            expect(oMetadata.actions.customAction2.readOnly).to.eql(false);
            expect(typeof oMetadata.actions.customAction2.checkReadOnly).to.eq("function");
        });
    });

    it("allows to define enumerations for attributes", () => {
        var oDefinition = {
            Root: {
                attributes: {
                    TITLE: {
                        enum: ["A", "B", "C"]
                    },
                    DESCRIPTION: {
                        enum: {
                            A: "A",
                            B: "B",
                            C: "C"
                        }
                    }
                },
                table: "sap.aof.test.db.test::t_test",
            },
            actions: {
                create: {
                    authorizationCheck: false
                },
            }
        };

        return Metadata.getMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            var oRootMetadata = oMetadata.getNodeMetadata('Root');
            expect(oRootMetadata.attributes.TITLE.enum).to.eql(["A", "B", "C"]);
            expect(oRootMetadata.attributes.DESCRIPTION.enum).to.eql(["A", "B", "C"]);
            // Validate if the consistency checks were added
            expect(_.where(oRootMetadata.attributes.TITLE.consistencyChecks, {name: 'enumCheck'}).length).to.eql(1);
            expect(_.where(oRootMetadata.attributes.DESCRIPTION.consistencyChecks, {name: 'enumCheck'}).length).to.eql(1);
            expect(_.where(oRootMetadata.attributes.ID.consistencyChecks, {name: 'enumCheck'}).length).to.eql(0);
            expect(_.where(oRootMetadata.attributes.TITLE.inputChecks, {name: 'enumCheck'}).length).to.eql(1);
            expect(_.where(oRootMetadata.attributes.DESCRIPTION.inputChecks, {name: 'enumCheck'}).length).to.eql(1);
            expect(_.where(oRootMetadata.attributes.ID.inputChecks, {name: 'enumCheck'}).length).to.eql(0);
        });
    });

    it("allows to define json schemas for attributes", () => {
        var oTestSchema = {
            properties: {
                plz: {
                    type: 'string',
                    pattern: '^[0-9]{5}$'
                }
            }
        };
        var oDefinition = {
            Root: {
                attributes: {
                    DESCRIPTION: {
                        dataType: Metadata.DataType.JSON,
                        jsonSchema: oTestSchema
                    }
                },
                table: "sap.aof.test.db.test::t_test",
            },
            actions: {
                create: {
                    authorizationCheck: false
                },
            }
        };

        return Metadata.getMetadata("whateverAO", oCallerContext, oDefinition).then((oMetadata) => {
            var oRootMetadata = oMetadata.getNodeMetadata('Root');
            expect(oRootMetadata.attributes.DESCRIPTION.jsonSchema).to.eql(oTestSchema);
            expect(_.where(oRootMetadata.attributes.DESCRIPTION.consistencyChecks, {name: 'jsonSchemaCheck'}).length).to.eql(1);
            expect(_.where(oRootMetadata.attributes.ID.consistencyChecks, {name: 'jsonSchemaCheck'}).length).to.eql(0);
        });
    });

    it("enforces dataType JSON with jsomSchema", () => {
        var oTestSchema = {
            properties: {
                plz: {
                    type: 'string',
                    pattern: '^[0-9]{5}$'
                }
            }
        };
        var oInvalidDefinition = {
            Root: {
                attributes: {
                    DESCRIPTION: {
                        // Missing data type
                        jsonSchema: oTestSchema
                    }
                },
                table: "sap.aof.test.db.test::t_test",
            },
            actions: {
                create: {
                    authorizationCheck: false
                },
            }
        };
        return Metadata.getMetadata("whateverAO", oCallerContext, oInvalidDefinition).catch((oException) => {
            expect(oException.message.includes('DESCRIPTION'));
            return Promise.reject();
        }).then((oMetadata) => {
            expect(oMetadata).to.be.undefined; // as an error should be thrown
        }).catch((oError) => {
        });
    });
});
