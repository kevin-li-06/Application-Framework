"use strict";

var AOF = require("@sap/aof");
var Determine = AOF.Determination;

module.exports = {
    actions: {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.example.db.iam::t_identity",
        externalKey: true,
        determinations: {
            onModify: [Determine.systemAdminData]
        },
        attributes: {
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true
            },
            CHANGED_BY: {
                readOnly: true
            },
            NAME: {
                isName: true,
                required: true
            },
            EMAIL: {
                required: true
            }
        }
    }
};