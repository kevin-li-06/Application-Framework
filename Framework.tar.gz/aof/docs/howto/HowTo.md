## Building a "Todo" application with the SAP Application Object Framework (AOF) based on the SAP XS Advanced technology stack

In this tutorial, you’ll learn how to build a "Todo" application with the SAP Application Object Framework (AOF) 
based on the SAP XS Advanced technology stack. 

SAP released the "SAP HANA extended application services, advanced model" (short: SAP HANA XS Advanced or XSA) 
with SAP HANA SP11, allowing to build native HANA applications based on Node.js framework and the Javascript programming language.
XSA provides the basic foundation for application development on HANA, for example by offering an Application Router, 
taking care of authentication and authorization validation and enforcement or by publishing OData services.
  
SAP Application Object Framework (AOF) enhances the XSA stack by establishing an end-to-end development process 
offering an easy, fast and holistic development of data model oriented applications.

> AOF (Application Object Framework) allows application developers to concentrate on business logic organized around a data model. It provides a feature set, proven in real-world applications and provides a holistic approach reaching from database to user interface.

SAP AOF is available on [Github](https://github.wdf.sap.corp/pages/xs2/aof/) as an first major release 
[1.0.x](https://github.wdf.sap.corp/xs2/aof/tree/1.0.x).

### Project Generation

In this tutorial we are going to create a "Todo" application, supporting to add new "Todo" entries and setting "Todo"
entries to done. So we want to create a new SAP XSA application. Luckily when using SAP AOF, we don't have to start from
a blank project, but we can leverage the SAP AOF project generator to jump-start our application development.

To start the SAP AOF project generator we first have to install **Node.js**. Latest long-term support (LTS) version can be found here:
[Node.js v4.x.x LTS](https://nodejs.org/en/download/). 

Also ensure, that **Git** is installed on your machine, as it is later needed during installation of the generated 
AOF project. If not, **Git** can be installed from here: [Git 2.x.x](https://git-scm.com/download).  

In order to be able to install internal Node.js modules we have to point the NPM registry to the Nexus Milestone NPM repository, 
as SAP AOF is only available in the internal landscape. This can be configured by executing the following commands:

    npm config set registry "https://nexus.wdf.sap.corp:8443/nexus/content/groups/build.milestones.npm/"
    npm config rm proxy
    npm config rm https-proxy
    npm config set strict-ssl false

All NPM dependencies will now be resolved using the internal Nexus NPM repository, external dependencies will
be resolvable as well, as the the public NPM is mirrored into the Nexus NPM. So we have to remove the proxy settings.

First of all, we need to install the SAP AOF Node.js module globally, so that we can execute the **"sap-aof"** commands 
of the AOF project generator. This can be achieved by calling:
 
    npm install @sap/aof -g 

Having the SAP AOF Node.js module globally installed, we can execute the "init" command to start the AOF project generator on a newly 
created project directory.

    mkdir todo
    cd todo
    sap-aof init 

The AOF project generator will prompt a bunch of questions, to request the configuration to be used for project generation.
We use the configuration as depicted in figure 1 of the project generator result.
 
![sap-aof init](assets/sap_aof_init.png)
*<br>Figure 1: Project initialization using: sap-aof init*

So to sum the configuration above up, we created a AOF project called "Todo" based on the "hana" database using the 
XSA configuration, which embraces the following features:

- HANA Connection
- OData Support
- Authentication via Passport (JWT)
- HTTP Request Routing via Express
- Application Router
- SAP UI5
    
In addition, we leverage a test database, for which we generate HDI deployment scripts for local testing and a test 
User Account and Authentication (UAA) running in Cloud Foundry. 
An Application Object named "Todo" is created as well as part of the project generation. Socket.io we don't activate 
at this point in time, but will be added to the project later on.

The generated AOF project consists of following three sub-projects:  
 
- **DB**: 
    - Defines persistence tables
    - CDS entities are used for table modeling
    - HANA container (Schema) 
    - HDI deployment scripts
- **JS**: 
    - Node.js application server
    - Definition of Application Objects
    - Application logic
    - Exposure of HTTP protocols
- **WEB**:
    - Application Router
    - User Interface

Figure 2 shows a screenshot of the project in the IDE.

![project structure](assets/project_structure.png)
*<br>Figure 2: Project structure after initialization*

The project generation finishes successfully with the hint, to create a technical user named **SAP_APP_TODO_USER**, 
derived from the project's namespace. This user can be created in the Test HANA's catalog using the WebIDE SQL console, 
accessible via URL (user: 'SYSTEM', password: 'Toor1234'): 

    http://inno-next.mo.sap.corp:8000/sap/hana/ide

The following SQL commands need to be executed:

    create user SAP_APP_TODO_USER password Test1234;
    alter user SAP_APP_TODO_USER disable password lifetime;
    grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_APP_TODO_USER;
    grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_APP_TODO_USER;

Deployment of HANA content is triggered via HDI deploy command line tool, that needs to be installed beforehand:
     
    npm install git://github.wdf.sap.corp/hdi/hdijs.git -g
  
Having the technical user created and the NPM registry set up correctly, 
we can install our AOF project by calling:

    sap-aof install

This will call "npm install" on each sub-project and execute the HDI deployment scripts afterwards.
Therefore installation of the SAP AOF project needs to be triggered every time a **package.json** or a database 
entity is adjusted. Each HDI deployment will drop and re-create the HANA container, so that test data will be gone afterwards.

The generated "Todo" application can be started using the following command:

    sap-aof start
    
This will per default locally start the application server on port 3000, and the application router on 
port 5000, so that the generated test UI can be started by entering the following URL into a browser:

    localhost:5000
    
The first time you will be directed to the central User Account and Authentication (UAA) service configured for
the Test UAA used during project generation:

    https://xs2security.accounts400.ondemand.com/saml2/idp/sso/xs2security.accounts400.ondemand.com
    
Register once an account for UAA using your e-mail address or logon with your UAA credentials. 
After successful logon you're redirected to the generated project application again.

Now you can test drive the generated application.

### Object Definition

A central part of the Application Object Framework (AOF) is the definition of so-called Application Objects.
The project generator created an Application Object called **Todo** with a standard default definition. In this part 
of the tutorial we will have a look at the structure and enhance it to fit our needs. 

As the object definition references database entities, we need to perform changes there as well. 
As seen before, the persistence definition based on the HANA database is performed in the sub-project **db**. 

The table definitions are expressed using Core Data Services (CDS). More details on HDI can be found at  
[https://github.wdf.sap.corp/xs2/xs2-docs/wiki/CDSLibrary](https://github.wdf.sap.corp/xs2/xs2-docs/wiki/CDSLibrary).

Deployment of CDS and HANA entities are deployed using HDI. In this tutorial we will use the generated local HDI scripts, 
to control the HDI deployment, but details found be found at  
[https://github.wdf.sap.corp/xs2/xs2-docs/wiki/HDIContainer](https://github.wdf.sap.corp/xs2/xs2-docs/wiki/HDIContainer)

As part of this tutorial, we want to adjust the data model by adding the additional attribute
**IS_DONE** of type **Integer** on **Root** and **Items** level. In addition, we want to add an additional sub-node to 
the **Todo** Object called **Owner**

So we need to adjust the entities in the sub-project **db** to reflect CDS entity changes. The column **IS_DONE** is added 
as additional column of type **Integer** in the CDS entities **t_todo.hdbcds** and **t_todo_item.hdbcds**. To add the 
persistency entities for the **Owner** node, we add an additional CDS entity called **t_todo_owner.hdbcds** to store the 
owner's **USERNAME**, and the corresponding HANA sequence **s_todo_owber.hdbsequence**. The easiest way to accomplish this 
is to copy the **Item** files **t_todo_item** and **s_todo_item** to the **Owner** files **t_todo_owner** and **s_todo_owner** 
and make the necessary adjustments, to rename **item** with **owner**.

The changes to the sub-project **db** look as depicted in figure 3:

![db changes](assets/db_changes.png)
*<br>Figure 3: Changes to persistence definition*

The Application Object definition of **Todo** has to be adjusted of course as well, to reflect the wanted persistency changes
in the Application Object data model. Therefore, we have to perform changes in the sub-project **js** on the Application 
Object definition file of **Todo.js** in the path **sap/app/todo**.

The generated Application Object **Todo** currently consists of two nodes, the **Root** node, which is always mandatory,
and a sub-node called **Items**. We keep the structure as is and add in addition a new sub-node called **Owner** having 
the definition as follows:
 
    Owner: {
        table: "sap.app.db.todo::t_todo_owner",
        sequence: "sap.app.db.todo::s_todo_owner",
        parentKey: "PARENT_ID",
        readOnly: true,
        attributes: {
            USERNAME: {
                required: true,
                isName: true,
                isDescription: true
            }
        }
    },
    
Figure 4 depicts how the new node **Owner** is embedded into the object definition structure. 

![object changes](assets/object_changes.png)
*<br>Figure 4: Changes to application object definition: Adding read-only sub-node "Owner"*

The sub-node **Owner** is marked as **readOnly**, and thus cannot be changed from outside of the object, as we later are 
going to fill the node inside the application object based on the current logged-on user.

We don't explicitly need to add the attribute **IS_DONE** to the **Root** and **Items** node of our Application Object 
definition, as these will be automatically derived from the CDS entity metadata including type information. Only in case
we want to enhance the attributes with additional metadata, we need to list them. 

As we changed the persistence layer, we have to re-install the project to re-create the HDI container using the command:
 
    sap-aof install

Of course previously running processes have to be killed, to re-install and re-start the AOF project, every time either
the persistence layer or the **package.json** dependencies have been changed. 

For further information on the object definition, the documentation can be found at 
[API Documentation - Object Definition](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/Schema.SchemaObject.html).

### Object Implementation

The application logic of our Application Object **Todo** is also described in the file **sap/app/todo/Todo.js**, 
right in the same place we have and changed the object definition.

Application Logic is added with means of so-called **actions**, **determination** and **checks**. Per default our
Application Object **Todo** has two determinations registered, one running at time-point **onCreate**, and one 
running at time-point **onModify**, which basically runs both at **onCreate** and at **onUpdate**. We remove the first 
determination as it just only shows, how to raise messages in the implementation of a determination. The second determination
called **Determine.systemAdminData**, calls a re-use determination provided by AOF, to fill the system administrative data
of the **Todo** object, whenever it changes. Therefore, the **Root** node has to contain the following attributes with the
corresponding types:

- **CREATED_AT**
    - Type: UTCTimestamp not null
    - Description: Date/Time when the object was created
- **CREATED_BY** 
    - Type: String(256) not null
    - Description: Username of the user, who created the object
- **CHANGED_AT**
    - Type: UTCTimestamp not null
    - Description: Date/Time when the object was last changed
- **CHANGED_BY** 
    - Type: String(256) not null
    - Description: Username of the user, who last changed the object
    
Fortunately the correct system administrative data structure was already created for us by the AOF project generator, 
so that we don't have to take care about this manually.

As part of the tutorial we want to add the following application logic to the Application Object **Todo**:

- Fill the read-only node **Owner**
- Propagate attributes **NAME** and **IS_DONE** on Item level on each modification
- Check that only the creator of a **Todo** can read, update or delete it and raise an error message if not authorized
- Add and implement a custom action setting the **Todo** to done
- Check that NAME (Root and Item) is not changed anymore when **Todo** is done and raise an error message in case it changed

#### Filling the **Owner** sub-node

So we will start with the first task of creating the instance for the sub-node **Owner**. Therefore, we have to add a 
determination, which runs at time point **onCreate**, as the owner is only set once, when the object is created. We name 
the determination **initTodo**, add it to the array in the **onCreate** section of the object definition as callback function 
and implement it using the following code:
    
    function initTodo(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
        return oContext.getUser().then(function (sUser) {
            oWorkObject.Owner = [{
                USERNAME: sUser
            }];
        });
    }

As we can see, we can use the context object **oContext** to get additional context information on the currently processed
request, especially retrieving the currently logged on user. As the user may be derived asynchronously, we use **Promises**, 
to wait for the result, to build up the **Owner** sub-node. Important is, that the **Promise** is returned from the function, 
so that the AOF waits until the asynchronous operation has been performed. As sub-nodes are always represented as arrays in
the JSON/Javascript object, we just initialize it completely new, as we know, that there can only be exactly one sub-node
instance of **Owner**.

#### Creating an **Items** sub-node instance

Next we want to create an **Items** sub-node instance, based on the **Root** node information. As the sub-node **Items** shall
keep track in our use-case on the **Root** changes we append a new node instance, each time the root changes. Therefore, we
register an **onModify** determination named **propagateItem** in the array of the **onModify** section
of the object definition, as callback function, and implement it using the following code:

    function propagateItem(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
        if (!oPersistedObject || oWorkObject.NAME !== oPersistedObject.NAME || 
            oWorkObject.IS_DONE !== oPersistedObject.IS_DONE) {
            oWorkObject.Items.push({
                NAME: oWorkObject.NAME,
                IS_DONE: oWorkObject.IS_DONE
            });
        }
    }
    
The function checks, if the object is created (**oPersistedObject** is null) or either the attribute **NAME** or the attribute **IS_DONE**
changed, and then pushes a new instance to the **Items** array using the **Root** information. The AOF ensures, that a **sub-node**
array is always initialized with an empty array, so that we don't have to take care about that ourselves. To forbid changing the **Items**
from outside (e.g. the UI), we could set the complete node **Items** to read-only, but we don't do that in this tutorial.

#### Check on authorization for Todo

Every user has his own **Todos**, and therefore in our scenario, every user shall only be able to read, update and delete those. So we have to 
implement an authorization check on the actions **update**, **del** and **read**. Action **create** is not protected, as everybody shall 
be able to create new own **Todos**. So the corresponding authorization check named **checkAuth** looks as follows:

    function checkAuth(vKey, oPersistedObject, addMessage, oContext) {
        return oContext.getUser().then(function (sUser) {
            if (oPersistedObject.Owner[0].USERNAME !== sUser) {
                addMessage(Message.MessageSeverity.Error, "TODO_NO_AUTH", vKey, "Root");
            }
        });
    }
    
    
Authorization check **checkAuth** is registered in the object definition replacing the statement **authorizationCheck: false** in the 
actions section for the required actions (update, del read) by the following statement:

    authorizationCheck: checkAuth
    
What can be seen is, that the authorization check adds a message of severity **error** to express, that the authorization check
failed, when the Todo **Owner** **USERNAME** is not the current logged on user. Raising an error message, will stop the action processing 
and return response **forbidden**, so the action will not be executed. 

#### Adding a custom action to Todo to done

As the Todo object definition exposes a **IS_DONE** attribute of type Integer, that we treat like a **boolean** status flag, that shall be
changed by a custom status action, we set the attribute to read-only using the following definition into the attribute definition of the **Root** node:

    IS_DONE: {
        readOnly: true
    }
    
Having the **IS_DONE** attribute marked as read-only, we now need a custom action to perform modifications on it, as a normal **update** on the 
object is not allowed anymore on that attribute. But a custom action named **setToDone** added to the **actions** section can be used to implement 
the status change, as we are changing the attribute **IS_DONE** from the inside of the object implementation. The execution implementation of 
custom action **setToDone** looks as simple as that:

    function setToDone(vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) {
        oWorkObject.IS_DONE = 1;
    }

In addition we need to implement the enabling logic of the custom action **setToDone**, as it only can be executed once on each **Todo** instance. 
For that we create and register an **enabled check** function named **setToDoneEnabled** implemented by the following function:

    function setToDoneEnabled(vKey, oPersistedObject, addMessage, oContext) {
        if (oPersistedObject.IS_DONE === 1) {
            addMessage(Message.MessageSeverity.Error, "TODO_IS_DONE", vKey, "Root", "IS_DONE");
        }
    }

The custom action **setToDone** needs to be registered into the object definition **actions** section like follows:

    setToDone: {
        authorizationCheck: checkAuth,
        execute: setToDone,
        enabledCheck: setToDoneEnabled
    }

So again we check the authorization like for the update use-case, and we register the callback function **setToDone** as **execute** function 
and **setToDoneEnabled** as **enabledCheck** function for the custom action **setToDone**.

#### Check that Todo is not changed after it was set to done

Last change we want to apply to the application logic of the Application Object **Todo**, is that when the **Todo** is set to done, no changes can be performed anymore.
To do this we leverage a consistency check, named **checkChangeable**, that is registered in the **consistencyChecks** array of **Root** node of the object definition.
The check function implementation of **checkChangeable** looks as follows:

    function checkChangeable(vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) {
        if (oWorkObjectNode.IS_DONE === 1 &&
            oContext.getAction().name !== "setToDone" && oContext.getAction().name !== "del") {
            addMessage(Message.MessageSeverity.Error, "TODO_NOT_CHANGEABLE", vKey, "Root");
        }
    }

The consistency check is executed each time an action is called. An error message is added to the message buffer in case the **Todo**
is set to done, and the action is not the custom action, that sets the status to done, and in addition we still allow the 
deletion of the **Todos**.

So after performing a bunch of changes to the Application Object **Todo**, the enhancement to the object definition to support the 
object implementation look as shown in figure 5. 

![object enhancement](assets/object_enhancement.png)
*<br>Figure 5: Enhancement to application object definition for object implementation*
 
Figure 6 shows the callback functions that basically implement the application logic of the Application Object **Todo**.

![object implementation](assets/object_implementation.png)
*<br>Figure 6: Object implementation callback functions*

After changing the object implementation, the **Todo** application has to be restarted. So the running
process needs to be stopped and restarted calling again:

    sap-aof start

For further information on the object implementation, the documentation can be found at   
[API Documentation - Object Implementation](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/ImplementationExit.html).

### Protocol Exposure

In this part of the tutorial we want to understand how Application Objects are exposed via HTTP protocols. During project 
generation the basic setup for this is already prepared as part of the server file **/js/index.js**. There we find the 
AOF middleware configuration established with the Express application to offer the following protocol exposure configured 
for the defined URLs:

- REST Protocol:
    - AOF exposes a RESTful protocol, mapping the HTTP methods to the CRUD operations of application objects
- OData Protocol
    - AOF leverages the **XSOData** Node.js module to publish the Application Object nodes as OData entities and the foreign key relationship as associations.
    - OData protocol can only be used to read data. Writing Application Objects is not supported yet via OData.

In the **applicationObjects** section of the middleware, the mapping from the Application Object name to the URL path is done.
It was already prepared during the project generation for the **Todo** application object. 

A central metadata service and a central OData service is configured. Note that **.odata** or **.xsodata** needs to be appended 
to the OData service URL when called. When accessing the REST Protocol of Application Objects, the extension can be omitted or **.js** can be used.
For accessing the OData service for a single Application Object again **.odata** or **.xsodata** needs to be used as extension instead.

The REST protocol of the Application Object **Todo** can be tested in the browser for GET requests, and via a tool like **Postman**
for other request methods (POST, PUT, DEL). Here is a list of exemplary request calls:

    // Create Todo
    POST http://localhost:5000/sap/app/rest/Todo 
    {
        "ID" : -1
        "NAME" : "Test"
    }
    
    // Get Todo
    GET http://localhost:5000/sap/app/rest/Todo/<id>
    
    // Change Todo
    PUT http://localhost:5000/sap/app/rest/Todo
    {
        "ID" : <id>
        "NAME" : "Test update"
    }
    
    // Set to Done
    POST http://localhost:5000/sap/app/rest/Todo/<id>/setToDone
    
    // Delete Todo
    DELETE http://localhost:5000/sap/app/rest/Todo/<id>

OData request can be tested again in the browser or using the **Postman** tool, by calling for example the following URLs:

    // Get Todo Root
    GET http://localhost:5000/sap/app/rest/aof.odata/Todo_Root(<id>)?$format=json
    
    // Get Todo with item sub-nodes 
    GET http://localhost:5000/sap/app/rest/aof.odata/Todo_Root(<id>)?$expand=Todo_Items&$format=json
    
    // Search for Todos
    GET http://localhost:5000/sap/app/rest/aof.odata/Todo_Root?searchText=Test&$format=json

Based on the REST and OData protocol many more calls can be performed, to retrieve different aspects of the Application Object **Todo**.

As part of this tutorial, we enhance the protocol exposure of the AOF **Todo** project by WebSockets using the **websocket** middleware 
extension implemented by **socket.io** Node.js module. To enable this, the middleware configuration needs to be enhanced in the 
**extensions** section as follows:
 
    websocket: {
        name: "socket.io",
        lib: io,
        checkAuth: true,
        checkAuthDelete: "all",
        middleware: [
            passport.authenticate("JWT", {session: false})
        ]
    }

A **passport** middleware is registered as well to check authentication for web socket requests and to derive the current logged on user.
The **Socket.io** module used above needs to be required and the **io** library is instantiated in the project **after** the creation of the 
HTTP server:

    var socketio = require("socket.io");
    
    var app = express();
    var server = http.Server(app);
    var io = socketio(server);

We have to add the following dependency into file **/js/package.json** to make the web socket library **socket.io** available:
 
    "socket.io": "2.0.4"

Changes to **package.json** have to be installed by calling again:
 
    sap-aof install

To allow the **websocket** extension to create new connections to the HANA database, we add an additional parameter
to the AOF middleware at the end like this:

    aof.middleware(app, {
        // ... 
    }, oConfig);

So the final AOF middleware configuration for your **Todo** application looks as depicted in figure 7:

![aof_middleware](assets/aof_middleware.png)
*<br>Figure 7: AOF middleware configuration, enabling web-sockets*

In order to allow access via application router to the **socket.io** UI library we need to enhance the application router
configuration **xs-app.json** with the following additional route:

    {
        "source": "/socket.io/.*",
        "destination": "nodejs",
        "csrfProtection": false
    }

Furthermore web sockets need to be enabled in the application router, by adding the following configuration to **xs-app.json**:

    "websockets": {
        "enabled": true
    }
    
As communication of web sockets with backend are performed via POST requests, we need to disable **CRSF** protection
for this path.

Web sockets enabling can best be tested via a small standalone HTML test page, that can look as follows:

    <!DOCTYPE html>
    <html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta charset="UTF-8">
        <title>Test WebSockets</title>
        <script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/1.4.5/socket.io.min.js"></script>
        <script type="text/javascript">
            var oSocket;
            jQuery(document).ready(function () {
                oSocket = io("http://localhost:5000/sap/app/rest/Todo");
                oSocket.on("create", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
                    jQuery("#output").prepend(jQuery("<li>").text(vKey + " - " + oObject.NAME));
                });
            });
            function create() {
                var sName = jQuery("#name").val();
                if (sName) {
                    jQuery("#name").val("");
                    oSocket.emit("create", {
                        NAME: sName
                    });
                }
            }
        </script>
    </head>
    <body>
    <label for="name">Name: </label>
    <input id="name"/>
    <button id="create" onclick="create();">Create</button>
    <ul id="output"/>
    </body>
    </html>

When creating a HTML page called e.g. **test_websocket.html** from the code above and testing it locally in a browser, 
new **Todos** can be created via a UI input field, which newly creates instances via web socket when clicking the button. 
Newly created **Todos** are displayed, based on web socket event listening of Application Object creations.

For further information on the AOF middleware configuration, the documentation can be found at   
[API Documentation - AOF Module](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/AOF.html).

### User Interface

As we now have the backend persistence layer, the object modeling and implementation ready, we can now have a look, how
to build a User Interface (UI) based on SAP UI5 technology, leveraging the exposed protocols of the Application Object **Todo**.
AOF not only helps on development backend logic, but it also offers a UI5 library, that makes the communication with 
Application Objects in the backend via the exposed protocols much easier.

First we have a look on the structure of the UI generated by the AOF project generator, to see how we can extend it to reflect 
the AOF UI logic we want to cover as part of this tutorial (in folder **/web/resources**).
 
- **index.html**
    - Entry point of the user interface
    - Bootstraps the UI5 core 
    - Registers the AOF UI library
    - Creates and displays the UI5 shell and application
- **Todo.js**
    - UI Model corresponding to **Todo** Application Object.  
- **App.controller.js**
    - Application logic for user interface
    - Registers OData model for reading
    - Instantiates the **Todo** Application Object for writing 
- **App.view.xml**
    - Declarative UI parts of the **Todo** 

As part of the tutorial we want to add the following UI application logic to the Application Object **Todo** user interface:

- Bind the input field **maxLength** to AOF metadata information
- Bring **IS_DONE** information to list
- Add a button to each **Todo** to set it to done
- Disable **Set To Done** button, if user has no authorization to update **Todo**, or **Todo** is already set to done.
- Refresh list, when application object changes occur
- Enable deletion of a **Todo** entry

#### Binding of metadata information

The Application Object definition is used to derive metadata information, that is also available of the UI. To leverage 
this data, a special AOF UI model **sap.aof.MetaModel** singleton is available, that can be read or bound to, as it is 
a standard UI5 **sap.ui.model.json.JSONModel**. The model offers a function **getApplicationObjectMetadata** to synchronously
read the metadata JSON for a specific Application Object. When setting the **MetaModel** as UI5 model, binding can be 
used to access the metadata JSON declaratively.

To bind the **maxLength** property of input field with id **name** against the metadata
of the attribute **NAME** of the Application Object **Todo** we register the **MetaModel** with name **meta** in the 
**App.controller.js** and extend the input tag in **App.view.xml** as follows:
  
- **App.controller.js**
            
        onInit: function () {
            this.getView().setModel(MetaModel, "meta");
        }
    
- **App.view.xml**
    
        <Input id="name" maxLength="{meta>/sap.app.rest.Todo/nodes/Root/attributes/NAME/maxLength}"/>     

Object **MetaModel** needs to be imported in the **sap.ui.define** section of the app controller, via path **sap/aof/MetaModel**.
After rendering the UI5 input control in HTML when testing the UI, the corresponding HTML input field will get 
the following HTML attribute (can e.g. be checked in the DOM in browser's developer view).

    maxlength="5000"

This will automatically restrict the length of the entered **Todo** name to 5000 characters, as the underlying 
database column cannot handle more, and would reject requests with longer names anyway. But of course it's nicer
to prevent errors instead of handle them later in the backend and bring errors back to the user.  

Instead of using the **MetaModel** directly, an instance of an **ApplicationObject** also provides access to 
metadata information via function **getApplicationObjectMetadata** or by bindings starting with **"object>/meta/"**
(Application Object instance is set as model named **object**).

#### Enhancement of list item

**Todo** has a status attribute called **IS_DONE** of type Integer, where 0 is **false** and 1 is **true**. We would like to 
show, if the **Todo** is done or not. To do this, we add the information as status, using an expression binding
to map the Integer value to a String text in an **ObjectListItem** replacing the **StandardListItem**:
 
    <ObjectListItem title="{NAME}" type="Active">
        <firstStatus>
            <ObjectStatus text="{= ${IS_DONE} === 1 ? 'Done' : 'Open' }" 
                          state="{= ${IS_DONE} === 1 ? 'Success' : 'None' }"/>
        </firstStatus>
        <attributes>
        </attributes>
    </ObjectListItem>
    <headerToolbar>
        <Toolbar>
            <Title level="H3" text="Todos"/>
            <ToolbarSpacer />
        </Toolbar>
    </headerToolbar>

Additionally, we want to sort **Todos** first according to the **IS_DONE** state and second according to the **NAME**.
For that we change the list binding to the following:

    items="{ path: '/Root', sorter: [{ path: 'IS_DONE', descending: false }, 
           { path: 'NAME', descending: false }] }"

#### Execution of an action

A **Todo** can be set to done, via the custom action **setToDone**. We add a clickable object attribute to enable the 
button to change the object's status:

- **App.view.xml**
        
        <attributes>
            <ObjectAttribute text="Set To Done" active="true" press="onSetToDone"></ObjectAttribute>
        </attributes>

- **App.controller.js**
            
        onSetToDone: function (oEvent) {
            var iKey = oEvent.getSource().getBindingContext().getProperty("ID");
            ApplicationObject.setToDone(iKey);
        }

When object attribute with text **Set To Done** is tapped, the action **setToDone** is executed on the Application Object
**Todo** instance, and it is set to done.

#### Binding against dynamic properties

The custom action **setToDone** shall only be enabled, when the Application Object **Todo** is not already set to done and of course
when the the user is authorized to make changed to the **Todo** entry. As we do not want to code the logic of the custom action enabled 
and authorization check from the backend in the UI again, we leverage dynamic properties to bind against 
the **active** property of the **Set To Done** object attribute. 

As in a list of Application Object instances we neither have an Application Object UI model instance nor 
a **sap.aof.PropertyModel** instance, we leverage the static formatters of **sap.aof.PropertyModel** to perform the binding as follows:

- **App.controller.js**
        
        setToDoneEnabled: 
            PropertyModel.getActionEnabledStaticFormatter("sap.app.rest.Todo", "setToDone")
    
- **App.view.xml**

        <ObjectAttribute 
            text="Set To Done" 
            active="{ parts: [{path: 'ID'}, {path: '_'}, 
                              {path: 'CHANGED_AT'}], formatter: '.setToDoneEnabled' }" 
            press="onSetToDone">
        </ObjectAttribute>

Object **PropertyModel** needs to be imported in the **sap.ui.define** section of the app controller, via path **sap/aof/PropertyModel**.
Dynamic properties are then retrieved on-the-fly, as the object property **active** is bound against the
application object instance and the **CHANGED_AT** attribute. The read properties are cached, and therefore are only calculated once.
When a **Todo** instance is updated, the property cache is invalidated and the properties are re-read, as the instance changed.

#### Refresh list via web sockets 

Currently the todo list is only refreshed, when the user manually presses the refresh button. As the Application 
Object Framework (AOF) supports out-of-the-box web sockets, we want to leverage this technology in this tutorial
to automatically and instantly reload the **Todo** list, when any change to an Application Object occurs.

We already enabled web sockets on the application server using **socket.io**, when having a look into the protocol exposure in 
the AOF middleware configuration. To enable web sockets on UI side, we first have to load the **socket.io** client library
in the file **index.html**:

    <script src="/socket.io/socket.io.js"></script>

In the application controller **App.controller.js** in the **onInit** function we register on Application Object 
changes via web sockets:
 
    var oOutput = this.byId("output");
    var oSocket = io("/sap/app/rest/Todo");
    oSocket.on("change", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
        oOutput.getBinding("items").refresh();
    });

Each time any instance of **Todo** is created, updated or deleted, we simply refresh the binding of our output
list, so that the **Todo** items are re-read via OData to update the list. As now the list is automatically 
refreshed via web sockets, the list refresh from the project generation after calling **save** in function 
**onCreate** is not needed anymore,  so that we can change the code to the following in **App.controller.js**:

    var oObject = new ApplicationObject({
        ID: -1,
        NAME: sName,
        IS_DONE: 0
    });
    oObject.save();

The promise returned by **save** is not handled anymore. In addition, we initialize the **IS_DONE** attribute with **0**, 
so that a **Todo** is initialized as "not done" after creation.

#### Deletion of a Todo

Last thing we want to do, is to allow the deletion of **Todos**. The list has to be set to mode **delete**, and 
the delete event has to be handled like this:

- **App.view.xml**

        <List id="output" mode="Delete" delete="onDelete" 
              items="{ path: '/Root', sorter : { path : 'ID', descending: true } }">

- **App.controller.js**
        
        onDelete: function (oEvent) {
            var iKey = oEvent.getParameter("listItem").getBindingContext().getProperty("ID");
            ApplicationObject.del(iKey);
        }

The UI now displays for each **Todo** a red delete button, that deletes the **Todo** instance, once 
the button is clicked. The list is refreshed like before via web socket events, as developed above.

After finishing all UI enhancements of this tutorial the static UI description in file **App.view.xml** looks 
as depicted in figure 8:

![app view xml](assets/app_view_xml.png)
*<br>Figure 8: Changes to App.view.xml*

Changes to the UI application controller **App.controller.js** can be seen in figure 9: 

![app controller js](assets/app_controller_js.png)
*<br>Figure 9: Changes to App.controller.js*

After refreshing the **Todo** application in the browser, the finished UI, as shown in figure 10, can be tested including the 
newly enabled features, like setting **Todos** to done, seeing the **Todo** status, deletion of **Todo** entries and 
having the automatic list refresh via web sockets.
 
![todo ui](assets/todo_ui.png)
*<br>Figure 10: Started Todo application in the browser*  

For further information on the AOF UI5 library, the documentation can be found at   
[API Documentation - UI5 Lib](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/UI.html).

### Cloud Deployment

Up to now we only tested the application locally. We even leveraged for local testing shared services in Cloud Foundry, 
i.e. the project generator used the test UAA service and a test HANA database.  

But of course the XSA environment allows to run the whole application as cloud deployment, and there is also an On-Premise stack, 
to run XSA applications directly as native HANA apps. As part of this tutorial we will use the Cloud Foundry, to run our application in the cloud. 
The deployment to the XS On-Premise HANA server is not part of this how-to, but works very similar as the descriptor files are kept very much the same. 

To support Cloud Foundry deployment, the application has to be described via additional metadata, so that the 
server environment knows, how to configure and start the application. The easiest way to accomplish this, is to add a **manifest.yml**
file to the project root, describing the sub-projects for database (**db**), application server (**js**) and user interface (**web**)
settings and dependencies to external services. The **manifest.yml** for our **Todo** application looks as follows:

    ---
    applications:
    - name: sap-app-todo-db
      path: db
      memory: 256M
      no-route: true
      services:
        - todo-hdi-container
    
    - name: sap-app-todo-web
      host: sap-app-todo
      domain: cfapps.sap.hana.ondemand.com
      memory: 100M
      path: web
      env:
        destinations: >
          [
            {
              "name": "nodejs",
              "url": "https://sap-app-todo-nodejs.cfapps.sap.hana.ondemand.com",
              "forwardAuthToken": true
            }
          ]
      services:
        - todo-uaa
    
    - name: sap-app-todo-js
      host: sap-app-todo-nodejs
      domain: cfapps.sap.hana.ondemand.com
      path: js
      memory: 128M
      services:
        - todo-hdi-container
        - todo-uaa

We can see the dependencies to the services **todo-hdi-container** and **todo-uaa**, which needs to be created 
as user-created services in Cloud Foundry and are bound during push to the deployed application.

Additionally to ignore the **default-services.json** in Cloud Foundry we have to create a file named 
**.cfignore** containing the following line as entry in the folders **web** and **js**:
    
    default-services.json

The following steps have to be performed, to deploy and run an app in Cloud Foundry:

- [Onboard to Cloud Foundry (AWS)](https://onboard.cf.sap.hana.ondemand.com) 
- [Install Cloud Foundry CLI](https://github.com/cloudfoundry/cli/releases)
- Set Cloud Foundry API

        cf api https://api.cf.sap.hana.ondemand.com
    
- Login to Cloud Foundry (use credentials of on-boarding and select organization)
    
        cf login
        
- See available services on service marketplace
    
        cf marketplace
        
- Create user-service: **todo-hdi-container**
    
        cf create-service hana hdi-shared todo-hdi-container
        
- Create user-service: **todo-uaa**
        
        cf create-service xsuaa default todo-uaa
        
- Push **Todo** application
        
        cf push
        
- See list of deployed applications
        
        cf apps

After the application push is successfully completed (which can take some time), the application 
can be started via the URL: [http://sap-app-todo.cfapps.sap.hana.ondemand.com](http://sap-app-todo.cfapps.sap.hana.ondemand.com).

Additional support to Cloud Foundry can be found at the [SAP HANA Cloud Help](https://help.cf.sap.hana.ondemand.com).

## Summary

### What has been discussed

The tutorial covered the most important parts to build an application with the Application Object Framework (AOF) 
based on the SAP XS Advanced technology stack. The AOF framework allows an end-to-end development involving the 
following parts as show-cased in this how-to:

- Project generation to jump start development
- Persistence definition via CDS and HDI
- Object definition setting structural configuration of Application Object 
- Object implementation defining the application logic
- Protocol exposure via REST, OData and Web Sockets
- Consumption of AOF services in the user interface (UI)
- Cloud deployment to Cloud Foundry  

By this, application development can concentrate on business logic organized around a data model of the application objects, 
without having to cope with technical obstacles, as the AOF framework provides and end-to-end development process, 
that is very easy consumable.

The fully implemented "Todo" application can be found and downloaded 
[here](https://github.wdf.sap.corp/xs2/aof/tree/master/docs/howto/todo).  

### Where to go from here?

What we have seen is how easy is it to build an application based on the Application Object Framework (AOF). Of course
this is not all, but just the beginning of what you can do with AOF. The full feature set of AOF you can find 
in the [latest documentation](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/index.html).

Additionally the [AOF Github repository](https://github.wdf.sap.corp/xs2/aof) contains a bunch of examples, that 
show additional and more advanced features. Just check out the [examples](https://github.wdf.sap.corp/xs2/aof/tree/master/examples)
folder to find more information on how to run the code.
 
You will also find there a full-fledged "Todo" application. So you can see, how easily a more complex application can 
be build with AOF. So be inspired and take a look at the [AOF Example "Todo"](https://github.wdf.sap.corp/xs2/aof/tree/master/examples/todo-express-hanaxs).
A running version of this application can be tested in the Cloud Foundry environment following the link 
[Todo APP running on CF](https://sap-aof-todo.cfapps.sap.hana.ondemand.com).