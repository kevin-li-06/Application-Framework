"use strict";

var Determine = require("@sap/aof").Determination;

module.exports = {
    actions: {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        },
        wsConnect: {
            authorizationCheck: false,
            isStatic: true,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getUser().then(function (sUser) {
                    return {"USER": sUser};
                });
            }
        },
        wsDisconnect: {
            authorizationCheck: false,
            isStatic: true,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getUser().then(function (sUser) {
                    return {"USER": sUser};
                });
            }
        },
        post: {
            authorizationCheck: false,
            isStatic: true,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getApplicationObject("sap.chat.Chat").then(function (oApplicationObject) {
                    return oApplicationObject.create(oParameters);
                });
            }
        },
        dummy: {
            authorizationCheck: false,
            execute: function (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext) {
                oWorkObject.TEXT += " - " + new Date();
            }
        }
    },
    Root: {
        table: "sap.aof.example.db.chat::t_chat",
        sequence: "sap.aof.example.db.chat::s_chat",
        determinations: {
            onModify: [Determine.systemAdminData]
        },
        attributes: {
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true
            },
            CHANGED_BY: {
                readOnly: true
            }
        }
    }
};