"use strict";

var winston = require("winston");
var express = require("express");
var passport = require("passport");
var http = require("http");
var socketio = require("socket.io");
var xsenv = require("@sap/xsenv");
var xsodata = require("@sap/xsodata");
var hdbext = require("@sap/hdbext");
var xs2sec = require("@sap/xssec");
var aof = require("@sap/aof");

var PORT = process.env.PORT || 3000;
winston.level = process.env.winston_level || "error";

var app = express();
var server = http.Server(app);
var io = socketio(server);

passport.use("JWT", new xs2sec.JWTStrategy(xsenv.getServices({uaa: {tag: 'xsuaa'}}).uaa));
app.use(passport.initialize());

var fnPassportMiddleware = passport.authenticate("JWT", {session: false});

var oConfig = xsenv.getServices({hana: {tag: 'hana'}});

// > Remove XS_APPLICATIONUSER to suppress error 455: "the predefined session variable cannot be set via SET command: XS_APPLICATIONUSER" <
var fnGetRequestOptions = hdbext.connectionOptions.getRequestOptions;
hdbext.connectionOptions.getRequestOptions = function(req) { var opt = fnGetRequestOptions(req); delete opt.session.XS_APPLICATIONUSER; return opt; };
// > Only for test purposes! <

app.use("/",
    hdbext.middleware(oConfig.hana),
    fnPassportMiddleware
);

aof.middleware(app, {
    applicationObjects: {
        "sap.chat.Chat": "/sap/chat/Chat"
    },
    extensions: {
        odata: {
            name: "@sap/xsodata",
            lib: xsodata
        },
        websocket: {
            name: "socket.io",
            lib: io,
            middleware: [
                fnPassportMiddleware
            ]
        }
    }
}, oConfig);

server.listen(PORT, function () {
    console.log("Chat application is running on port: " + PORT);
});