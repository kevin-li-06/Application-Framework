var AOF = require("./lib/core/framework");
module.exports = AOF;
