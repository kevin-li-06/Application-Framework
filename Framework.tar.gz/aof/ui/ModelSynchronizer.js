sap.ui.define([
    "sap/aof/ApplicationObjectChange",
    "sap/aof/PropertyModel",
    "sap/ui/base/ManagedObject"
], function (ApplicationObjectChange, PropertyModel, ManagedObject) {
    "use strict";

    /**
     * A collection of application object instances to be syncronized
     */
    var oObjects = {};

    /**
     * A collection of application object instance dependencies. One dependence is an object:
     * 1. application object instance
     * 2. dependent model instance
     * 3. function to be called when the application object instance is changed
     */
    var oDependencies = {};

    /**
     * A reference to the OData models that have to be synchronized.
     */
    var aODataModel = [];

    var ModelSynchronizer = ManagedObject.extend("sap.aof.ModelSynchronizer", {
        metadata: {}
    });

    ModelSynchronizer = new ModelSynchronizer({});

    /**
     * Copies the values of oData object properties to the corresponding
     * properties of oInstance application object.
     */
    function updateAOInstance(oNewInstanceData, oAOInstance) {
        if (oAOInstance && oNewInstanceData) {
            for (var prop in oNewInstanceData) {
                if (oNewInstanceData.hasOwnProperty(prop)) {
                    oAOInstance.setProperty("/" + prop, oNewInstanceData[prop]);
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Copies the values of oSource object properties to
     * the corresponding properties of oTarget object.
     */
    function copyProperties(oSource, oTarget) {
        if (oSource && oTarget) {
            for (var prop in oTarget) {
                if (oSource.hasOwnProperty(prop) && oTarget.hasOwnProperty(prop)) {
                    oTarget[prop] = oSource[prop];
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Constructs an OData entity key from the entity name and an object key
     */
    function getEntityKey(sEntitySetName, vKey, oODataModel) {
        var oCalcViewRegex = new RegExp("^" + sEntitySetName + "\\(.*" + vKey + "\\)$");
        var oCalcViewRegex2 = new RegExp("^" + sEntitySetName + "\\(.*(')(" + vKey + ")\\1\\)$");
        var oData = oODataModel.getProperty("/");
        var sEntityKey;
        jQuery.each(oData, function (sKey) {
            if (oCalcViewRegex.test(sKey) || oCalcViewRegex2.test(sKey)) {
                sEntityKey = sKey;
            }
        });
        return sEntityKey;
    }

    /**
     * Copies the content of oData object to the OData entities identified by
     * entity set names contained in aEntitySetNames and vKey
     */
    function syncODataModels(aEntitySetNames, vKey, oData) {
        jQuery.each(aODataModel, function (iIndex, oODataModel) {
            syncODataModel(oODataModel, aEntitySetNames, vKey, oData);
        });
    }

    /**
     * Copies the content of oData object to the OData entities identified by
     * entity set names contained in aEntitySetNames and vKey
     */
    function syncODataModel(oODataModel, aEntitySetNames, vKey, oData) {
        var mChangedEntities = {};
        jQuery.each(aEntitySetNames, function (iIndex, sEntitySetName) {
            var sEntityKey = getEntityKey(sEntitySetName, vKey, oODataModel);
            var oTarget = oODataModel.getProperty("/" + sEntityKey);
            if (oTarget) {
                copyProperties(oData, oTarget);
                mChangedEntities[sEntityKey] = true;
            }
        });
        if (!jQuery.isEmptyObject(mChangedEntities)) {
            oODataModel.checkUpdate(true, false, mChangedEntities);
        }
    }

    /**
     * Adds the application object instance to the collection of
     * application object instances to be kept in sync
     */
    ModelSynchronizer.addApplicationObject = function (sApplicationObjectKey, oInstance) {
        var sApplicationObjectName = oInstance.getApplicationObject().getMetadata().getName();
        if (!oObjects[sApplicationObjectName]) {
            oObjects[sApplicationObjectName] = {};
        }
        if (!oObjects[sApplicationObjectName][sApplicationObjectKey]) {
            oObjects[sApplicationObjectName][sApplicationObjectKey] = [];
        }
        var aInstances = oObjects[sApplicationObjectName][sApplicationObjectKey];
        if (jQuery.inArray(oInstance, aInstances) === -1) {
            aInstances.push(oInstance);
        }
    };

    /**
     * Remove application object instance from the list of instances synchronized by ModelSynchronizer.
     */
    ModelSynchronizer.removeApplicationObject = function (sApplicationObjectKey, oInstance) {
        var sApplicationObjectName = oInstance.getApplicationObject().getMetadata().getName();
        var aInstances = oObjects && oObjects[sApplicationObjectName] && oObjects[sApplicationObjectName][sApplicationObjectKey];
        if (aInstances) {
            oObjects[sApplicationObjectName][sApplicationObjectKey] = jQuery.grep(aInstances, function (oAOInstance, iIndex) {
                return oInstance !== oAOInstance;
            });
        }
    };

    /**
     * Retrieves a set of application object instances with the given type and key
     */
    ModelSynchronizer.getApplicationObject = function (sApplicationObjectName, sApplicationObjectKey) {
        return oObjects && oObjects[sApplicationObjectName] && oObjects[sApplicationObjectName][sApplicationObjectKey] || [];
    };

    /**
     * Add a dependency between two models. The dependency consists of the application object model,
     * the dependent model, and a function that is executed. Once the application object model
     * is changed, the function is called with arguments: the changed application object model and the dependent model.
     */
    ModelSynchronizer.addAODependency = function (oApplicationObject, oDependentModel, fnSyncFunction) {
        if (oApplicationObject && oDependentModel && fnSyncFunction) {
            var oModelDependencies = oDependencies[oApplicationObject];
            if (!oModelDependencies) {
                oModelDependencies = {};
                oDependencies[oApplicationObject] = oModelDependencies;
            }
            oModelDependencies[oDependentModel] = {
                "dependentModel": oDependentModel,
                "syncFunction": fnSyncFunction
            };
            return true;
        }
        return false;
    };

    ModelSynchronizer.removeAODependency = function (oApplicationObject, oDependentModel, fnSyncFunction) {
        if (oApplicationObject && oDependentModel && fnSyncFunction) {
            var oModelDependencies = oDependencies[oApplicationObject];
            if (oModelDependencies) {
                delete oModelDependencies[oDependentModel];
            }
        }
    };

    /**
     * Add an ODataModel to be kept in sync
     */
    ModelSynchronizer.addODataModel = function (oODataModel) {
        aODataModel.push(oODataModel);
    };

    /**
     * Removes an ODataModel to be kept in sync
     */
    ModelSynchronizer.removeODataModel = function (oODataModel) {
        aODataModel = jQuery.grep(aODataModel, function (_oODataModel) {
            return _oODataModel !== oODataModel;
        });
    };

    /**
     * Obtain ODataModels that are kept in sync
     */
    ModelSynchronizer.getODataModels = function () {
        return aODataModel;
    };

    ModelSynchronizer._getApplicationObjectByName = function (sObjectName) {
        jQuery.sap.require(sObjectName);
        return jQuery.sap.getObject(sObjectName, 0);
    };

    ModelSynchronizer.syncEntity = function (sEntitySetName, sKey) {
        var aDeferred = [];
        jQuery.each(aODataModel, function (iIndex, oODataModel) {
            var sEntityKey = getEntityKey(sEntitySetName, sKey, oODataModel);
            if (sEntityKey) {
                var oDeferred = new jQuery.Deferred();
                oODataModel.read("/" + sEntityKey, {
                    success: function (oData) {
                        syncODataModel(syncODataModel, [sEntitySetName], sKey, oData);
                        oDeferred.resolve();
                    },
                    error: function (oError) {
                        oDeferred.reject(oError);
                    }
                });
                aDeferred.push(oDeferred);
            }
        });
        var oResultDeferred = new jQuery.Deferred();
        var oPromise = jQuery.when.apply(jQuery, aDeferred);
        oPromise.done(function () {
            oResultDeferred.resolve();
        });
        oPromise.fail(function (oError) {
            oResultDeferred.reject(oError);
        });
        return oResultDeferred.promise();
    };

    ModelSynchronizer.update = function (oInstance, sActionName, oApplicationObject, vKey, oData, oChangeRequest) {
        if (oInstance) {
            oApplicationObject = oApplicationObject || oInstance.getApplicationObject();
            vKey = vKey || oInstance.getKey();
            oData = oData || oInstance.getData();
        }
        if (!oChangeRequest) {
            oChangeRequest = oData;
        }
        var aEntitySetName = oApplicationObject && oApplicationObject.invalidation && oApplicationObject.invalidation.entitySets;
        var aAOInstances;
        if (oData) {
            /**
             * The application object that triggered the change event
             * has inconsistent OData models. These models have to be updated.
             */
            if (aEntitySetName) {
                syncODataModels(aEntitySetName, vKey, oData);
            }
            aAOInstances = vKey && oApplicationObject && ModelSynchronizer.getApplicationObject(oApplicationObject.getMetadata().getName(), vKey);
            if (aAOInstances && aAOInstances.length > 1) {
                jQuery.each(aAOInstances, function (iIndex, oAOInstance) {
                    if (oAOInstance !== oInstance) {
                        updateAOInstance(oData, oAOInstance);
                    }
                });
                // Update property models of the impacted AO instances
                if (oInstance && oInstance.getPropertyModel()) {
                    oInstance.getPropertyModel().getDataInitializedPromise().done(function () {
                        jQuery.each(aAOInstances, function (iIndex, oAOInstance) {
                            if (oAOInstance !== oInstance && oAOInstance.getPropertyModel()) {
                                oAOInstance.getPropertyModel().sync(vKey, true);
                            }
                        });
                    });
                }
            }
        }
        // A static action is handled
        if (!oInstance && vKey && sActionName !== "del") {
            var sAOName = oApplicationObject.getMetadata().getName();
            var oStaticAO = ModelSynchronizer._getApplicationObjectByName(sAOName);
            jQuery.each(aODataModel, function (iIndex, oODataModel) {
                var oStaticRequest = oStaticAO.readData(vKey, {model: oODataModel, onlyRoot: true});
                if (oStaticRequest) {
                    oStaticRequest.done(function (oSData) {
                        if (aEntitySetName) {
                            syncODataModels(aEntitySetName, vKey, oSData);
                        }
                        // Check if there is an application objects instance to be updated
                        var aSAOInstances = ModelSynchronizer.getApplicationObject(sAOName, vKey);
                        if (aSAOInstances) {
                            jQuery.each(aSAOInstances, function (iIndex, oSAOInstance) {
                                updateAOInstance(oSData, oSAOInstance);
                            });
                        }
                    });
                }
            });
            PropertyModel.invalidateCachedProperties(oApplicationObject.getObjectName(), vKey);
        }

        /**
         * The change of application object that triggered the event impacts other
         * application objects. The models describing these objects have to be updated
         * Change request is also in place for static actions and contains information for foreign keys
         */

        // Check if there are application object types that are impacted by the application object event
        var aImpactedAO = sActionName && oApplicationObject.actions && oApplicationObject.actions[sActionName] && oApplicationObject.actions[sActionName].impacts;
        if (aImpactedAO) {
            // There are application object types impacted by the application object event
            jQuery.each(aImpactedAO, function (iIndex, oImpactedAO) {
                // Retrieve data about the impacted application objects
                var sImpactedObjectName = oImpactedAO.objectName;
                var aObjectKey = oChangeRequest && oImpactedAO.objectKey && oChangeRequest[oImpactedAO.objectKey];
                if (aObjectKey && !Array.isArray(aObjectKey)) {
                    aObjectKey = [aObjectKey];
                }
                if (aObjectKey && sImpactedObjectName) {
                    var oImpactedAOInstance = ModelSynchronizer._getApplicationObjectByName(sImpactedObjectName);
                    // Request the new data for the impacted application object
                    var sImpactedAOName = oImpactedAOInstance.getMetadata().getName();
                    jQuery.each(aODataModel, function (iODataModelIndex, oODataModel) {
                        var oSettings = {
                            model: oODataModel,
                            projection: oImpactedAO.impactedAttributes
                        };
                        jQuery.each(aObjectKey, function (iObjectKeyIndex, vObjectKey) {
                            var oApplicationObjectRequest = oImpactedAOInstance.readSource(vObjectKey, sImpactedAOName, {}, oSettings);
                            oApplicationObjectRequest.done(function (oNewData) {
                                var aImpactedEntitySetName = oImpactedAOInstance.invalidation && oImpactedAOInstance.invalidation.entitySets;
                                syncODataModel(oODataModel, aImpactedEntitySetName, vObjectKey, oNewData);
                                // Check if there is an application objects instance to be updated
                                var aAOInstance = ModelSynchronizer.getApplicationObject(sImpactedObjectName, vObjectKey);
                                if (aAOInstance) {
                                    jQuery.each(aAOInstance, function (iAOInstanceIndex, oAOInstance) {
                                        updateAOInstance(oNewData, oAOInstance);
                                    });
                                }
                            });
                        });
                    });
                }
                var oImpactedEntity = oImpactedAO.entity;
                if (oImpactedEntity) {
                    ModelSynchronizer.syncEntity(oImpactedEntity.entitySet, oImpactedEntity.key);
                }
            });
        }

        // Check if changed application object instance has additional dependents that need an update
        var oModelDependencies = oInstance && oDependencies && oDependencies[oInstance];
        if (oModelDependencies) {
            jQuery.each(oModelDependencies, function (iIndex, oDependency) {
                if (oDependency && oDependency.dependentModel && oDependency.syncFunction) {
                    oDependency.syncFunction(oInstance, oDependency.dependentModel);
                }
            });
        }

        if (oInstance && sActionName === "del" && aAOInstances) {
            aAOInstances.forEach(function (oAOInstance) {
                ModelSynchronizer.removeApplicationObject(oInstance.getKey(), oAOInstance);
                oAOInstance._isDeleted = true;
            });
            delete oObjects[oApplicationObject.getMetadata().getName()][vKey];
        }
    };

    ApplicationObjectChange.attachChange(ApplicationObjectChange.Action.All, function (oEvent) {
        var oInstance = oEvent.getParameter("instance");
        var sActionName = oEvent.getParameter("actionName");
        var oApplicationObject = oEvent.getParameter("object");
        var vKey = oEvent.getParameter("key");
        var oData = oEvent.getParameter("dataUpdate");
        var oChangeRequest = oEvent.getParameter("changeRequest");
        ModelSynchronizer.update(oInstance, sActionName, oApplicationObject, vKey, oData, oChangeRequest);
    });

    return ModelSynchronizer;
});