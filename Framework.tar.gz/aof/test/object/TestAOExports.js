"use strict";

module.exports.default = {
    actions: {
        create: {
            authorizationCheck: false,
        },
        update: {
            authorizationCheck: false,
        },
        del: {
            authorizationCheck: false,
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "t_test",
        sequence: "s_test"
    }
};

module.exports.mapper = {
    in: () => {

    },
    out: () => {

    }
};
