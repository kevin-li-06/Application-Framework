"use strict";

var check = require("@sap/aof").Check;
var Message = require("./message");

module.exports.Role = {
    CommentOwner: "COMMENT_OWNER"
};

module.exports.ObjectType = {
    Comment: "COMMENT"
};

module.exports.node = function (sObjectType, sRole, bReadOnly) {
    return {
        table: "sap.aof.example.db.iam::t_object_identity_role",
        historyTable: "sap.aof.example.db.iam::t_object_identity_role_h",
        sequence: "sap.aof.example.db.iam::s_object_identity_role",
        parentKey: "OBJECT_ID",
        readOnly: bReadOnly,
        consistencyChecks: [check.duplicateCheck("IDENTITY", Message.DUPLICATE_IDENTITY)],
        attributes: {
            OBJECT_TYPE_CODE: {
                constantKey: sObjectType
            },
            ROLE_CODE: {
                constantKey: sRole
            },
            IDENTITY: {
                //foreignKeyTo: "sap.ino.xs.object.iam.Identity.Root"
            }
        }
    };
};