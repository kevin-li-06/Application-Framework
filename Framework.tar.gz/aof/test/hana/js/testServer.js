"use strict";

var http = require("http");
var express = require("express");
var xsodata = require("@sap/xsodata");
var socketio = require("socket.io");
var aof = require("../../../");

process.env.XSODATA_NODE_ENV = xsodata.modes.development;

var PORT = process.env.PORT || 3000;
var oOptions = require("./default-services.json").hana;

var app = express();
var server = http.Server(app);
var io = socketio(server);

aof.middleware(app, {
    metadata: "/test/object/metadata",
    odata: "/test/object/aof",
    applicationObjects: {
        "test.object.TestAO": "/test/object/TestAO",
        "test.object.TestAOConcurrency": "/test/object/TestAOConcurrency",
        "test.object.TestAOFK": "/test/object/TestAOFK",
        "test.object.TestAOM": "/test/object/TestAOM",
        "test.object.TestAOCKA": "/test/object/TestAOCKA"
    },
    extensions: {
        odata: {
            name: "@sap/xsodata",
            lib: xsodata,
            startPath: "/test/hana/js",
            parameters: {
                search: {
                    name: "searchText",
                    fuzzy: 0.8
                },
                views: {
                    "test.object.TestAO.Root": "sap.aof.test.db.test::v_test_odata"
                },
                filters: {
                    filter: {
                        evenIds: {
                            condition: "sap.aof.test.db.test::v_test_even_id",
                            nodes: ["test.object.TestAO.Root"]
                        }
                    },
                    filterTitleOccursNTimes: {
                        condition: "sap.aof.test.db.test::v_test_title_times",
                        nodes: ["test.object.TestAO.Root"],
                        compare: ">="
                    },
                    filterNode1ContainsSometexts: {
                        condition: "sap.aof.test.db.test::v_test_node1_sometexts",
                        nodes: ["test.object.TestAO.Root"],
                        separator: ",",
                        compare: "in",
                        match: "all"
                    },
                    filterNode1SearchSometexts: {
                        condition: "sap.aof.test.db.test::v_test_node1_sometexts",
                        nodes: ["test.object.TestAO.Root"],
                        compare: "search",
                        fuzzy: 0.2
                    }
                }
            }
        },
        websocket: {
            name: "socket.io",
            lib: io
        }
    }
}, {hana: oOptions});

/*server.listen(PORT, function () {
 console.log("Test server running on http://localhost:" + PORT);
 });*/

process.on('unhandledRejection', r => console.log(r));

module.exports = server;