sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/aof/test/controller/CommentDialog",
    "sap/aof/ModelSynchronizer"
], function (UIComponent, ODataModel, CommentDialog, ModelSynchronizer) {
    "use strict";

    return UIComponent.extend("sap.ui.aof.test.Component", {

        metadata: {
            manifest: "json"
        },

        init: function () {
            UIComponent.prototype.init.apply(this, arguments);

            var oConfig = this.getMetadata().getConfig();
            var oCommentModel = new ODataModel(oConfig.comment);
            oCommentModel.setUseBatch(false);
            this.setModel(oCommentModel, "comment");

            ModelSynchronizer.addODataModel(oCommentModel);

            this.commentDialog = new CommentDialog();

            this.getRouter().initialize();
        },

        exit : function() {
            UIComponent.prototype.exit.apply(this, arguments);
            this.getModel("comment").releaseFromSync();
        }
    });
});