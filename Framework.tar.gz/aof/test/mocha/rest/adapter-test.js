"use strict";
var expect = require("chai").expect;
var request = require("supertest");

var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");
var AOF = require("../../../index");
var Adapter = require("../../../lib/rest/adapter");
var SQLiteStore = require("../../../lib/db/sqlite/store");

var util = {};

var sUser = "SAP_AOF_APP";

var express = require("express");

var sqlite;
try {
    sqlite = require("sqlite3").verbose();
} catch (ex) {
    console.log(ex);
    console.log("run?: sudo npm ln sqlite3");
    return;
}

var oDB;

var oApp;

describe("rest-adapter", () => {
    before(() => {
        oApp = express();
        return new Promise((resolve, reject) => {
            Promise.promisifyAll(sqlite.Database.prototype);
            oDB = new sqlite.Database(':memory:', (error) => {
                expect(error).to.be.null;
                oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test" (ID integer primary key, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))')
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_2" (ID integer primary key not null, INT_01 integer, DOUBLE_01 double, TEXT_01 nvarchar(5000), TEXT_02 nvarchar(100), BOOL_01 integer, TS_01 timestamp, DATE_01 date)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null, ANOTHERONE nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_3" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, ANOTHER_TYPE_CODE nvarchar(240) not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_ext_node" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, CUST1 nvarchar(240), CUST2 nvarchar(240), CUST3 nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_h" (HISTORY_DB_EVENT nvarchar(8) not null, HISTORY_BIZ_EVENT nvarchar(600) not null, HISTORY_AT  timestamp not null, HISTORY_ACTOR nvarchar(256) not null, ID integer not null, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_5" (ID integer primary key not null, PARENT_ID integer not null, OBJECT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_concurrency" (ID integer primary key not null, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000), CHANGED_AT timestamp not null, CHANGED_BY nvarchar(256) not null)');
                    })
                    .then(() => {
                        oApp.use((req, res, next) => {
                            req.user = {
                                id: 42
                            };
                            next();
                        });

                        AOF.removeObjectExtension("test.object.TestAO");
                        AOF.middleware(oApp, {
                            metadata: "/test/object/metadata",
                            applicationObjects: {
                                "test.object.TestAO": "/test/object/TestAO",
                                "test.object.TestAOConcurrency": "/test/object/TestAOConcurrency",
                                "test.object.TestAOFK": "/test/object/TestAOFK",
                                "test.object.TestAOM": "/test/object/TestAOM",
                                "test.object.TestAOCKA": "/test/object/TestAOCKA"
                            }
                        }, {
                            sqlite: {
                                db: oDB
                            }
                        });

                        oDB.on('trace', (sql) => {
                            //console.log('SQLite: ' + sql);
                        });
                        resolve();
                    }).catch((e) => {
                    reject(e);
                });
            });
        });
    });

    function createResponseMock() {
        return {
            writeHead: function (sStatus, oHeaders) {
                this.status = sStatus;
                this.contentType = oHeaders["Content-Type"];
            },
            write: function (sBody) {
                this.body = sBody;
            }
        };
    }

    it("exceptions fill correctly the HTTP response", () => {
        var oException = new Adapter.HttpResponseException(_.HTTP.OK, "text");
        var oResponseMock = createResponseMock();
        oException.fillResponse(oResponseMock);

        expect(oResponseMock.status).to.eql(_.HTTP.OK);
        expect(oResponseMock.contentType).to.eql(_.ContentType.PLAIN);
        expect(oResponseMock.body).to.eql("text");
    });

    it("correctly derives the action from the HTTP request", () => {
        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/1455/"
        });

        expect(oInfo.action).to.eql(AOF.Action.Read);
        expect(_.first(oInfo.keys)).to.eql(1455);

        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/1455"
        });

        expect(oInfo.action).to.eql(AOF.Action.Read);
        expect(_.first(oInfo.keys)).to.eql(1455);

        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js"
        });

        expect(oInfo.action).to.eql(AOF.Action.Create);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/" + AOF.Action.Create
        });

        expect(oInfo.action).to.eql(AOF.Action.Create);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.PUT,
            url: "/test.js"
        });

        expect(oInfo.action).to.eql(AOF.Action.Update);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/" + AOF.Action.Update
        });

        expect(oInfo.action).to.eql(AOF.Action.Update);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.PUT,
            url: "/test.js/1232"
        });

        expect(oInfo.action).to.eql(AOF.Action.Update);
        expect(_.first(oInfo.keys)).to.eql(1232);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.PUT,
            url: "/test.js/1232/trace"
        });

        expect(oInfo.action).to.eql(AOF.Action.Update);
        expect(_.first(oInfo.keys)).to.eql(1232);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/1232/" + AOF.Action.Update
        });

        expect(oInfo.action).to.eql(AOF.Action.Update);
        expect(_.first(oInfo.keys)).to.eql(1232);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.DEL,
            url: "/test.js"
        });

        expect(oInfo.action).to.eql(AOF.Action.Del);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/" + AOF.Action.Del
        });

        expect(oInfo.action).to.eql(AOF.Action.Del);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/121/customaction"
        });

        expect(oInfo.action).to.eql("customaction");
        expect(_.first(oInfo.keys)).to.eql(121);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/121/customaction/traced"
        });

        expect(oInfo.action).to.eql("customaction");
        expect(_.first(oInfo.keys)).to.eql(121);

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.POST,
            url: "/test.js/customaction"
        });

        expect(oInfo.action).to.eql("customaction");

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/action/customaction"
        });

        expect(oInfo.action).to.eql("customaction");

        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/121/action/customaction"
        });

        expect(oInfo.action).to.eql("customaction");
    });

    it("maps HTTP response compatibly", () => {
        var oResponse = Adapter._getModifyResponse({
            generatedKeys: {
                "-1": 12,
                "-2": 13
            },
            messages: [{
                severity: AOF.MessageSeverity.Error,
                messageKey: "MSG_KEY",
                refKey: 2343,
                refNode: "SOME_NODE",
                refAttribute: "SOMEATTR",
                parameters: ["PARAM1", "PARAM2", "PARAM3"]
            }]
        }, _.HTTP.CREATED);

        expect(oResponse.status).to.eql(_.HTTP.BAD_REQUEST);

        var oBody = JSON.parse(oResponse.body);

        expect(oBody.GENERATED_KEYS).to.eql({
            "-1": 12,
            "-2": 13
        });

        expect(oBody.MESSAGES).to.eql([{
            TYPE: 'E',
            MESSAGE: 'MSG_KEY',
            REF_KEY: 2343,
            REF_NODE: 'SOME_NODE',
            REF_FIELD: 'SOMEATTR',
            PARAMETERS: ['PARAM1', 'PARAM2', 'PARAM3']
        }]);

        oResponse = Adapter._getModifyResponse({
            generatedKeys: {
                "-1": 12,
                "-2": 13
            }
        }, _.HTTP.CREATED);
        oBody = JSON.parse(oResponse.body);

        expect(oBody.GENERATED_KEYS).to.eql({
            "-1": 12,
            "-2": 13
        });

        expect(oResponse.status).to.eql(_.HTTP.CREATED);
    });

    it("CRUDs a simple object from outside without errors", () => {
        var iId;
        var iCopyId;
        return prepareWriteRequest(oApp, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title"
        }).then((oResponse) => {
            expect(oResponse.body.MESSAGES).to.eql([]);
            expect(oResponse.status).to.eql(_.HTTP.CREATED);
            iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).to.be.ok;

            return prepareReadRequest(oApp, "/test/object/TestAO.js/" + iId);
        }).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.OK);
            expect(oResponse.body).to.eql({
                "ID": iId,
                "TITLE": "Test Title",
                "DESCRIPTION": "Test Title",
                "Node1": [],
                "Node2": []
            });

            return prepareWriteRequest(oApp, "/test/object/TestAO.js/" + iId, {
                DESCRIPTION: "Test Description (Update)"
            }, true);
        }).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.OK);
            expect(oResponse.body.MESSAGES).to.eql([]);
            return prepareReadRequest(oApp, "/test/object/TestAO.js/" + iId);
        }).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.OK);
            expect(oResponse.body).to.eql({
                "ID": iId,
                "TITLE": "Test Title",
                "DESCRIPTION": "Test Description (Update)",
                "Node1": [],
                "Node2": []
            });

            return prepareWriteRequest(oApp, "/test/object/TestAO.js/" + iId + "/copy", {
                ID: -1,
                DESCRIPTION: "Test Description Copy"
            });
        }).then((oResponse) => {
            expect(oResponse.body.MESSAGES).to.eql([]);
            expect(oResponse.status).to.eql(_.HTTP.OK);
            iCopyId = oResponse.body.GENERATED_KEYS[-1];
            expect(iCopyId).to.be.ok;
            return prepareDelRequest(oApp, "/test/object/TestAO.js/" + iId);
        }).then((oResponse) => {
            expect(oResponse.body.MESSAGES).to.eql([]);
            expect(oResponse.status).to.eql(_.HTTP.OK);

            return prepareReadRequest(oApp, "/test/object/TestAO.js/" + iId);
        }).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.NOT_FOUND);
        });
    });

    it("executes a static custom action", () => {
        return prepareWriteRequest(oApp, "/test/object/TestAO.js/staticCustomAction", {
            PARAMETER1: "Test Parameter"
        }).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.OK);
            expect(oResponse.body.MESSAGES.length).to.eql(1);
            expect(oResponse.body.MESSAGES[0].MESSAGE).to.eql("Test Parameter");
        });
    });

    it("execution of not exposed action is not allowed", () => {
        return prepareWriteRequest(oApp, "/test/object/TestAO.js/notExposedAction", {
            PARAMETER1: "Test Parameter"
        }).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.METHOD_NOT_ALLOWED);
            expect(oResponse.body.MESSAGES).not.to.be.ok;
        });
    });

    it("reads a static ready-only custom action (query) via GET", () => {
        return prepareReadRequest(oApp, "/test/object/TestAO.js/action/readOnlyCustomAction?PARAMETER1=Test Parameter", {}).then((oResponse) => {
            expect(oResponse.status).to.eql(_.HTTP.OK);
            expect(oResponse.body.MESSAGES.length).to.eql(1);
            expect(oResponse.body.MESSAGES[0].MESSAGE).to.eql("Test Parameter");
        });
    });

    it("handles optimistic concurrency locking", () => {
        var sGoodEtag = '{"CHANGED_AT":"2014-05-20T14:58:00.123Z"}';

        return prepareWriteRequest(oApp, "/test/object/TestAOConcurrency.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            CHANGED_AT: "2014-05-20T14:58:00.123Z",
            CHANGED_BY: sUser
        }).then((oResponse) => {
            expect(oResponse.body.MESSAGES).to.eql([]);
            expect(oResponse.status).to.eql(_.HTTP.CREATED);
            var iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).to.be.ok;
            return prepareReadRequest(oApp, "/test/object/TestAOConcurrency.js/" + iId).then((oResponse) => {
                expect(oResponse.statusCode).to.eql(_.HTTP.OK);
                var sEtag = oResponse.headers["etag"];
                expect(sEtag).to.eql(sGoodEtag);
            }).then(() => {
                var sOutdatedEtag = '{"CHANGED_AT":"2014-05-20T14:57:50.000Z"}';
                return prepareWriteRequest(oApp, "/test/object/TestAOConcurrency.js/" + iId, {
                    ID: iId,
                    DESCRIPTION: "Test Description(Update)"
                }, true, {
                    "If-Match": sOutdatedEtag
                }).then((oResponse) => {
                    expect(oResponse.statusCode).to.eql(_.HTTP.PRECONDITION_FAILED);
                    var sEtag = oResponse.headers["etag"];
                    expect(sEtag).to.eql(sGoodEtag);
                });
            }).then(() => {
                return prepareWriteRequest(oApp, "/test/object/TestAOConcurrency.js/" + iId, {
                    ID: iId,
                    DESCRIPTION: "Test Description (Update)",
                    CHANGED_AT: "2014-05-20T14:59:50.000Z"
                }, true, {
                    "If-Match": sGoodEtag
                }).then((oResponse) => {
                    expect(oResponse.statusCode).to.eql(_.HTTP.OK);
                    var sEtag = oResponse.headers["etag"];
                    expect(sEtag).to.eql('{"CHANGED_AT":"2014-05-20T14:59:50.000Z"}');
                });
            }).then(() => {
                return prepareWriteRequest(oApp, "/test/object/TestAOConcurrency.js/" + iId, {
                    ID: iId,
                    DESCRIPTION: "Test Description (Update)",
                    CHANGED_AT: "2014-05-20T14:59:55.000Z"
                }, true, {
                    "If-Match": "*"
                }).then((oResponse) => {
                    expect(oResponse.statusCode).to.eql(_.HTTP.OK);
                    var sEtag = oResponse.headers["etag"];
                    expect(sEtag).to.eql('{"CHANGED_AT":"2014-05-20T14:59:55.000Z"}');
                });
            });
        });
    });

    it("correctly derives metadata access from HTTP request", () => {
        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/metadata"
        });
        expect(oInfo.isMetadataRequest).to.eql(true);
    });

    it("correctly derives properties access from HTTP request", () => {
        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/2/properties",
            query: {
                "action": [
                    "update",
                    "customAction",
                    '{ "customAction2" : { "XYZ" : "B" } }'
                ],
                "node": [
                    "Root",
                    "Node1"
                ]
            }
        });
        expect(oInfo.isMetadataRequest).to.eql(false);
        expect(oInfo.isPropertiesRequest).to.eql(true);
        expect(oInfo.keys).to.eql([2]);
        expect(oInfo.requestedActions).to.eql(["update", "customAction", {
            name: "customAction2",
            parameters: {
                XYZ: "B"
            }
        }]);
        expect(oInfo.requestedNodes).to.eql(["Root", "Node1"]);
        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/properties",
            query: {
                "action": [
                    "all"
                ],
                "key": [
                    "11",
                    "12"
                ]
            }
        });

        expect(oInfo.requestedActions).to.eql(true);
        expect(oInfo.requestedNodes).to.eql([]);
        expect(oInfo.keys).to.eql([11, 12]);
        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/staticProperties",
            query: {
                action: [
                    '{ "create" : { "REF_ID" : 1 } }',
                    '{ "betterCreate" : { "REF_ID_BETTER" : 1 } }'
                ]
            }
        });
        expect(oInfo.requestedActions).to.eql([{
            name: "create",
            parameters: {
                REF_ID: 1
            }
        }, {
            name: "betterCreate",
            parameters: {
                REF_ID_BETTER: 1
            }
        }]);
        expect(oInfo.requestedNodes).to.eql([]);
    });

    it("correctly returns metadata requested from outside", () => {
        return prepareReadRequest(oApp, "/test/object/TestAO.js/metadata").then((oResponse) => {
            expect(oResponse).to.be.ok;
            oResponse = oResponse.body;
            expect(oResponse.type).to.eql("Standard");
            expect(oResponse.nodes.Root.readOnly).to.eql(false);
            expect(oResponse.nodes.Root.attributes).to.eql({
                ID: {
                    name: "ID",
                    dataType: AOF.DataType.Integer,
                    isConstant: true,
                    isAlternativeKey: false,
                    required: true,
                    isPrimaryKey: true,
                    readOnly: false,
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TITLE: {
                    name: "TITLE",
                    dataType: AOF.DataType.String,
                    isConstant: false,
                    isAlternativeKey: false,
                    required: true,
                    maxLength: 240,
                    isPrimaryKey: false,
                    readOnly: false,
                    concurrencyControl: true,
                    label: "",
                    isName: true,
                    isDescription: true
                },
                DESCRIPTION: {
                    name: "DESCRIPTION",
                    dataType: AOF.DataType.String,
                    isConstant: false,
                    isAlternativeKey: false,
                    required: false,
                    maxLength: 1000,
                    isPrimaryKey: false,
                    readOnly: false,
                    label: "",
                    isName: false,
                    isDescription: false
                }
            });
            expect(oResponse.actions.create).to.be.ok;
            expect(oResponse.actions.copy).to.be.ok;
            expect(oResponse.actions.copy.isStatic).to.eql(false);
            expect(oResponse.actions.staticCustomAction).to.be.ok;
            // internal action cannot be called and thus should not be exposed in metadata
            expect(oResponse.actions.internalCustomAction === undefined).to.eql(true);
        });
    });

    it("correctly returns properties requested from outside", () => {
        return prepareWriteRequest(oApp, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            Node2: [{
                ID: -2,
                SOMETEXT: "Blafasel"
            }]
        }).then((oResponse) => {
            expect(oResponse.statusCode).to.eql(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).to.eql([]);
            var iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).to.be.ok;
            var iNode2Id = oResponse.body.GENERATED_KEYS[-2];
            expect(iNode2Id).to.be.ok;
            return prepareReadRequest(oApp, "/test/object/TestAO.js/properties?node=all&action=update&key=" + iId).then((oResponse) => {
                expect(oResponse).to.be.ok;
                oResponse = oResponse.body;
                expect(oResponse[iId].nodes.Root[iId]).to.eql({
                    readOnly: false,
                    messages: [],
                    attributes: {
                        ID: {
                            readOnly: false,
                            messages: []
                        },
                        TITLE: {
                            readOnly: false,
                            messages: []
                        },
                        DESCRIPTION: {
                            readOnly: false,
                            messages: []
                        }
                    }
                });
                expect(oResponse[iId].nodes.Node2[iNode2Id]).to.eql({
                    readOnly: false,
                    messages: [],
                    attributes: {
                        ID: {
                            readOnly: false,
                            messages: []
                        },
                        SOMETEXT: {
                            readOnly: false,
                            messages: []
                        }
                    }
                });
                expect(oResponse[iId].actions.del === undefined).to.eql(true);
                expect(oResponse[iId].actions.update).to.eql({
                    enabled: true,
                    messages: [],
                    readOnly: false
                });
            });
        });
    });

    it("correctly returns static properties requested from outside", () => {
        var sAction = encodeURI(JSON.stringify({
            create: {
                REF_ID: 1
            }
        }));

        prepareReadRequest(oApp, "/test/object/TestAO.js/staticProperties?action=" + sAction).then((oResponse) => {
            expect(oResponse).to.be.ok;
            oResponse = oResponse.body;
            expect(oResponse.actions.create).to.eql({
                enabled: true,
                messages: [],
                readOnly: false
            });
        }).then(() => {
            return prepareReadRequest(oApp, "/test/object/TestAO.js/staticProperties?node=Root").then((oResponse) => {
                expect(oResponse).to.be.ok;
                oResponse = oResponse.body;
                expect(oResponse.nodes.Root).to.eql({
                    readOnly: false,
                    attributes: {
                        ID: {
                            readOnly: false
                        },
                        TITLE: {
                            readOnly: false
                        },
                        DESCRIPTION: {
                            readOnly: false
                        }
                    }
                });
            });
        });
    });

    it("correctly calls request and response mapper functions", () => {
        var oMapper = {
            requestMapper: (oRequest) => {
                return {
                    ID: -1,
                    TITLE: "ABC"
                };
            },
            responseMapper: (oResponse, sAction) => {
                return {
                    status: _.HTTP.BAD_REQUEST,
                    contentType: "text/html",
                    body: "<html><p>Hallo!</p></html>"
                };
            }
        };

        var oResponseMock = createResponseMock();
        Adapter._handleRequest("test.object.TestAO", {
            method: _.HTTP.POST,
            url: "test.js",
            store: new SQLiteStore({
                db: oDB
            }),
            user: {
                id: "4711"
            },
            AOF: AOF,
        }, oResponseMock, oMapper).then(() => {
            expect(oResponseMock.status).to.eql(_.HTTP.BAD_REQUEST);
            expect(oResponseMock.contentType).to.eql("text/html");
            expect(oResponseMock.body).to.eql("<html><p>Hallo!</p></html>");
        });
    });
});

function prepareWriteRequest(oApp, sPath, oPayload, bUpdate, oHeaders) {
    var oHeaders = oHeaders || {};
    var oRequest = request(oApp);
    oRequest = bUpdate ? oRequest.put(sPath) : oRequest.post(sPath);
    oRequest = oRequest
        .set('Content-Type', 'application/json')
        .send(oPayload);

    _.each(oHeaders, (sValue, sKey) => {
        oRequest.set(sKey, sValue);
    });

    return oRequest;
}

function prepareDelRequest(oApp, sPath, oHeaders) {
    var oRequest = request(oApp);
    oRequest = oRequest.delete(sPath);
    return oRequest;
}

function prepareReadRequest(oApp, sPath, oPayload, bUpdate, oHeaders) {
    var oRequest = request(oApp);
    return oRequest
        .get(sPath)
        .set('Accept', 'application/json');
}
