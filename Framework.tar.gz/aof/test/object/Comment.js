"use strict";

var determine = require("../../lib/lib/determination");
var ObjectIdentityRole = require("./ObjectIdentityRole");

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "COMMENT_CREATED"
        },
        update: {
            authorizationCheck: false,
            historyEvent: "COMMENT_UPDATED"
        },
        del: {
            authorizationCheck: false,
            historyEvent: "COMMENT_DELETED"
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.test.db.comment::t_comment",
        view: "sap.aof.test.db.comment::v_comment",
        sequence: "sap.aof.test.db.comment::s_comment",
        determinations: {
            onModify: [determine.systemAdminData]
        },
        nodes: {
            Owner: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Comment, ObjectIdentityRole.Role.CommentOwner)
        }
    }
};