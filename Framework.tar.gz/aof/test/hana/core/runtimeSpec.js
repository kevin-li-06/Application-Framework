"use strict";

var Promise = require("bluebird");
Promise.longStackTraces();

require("jasmine-before-all");

var _ = require("../../../lib/util/underscore");
var AOF = require("../../../lib/core/framework");
var Runtime = require("../../../lib/core/runtime");
var Metadata = require("../../../lib/core/metadata");
var Message = require("../../../lib/core/message");
var Checks = require("../../../lib/lib/check");
var StoreFactory = require("../../../lib/db/store-factory");
var HANAStore = require("../../../lib/db/hana/store");

var oContext;

describe("SAP/AOF/CORE/RUNTIME", (done) => {

    var TEST_TABLE = 'sap.aof.test.db.test::t_test';
    var TEST_TABLE_CONCURRENCY = 'sap.aof.test.db.test::t_test_concurrency';
    var TEST_TABLE2 = 'sap.aof.test.db.test::t_test_2';
    var TEST_SEQUENCE = 'sap.aof.test.db.test::s_test';

    var TEST_TABLE_NODE_1 = 'sap.aof.test.db.test::t_test_node_1';
    var TEST_SEQUENCE_NODE_1 = 'sap.aof.test.db.test::s_test_node_1';

    var TEST_TABLE_NODE_2 = 'sap.aof.test.db.test::t_test_node_2';
    var TEST_SEQUENCE_NODE_2 = 'sap.aof.test.db.test::s_test_node_2';

    var TEST_TABLE_NODE_2_1 = 'sap.aof.test.db.test::t_test_node_2_1';
    var TEST_SEQUENCE_NODE_2_1 = 'sap.aof.test.db.test::s_test_node_2_1';

    var TEST_TABLE_NODE_3 = 'sap.aof.test.db.test::t_test_node_3';
    var TEST_SEQUENCE_NODE_3 = 'sap.aof.test.db.test::s_test_node_3';

    var TEST_TABLE_NODE_5 = 'sap.aof.test.db.test::t_test_node_5';
    var TEST_SEQUENCE_NODE_5 = 'sap.aof.test.db.test::s_test_node_5';

    var checkCreateResponse = (oResponse, oRuntimeFacade) => {
        expect(oResponse).toBeDefined();
        expect(oResponse.generatedKeys[-1] > 0).toBeTruthy();
        return oRuntimeFacade.exists(oResponse.generatedKeys[-1]).then((bExists) => {
            expect(bExists).toBe(true);
        });
    };

    var oDummyActions = {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    };

    function asyncLogic(vResult) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve(vResult);
            }, 50);
        });
    }

    function containsMessage(aMessage, iSeverity, sMessageKey) {
        var bContainsMessage = false;
        _.each(aMessage, (oMessage) => {
            if (oMessage.messageKey == sMessageKey && oMessage.severity == iSeverity) {
                bContainsMessage = true;
            }
        });
        return bContainsMessage;
    }

    beforeAll((done) => {
        oContext = {
            storeInfo: {
                hana: require("../../hana/js/default-services.json").hana
            }
        };
        HANAStore.createDB(oContext.storeInfo.hana)
            .then((oDB) => {
                oContext.db = oDB;
                oContext.AOF = AOF;
                return StoreFactory(oContext);
            })
            .then((oStore) => {
                oContext.store = oStore;
                done();
            });
    });

    afterAll((done) => {
        if (oContext.store) {
            oContext.store.rollback();
            oContext.store.close();
        }
        if (oContext.db) {
            oContext.db.close();
        }
        done();
    });

    it("provides a correct runtime facade", (done) => {
        var fnDummy = () => {
            return asyncLogic();
        };

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                myCustomAction1: {
                    authorizationCheck: fnDummy,
                    execute: fnDummy
                },
                myCustomAction2: {
                    authorizationCheck: fnDummy,
                    execute: fnDummy
                },
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            expect(typeof oRuntimeFacade.create).toBe("function");
            expect(typeof oRuntimeFacade.update).toBe("function");
            expect(typeof oRuntimeFacade.del).toBe("function");
            expect(typeof oRuntimeFacade.exists).toBe("function");
            expect(typeof oRuntimeFacade.read).toBe("function");

            expect(typeof oRuntimeFacade.myCustomAction1).toBe("function");
            expect(typeof oRuntimeFacade.myCustomAction2).toBe("function");

            done();
        });
    });

    it("provides a correct runtime phase for reduced actions", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                myCustomAction1: {
                    authorizationCheck: false,
                    execute: () => {
                        return asyncLogic();
                    }
                },
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            expect(typeof oRuntimeFacade.create).toBe("function");
            expect(typeof oRuntimeFacade.update).toBe("function");
            expect(oRuntimeFacade.del === undefined).toBe(true);

            done();
        })
    });

    it("creates, updates and deletes a structured object", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID",
                                attributes: {
                                    ANOTHERONE: {
                                        readOnly: true
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description',
                Node1: [{
                    ID: -2,
                    SOMETEXT: 'Instance 1 of Node 1'
                }, {
                    ID: -3,
                    SOMETEXT: 'Instance 2 of Node 1'
                }],
                Node2: [{
                    ID: -4,
                    SOMETEXT: 'Instance 1 of Node 2',
                    Node21: [{
                        ID: -5,
                        SOMETEXT: 'Instance 1 of Node 2_1',
                        // This is read-only thus this input should be ignored
                        ANOTHERONE: 'Any value'
                    }, {
                        ID: -6,
                        SOMETEXT: 'Instance 2 of Node 2_1'
                    }]
                }, {
                    ID: -7,
                    SOMETEXT: 'Instance 2 of Node 2',
                    Node21: [{
                        ID: -8,
                        SOMETEXT: 'Instance 3 of Node 2_1'
                    }, {
                        ID: -9,
                        SOMETEXT: 'Instance 4 of Node 2_1'
                    }]
                }]
            }).then((oResponse) => {
                return checkCreateResponse(oResponse, oRuntimeFacade).then(() => {
                    expect(_.keys(oResponse.generatedKeys).length).toBe(9);
                    var iRootKey = oResponse.generatedKeys[-1];
                    return oRuntimeFacade.read(iRootKey).then((oPersistedObject) => {
                        expect(oPersistedObject).toEqual({
                            ID: oResponse.generatedKeys[-1],
                            TITLE: 'New node title',
                            DESCRIPTION: 'New node description',
                            Node1: [{
                                ID: oResponse.generatedKeys[-2],
                                SOMETEXT: 'Instance 1 of Node 1'
                            }, {
                                ID: oResponse.generatedKeys[-3],
                                SOMETEXT: 'Instance 2 of Node 1'
                            }],
                            Node2: [{
                                ID: oResponse.generatedKeys[-4],
                                SOMETEXT: 'Instance 1 of Node 2',
                                Node21: [{
                                    ID: oResponse.generatedKeys[-5],
                                    SOMETEXT: 'Instance 1 of Node 2_1',
                                    ANOTHERONE: null
                                }, {
                                    ID: oResponse.generatedKeys[-6],
                                    SOMETEXT: 'Instance 2 of Node 2_1',
                                    ANOTHERONE: null
                                }]
                            }, {
                                ID: oResponse.generatedKeys[-7],
                                SOMETEXT: 'Instance 2 of Node 2',
                                Node21: [{
                                    ID: oResponse.generatedKeys[-8],
                                    SOMETEXT: 'Instance 3 of Node 2_1',
                                    ANOTHERONE: null
                                }, {
                                    ID: oResponse.generatedKeys[-9],
                                    SOMETEXT: 'Instance 4 of Node 2_1',
                                    ANOTHERONE: null
                                }]
                            }]
                        });
                    }).then(() => {
                        return oRuntimeFacade.update({
                            ID: oResponse.generatedKeys[-1],
                            TITLE: 'New node title (Update)',
                            Node1: [{
                                ID: oResponse.generatedKeys[-2],
                                SOMETEXT: 'Instance 1 of Node 1 (Update)'
                            }, {
                                ID: -1,
                                SOMETEXT: 'Instance 3 of Node 1 (New)'
                            }],
                            Node2: [{
                                ID: oResponse.generatedKeys[-4],
                                Node21: [{
                                    ID: oResponse.generatedKeys[-5],
                                    SOMETEXT: 'Instance 1 of Node 2_1 (Update)'
                                }, {
                                    ID: -2,
                                    SOMETEXT: 'Instance 3 of Node 2_1 (New)'
                                }]
                            }, {
                                ID: -3,
                                SOMETEXT: 'Instance 3 of Node 2 (New)',
                                Node21: [{
                                    ID: -4,
                                    SOMETEXT: 'Instance 5 of Node 2_1 (New)'
                                }, {
                                    ID: -5,
                                    SOMETEXT: 'Instance 6 of Node 2_1 (New)'
                                }]
                            }]
                        }).then((oUpdateResponse) => {
                            expect(_.keys(oUpdateResponse.generatedKeys).length).toBe(5);
                            return oRuntimeFacade.read(iRootKey).then((oPersistedObject) => {
                                expect(oPersistedObject).toEqual({
                                    ID: oResponse.generatedKeys[-1],
                                    TITLE: 'New node title (Update)',
                                    DESCRIPTION: 'New node description',
                                    Node1: [{
                                        ID: oUpdateResponse.generatedKeys[-1],
                                        SOMETEXT: 'Instance 3 of Node 1 (New)'
                                    }, {
                                        ID: oResponse.generatedKeys[-2],
                                        SOMETEXT: 'Instance 1 of Node 1 (Update)'
                                    }],
                                    Node2: [{
                                        ID: oResponse.generatedKeys[-4],
                                        SOMETEXT: 'Instance 1 of Node 2',
                                        Node21: [{
                                            ID: oUpdateResponse.generatedKeys[-2],
                                            SOMETEXT: 'Instance 3 of Node 2_1 (New)',
                                            ANOTHERONE: null
                                        }, {
                                            ID: oResponse.generatedKeys[-5],
                                            SOMETEXT: 'Instance 1 of Node 2_1 (Update)',
                                            ANOTHERONE: null
                                        }]
                                    }, {
                                        ID: oUpdateResponse.generatedKeys[-3],
                                        SOMETEXT: 'Instance 3 of Node 2 (New)',
                                        Node21: [{
                                            ID: oUpdateResponse.generatedKeys[-4],
                                            SOMETEXT: 'Instance 5 of Node 2_1 (New)',
                                            ANOTHERONE: null
                                        }, {
                                            ID: oUpdateResponse.generatedKeys[-5],
                                            SOMETEXT: 'Instance 6 of Node 2_1 (New)',
                                            ANOTHERONE: null
                                        }]
                                    }]
                                });
                            });
                        }).then(() => {
                            return oRuntimeFacade.del(iRootKey);
                        }).then(() => {
                            return oRuntimeFacade.read(iRootKey);
                        }).then((oPersistedObject) => {
                            expect(oPersistedObject).toBe(null);

                            done();
                        });
                    });
                });
            });
        });
    });

    it("creates a root node", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                attributes: {
                    DESCRIPTION: {
                        readOnly: true
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description'
            }).then((oRequestResponse1) => {
                return checkCreateResponse(oRequestResponse1, oRuntimeFacade).then(() => {
                    return oRuntimeFacade.create({
                        ID: -1,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description'
                    });
                }).then((oRequestResponse2) => {
                    return checkCreateResponse(oRequestResponse2, oRuntimeFacade).then(() => {
                        expect(oRequestResponse2.generatedKeys[-1]).not.toBe(oRequestResponse1.generatedKeys[-1]);
                        // Check that description is empty as it is read-only
                        return oRuntimeFacade.read(oRequestResponse1.generatedKeys[-1]).then((oObject) => {
                            expect(oObject.DESCRIPTION).toBe(null);

                            done();
                        });
                    });
                });
            });
        });
    });

    it("does not allow to change the framework internal object buffer from outside", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            oRuntimeFacade.create({
                ID: -1,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description',
                Node1: [{
                    SOMETEXT: 'Instance 1 of Node 1'
                }]
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var iKey = oResponse.generatedKeys[-1];

                oRuntimeFacade.read(iKey).then((oObject1) => {
                    expect(oObject1).toBeDefined();
                    expect(oObject1.TITLE).toBe("New node title");
                    expect(oObject1.Node1[0].SOMETEXT).toBe("Instance 1 of Node 1");

                    oObject1.TITLE = "DUMMY";
                    oObject1.Node1[0].SOMETEXT = "DUMMY";
                }).then(() => {
                    return oRuntimeFacade.read(iKey);
                }).then((oObject2) => {
                    expect(oObject2).toBeDefined();
                    expect(oObject2.TITLE).toBe("New node title");
                    expect(oObject2.Node1[0].SOMETEXT).toBe("Instance 1 of Node 1");

                    done();
                });
            });
        });
    });

    it("merge two objects", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID",
                        readOnly: () => {
                            return asyncLogic(true);
                        }
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID",
                                attributes: {
                                    ANOTHERONE: {
                                        readOnly: () => {
                                            return asyncLogic(true);
                                        }
                                    }
                                }
                            }
                        }
                    },
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        sequence: TEST_SEQUENCE_NODE_3,
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                constantKey: "CONSTANT_KEY"
                            }
                        },
                        readOnly: true
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDestination = {
                ID: 1,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description',
                Node1: [{
                    ID: 2,
                    SOMETEXT: 'Instance 1 of Node 1'
                }, {
                    ID: 3,
                    SOMETEXT: 'Instance 2 of Node 1'
                }],
                Node2: [{
                    ID: 4,
                    SOMETEXT: 'Instance 1 of Node 2',
                    Node21: [{
                        ID: 5,
                        SOMETEXT: 'Instance 1 of Node 2_1',
                        ANOTHERONE: 'Instance 1 of Node 2_1'
                    }, {
                        ID: 6,
                        SOMETEXT: 'Instance 2 of Node 2_1'
                    }]
                }, {
                    ID: 7,
                    SOMETEXT: 'Instance 2 of Node 2',
                    Node21: [{
                        ID: 8,
                        SOMETEXT: 'Instance 3 of Node 2_1'
                    }, {
                        ID: 9,
                        SOMETEXT: 'Instance 4 of Node 2_1'
                    }]
                }],
                Node3: [{
                    ID: 10,
                    OBJECT_TYPE_CODE: "ABC",
                    ANOTHER_TYPE_CODE: "DEF",
                    SOMETEXT: "Read-only Instance 1 of Node 3"
                }]
            };

            var oSource = {
                ID: 1,
                TITLE: 'New node title (Update)',
                Node1: [{
                    ID: 2,
                    SOMETEXT: 'Instance 1 of Node 1 (Update)'
                }, {
                    ID: -1,
                    SOMETEXT: 'Instance 3 of Node 1 (New)'
                }],
                Node2: [{
                    ID: 4,
                    Node21: [{
                        ID: 5,
                        SOMETEXT: 'Instance 1 of Node 2_1 (Update)',
                        ANOTHERONE: 'Instance 1 of Node 2_1 (Update)'
                    }, {
                        ID: -2,
                        SOMETEXT: 'Instance 3 of Node 2_1 (New)'
                    }]
                }, {
                    ID: -3,
                    SOMETEXT: 'Instance 3 of Node 2 (New)',
                    Node21: [{
                        ID: -4,
                        SOMETEXT: 'Instance 5 of Node 2_1 (New)'
                    }, {
                        ID: -5,
                        SOMETEXT: 'Instance 6 of Node 2_1 (New)'
                    }]
                }],
                Node3: [{
                    ID: -6,
                    OBJECT_TYPE_CODE: "ABC",
                    ANOTHER_TYPE_CODE: "XYZ",
                    SOMETEXT: "Read-only Instance 1 of Node 3"
                }]
            };

            Runtime._mergeObjects(oDestination, oSource, oMetadataAccess, Message.createMessageBuffer("test.object.TestAO")).then((oResult) => {
                expect(oResult).toEqual({
                    ID: 1,
                    TITLE: 'New node title (Update)',
                    DESCRIPTION: 'New node description',
                    // Node 1 read-only
                    Node1: [{
                        ID: 2,
                        SOMETEXT: 'Instance 1 of Node 1'
                    }, {
                        ID: 3,
                        SOMETEXT: 'Instance 2 of Node 1'
                    }],
                    Node2: [{
                        ID: 4,
                        SOMETEXT: 'Instance 1 of Node 2',
                        Node21: [{
                            ID: 5,
                            SOMETEXT: 'Instance 1 of Node 2_1 (Update)',
                            // Another one is read-only
                            ANOTHERONE: 'Instance 1 of Node 2_1'
                        }, {
                            ID: -2,
                            SOMETEXT: 'Instance 3 of Node 2_1 (New)'
                        }]
                    }, {
                        ID: -3,
                        SOMETEXT: 'Instance 3 of Node 2 (New)',
                        Node21: [{
                            ID: -4,
                            SOMETEXT: 'Instance 5 of Node 2_1 (New)'
                        }, {
                            ID: -5,
                            SOMETEXT: 'Instance 6 of Node 2_1 (New)'
                        }]
                    }],
                    Node3: [{
                        ID: 10,
                        OBJECT_TYPE_CODE: "ABC",
                        ANOTHER_TYPE_CODE: "DEF",
                        SOMETEXT: "CONSTANT_KEY"
                    }]
                });

                done();
            });
        });
    });

    it("merge error with source object having unknown key", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDestination = {
                ID: 1,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description',
                Node1: [{
                    ID: 2,
                    SOMETEXT: 'Instance 1 of Node 1'
                }, {
                    ID: 3,
                    SOMETEXT: 'Instance 2 of Node 1'
                }]
            };

            var oSource = {
                ID: 1,
                TITLE: 'New node title (Update)',
                Node1: [{
                    ID: 2,
                    SOMETEXT: 'Instance 1 of Node 1 (Update)'
                }, {
                    ID: 4,
                    SOMETEXT: 'Instance 3 of Node 1 (Unkown Node)'
                }]
            };

            var oMessageBuffer = Message.createMessageBuffer("test.object.TestAO");

            Runtime._mergeObjects(oDestination, oSource, oMetadataAccess, oMessageBuffer).then(() => {
                expect(0).toBe(1);

                done();
            }).catch((e) => {
                expect(oMessageBuffer.getMessages()).toEqual([{
                    severity: 1,
                    messageKey: 'MSG_AOF_NODE_INSTANCE_UNKNOWN',
                    refObject: 'test.object.TestAO',
                    refKey: 4,
                    refNode: 'Node1',
                    refAttribute: 'ID',
                    parameters: [4, 'Node1']
                }]);

                done();
            });
        });
    });

    it("considers authorization checks", (done) => {
        var bAuthCheckFail = true;

        function noAuth(vKey, oRequest, fnMessage) {
            if (bAuthCheckFail) {
                fnMessage(Runtime.MessageSeverity.Fatal, "MSG_NO_AUTH_FOR_NOTHING");
            }
            return asyncLogic();
        }

        function authorizationCheckResponse(oResponse) {
            expect(_.first(oResponse.messages)).toEqual({
                severity: Runtime.MessageSeverity.Fatal,
                messageKey: 'MSG_NO_AUTH_FOR_NOTHING',
                refObject: 'sap.aof.test.db.test.WhateverAO',
                refKey: undefined,
                refNode: 'Root',
                refAttribute: undefined,
                parameters: [],
                auth: true
            });
        }

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                create: {
                    authorizationCheck: noAuth
                },
                update: {
                    authorizationCheck: noAuth
                },
                del: {
                    authorizationCheck: noAuth
                },
                read: {
                    authorizationCheck: noAuth
                },
                customAction: {
                    authorizationCheck: noAuth,
                    execute: () => {
                        return asyncLogic();
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);

            bAuthCheckFail = true;
            return oRuntimeFacade.create({
                ID: -1
            }).then((oResponse) => {
                authorizationCheckResponse(oResponse);
                bAuthCheckFail = false;
            }).then(() => {
                return oRuntimeFacade.create({
                    ID: -1,
                    TITLE: 'ABC'
                }).then((oResponse) => {
                    var iId = oResponse.generatedKeys[-1];
                    bAuthCheckFail = true;
                    return oRuntimeFacade.read(iId).then((oResponse) => {
                        authorizationCheckResponse(oResponse);
                    }).then(() => {
                        bAuthCheckFail = true;
                        return oRuntimeFacade.update({
                            ID: iId
                        });
                    }).then((oResponse) => {
                        authorizationCheckResponse(oResponse);
                    }).then(() => {
                        bAuthCheckFail = true;
                        return oRuntimeFacade.del(iId);
                    }).then((oResponse) => {
                        authorizationCheckResponse(oResponse);
                    }).then(() => {
                        bAuthCheckFail = true;
                        return oRuntimeFacade.customAction(iId);
                    }).then((oResponse) => {
                        authorizationCheckResponse(oResponse);
                    }).then(() => {

                        done();
                    });
                });
            });
        });
    });

    it("calls action callback methods", (done) => {
        var mArgs = {};
        var fnStub = (sName) => {
            return (...args) => {
                var aArgs = _.toArray(args);
                mArgs[sName] = mArgs[sName] || [];
                mArgs[sName].push(aArgs);
                return asyncLogic();
            };
        };

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                doCustomAction: {
                    authorizationCheck: fnStub("authorizationCheck"),
                    enabledCheck: fnStub("check"),
                    execute: fnStub("execute")
                },
                doStaticCustomAction: {
                    isStatic: true,
                    authorizationCheck: fnStub("staticAuthorizationCheck"),
                    enabledCheck: fnStub("staticEnabledCheck"),
                    execute: fnStub("staticExecute")
                },
                create: {
                    authorizationCheck: false,
                    executionCheck: fnStub("executionCheck")
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            var oParams = {
                PARAM1: "ABC",
                PARAM2: "XYZ"
            };
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "TEST TITLE"
            }).then((oResponse) => {
                oRuntimeFacade.doCustomAction(oResponse.generatedKeys[-1], oParams).then(() => {
                    expect(mArgs["execute"].length).toBe(1);
                    expect(_.first(mArgs["execute"])[0]).toBe(oResponse.generatedKeys[-1]);
                    expect(_.first(mArgs["execute"])[1]).toEqual(oParams);
                    // oWorkObject
                    expect(_.first(mArgs["execute"])[2]).toBeDefined();
                    // oMessageBuffer
                    expect(_.first(mArgs["execute"])[3]).toBeDefined();

                    expect(mArgs["check"].length).toBe(1);
                    expect(_.first(mArgs["check"])[0]).toBe(oResponse.generatedKeys[-1]);
                    expect(_.first(mArgs["check"])[1]).toBeDefined();

                    expect(mArgs["authorizationCheck"].length).toBe(1);
                    expect(_.first(mArgs["authorizationCheck"])[0]).toBe(oResponse.generatedKeys[-1]);
                    expect(_.first(mArgs["authorizationCheck"])[1]).toBeDefined();

                    expect(mArgs["executionCheck"].length).toBe(1);
                }).then(() => {
                    return oRuntimeFacade.doStaticCustomAction(oParams);
                }).then(() => {
                    expect(mArgs["staticExecute"].length).toBe(1);
                    expect(_.first(mArgs["staticExecute"])[0]).toBe(oParams);

                    expect(mArgs["staticAuthorizationCheck"].length).toBe(1);
                    expect(_.first(mArgs["staticAuthorizationCheck"])[0]).toBe(oParams);

                    expect(mArgs["staticEnabledCheck"].length).toBe(1);
                    expect(_.first(mArgs["staticEnabledCheck"])[0]).toBe(oParams);

                    done();
                });
            });
        });
    });

    it("executes a custom action", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                doCustomAction: {
                    authorizationCheck: false,
                    execute: (vKey, oParams, oWorkObject, fnMessage, oContext, fnNextHandle) => {
                        if (!oParams.NEW_DESCRIPTION) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "MSG_PARAM_INVALID");
                            return;
                        }
                        oWorkObject.DESCRIPTION = oParams.NEW_DESCRIPTION;
                        return asyncLogic();
                    }
                },
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Any title"
            }).then((oResponse) => {
                var iKey = oResponse.generatedKeys[-1];

                return oRuntimeFacade.doCustomAction(iKey, {
                    NEW_DESCRIPTION: "Changed description"
                }).then((oResponse) => {
                    expect(oResponse).toBeDefined();
                    expect(oResponse.messages.length).toBe(0);

                    return oRuntimeFacade.read(iKey).then((oObject) => {
                        expect(oObject.DESCRIPTION).toBe("Changed description");
                        return oRuntimeFacade.doCustomAction(iKey, {});
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages.length).toBe(1);

                        done();
                    });
                });
            });
        });
    });

    it("executes a static custom action", (done) => {
        var oRuntimeFacade = undefined;
        var vKey = undefined;

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                doCustomAction: {
                    isStatic: true,
                    authorizationCheck: false,
                    execute: (oParams, oBulkAccess, addMessage, oContext) => {
                        return oRuntimeFacade.create({
                            ID: -1,
                            TITLE: oParams.DESCRIPTION
                        }).then((oResponse) => {
                            vKey = oResponse.generatedKeys[-1];
                            addMessage(oResponse.messages);
                        });
                    }
                },
                create: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.doCustomAction({
                DESCRIPTION: "Static Action Description"
            }).then((oResponse) => {
                expect(oResponse).toBeDefined();
                expect(oResponse.messages.length).toBe(0);
                return oRuntimeFacade.read(vKey);
            }).then((oObject) => {
                expect(oObject.TITLE).toBe("Static Action Description");

                done();
            });
        });
    });

    it("calls check callback methods", (done) => {
        var mArgs = {};
        var fnStub = (sName) => {
            return (...args) => {
                var aArgs = _.toArray(args);
                mArgs[sName] = mArgs[sName] || [];
                mArgs[sName].push(aArgs);
                return asyncLogic();
            };
        };

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                consistencyChecks: [fnStub("rootCheck")],
                inputChecks: [fnStub("rootCheck2")],
                attributes: {
                    TITLE: {
                        consistencyChecks: [fnStub("titleCheck")],
                        inputChecks: [fnStub("titleCheck2")],
                    }
                },
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnStub("node2Check")],
                        inputChecks: [fnStub("node2Check2")],
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID",
                                consistencyChecks: [fnStub("node21Check")],
                                inputChecks: [fnStub("node21Check2")],
                                attributes: {
                                    SOMETEXT: {
                                        consistencyChecks: [fnStub("someTextCheck")],
                                        inputChecks: [fnStub("someTextCheck2")]
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Any title",
                Node2: [{
                    ID: -2,
                    SOMETEXT: "Instance 1 Node 2",
                    Node21: [{
                        ID: -3,
                        SOMETEXT: "Instance 1 Node 21"
                    }, {
                        ID: -4,
                        SOMETEXT: "Instance 2 Node 21"
                    }]
                }, {
                    ID: -5,
                    SOMETEXT: "Instance 2 Node 2",
                    Node21: [{
                        ID: -6,
                        SOMETEXT: "Instance 3 Node 21",
                    }]
                }]
            }).then((oResponse) => {
                expect(oResponse).toBeDefined();

                expect(mArgs["rootCheck"].length).toBe(1);
                expect(mArgs["rootCheck2"].length).toBe(1);

                expect(mArgs["node2Check"].length).toBe(1);
                expect(mArgs["node2Check2"].length).toBe(1);
                // Subnode checks run once per parent usage (called with the whole array)
                expect(mArgs["node21Check"].length).toBe(2);
                expect(mArgs["node21Check2"].length).toBe(2);

                expect(mArgs["titleCheck"].length).toBe(1);
                expect(mArgs["titleCheck2"].length).toBe(1);
                expect(mArgs["someTextCheck"].length).toBe(3);
                expect(mArgs["someTextCheck2"].length).toBe(3);

                done();
            });
        });
    });

    it("calls determination callback methods", (done) => {
        var mArgs = {};
        var fnStub = (sName) => {
            return (...args) => {
                var aArgs = _.toArray(args);
                mArgs[sName] = mArgs[sName] || [];
                mArgs[sName].push(aArgs);
                return asyncLogic();
            };
        };

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onCreate: [fnStub("onCreate")],
                    onUpdate: [fnStub("onUpdate")],
                    onModify: [fnStub("onModify")],
                    onDelete: [fnStub("onDelete")],
                    onRead: [fnStub("onRead")],
                    onPersist: [fnStub("onPersist")]
                }
            },
            actions: {
                doCustomAction: {
                    authorizationCheck: fnStub("authorizationCheck"),
                    check: fnStub("check"),
                    execute: fnStub("execute")
                },
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            var oParams = {
                PARAM1: "ABC",
                PARAM2: "XYZ"
            };
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "TEST TITLE"
            }).then((oResponse) => {

                expect(mArgs["onCreate"].length).toBe(1);
                expect(!mArgs["onUpdate"]).toBeTruthy();
                expect(mArgs["onModify"].length).toBe(1);
                expect(!mArgs["onDelete"]).toBeTruthy();
                expect(mArgs["onPersist"].length).toBe(1);

                var iKey = oResponse.generatedKeys[-1];

                return oRuntimeFacade.read(iKey).then(() => {
                }).then(() => {
                    return oRuntimeFacade.update({
                        ID: iKey,
                        TITLE: "NEW TITLE"
                    });
                }).then((oResponse) => {
                    expect(mArgs["onCreate"].length).toBe(1);
                    expect(mArgs["onUpdate"].length).toBe(1);
                    expect(mArgs["onModify"].length).toBe(2);
                    expect(!mArgs["onDelete"]).toBeTruthy();
                    expect(mArgs["onRead"].length).toBe(2);
                    expect(mArgs["onPersist"].length).toBe(2);
                    return oRuntimeFacade.doCustomAction(iKey, oParams);
                }).then((oResponse) => {
                    expect(mArgs["onCreate"].length).toBe(1);
                    expect(mArgs["onUpdate"].length).toBe(2);
                    expect(mArgs["onModify"].length).toBe(3);
                    expect(mArgs["onRead"].length).toBe(3);
                    expect(mArgs["onPersist"].length).toBe(3);
                    return oRuntimeFacade.del(iKey);
                }).then((oResponse) => {
                    expect(mArgs["onCreate"].length).toBe(1);
                    expect(mArgs["onUpdate"].length).toBe(2);
                    expect(mArgs["onModify"].length).toBe(3);
                    expect(mArgs["onDelete"].length).toBe(1);
                    expect(mArgs["onRead"].length).toBe(4);
                    expect(mArgs["onPersist"].length).toBe(4);
                    return oRuntimeFacade.read(iKey);
                }).then((oResponse) => {
                    expect(mArgs["onCreate"].length).toBe(1);
                    expect(mArgs["onUpdate"].length).toBe(2);
                    expect(mArgs["onModify"].length).toBe(3);
                    expect(mArgs["onDelete"].length).toBe(1);
                    expect(mArgs["onRead"].length).toBe(4);
                    expect(mArgs["onPersist"].length).toBe(4);

                    done();
                });
            });
        });
    });

    it("checks required attributes", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                required: true
                            }
                        },
                        nodes: {
                            Node11: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID",
                                attributes: {
                                    SOMETEXT: {
                                        required: true
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                Node1: [{
                    ID: -2,
                    Node11: [{
                        ID: -3,
                    }]
                }]
            }).then((oResponse) => {
                expect(oResponse).toBeDefined();
                expect(oResponse.messages).toBeDefined();
                expect(oResponse.messages.length).toBe(3);

                done();
            });
        });
    });

    it("consistency checks foreign key references", (done) => {
        var oMetadata;
        Metadata.getMetadata("An.arbitrary.object", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE_NODE_3,
                sequence: TEST_SEQUENCE_NODE_3,
                attributes: {
                    OBJECT_ID: {
                        foreignKeyTo: "test.object.TestAO.Root"
                    }
                }
            }
        }).then((_oMetadata) => {
            oMetadata = _oMetadata;
            return AOF.getApplicationObject("test.object.TestAO", oContext);
        }).then((oApplicationObject) => {
            expect(oApplicationObject).toBeDefined();

            return oApplicationObject.create({
                ID: -1,
                TITLE: "A reference title",
                DESCRIPTION: "A"
            }).then((oResponse) => {
                var iKey = oResponse.generatedKeys[-1];

                var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
                expect(oRuntimeFacade).toBeDefined();

                return oRuntimeFacade.create({
                    ID: -1,
                    OBJECT_ID: iKey,
                    OBJECT_TYPE_CODE: "ABC",
                    ANOTHER_TYPE_CODE: "ABC",
                    SOMETEXT: "Sometext"
                }).then((oResponse) => {
                    expect(oResponse).toBeDefined();
                    expect(oResponse.messages).toBeDefined();
                    expect(oResponse.messages.length).toBe(0);

                    return oRuntimeFacade.create({
                        ID: -1,
                        OBJECT_ID: iKey + 1000, // this reference won't exist
                        OBJECT_TYPE_CODE: "ABC",
                        ANOTHER_TYPE_CODE: "ABC",
                        SOMETEXT: "Sometext"
                    });

                }).then((oResponse) => {
                    expect(oResponse).toBeDefined();
                    expect(oResponse.messages).toBeDefined();
                    expect(oResponse.messages.length).toBe(1);

                    done();
                });
            });
        });
    });

    it("generates handles correctly", (done) => {
        var oHandleManager = Runtime._createHandleManager();
        expect(oHandleManager).toBeDefined();

        var iNextHandle = oHandleManager.getNextHandle();
        expect(iNextHandle).toBe(-1);

        iNextHandle = oHandleManager.getNextHandle();
        expect(iNextHandle).toBe(-2);

        oHandleManager.registerUsedHandle(-10);
        iNextHandle = oHandleManager.getNextHandle();
        expect(iNextHandle).toBe(-11);

        iNextHandle = oHandleManager.getNextHandle();
        expect(iNextHandle).toBe(-12);

        oHandleManager = Runtime._createHandleManager();
        expect(oHandleManager).toBeDefined();
        iNextHandle = oHandleManager.registerUsedHandle(-1);
        iNextHandle = oHandleManager.getNextHandle();
        expect(iNextHandle).toBe(-2);

        done();
    });

    it("determines start value for handles correctly", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oSource = {
                ID: 1,
                TITLE: 'New node title (Update)',
                Node1: [{
                    ID: 2,
                    SOMETEXT: 'Instance 1 of Node 1 (Update)'
                }, {
                    ID: -13,
                    SOMETEXT: 'Instance 3 of Node 1 (New)'
                }]
            };

            var oDestination = {
                ID: 1,
                Node1: [{
                    ID: 2,
                    SOMETEXT: 'Instance 1 of Node 1'
                }]
            };

            var oHandleManager = Runtime._createHandleManager();
            return Runtime._mergeObjects(oDestination, oSource, oMetadataAccess, Message.createMessageBuffer("test.object.TestAO"), oHandleManager.registerUsedHandle).then(() => {
                var iNextHandle = oHandleManager.getNextHandle();
                expect(iNextHandle).toBe(-14);

                oSource = {
                    ID: -1,
                    TITLE: "ABC"
                };

                // this indicates the creation case
                oDestination = {};

                oHandleManager = Runtime._createHandleManager();
                return Runtime._mergeObjects(oDestination, oSource, oMetadataAccess, Message.createMessageBuffer("test.object.TestAO"), oHandleManager.registerUsedHandle).then(() => {
                    var iNextHandle = oHandleManager.getNextHandle();
                    expect(iNextHandle).toBe(-2);

                    done();
                });
            });
        });
    });

    it("determines properties", (done) => {

        var bFailAuth = true;
        var bFailEnabled = true;
        var bDescriptionReadOnly = true;

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false,
                    enabledCheck: false
                },
                update: {
                    authorizationCheck: (vKey, oObject, fnMessage, oContext) => {
                        if (bFailAuth) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "AUTH_ERROR", oObject.ID);
                        }
                        return asyncLogic();
                    },
                    enabledCheck: (vKey, oObject, fnMessage, oContext) => {
                        if (bFailEnabled) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "ENABLED_ERROR", oObject.ID);
                        }
                        return asyncLogic();
                    }
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                },
                customAction: {
                    authorizationCheck: false,
                    enabledCheck: (vKey, oObject, fnMessage, oContext) => {
                        return asyncLogic();
                    },
                    execute: () => {
                        return asyncLogic();
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                },
                customAction2: {
                    authorizationCheck: false,
                    execute: () => {
                        return asyncLogic();
                    },
                    customProperties: (vKey, oParameters, oPersistedObject, addMessage, oContext) => {
                        return asyncLogic({
                            bla: oParameters || vKey
                        });
                    }
                },
                staticCustomAction: {
                    isStatic: true,
                    authorizationCheck: false,
                    execute: () => {
                        return asyncLogic();
                    }
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_2_1,
                        sequence: TEST_SEQUENCE_NODE_2_1,
                        parentKey: "PARENT_ID",
                        readOnly: (vKey, oObjectNode, fnMessage) => {
                            if (!vKey) {
                                return false;
                            }
                            return asyncLogic(oObjectNode.SOMETEXT === "Instance 1");
                        },
                        attributes: {
                            ANOTHERONE: {
                                readOnly: true,
                                customProperties: (vKey, oPersistedObject, addMessage, oContext) => {
                                    return asyncLogic({
                                        bla: vKey
                                    });
                                }
                            }
                        },
                        customProperties: (vKey, oPersistedObject, addMessage, oContext) => {
                            return asyncLogic({
                                bla: vKey
                            });
                        }
                    }
                },
                attributes: {
                    DESCRIPTION: {
                        readOnly: (vKey, oObjectNode, fnMessage) => {
                            return asyncLogic(bDescriptionReadOnly);
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            expect(typeof oRuntimeFacade.properties).toBe("function");

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "ABC",
                Node1: [{
                    ID: -2,
                    SOMETEXT: "Instance 1"
                }, {
                    ID: -3,
                    SOMETEXT: "Instance 2"
                }]
            }).then((oResponse) => {
                var vKey = oResponse.generatedKeys[-1];
                var vKeyNode11 = oResponse.generatedKeys[-2];
                var vKeyNode12 = oResponse.generatedKeys[-3];
                expect(vKey).toBeDefined();

                return oRuntimeFacade.properties(vKey, {
                    actions: [Metadata.Action.Update],
                    nodes: true
                }).then((oProperties) => {

                    expect(oProperties.actions.update).toEqual({
                        readOnly: false,
                        enabled: false,
                        messages: [{
                            severity: Runtime.MessageSeverity.Fatal,
                            messageKey: "AUTH_ERROR",
                            refObject: 'sap.aof.test.db.test.WhateverAO',
                            refKey: vKey,
                            refNode: 'Root',
                            refAttribute: undefined,
                            parameters: [],
                            auth: true
                        }]
                    });

                    expect(oProperties.nodes.Root[vKey]).toEqual({
                        readOnly: false,
                        messages: [],
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        },
                        attributes: {
                            ID: {
                                readOnly: false,
                                messages: []
                            },
                            TITLE: {
                                readOnly: false,
                                messages: []
                            },
                            DESCRIPTION: {
                                readOnly: true,
                                messages: [],
                                customProperties: {
                                    prop1: "val1",
                                    prop2: "val2"
                                }
                            }
                        }
                    });

                    // Node "read only" delegates to attributes
                    expect(oProperties.nodes.Node1[vKeyNode11]).toEqual({
                        readOnly: true,
                        messages: [],
                        customProperties: {
                            bla: vKeyNode11
                        },
                        attributes: {
                            ID: {
                                readOnly: true,
                                messages: []
                            },
                            SOMETEXT: {
                                readOnly: true,
                                messages: []
                            },
                            ANOTHERONE: {
                                readOnly: true,
                                messages: [],
                                customProperties: {
                                    bla: vKeyNode11
                                }
                            }
                        }
                    });

                    expect(oProperties.nodes.Node1[vKeyNode12]).toEqual({
                        readOnly: false,
                        messages: [],
                        customProperties: {
                            bla: vKeyNode12
                        },
                        attributes: {
                            ID: {
                                readOnly: false,
                                messages: []
                            },
                            SOMETEXT: {
                                readOnly: false,
                                messages: []
                            },
                            ANOTHERONE: {
                                readOnly: true,
                                messages: [],
                                customProperties: {
                                    bla: vKeyNode12
                                }
                            }
                        }
                    });

                    bFailAuth = false;

                    return oRuntimeFacade.properties(vKey, {
                        actions: [Metadata.Action.Update],
                        nodes: false
                    });

                }).then((oProperties) => {

                    expect(oProperties.actions.update).toEqual({
                        readOnly: false,
                        enabled: false,
                        messages: [{
                            severity: Runtime.MessageSeverity.Fatal,
                            messageKey: "ENABLED_ERROR",
                            refObject: 'sap.aof.test.db.test.WhateverAO',
                            refKey: vKey,
                            refNode: 'Root',
                            refAttribute: undefined,
                            parameters: []
                        }]
                    });

                    expect(oProperties.nodes).toEqual({});

                    bFailEnabled = false;
                    return oRuntimeFacade.properties(vKey, {
                        actions: true,
                        nodes: ["Node1"]
                    });
                }).then((oProperties) => {
                    expect(oProperties.actions.update).toEqual({
                        readOnly: false,
                        enabled: true,
                        messages: []
                    });

                    expect(oProperties.actions.del).toEqual({
                        readOnly: false,
                        enabled: true,
                        messages: []
                    });

                    expect(oProperties.actions.customAction).toEqual({
                        readOnly: false,
                        enabled: true,
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        },
                        messages: []
                    });

                    expect(oProperties.actions.customAction2).toEqual({
                        readOnly: false,
                        enabled: true,
                        customProperties: {
                            bla: vKey
                        },
                        messages: []
                    });

                    expect(oProperties.actions.staticCustomAction === undefined).toBe(true);
                    expect(_.size(oProperties.nodes.Node1)).toBe(2);
                    expect(oProperties.nodes.Root === undefined).toBe(true);

                    return oRuntimeFacade.properties(vKey, {
                        actions: [{
                            name: "customAction2",
                            parameters: "A"
                        }]
                    });

                }).then((oProperties) => {

                    expect(oProperties.actions.customAction2).toEqual({
                        readOnly: false,
                        enabled: true,
                        customProperties: {
                            bla: "A"
                        },
                        messages: []
                    });

                    done();
                });
            });
        });
    });

    it("determines static properties", (done) => {

        var bFailAuth = true;
        var bFailEnabled = true;

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: (vKey, oParameter, fnMessage, oContext) => {
                        if (bFailAuth) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "AUTH_ERROR", oParameter.REF_ID);
                        }
                        return asyncLogic();
                    },
                    enabledCheck: (vKey, oParameter, fnMessage, oContext) => {
                        if (bFailEnabled) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "ENABLED_ERROR", oParameter.REF_ID);
                        }
                        return asyncLogic();
                    },
                    customProperties: {
                        prop1: "val1"
                    }
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                },
                staticCustomAction: {
                    isStatic: true,
                    execute: () => {
                        return asyncLogic();
                    },
                    authorizationCheck: (oParameter, fnMessage, oContext) => {
                        if (bFailAuth) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "AUTH_ERROR", oParameter.REF_ID);
                        }
                        return asyncLogic();
                    },
                    enabledCheck: (oParameter, oBulkAccess, fnMessage, oContext) => {
                        if (bFailEnabled) {
                            fnMessage(Runtime.MessageSeverity.Fatal, "ENABLED_ERROR", oParameter.REF_ID);
                        }
                        return asyncLogic();
                    },
                    customProperties: {
                        prop2: "val3"
                    }
                },
                staticCustomAction2: {
                    isStatic: true,
                    authorizationCheck: false,
                    execute: () => {
                        return asyncLogic();
                    },
                    customProperties: (oParameter, oBulkAccess, fnMessage, oContext, oActionMetadata) => {
                        return asyncLogic(oParameter);
                    }
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                customProperties: {
                    prop1: "val1"
                },
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            expect(typeof oRuntimeFacade.staticProperties).toBe("function");

            return oRuntimeFacade.staticProperties({
                actions: [{
                    name: "create",
                    parameters: {
                        REF_ID: 1
                    }
                }, {
                    name: "staticCustomAction",
                    parameters: {
                        PARAM1: "Bla",
                        REF_ID: 1
                    }
                }]
            }).then((oStaticProperties) => {

                expect(oStaticProperties.actions.create).toEqual({
                    readOnly: false,
                    enabled: false,
                    customProperties: {
                        prop1: "val1"
                    },
                    messages: [{
                        severity: Runtime.MessageSeverity.Fatal,
                        messageKey: "AUTH_ERROR",
                        refObject: 'sap.aof.test.db.test.WhateverAO',
                        refKey: 1,
                        refNode: 'Root',
                        refAttribute: undefined,
                        parameters: [],
                        auth: true
                    }]
                });

                expect(oStaticProperties.actions.staticCustomAction).toEqual({
                    readOnly: false,
                    enabled: false,
                    customProperties: {
                        prop2: "val3"
                    },
                    messages: [{
                        severity: Runtime.MessageSeverity.Fatal,
                        messageKey: "AUTH_ERROR",
                        refObject: 'sap.aof.test.db.test.WhateverAO',
                        refKey: 1,
                        refNode: 'Root',
                        refAttribute: undefined,
                        parameters: [],
                        auth: true
                    }]
                });

                bFailAuth = false;

                return oRuntimeFacade.staticProperties({
                    actions: [{
                        name: "create",
                        parameters: {
                            REF_ID: 1
                        }
                    }, {
                        name: "staticCustomAction",
                        parameters: {
                            PARAM1: "Bla",
                            REF_ID: 1
                        }
                    }]
                });
            }).then((oStaticProperties) => {

                expect(oStaticProperties.actions.create).toEqual({
                    readOnly: false,
                    enabled: false,
                    customProperties: {
                        prop1: "val1"
                    },
                    messages: [{
                        severity: Runtime.MessageSeverity.Fatal,
                        messageKey: "ENABLED_ERROR",
                        refObject: 'sap.aof.test.db.test.WhateverAO',
                        refKey: 1,
                        refNode: 'Root',
                        refAttribute: undefined,
                        parameters: []
                    }]
                });

                expect(oStaticProperties.actions.staticCustomAction).toEqual({
                    readOnly: false,
                    enabled: false,
                    customProperties: {
                        prop2: "val3"
                    },
                    messages: [{
                        severity: Runtime.MessageSeverity.Fatal,
                        messageKey: "ENABLED_ERROR",
                        refObject: 'sap.aof.test.db.test.WhateverAO',
                        refKey: 1,
                        refNode: 'Root',
                        refAttribute: undefined,
                        parameters: []
                    }]
                });

                bFailEnabled = false;

                return oRuntimeFacade.staticProperties({
                    actions: [{
                        name: "create",
                        parameters: {
                            REF_ID: 1
                        }
                    }, {
                        name: "staticCustomAction",
                        parameters: {
                            PARAM1: "Bla",
                            REF_ID: 1
                        }
                    }]
                });
            }).then((oStaticProperties) => {

                expect(oStaticProperties.actions.create).toEqual({
                    readOnly: false,
                    enabled: true,
                    customProperties: {
                        prop1: "val1"
                    },
                    messages: []
                });

                expect(oStaticProperties.actions.staticCustomAction).toEqual({
                    readOnly: false,
                    enabled: true,
                    customProperties: {
                        prop2: "val3"
                    },
                    messages: []
                });

                return oRuntimeFacade.staticProperties({
                    actions: [{
                        name: "staticCustomAction2",
                        parameters: {
                            PARAM1: "Blubb",
                            PARAM2: 2
                        }
                    }]
                });
            }).then((oStaticProperties) => {

                expect(oStaticProperties.actions.staticCustomAction2.customProperties).toEqual({
                    PARAM1: "Blubb",
                    PARAM2: 2
                });

                return oRuntimeFacade.staticProperties({
                    nodes: [Metadata.Node.Root]
                });
            }).then((oStaticProperties) => {

                expect(oStaticProperties.nodes.Root).toEqual({
                    readOnly: false,
                    customProperties: {
                        prop1: "val1"
                    },
                    attributes: {
                        ID: {
                            readOnly: false
                        },
                        TITLE: {
                            readOnly: false
                        },
                        DESCRIPTION: {
                            readOnly: false
                        }
                    }
                });

                expect(oStaticProperties.nodes.Node1 === undefined).toBe(true);

                done();
            });
        });
    });

    it("returns database type issues (length ...) as error messages", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "A muuuuuuuuch toooo long title which is more than 240 characters especially when we repeat it. " + "A muuuuuuuuch toooo long title which is more than 240 characters especially when we repeat it." + "A muuuuuuuuch toooo long title which is more than 240 characters especially when we repeat it."
            });
        }).then((oResponse) => {
            expect(oResponse.messages.length).toBe(1);

            done();
        });
    });

    it("only returns generates keys which are present as handles in input", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                }
            },

            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onCreate: [(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) => {
                        oWorkObject.Node1 = [{
                            ID: getNextHandle(),
                            SOMETEXT: "SOMETEXT"
                        }];
                        return asyncLogic();
                    }]
                },
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Bla",
                DESCRIPTION: "Blub"
            });
        }).then((oResponse) => {
            expect(_.size(oResponse.generatedKeys)).toBe(1);
            expect(oResponse.generatedKeys[-1]).toBeDefined();

            done();
        });
    });

    it("allows a 1:1 sub nodes without sequence", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onCreate: [(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) => {
                        oWorkObject.Node1 = [{
                            PARENT_ID: 1212,
                            SOMETEXT: "SOMETEXT"
                        }];
                        return asyncLogic();
                    }]
                },
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        parentKey: "ID"
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Bla",
                DESCRIPTION: "Blub"
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var iKey = oResponse.generatedKeys[-1];
                expect(iKey).toBeDefined();
                return oRuntimeFacade.read(iKey).then((oObject) => {
                    expect(oObject.Node1).toEqual([{
                        ID: iKey,
                        PARENT_ID: 1212,
                        SOMETEXT: "SOMETEXT"
                    }]);
                    return oRuntimeFacade.update({
                        ID: iKey,
                        TITLE: "Blub",
                        DESCRIPTION: "Bla",
                        Node1: [{
                            ID: iKey,
                            SOMETEXT: "Changed subnode"
                        }]
                    });
                }).then(() => {
                    return oRuntimeFacade.read(iKey);
                }).then((oObject) => {
                    expect(oObject.Node1).toEqual([{
                        ID: iKey,
                        PARENT_ID: 1212,
                        SOMETEXT: "Changed subnode"
                    }]);

                    done();
                });
            });
        });
    });

    it("runs in explicit privileged mode", (done) => {
        var fnDummyAuthCheck = () => {
            return asyncLogic();
        };

        var oCreateAction = {
            authorizationCheck: fnDummyAuthCheck
        };
        spyOn(oCreateAction, 'authorizationCheck');

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: oCreateAction
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext, true);
            expect(oRuntimeFacade).toBeDefined();

            return oRuntimeFacade.create({
                ID: -1,
                DESCRIPTION: "Blub"
            });

        }).then(() => {
            expect(oCreateAction.authorizationCheck).not.toHaveBeenCalled();

            done();
        });
    });

    it("runs in implicit privileged mode", (done) => {

        var oCreateAction = {
            authorizationCheck: () => {
                return asyncLogic();
            }
        };
        spyOn(oCreateAction, 'authorizationCheck');

        var oUpdateAction = {
            authorizationCheck: () => {
                return asyncLogic();
            }
        };
        spyOn(oUpdateAction, 'authorizationCheck');

        var oReadAction = {
            authorizationCheck: () => {
                return asyncLogic();
            }
        };
        spyOn(oReadAction, 'authorizationCheck');

        var oRuntimeFacade;

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: oCreateAction,
                update: oUpdateAction,
                read: oReadAction
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onCreate: [(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) => {
                        return oRuntimeFacade.read(1);
                    }]
                }
            }
        }).then((oMetadata) => {
            oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                DESCRIPTION: "Blub"
            }).then(() => {
                expect(oCreateAction.authorizationCheck).toHaveBeenCalled();
                expect(oReadAction.authorizationCheck).not.toHaveBeenCalled();
                return oRuntimeFacade.create({
                    ID: -1,
                    DESCRIPTION: "Blub"
                });
            }).then(() => {
                expect(oCreateAction.authorizationCheck.calls.length).toBe(2);
                expect(oReadAction.authorizationCheck).not.toHaveBeenCalled();

                done();
            });
        });
    });

    it("calls read-only check only when input and persistent object differ", (done) => {

        var oReadOnlyCheck = {
            readOnly: () => {
                return asyncLogic();
            }
        };
        spyOn(oReadOnlyCheck, 'readOnly');

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                attributes: {
                    DESCRIPTION: {
                        readOnly: oReadOnlyCheck.readOnly
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Bla",
                DESCRIPTION: "Blub"
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var iKey = oResponse.generatedKeys[-1];
                expect(oReadOnlyCheck.readOnly.calls.length).toBe(1);
                return oRuntimeFacade.update({
                    ID: iKey,
                    DESCRIPTION: "Blub"
                }).then(() => {
                    expect(oReadOnlyCheck.readOnly.calls.length).toBe(1);
                    return oRuntimeFacade.update({
                        ID: iKey,
                        DESCRIPTION: "Bla"
                    });
                }).then(() => {
                    expect(oReadOnlyCheck.readOnly.calls.length).toBe(2);

                    done();
                });
            });
        });
    });


    it("initializes the object for creation", (done) => {
        var oDeterminationWorkObject = undefined;
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onCreate: [(vKey, oWorkObject) => {
                        oDeterminationWorkObject = oWorkObject;
                        return asyncLogic();
                    }]
                },
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            return oRuntimeFacade.create({});
        }).then(() => {
            expect(oDeterminationWorkObject).toEqual({
                ID: null,
                TITLE: null,
                DESCRIPTION: null,
                Node1: [],
                Node2: []
            });

            done();
        });
    });

    it("calls persist callback for actions", (done) => {
        var bPersistCalled = false;
        var oDBWrapper = undefined;
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false,
                    persist: (vKey, oObject, oDBAction, addMessage, oContext) => {
                        bPersistCalled = true;
                        oDBWrapper = oDBAction;
                    }
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "ABC",
                DESRIPTION: "XYZ"
            });
        }).then(() => {
            expect(bPersistCalled).toBe(true);
            expect(oDBWrapper.create).toBeDefined();
            expect(oDBWrapper.update).toBeDefined();
            expect(oDBWrapper.del).toBeDefined();

            done();
        });
    });

    it("provides a generic copy action", (done) => {
        var bEnabledCheckCalled = false;
        var bPrepareCopyCalled = false;
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                copy: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                        bEnabledCheckCalled = true;
                        return asyncLogic();
                    }
                },
                read: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onPrepareCopy: [(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) => {
                        bPrepareCopyCalled = true;
                        return asyncLogic();
                    }],
                    onCopy: [(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) => {
                        oWorkObject.TITLE = "Adjusted title in copy determination";
                        return asyncLogic();
                    }]
                },
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Copy test title original",
                DESCRIPTION: "Copy test description original",
                Node2: [{
                    ID: -2,
                    SOMETEXT: "Copy test node 1 original",
                    Node21: [{
                        ID: -3,
                        SOMETEXT: "Copy test node 21 original",
                        ANOTHERONE: "Bla"
                    }]
                }]
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var iId = oResponse.generatedKeys[-1];
                var iNode2Id = oResponse.generatedKeys[-2];
                var iNode21Id = oResponse.generatedKeys[-3];
                return oRuntimeFacade.copy(iId, {
                    ID: -11,
                    DESCRIPTION: "Changed by copy call"
                }).then((oResponse) => {
                    expect(oResponse.messages).toEqual([]);
                    var iCopyId = oResponse.generatedKeys[-11];
                    expect(iCopyId).toBeDefined();
                    return oRuntimeFacade.read(iCopyId);
                }).then((oCopy) => {
                    expect(oCopy.ID).not.toBe(iId);
                    expect(oCopy.TITLE).toBe("Adjusted title in copy determination");
                    expect(oCopy.DESCRIPTION).toBe("Changed by copy call");
                    expect(oCopy.Node2[0].ID).not.toBe(iNode2Id);
                    expect(oCopy.Node2[0].SOMETEXT).toBe("Copy test node 1 original");
                    expect(oCopy.Node2[0].Node21[0].ID).not.toBe(iNode21Id);
                    expect(oCopy.Node2[0].Node21[0].SOMETEXT).toBe("Copy test node 21 original");
                    expect(oCopy.Node2[0].Node21[0].ANOTHERONE).toBe("Bla");
                    expect(bEnabledCheckCalled).toBe(true);
                    expect(bPrepareCopyCalled).toBe(true);

                    done();
                });
            });
        });
    });

    it("provides a generic copy action respecting intra-object references", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                copy: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node5: {
                        table: TEST_TABLE_NODE_5,
                        sequence: TEST_SEQUENCE_NODE_5,
                        parentKey: "PARENT_ID",
                        attributes: {
                            OBJECT_ID: {
                                foreignKeyTo: "test.object.TestAO.Node5",
                                foreignKeyIntraObject: true
                            }
                        }
                    }

                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "MyTestTitle",
                DESCRIPTION: "MyTestDescription",
                Node5: [{
                    ID: -2,
                    OBJECT_ID: -3,
                    SOMETEXT: "Sometext"
                }, {
                    ID: -3,
                    OBJECT_ID: -2,
                    SOMETEXT: "Sometext2"
                }]
            }).then((oResponse) => {
                expect(oResponse).toBeDefined();
                expect(oResponse.messages).toEqual([]);
                var vRootKey = oResponse.generatedKeys[-1];
                return oRuntimeFacade.read(vRootKey).then((oObject) => {
                    var vNode5_1Key = oObject.Node5[0].OBJECT_ID;
                    var vNode5_2Key = oObject.Node5[1].OBJECT_ID;
                    expect(oObject.Node5[0].OBJECT_ID).toBe(oObject.Node5[1].ID);
                    expect(oObject.Node5[1].OBJECT_ID).toBe(oObject.Node5[0].ID);
                    return oRuntimeFacade.copy(vRootKey, {
                        ID: -11
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages).toEqual([]);
                        var vCopyKey = oResponse.generatedKeys[-11];
                        expect(vCopyKey).toBeDefined();
                        return oRuntimeFacade.read(vCopyKey);
                    }).then((oCopy) => {
                        expect(oCopy.Node5[0].OBJECT_ID).toBe(oCopy.Node5[1].ID);
                        expect(oCopy.Node5[1].OBJECT_ID).toBe(oCopy.Node5[0].ID);
                        expect(oCopy.Node5[0].OBJECT_ID).not.toBe(vNode5_1Key);
                        expect(oCopy.Node5[1].OBJECT_ID).not.toBe(vNode5_2Key);

                        done();
                    });
                });
            });
        });
    });

    it("checks dataTypes, min/max values, max length", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE2,
                sequence: TEST_SEQUENCE,
                attributes: {
                    INT_01: {
                        minValue: 5,
                        maxValue: 10
                    },
                    DOUBLE_01: {
                        minValue: 5.5,
                        maxValue: 9.5
                    },
                    TEXT_01: {
                        maxLength: 10
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                INT_01: 6,
                DOUBLE_01: 6
            }).then((oResponse) => {
                expect(oResponse.messages.length).toBe(0);
                return oRuntimeFacade.create({
                    ID: -1,
                    TEXT_01: "ABC",
                    TEXT_02: "XYZ",
                    DATE_01: "2009-05-12",
                    TS_01: "2015-04-08T09:00:00Z"
                });
            }).then((oResponse) => {
                expect(oResponse.messages.length).toBe(0);
                return oRuntimeFacade.create({
                    ID: -1,
                    TEXT_01: "ABCDEFGHIJKLMONPQRSTUVWXYZ"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.INVALID_MAX_LENGTH)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    INT_01: "ABC"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_NUMBER)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    INT_01: "ABC"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_NUMBER)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    INT_01: 4.5
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_NUMBER)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    DOUBLE_01: "ABC"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_NUMBER)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    TEXT_01: new Date()
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_STRING)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    TEXT_01: 123
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_STRING)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    DATE_01: "ABC"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_DATE)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    DATE_01: "2015-02-29"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_DATE)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    DATE_01: "2015-13-01"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_DATE)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    TS_01: "2015-01-30T25:00:00Z"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_DATE)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    TS_01: "2015-02-31T12:00:61Z"
                });
            }).then((oResponse) => {
                expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Error, Checks.Messages.NOT_A_VALID_DATE)).toBe(true);
                return oRuntimeFacade.create({
                    ID: -1,
                    INT_01: null
                });
            }).then((oResponse) => {
                expect(oResponse.messages.length).toBe(0);
                return oRuntimeFacade.create({
                    ID: -1,
                    TS_01: null
                });
            }).then((oResponse) => {
                expect(oResponse.messages.length).toBe(0);
                // Empty string should be handled like null
                return oRuntimeFacade.create({
                    ID: -1,
                    INT_01: ""
                });
            }).then((oResponse) => {
                expect(oResponse.messages.length).toBe(0);

                done();
            });
        });
    });

    it("handles optimistic concurrency correctly", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                read: {
                    authorizationCheck: false
                },
                custAction1: {
                    authorizationCheck: false,
                    execute: () => {
                        return asyncLogic();
                    }
                }
            },
            Root: {
                table: TEST_TABLE_CONCURRENCY,
                sequence: TEST_SEQUENCE,
                attributes: {
                    CHANGED_AT: {
                        concurrencyControl: true
                    }
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Concurrency",
                CHANGED_AT: "2014-05-14T11:16:00.000Z",
                CHANGED_BY: oContext.storeInfo.hana.user
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var vKey = oResponse.generatedKeys[-1];
                expect(oRuntimeFacade.calculateConcurrencyToken).toBeDefined();
                return oRuntimeFacade.calculateConcurrencyToken(vKey).then((sConcurrencyToken) => {
                    expect(sConcurrencyToken).toBe(JSON.stringify({
                        CHANGED_AT: "2014-05-14T11:16:00.000Z"
                    }));
                    return oRuntimeFacade.read(vKey);
                }).then((oObject) => {
                    return oRuntimeFacade.calculateConcurrencyToken(vKey, oObject).then((sConcurrencyToken) => {
                        expect(sConcurrencyToken).toBe(JSON.stringify({
                            CHANGED_AT: "2014-05-14T11:16:00.000Z"
                        }));
                        var sOutdatedConcurrencyToken = JSON.stringify({
                            CHANGED_AT: "2014-05-14T11:14:00.000Z"
                        });
                        // update
                        return oRuntimeFacade.update({
                            ID: vKey,
                            TITLE: "Concurrency update"
                        }, sOutdatedConcurrencyToken).then((oResponse) => {
                            expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Fatal, Runtime.Messages.CONCURRENCY_TOKEN_CONFLICT)).toBe(true);
                            expect(oResponse.concurrencyToken).toBe(JSON.stringify({
                                CHANGED_AT: "2014-05-14T11:16:00.000Z"
                            }));
                            return oRuntimeFacade.read(vKey);
                        }).then((oObjectAfterUpdate) => {
                            expect(oObjectAfterUpdate).toEqual(oObject);
                            return oRuntimeFacade.update({
                                ID: vKey,
                                TITLE: "Concurrency update",
                                CHANGED_AT: "2014-05-14T11:17:00.000Z"
                            }, sConcurrencyToken);
                        }).then((oResponse) => {
                            expect(oResponse.messages).toEqual([]);
                            expect(oResponse.concurrencyToken).toBe(JSON.stringify({
                                CHANGED_AT: "2014-05-14T11:17:00.000Z"
                            }));
                            return oRuntimeFacade.update({
                                ID: vKey,
                                TITLE: "Concurrency update 2 ",
                                CHANGED_AT: "2014-05-14T11:16:00.000Z"
                            });
                        }).then((oResponse) => {
                            expect(oResponse.messages).toEqual([]);
                            // Custom action
                            return oRuntimeFacade.custAction1(vKey, {}, sOutdatedConcurrencyToken);
                        }).then((oResponse) => {
                            expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Fatal, Runtime.Messages.CONCURRENCY_TOKEN_CONFLICT)).toBe(true);
                            return oRuntimeFacade.custAction1(vKey, {}, sConcurrencyToken);
                        }).then((oResponse) => {
                            expect(oResponse.messages).toEqual([]);
                            return oRuntimeFacade.custAction1(vKey, {});
                        }).then((oResponse) => {
                            expect(oResponse.messages).toEqual([]);
                            // Delete
                            return oRuntimeFacade.del(vKey, sOutdatedConcurrencyToken);
                        }).then((oResponse) => {
                            expect(containsMessage(oResponse.messages, Runtime.MessageSeverity.Fatal, Runtime.Messages.CONCURRENCY_TOKEN_CONFLICT)).toBe(true);
                            return oRuntimeFacade.del(vKey, sConcurrencyToken);
                        }).then((oResponse) => {
                            expect(oResponse.messages).toEqual([]);

                            done();
                        });
                    });
                });
            });
        })
    });

    it("consistency checks intra object foreign key references", (done) => {
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node5: {
                        table: TEST_TABLE_NODE_5,
                        sequence: TEST_SEQUENCE_NODE_5,
                        parentKey: "PARENT_ID",
                        attributes: {
                            OBJECT_ID: {
                                foreignKeyTo: "test.object.TestAO.Node5",
                                foreignKeyIntraObject: true,
                            }
                        }
                    }

                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "MyTestTitle",
                DESCRIPTION: "MyTestDescription",
                Node5: [{
                    ID: -2,
                    OBJECT_ID: 0,
                    SOMETEXT: "Sometext"
                }, {
                    ID: -3,
                    OBJECT_ID: -2,
                    SOMETEXT: "Sometext2"
                }]
            }).then((oResponse) => {
                expect(oResponse).toBeDefined();
                expect(oResponse.messages).toBeDefined();
                expect(oResponse.messages.length).toBe(0);
                var vRootKey = oResponse.generatedKeys[-1];
                var vNode5_1Key = oResponse.generatedKeys[-2];
                var vNode5_2Key = oResponse.generatedKeys[-3];
                return oRuntimeFacade.read(vRootKey).then((oPersistedObject) => {
                    expect(oPersistedObject).toBeDefined();
                    expect(oPersistedObject.Node5[1].OBJECT_ID).toBe(vNode5_1Key);
                    return oRuntimeFacade.update({
                        ID: vRootKey,
                        TITLE: "MyTestTitle Updated",
                        DESCRIPTION: "MyTestDescription Updated",
                        Node5: [{
                            ID: vNode5_1Key,
                            OBJECT_ID: vNode5_2Key,
                            SOMETEXT: "Sometext Update",
                        }, {
                            ID: vNode5_2Key,
                            OBJECT_ID: -4,
                            SOMETEXT: "Sometext2 Update",
                        }, {
                            ID: -4,
                            OBJECT_ID: vNode5_1Key,
                            SOMETEXT: "Sometext3",
                        }]
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages).toBeDefined();
                        expect(oResponse.messages.length).toBe(0);
                        var vNode5_3Key = oResponse.generatedKeys[-4];
                        return oRuntimeFacade.read(vRootKey).then((oPersistedObject) => {
                            expect(oPersistedObject).toBeDefined();
                            oPersistedObject.Node5 = _.sortBy(oPersistedObject.Node5, (oNode) => {
                                return oNode.ID;
                            });
                            expect(oPersistedObject.Node5[0].OBJECT_ID).toBe(vNode5_2Key);
                            expect(oPersistedObject.Node5[1].OBJECT_ID).toBe(vNode5_3Key);
                            expect(oPersistedObject.Node5[2].OBJECT_ID).toBe(vNode5_1Key);
                            return oRuntimeFacade.update({
                                ID: vRootKey,
                                TITLE: "MyTestTitle Updated",
                                DESCRIPTION: "MyTestDescription Updated",
                                Node5: [{
                                    ID: vNode5_1Key,
                                    OBJECT_ID: vNode5_2Key,
                                    SOMETEXT: "Sometext Update",
                                }, {
                                    ID: vNode5_2Key,
                                    OBJECT_ID: -42,
                                    SOMETEXT: "Sometext2 Update",
                                }, {
                                    ID: vNode5_3Key,
                                    OBJECT_ID: 666666666, // should not exist
                                    SOMETEXT: "Sometext3 Update",
                                }]
                            });
                        }).then((oResponse) => {
                            expect(oResponse).toBeDefined();
                            expect(oResponse.messages).toBeDefined();
                            expect(oResponse.messages.length).toBe(2);
                            expect(oResponse.messages).toEqual([{
                                severity: 2,
                                messageKey: 'MSG_AOF_INVALID_FOREIGN_KEY',
                                refObject: 'test.object.TestAO',
                                refKey: vNode5_2Key,
                                refNode: 'Node5',
                                refAttribute: 'OBJECT_ID',
                                parameters: [-42]
                            }, {
                                severity: 2,
                                messageKey: 'MSG_AOF_INVALID_FOREIGN_KEY',
                                refObject: 'test.object.TestAO',
                                refKey: vNode5_3Key,
                                refNode: 'Node5',
                                refAttribute: 'OBJECT_ID',
                                parameters: [666666666]
                            }]);

                            done();
                        });
                    });
                });
            });
        });
    });

    it("executes cascading delete", (done) => {
        AOF.getApplicationObject("test.object.TestAO", oContext).then((TestAO) => {
            expect(TestAO).toBeDefined();
            AOF.getApplicationObject("test.object.TestAOFK", oContext).then((TestAOFK) => {
                expect(TestAOFK).toBeDefined();
                return TestAO.create({
                    ID: -1,
                    TITLE: "A reference title",
                    DESCRIPTION: "A"
                }).then((oResponse) => {
                    var iKey = oResponse.generatedKeys[-1];
                    return TestAOFK.create({
                        ID: -1,
                        OBJECT_ID: iKey,
                        OBJECT_TYPE_CODE: "ABC",
                        ANOTHER_TYPE_CODE: "ABC",
                        SOMETEXT: "Sometext"
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages).toEqual([]);
                        return TestAO.del(iKey);
                    }).then((oResponse) => {
                        expect(oResponse.messages).toEqual([]);
                        return oContext.store.getClient().statement('select * from "sap.aof.test.db.test::t_test_node_3" where object_id = ?').execute(iKey).then((aFKRefs) => {
                            expect(aFKRefs).toEqual([]);
                            done();
                        });
                    });
                });
            });
        });
    });

    it("runs in implicit privileged mode for properties and staticProperties", (done) => {
        var oCreateAction = {
            authorizationCheck: () => {
                return asyncLogic();
            }
        };
        spyOn(oCreateAction, 'authorizationCheck');

        var oUpdateAction = {
            authorizationCheck: () => {
                return asyncLogic();
            }
        };
        spyOn(oUpdateAction, 'authorizationCheck');

        var oReadAction = {
            authorizationCheck: () => {
                return asyncLogic();
            }
        };
        spyOn(oReadAction, 'authorizationCheck');
        var vKey = 0;
        var oRuntimeFacade;
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                create: oCreateAction,
                update: oUpdateAction,
                read: oReadAction
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                attributes: {
                    TITLE: {
                        readOnly: (vKey, oObjectNode, fnMessage) => {
                            return oRuntimeFacade.read(vKey).then((oResponse) => {
                                return false;
                            });
                        },
                        customProperties: (vKey, oPersistedObject, addMessage, oContext) => {
                            return oRuntimeFacade.read(vKey).then((oResponse) => {
                                return;
                            });
                        }
                    }
                }
            }
        }).then((oMetadata) => {
            oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Blib",
                DESCRIPTION: "Blub"
            }).then((oResponse) => {
                vKey = oResponse.generatedKeys[-1];
                expect(oReadAction.authorizationCheck).not.toHaveBeenCalled();
                return oRuntimeFacade.properties(vKey, {
                    nodes: true
                });
            }).then((oResponse) => {
                expect(oReadAction.authorizationCheck).not.toHaveBeenCalled();
                return oRuntimeFacade.staticProperties({
                    nodes: true,
                    actions: [{
                        name: "create",
                        parameters: {
                            REF_ID: 1
                        }
                    }]
                });
            }).then((oResponse) => {
                expect(oReadAction.authorizationCheck).not.toHaveBeenCalled();

                done();
            });
        });
    });

    it("provides the root object in context for callback functions", (done) => {
        var oDetProcessedObject = null;
        var oCreateDetermination = (vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) => {
            oDetProcessedObject = _.clone(oContext.getProcessedObject());
            return asyncLogic();
        };

        var oCheckProcessedObject = null;
        var oAttrCheck = (vKey, oAttribute, addMessage, oContext, oNodeMetadata) => {
            oCheckProcessedObject = _.clone(oContext.getProcessedObject());
            return asyncLogic();
        };

        var oCheckProcessedObject2 = null;
        var oAttrCheck2 = (vKey, oAttribute, addMessage, oContext, oNodeMetadata) => {
            oCheckProcessedObject2 = _.clone(oContext.getProcessedObject());
            return asyncLogic();
        };

        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                determinations: {
                    onCreate: [oCreateDetermination]
                },
                attributes: {
                    DESCRIPTION: {
                        consistencyChecks: [oAttrCheck],
                        inputChecks: [oAttrCheck2]
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRoot = {
                ID: -1,
                TITLE: "TEST TITLE",
                DESCRIPTION: "Test"
            };
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            return oRuntimeFacade.create(oRoot).then(() => {
                expect(oDetProcessedObject).toEqual(oRoot);
                expect(oCheckProcessedObject).toEqual(oRoot);
                expect(oCheckProcessedObject2).toEqual(oRoot);

                done();
            });
        });
    });

    it("only allows calling internal actions from AO implementation", (done) => {
        var oRuntimeFacade = undefined;
        Metadata.getMetadata("test.object.TestAO", oContext, {
            actions: {
                create: {
                    isInternal: true,
                    authorizationCheck: false,
                },
                myStaticAction: {
                    isStatic: true,
                    authorizationCheck: false,
                    execute: (oParameters, oBulkAccess, addMessage) => {
                        return oRuntimeFacade.create({
                            ID: -1,
                            TITLE: "Bla"
                        }).then((oResponse) => {
                            addMessage(oResponse.messages);
                            return oRuntimeFacade.myInternalStaticAction({});
                        }).then((oResponse) => {
                            addMessage(oResponse.messages);
                        });
                    }
                },
                myInternalStaticAction: {
                    isStatic: true,
                    isInternal: true,
                    authorizationCheck: false,
                    execute: () => {
                        return asyncLogic();
                    }
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadata) => {
            oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "ABC"
            });
        }).then((oResponse) => {
            expect(containsMessage(oResponse.messages, Message.MessageSeverity.Fatal, Runtime.Messages.INTERNAL_ACTION_CALLED)).toBe(true);
            return oRuntimeFacade.myInternalStaticAction({
                PARAM: "Value"
            });
        }).then((oResponse) => {
            expect(containsMessage(oResponse.messages, Message.MessageSeverity.Fatal, Runtime.Messages.INTERNAL_ACTION_CALLED)).toBe(true);
            return oRuntimeFacade.myStaticAction({
                PARAM: "Value"
            });
        }).then((oResponse) => {
            expect(oResponse.messages).toEqual([]);

            done();
        });
    });

    it("keeps the same request timestamp for nested calls", (done) => {
        var sRequestTimestamp1 = null;
        var sRequestTimestamp2 = null;
        var oRuntimeFacade;
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            actions: {
                customStaticAction1: {
                    authorizationCheck: false,
                    isStatic: true,
                    execute: (oParameters, oBulkAccess, addMessage, getNextHandle, oContext) => {
                        sRequestTimestamp1 = oContext.getRequestTimestamp();
                        // make sure some time goes bye
                        return new Promise((resolve, reject) => {
                            setTimeout(() => {
                                oRuntimeFacade.customStaticAction2({}).then(() => {
                                    resolve();
                                });
                            }, 50);
                        });
                    }
                },
                customStaticAction2: {
                    authorizationCheck: false,
                    isStatic: true,
                    execute: (oParameters, oBulkAccess, addMessage, getNextHandle, oContext) => {
                        sRequestTimestamp2 = oContext.getRequestTimestamp();
                        return asyncLogic();
                    }
                }
            },
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadata) => {
            oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            return oRuntimeFacade.customStaticAction1();
        }).then((oResponse) => {
            expect(oResponse.messages).toEqual([]);
            expect(sRequestTimestamp1).toBeDefined();
            expect(sRequestTimestamp1).toBe(sRequestTimestamp2);

            done();
        })
    });

    it("Custom action with return value", (done) => {
        var fnDummy = () => {
            return asyncLogic();
        };
        var fnCustomAction = () => {
            return asyncLogic({
                test: "test"
            });
        };
        Metadata.getMetadata("sap.aof.test.db.test.WhateverAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            },
            actions: {
                myCustomAction1: {
                    authorizationCheck: fnDummy,
                    execute: fnCustomAction
                },
                create: {
                    authorizationCheck: false
                }
            }
        }).then((oMetadata) => {
            var oRuntimeFacade = Runtime.getObjectFacade(oMetadata, oContext);
            expect(oRuntimeFacade).toBeDefined();
            return oRuntimeFacade.create({
                ID: -1,
                TITLE: "Test"
            }).then((oResponse) => {
                expect(oResponse.messages).toEqual([]);
                var vKey = oResponse.generatedKeys[-1];
                expect(vKey).toBeDefined();
                return oRuntimeFacade.myCustomAction1(vKey);
            }).then((oResponse) => {
                expect(oResponse.result).toBeDefined();
                expect(oResponse.result).toEqual({
                    test: "test"
                });

                done();
            });
        });
    });

    it("executes a mass-enabled custom action", (done) => {
        AOF.getApplicationObject("test.object.TestAOM", oContext).then((oApplicationObject) => {
            expect(oApplicationObject).toBeDefined();
            return oApplicationObject.create({
                ID: -1,
                TITLE: "Any title 1"
            }).then((oResponse) => {
                var iKey1 = oResponse.generatedKeys[-1];
                return oApplicationObject.create({
                    ID: -1,
                    TITLE: "Any title 2"
                }).then((oResponse) => {
                    var iKey2 = oResponse.generatedKeys[-1];
                    return oApplicationObject.doCustomMassAction({
                        keys: [iKey1, iKey2],
                        NEW_DESCRIPTION: "Changed description"
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages.length).toBe(0);
                        var oResult = {
                            generatedKeys: {},
                            massResult: {}
                        };
                        oResult.massResult[iKey1] = "Result_" + iKey1;
                        oResult.massResult[iKey2] = "Result_" + iKey2;
                        expect(oResponse.result).toEqual(oResult);
                        return oApplicationObject.read(iKey1);
                    }).then((oObject1) => {
                        expect(oObject1.DESCRIPTION).toBe("Changed description " + iKey1);
                        return oApplicationObject.read(iKey2);
                    }).then((oObject2) => {
                        expect(oObject2.DESCRIPTION).toBe("Changed description " + iKey2);
                        return oApplicationObject.doCustomMassAction({
                            TEST: [iKey1, iKey2],
                            NEW_DESCRIPTION: "Changed description"
                        });
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages.length).toBe(1);
                        return oApplicationObject.doCustomMassAction();
                    }).then((oResponse) => {
                        expect(oResponse).toBeDefined();
                        expect(oResponse.messages.length).toBe(1);

                        done();
                    });
                });
            });
        });
    });

    it("creates an object with external key", (done) => {
        AOF.getApplicationObject("test.object.TestAOEK", oContext).then((oApplicationObject) => {
            expect(oApplicationObject).toBeDefined();
            var iExternalKey = 999999;
            return oApplicationObject.create({
                ID: iExternalKey,
                TITLE: "Any title 1"
            }).then((oResponse) => {
                expect(oResponse.generatedKeys).toEqual([]);
                expect(oResponse.messages).toEqual([]);
                return oApplicationObject.del(iExternalKey).then(() => {
                    expect(oResponse.messages).toEqual([]);
                    done();
                });
            });
        });
    });
});