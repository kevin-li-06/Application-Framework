sap.ui.define([
    "sap/todo/aof/example/vc/BaseController",
    "sap/todo/aof/example/model/Todo",
    "sap/aof/ApplicationObjectChange",
    "sap/ui/core/ValueState",
    "sap/ui/model/Sorter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/StandardListItem",
    "sap/m/ListType",
    "sap/m/ListMode",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (BaseController, Todo, ApplicationObjectChange, ValueState, Sorter, Filter, FilterOperator, StandardListItem, ListType, ListMode, MessageToast, MessageBox) {
    "use strict";

    return BaseController.extend("sap.todo.aof.example.vc.TodoList", {

        onInit: function () {
            BaseController.prototype.onInit.apply(this, arguments);

            this.setViewData({
                edit: false,
                editVisible: true,
                createVisible: true,
                filterName: "",
                searchText: "",
                filterDone: 0
            });

            var that = this;
            ApplicationObjectChange.attachChange(ApplicationObjectChange.Action.Del, function () {
                that.refresh();
            });
            ApplicationObjectChange.attachChange(ApplicationObjectChange.Action.Create, function () {
                that.refresh();
            });

            this.onSelectTodoType();
        },

        onEditPressed: function (oEvent) {
            var bEdit = !this.getViewProperty("/edit");
            this.setViewProperty("/edit", bEdit);
            var oList = this.byId("todoList");
            if (bEdit) {
                oList.setMode(ListMode.Delete);
            } else {
                oList.setMode(ListMode.None);
            }
        },

        onDetailPress: function (oEvent) {
        },

        onDelete: function (oEvent) {
            var that = this;
            var oItem = oEvent.getParameter("listItem");
            var iTodoId = oItem.getBindingContext("data").getObject().ID;
            var oCurrentDetailController = that.getOwnerComponent().getCurrentDetailController();
            var bClearDetailView = oCurrentDetailController && oCurrentDetailController.getObjectModel() && oCurrentDetailController.getObjectModel().getKey() === iTodoId;
            this.showConfirmation(MessageBox.Icon.QUESTION, that.getText("MSG_TODO_DELETE_MSG"), that.getText("MSG_TODO_DELETE"), function (oAction) {
                if (oAction === MessageBox.Action.OK) {
                    that.setBusy(true);
                    Todo.del(iTodoId).done(function () {
                        MessageToast.show(that.getText("MSG_TODO_DELETED"));
                        if (bClearDetailView) {
                            that.getOwnerComponent().clearDetailView();
                        }
                    }).always(function () {
                        that.setBusy(false);
                    });
                }
            });
        },

        onRefresh: function () {
            this.byId("todoList").getBinding("items").refresh();
        },

        onUpdateFinished: function (oEvent) {
            this.byId("pullToRefresh").hide();
        },

        onSelect: function (oEvent) {
            this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
        },

        showDetail: function (oItem) {
            var iTodoId = oItem.getBindingContext("data").getObject().ID;
            this.navTo(iTodoId);
        },

        onSearch: function (oEvent) {
            var sSearchText = oEvent.getSource().getValue();
            this.setViewProperty("/searchText", sSearchText);
            this.updateBinding();
        },

        onSelectTodoType: function (oEvent) {
            var sFilterName = oEvent && oEvent.getParameter("button").data("filter") || "myTodos";
            this.setViewProperty("/filterName", sFilterName);
            this.updateBinding();
        },

        refresh: function () {
            this.updateBinding();
        },

        isObjectRelevant: function (oObject) {
            var bBindingRelevant = false;
            var sUserName = this.getUserModel().getProperty("/USER_NAME");
            if (oObject.Owner[0].IDENTITY === sUserName) {
                bBindingRelevant = true;
            }
            jQuery.each(oObject.Readers || [], function (iIndex, oReader) {
                if (oReader.IDENTITY === sUserName) {
                    bBindingRelevant = true;
                }
            });
            jQuery.each(oObject.Writers || [], function (iIndex, oWriter) {
                if (oWriter.IDENTITY === sUserName) {
                    bBindingRelevant = true;
                }
            });
            return bBindingRelevant;
        },

        updateBinding: function () {
            var that = this;
            var aFilter = [];
            var sFilterName = this.getViewProperty("/filterName");
            var sUserName = (this.getUserModel() && this.getUserModel().getProperty("/USER_NAME")) || "";
            switch (sFilterName) {
                case "myTodos":
                    aFilter.push(new Filter("CREATED_BY", FilterOperator.EQ, sUserName));
                    break;
                case "sharedTodos":
                    aFilter.push(new Filter("IS_PUBLIC", FilterOperator.NE, 1));
                    break;
                case "publicTodos":
                    aFilter.push(new Filter("IS_PUBLIC", FilterOperator.EQ, 1));
                    break;
            }
            var aSorter = [new Sorter("IS_DONE", false), new Sorter("CHANGED_AT", true)];
            var sSearchText = this.getViewProperty("/searchText");
            var oParameters = {custom: {}};
            if (sSearchText) {
                oParameters.custom.filterSearch = jQuery.sap.encodeURL(sSearchText);
                aSorter = null;
            }
            var fFilterDone = this.getViewProperty("/filterDone");
            if (fFilterDone > 0) {
                oParameters.custom.filterItemsDonePercentGE = "" + fFilterDone;
            }

            var oModel = this.getModel("view");
            oModel.setProperty("/editVisible", sFilterName === "myTodos");
            oModel.setProperty("/createVisible", sFilterName === "myTodos");

            var oTodoList = this.byId("todoList");
            oTodoList.bindItems({
                path: "data>/Todo_Root",
                sorter: aSorter,
                filters: aFilter,
                parameters: oParameters,
                template: new StandardListItem({
                    title: "{data>TEXT}",
                    description: "{data>CREATED_BY_NAME}",
                    type: ListType.Navigation,
                    press: function (oEvent) {
                        that.onSelect(oEvent);
                    },
                    detailPress: function (oEvent) {
                        that.onDetailPress(oEvent);
                    },
                    info: {
                        path: "data>IS_DONE",
                        formatter: function (iIsDone) {
                            return iIsDone === 1 ? that.getText("TODO_INFO_STATE_DONE") : that.getText("TODO_INFO_STATE_NOT_DONE");
                        }
                    },
                    infoState: {
                        path: "data>IS_DONE",
                        formatter: function (iIsDone) {
                            return iIsDone === 1 ? ValueState.Success : ValueState.Warning;
                        }
                    }
                })
            });
        },

        on50PercentDonePressed: function (oEvent) {
            var bPressed = oEvent.getSource().getPressed();
            this.setViewProperty("/filterDone", bPressed ? 50 : 0);
            this.updateBinding();
        },

        onCreateTodoPressed: function (oEvent) {
            if (!this.oDialog) {
                this.oDialog = sap.ui.xmlfragment("sap.todo.aof.example.vc.fragments.TodoCreateDialog", this);
                this.getView().addDependent(this.oDialog);
            }

            var oTodoModel = new Todo({
                "TEXT": "",
                "IS_DONE": 0,
                "IS_PUBLIC": 0
            });
            this.oDialog.setModel(oTodoModel, "object");
            this.oDialog.open();

            setTimeout(function () {
                sap.ui.getCore().byId("todo-text").focus();
            }, 250);
        },

        onDialogOK: function () {
            var that = this;
            var oTodoModel = this.oDialog.getModel("object");
            oTodoModel.save().always(function () {
                that.oDialog.close();
                that.navTo(oTodoModel.getKey());
            });
        },

        onDialogCancel: function () {
            this.oDialog.close();
        },

        navTo: function (iTodoId) {
            var bReplace = !jQuery.device.is.phone;
            this.getRouter().navTo("todo", {
                todoId: iTodoId
            }, bReplace);
        }
    });
});