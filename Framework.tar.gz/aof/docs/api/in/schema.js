"use strict";

/**
 * Application Object Framework Schema and validation
 * @example
 * "use strict";
 *
 * var AOF = require("@sap/aof");
 * var Determine = AOF.Determination;
 *
 * module.exports = {
 *   actions: {
 *     create: {
 *       authorizationCheck: false
 *     },
 *     update: {
 *       authorizationCheck: false
 *     },
 *     del: {
 *       authorizationCheck: false
 *     },
 *     read: {
 *       authorizationCheck: false
 *     }
 *   },
 *   Root: {
 *     table: "test.object::t_root",
 *     sequence: "test.object::s_root",
 *     determinations: {
 *       onModify: [Determine.systemAdminData]
 *     },
 *     nodes: {
 *       Items: {
 *         table: "test.object::t_item",
 *         sequence: "test.object::s_item",
 *         parentKey: "PARENT_ID",
 *         attributes: {
 *           NAME: {
 *             required: true,
 *             isName: true
 *           }
 *         }
 *       }
 *     },
 *     attributes: {
 *       CREATED_AT: {
 *         readOnly: true
 *       },
 *       CREATED_BY: {
 *         readOnly: true
 *       },
 *       CHANGED_AT: {
 *         readOnly: true,
 *         concurrencyControl: true
 *       },
 *       CHANGED_BY: {
 *         readOnly: true
 *       },
 *       NAME: {
 *         required: true,
 *         isName: true
 *       }
 *     }
 *   }
 * };
 * @namespace Schema
 */
function Schema() {
}

/**
 * Schema validation scope
 * @enum {String}
 */
Schema.SchemaScope = {
    /**
     *
     */
    Default: "",
    /**
     * SQL
     */
    Sql: "sql",
    /**
     * CDS
     */
    Cds: "cds"
};

/**
 * Validates a metadata definition object of an Application Object
 * @param oMetadataDefinition {Schema.SchemaObject} Application Object metadata definition object
 * @param sScope {Schema.SchemaScope} Scope of the validation, e.g. SQL
 * @returns {Array} Array of error messages
 */
Schema.prototype.validateMetadataDefinition = function (oMetadataDefinition, sScope) {
    return [];
};

/**
 * Validates a extension metadata definition object of an Application Object
 * @param oMetadataDefinition {Schema.SchemaExtensionObject} Application Object extension metadata definition object
 * @param sScope {Schema.SchemaScope} Scope of the validation, e.g. SQL
 * @returns {Array} Array of error messages
 */
Schema.prototype.validateExtensionMetadataDefinition = function (oMetadataDefinition, sScope) {
    return [];
};

/**
 * Application Object schema
 * @example
 * "use strict";
 *
 * var AOF = require("@sap/aof");
 * var Determine = AOF.Determination;
 *
 * module.exports = {
 *   actions: {
 *     create: {
 *       authorizationCheck: false
 *     },
 *     update: {
 *       authorizationCheck: false
 *     },
 *     del: {
 *       authorizationCheck: false
 *     },
 *     read: {
 *       authorizationCheck: false
 *     }
 *   },
 *   Root: {
 *     table: "test.object::t_root",
 *     sequence: "test.object::s_root",
 *     determinations: {
 *       onModify: [Determine.systemAdminData]
 *     },
 *     nodes: {
 *       Items: {
 *         table: "test.object::t_item",
 *         sequence: "test.object::s_item",
 *         parentKey: "PARENT_ID",
 *         attributes: {
 *           NAME: {
 *             required: true,
 *             isName: true
 *           }
 *         }
 *       }
 *     },
 *     attributes: {
 *       CREATED_AT: {
 *         readOnly: true
 *       },
 *       CREATED_BY: {
 *         readOnly: true
 *       },
 *       CHANGED_AT: {
 *         readOnly: true,
 *         concurrencyControl: true
 *       },
 *       CHANGED_BY: {
 *         readOnly: true
 *       },
 *       NAME: {
 *         required: true,
 *         isName: true
 *       }
 *     }
 *   }
 * };
 * @memberOf Schema
 * @namespace SchemaObject
 */
function SchemaObject() {
    /**
     * Allows to define the schena scioope of the application object definition.
     *  Allowed values: '', 'sql', 'cds'
     * @name type
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {ObjectType}
     */
    this.schemaScope = String;

    /**
     * Allows to define the type of the application object.
     *  Allowed values: 'STANDARD', 'CONFIGURATION', 'STAGE'
     * @name type
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {ObjectType}
     */
    this.type = String;

    /**
     * Name of the Application Object. Used to instantiate the Application Object Facade.
     * @name name
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {String}
     * @see {@link AOF} Use registerApplicationObject, specifying the module path, to register Application Object by name.
     */
    this.name = String;

    /**
     * Allows to define an extension to the definition
     * @name isExtensible
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {Boolean}
     */
    this.isExtensible = Boolean;

    /**
     * Allows to define other application object to which deletion of this object should be cascaded.
     * Contains a list of Application Object names
     * @name cascadeDelete
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {Array.<String>}
     */
    this.cascadeDelete = [];

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Definition of the application object root
     * @name Root
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {Schema.SchemaRootNode}
     */
    this.Root = {};

    /**
     * Definition of the application object actions<br>
     * - Default framework actions are: create, copy, update, del, read<br>
     * - Reserved action names are: exists, convertKey, calculateConcurrencyToken, properties, staticProperties<br>
     * - Custom name can have any other name than the ones above
     * @name actions
     * @memberOf Schema.SchemaObject
     * @instance
     * @type {(Object.<String, Schema.SchemaAction>|Object.<String, Schema.SchemaCustomAction>)}
     */
    this.actions = {};
}

/**
 * Application Object root node schema
 * @memberOf Schema
 * @namespace SchemaRootNode
 */
function SchemaRootNode() {

    /**
     * Specifies the persistence table for the application object node<br>
     * Only valid in SQL schema scope context
     * @name table
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {String}
     */
    this.table = String;

    /**
     * Specifies the sequence for the application object node<br>
     * Only valid in SQL schema scope context
     * @name sequence
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {String}
     */
    this.sequence = String;

    /**
     * Specifies the persistence history table for the application object node<br>
     * Only valid in SQL schema scope context
     * @name historyTable
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {String}
     */
    this.historyTable = String;

    /**
     * Specifies the read view (must join the persistence table and select all attributes of the application object node)<br>
     * Only valid in SQL schema scope context
     * @name view
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {String}
     */
    this.view = String;

    /**
     * Specifies that the node primary key is not determined internally, but needs to be passed from external
     * @name externalKey
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {Boolean}
     */
    this.externalKey = Boolean;

    /**
     * Specifies if the node (incl. attributes is modifiable from outside
     * @name readOnly
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {(Boolean|ImplementationExit.nodeReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Specifies if the attributes need to be explicitly defined instead of implicit derivation from the table definition
     * @name explicitAttributeDefinition
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {Boolean}
     */
    this.explicitAttributeDefinition = Boolean;

    /**
     * Specifies consistency checks on node after modifications
     * @name consistencyChecks
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {Array.<ImplementationExit.nodeConsistencyCheck>}
     */
    this.consistencyChecks = [];

    /**
     * Specifies input checks on node before modifications
     * @name inputChecks
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {Array.<ImplementationExit.nodeInputCheck>}
     */
    this.inputChecks = [];

    /**
     * Only for configuration staging objects, is called when staging content is activated
     * @name activationCheck
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {ImplementationExit.activationCheck}
     */
    this.activationCheck = Function;

    /**
     * Specifies attributes on node
     * @name attributes
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {(Object.<String, Schema.SchemaAttribute>)}
     */
    this.attributes = {};

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {(Object|ImplementationExit.nodeCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies determinations executed after application object modifications. The following timepoints exist:<br>
     * - onCreate: Specifies determinations executed at application object creation<br>
     * - onPrepareCopy: Specifies determinations executed before application object copy<br>
     * - onCopy: Specifies determinations executed at application object copy<br>
     * - onUpdate: Specifies determinations executed at application object updates, custom actions<br>
     * - onModify: Specifies determinations executed at application object creation, copy, update, customAction<br>
     * - onDelete: Specifies determinations executed at application object deletion<br>
     * - onPersist: Specifies determinations executed at after changes have been persisted in the database<br>
     * - onRead: Specifies determinations executed at application object creation read<br>
     * @name determinations
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {(Object.<String, Array.<ImplementationExit.determination>>|Object.<String, Array.<ImplementationExit.onPersistDetermination>>|Object.<String, Array.<ImplementationExit.readDetermination>>)}
     */
    this.determinations = {};

    /**
     * Specifies sub-nodes of the current node
     * @name nodes
     * @memberOf Schema.SchemaRootNode
     * @instance
     * @type {(Object.<String, Schema.SchemaNode>)}
     */
    this.nodes = {};
}

/**
 * Application Object node schema
 * @memberOf Schema
 * @namespace SchemaNode
 */
function SchemaNode() {

    /**
     * Specifies the persistence table for the application object node<br>
     * Only valid in SQL schema scope context
     * @name table
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {String}
     */
    this.table = String;

    /**
     * Specifies the sequence for the application object node<br>
     * Only valid in SQL schema scope context
     * @name sequence
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {String}
     */
    this.sequence = String;

    /**
     * Specifies the persistence history table for the application object node<br>
     * Only valid in SQL schema scope context
     * @name historyTable
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {String}
     */
    this.historyTable = String;

    /**
     * Specifies the read view (must join the persistence table and select all attributes of the application object node)<br>
     * Only valid in SQL schema scope context
     * @name view
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {String}
     */
    this.view = String;

    /**
     * Specifies that the node primary key is not determined internally, but needs to be passed from external
     * @name externalKey
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {Boolean}
     */
    this.externalKey = Boolean;

    /**
     * Specifies the parent key table field for sub-nodes
     * @name parentKey
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {String}
     */
    this.parentKey = String;

    /**
     * Specifies if the node (incl. attributes is modifiable from outside
     * @name readOnly
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {(Boolean|ImplementationExit.nodeReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Specifies if the attributes need to be explicitly defined instead of implicit derivation from the table definition
     * @name explicitAttributeDefinition
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {Boolean}
     */
    this.explicitAttributeDefinition = Boolean;

    /**
     * Specifies consistency checks on node after modifications
     * @name consistencyChecks
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {Array.<ImplementationExit.nodeConsistencyCheck>}
     */
    this.consistencyChecks = [];

    /**
     * Specifies input checks on node before modifications
     * @name inputChecks
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {Array.<ImplementationExit.nodeInputCheck>}
     */
    this.inputChecks = [];

    /**
     * Specifies attributes on node
     * @name attributes
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {(Object.<String, Schema.SchemaAttribute>)}
     */
    this.attributes = {};

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {(Object|ImplementationExit.nodeCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies sub-nodes of the current node
     * @name nodes
     * @memberOf Schema.SchemaNode
     * @instance
     * @type {(Object.<String, Schema.SchemaNode>)}
     */
    this.nodes = {};
}

/**
 * Application Object attribute schema
 * @memberOf Schema
 * @namespace SchemaAttribute
 */
function SchemaAttribute() {

    /**
     * Specifies the data type of the attribute - is normally derived from database metadata, if available)
     * @name dataType
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {DataType}
     */
    this.dataType = String;

    /**
     * Specifies that the attribute is mandatory
     * @name required
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Boolean}
     */
    this.required = Boolean;

    /**
     * Specifies the application object name, the attribute value is a foreign key
     * @name foreignKeyTo
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {String}
     */
    this.foreignKeyTo = String;

    /**
     * Specifies that the foreign key to reference is an intra-object instance
     * @name foreignKeyIntraObject
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {String}
     */
    this.foreignKeyIntraObject = String;

    /**
     * Specifies a constant key the attribute is default with and which is used during read for selection
     * @name constantKey
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {String}
     */
    this.constantKey = String;

    /**
     * Specifies that the attribute is read only and not modifiable from outside
     * @name readOnly
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {(Boolean|ImplementationExit.attributeReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Specifies that the attribute is the (one and only) name attribute usable for human-readable display and fuzzy search purposes of an object (node) instance
     * @name isName
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {String}
     */
    this.isName = Boolean;

    /**
     * Specifies that the attribute is a description attribute usable for human-readable fuzzy search purposes of an object (node) instance
     * @name isDescription
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {String}
     */
    this.isDescription = Boolean;

    /**
     * Specifies that the attribute is part of the concurrency token, which might consist of multiple attributes
     * @name concurrencyControl
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Boolean}
     */
    this.concurrencyControl = Boolean;

    /**
     * Specifies that the min value of the attribute value if it has type Number (Integer or Double)
     * @name minValue
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Number}
     */
    this.minValue = 0;

    /**
     * Specifies that the max length of the attribute value if it has type String
     * @name maxLength
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Number}
     */
    this.maxLength = 0;

    /**
     * Specifies that the max value of the attribute value if it has type Number (Integer or Double)
     * @name maxValue
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Number}
     */
    this.maxValue = 0;

    /**
     * Specifies the enumeration values which will be used for validation.
     * @name enum
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Array.<String>|Object}
     */
    this.enum = {};

    /**
     * Specifies a json schema which will be used for validation. Note: ensure to use the respective json data type.
     * @name jsonSchema
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {Object}
     * @see {@link https://github.com/epoberezkin/ajv/blob/master/KEYWORDS.md Key word documentation}
     */
    this.jsonSchema = {};

    /**
     * Specifies consistency checks on attribute after modifications
     * @name consistencyChecks
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {(Array.<ImplementationExit.attributeConsistencyCheck>)}
     */
    this.consistencyChecks = [];

    /**
     * Specifies input checks on attribute before modifications
     * @name inputChecks
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {(Array.<ImplementationExit.attributeInputCheck>)}
     */
    this.inputChecks = [];

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {(Object|ImplementationExit.attributeCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Attribute is constant (not changeable after node creation)
     * @name isConstant
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {boolean}
     */
    this.isConstant = false;

    /**
     * Attribute is part of the alternative key
     * @name isAlternativeKey
     * @memberOf Schema.SchemaAttribute
     * @instance
     * @type {boolean}
     */
    this.isAlternativeKey = false;
}

/**
 * Application Object action schema
 * @memberOf Schema
 * @namespace SchemaAction
 */
function SchemaAction() {

    /**
     * Specifies the authorization check for the action
     * @name authorizationCheck
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {(ImplementationExit.authorizationCheck|ImplementationExit.staticAuthorizationCheck)}
     */
    this.authorizationCheck = function () {
    };

    /**
     * Specifies the enabled check for the action
     * @name enabledCheck
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {(ImplementationExit.enabledCheck|ImplementationExit.staticEnabledCheck)}
     */
    this.enabledCheck = function () {
    };

    /**
     * Specifies the execution check for the action for create, update, del action
     * @name executionCheck
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {ImplementationExit.executionCheck}
     */
    this.executionCheck = function () {
    };

    /**
     * Optional function to redefine persist behavior
     * @name persist
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {ImplementationExit.persistActionExecute}
     */
    this.persist = function () {
    };

    /**
     * Specifies history event name for the history table entry
     * @name historyEvent
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {String}
     */
    this.historyEvent = String;

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {(Object|ImplementationExit.actionCustomProperties|ImplementationExit.staticActionCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies that the action may only be called in application object implementations
     * @name isInternal
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {Boolean}
     */
    this.isInternal = Boolean;

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies if action is exposed to outside consumers (e.g. Rest, WS)
     * Default is true (exposed) for non-internal actions
     * @name isExposed
     * @memberOf Schema.SchemaAction
     * @instance
     * @type {boolean}
     */
    this.isExposed = true;
}

/**
 * Application Object custom schema
 * @memberOf Schema
 * @namespace SchemaCustomAction
 */
function SchemaCustomAction() {

    /**
     * Specifies the authorization check for the action
     * @name authorizationCheck
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {(ImplementationExit.authorizationCheck|ImplementationExit.staticAuthorizationCheck)}
     */
    this.authorizationCheck = function () {
    };

    /**
     * Specifies the enabled check for the action
     * @name enabledCheck
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {(ImplementationExit.enabledCheck|ImplementationExit.staticEnabledCheck)}
     */
    this.enabledCheck = function () {
    };

    /**
     * Specifies if the custom action execution can have side effects
     * @name readOnly
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {(Boolean|ImplementationExit.actionReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Optional function to redefine persist behavior
     * @name persist
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {ImplementationExit.persistActionExecute}
     */
    this.persist = function () {
    };

    /**
     * Specifies history event name for the history table entry
     * @name historyEvent
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {String}
     */
    this.historyEvent = String;

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {(Object|ImplementationExit.actionCustomProperties|ImplementationExit.staticActionCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies that the action may only be called in application object implementations
     * @name isInternal
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {Boolean}
     */
    this.isInternal = Boolean;

    /**
     * Specifies the execution logic of the custom action including checks
     * @name execute
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {ImplementationExit.actionExecute}
     */
    this.execute = Boolean;

    /**
     * Specifies whether this is a static action
     * @name isStatic
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {Boolean}
     */
    this.isStatic = Boolean;

    /**
     * specifies the name of the mass enabled action. A new static action with this name is generated accepting a parameter, containing the action keys as array on the parameter object, i.e. { keys : [...], ... }
     * @name massActionName
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {String}
     */
    this.massActionName = String;

    /**
     * Specifies other application objects that are impacted by action execution
     * @name impacts
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {Array.<String>}
     */
    this.impacts = "";

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaCustomAction
     * @instance
     * @type {String}
     */
    this.label = "";
}

/**
 * Application Object extension schema
 * @memberOf Schema
 * @namespace SchemaExtensionObject
 */
function SchemaExtensionObject() {
    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaExtensionObject
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Extension definition of the application object root
     * @name Root
     * @memberOf Schema.SchemaExtensionObject
     * @instance
     * @type {Schema.SchemaExtensionRootNode}
     */
    this.Root = {};

    /**
     * Extension definition of the application object actions<br>
     * - Default framework actions are: create, copy, update, del, read<br>
     * - Reserved action names are: exists, convertKey, calculateConcurrencyToken, properties, staticProperties<br>
     * - Custom name can have any other name than the ones above
     * @name actions
     * @memberOf Schema.SchemaExtensionObject
     * @instance
     * @type {(Object.<String, Schema.SchemaExtensionAction>|Object.<String, Schema.SchemaExtensionCustomAction>|Object.<String, Schema.SchemaCustomAction>)}
     */
    this.actions = {};
}

/**
 * Application Object root node extension schema
 * @memberOf Schema
 * @namespace SchemaExtensionRootNode
 */
function SchemaExtensionRootNode() {

    /**
     * Specifies if the node (incl. attributes is modifiable from outside
     * @name readOnly
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {(Boolean|ImplementationExit.nodeReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Specifies consistency checks on node after modifications
     * @name consistencyChecks
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {Array.<ImplementationExit.nodeConsistencyCheck>}
     */
    this.consistencyChecks = [];

    /**
     * Specifies input checks on node before modifications
     * @name inputChecks
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {Array.<ImplementationExit.nodeInputCheck>}
     */
    this.inputChecks = [];

    /**
     * Specifies attributes on node
     * @name attributes
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {(Object.<String, Schema.SchemaExtensionAttribute>)}
     */
    this.attributes = {};

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {(Object|ImplementationExit.nodeCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies determinations executed after application object modifications. The following timepoints exist:<br>
     * - onCreate: Specifies determinations executed at application object creation<br>
     * - onPrepareCopy: Specifies determinations executed before application object copy<br>
     * - onCopy: Specifies determinations executed at application object copy<br>
     * - onUpdate: Specifies determinations executed at application object updates, custom actions<br>
     * - onModify: Specifies determinations executed at application object creation, copy, update, customAction<br>
     * - onDelete: Specifies determinations executed at application object deletion<br>
     * - onPersist: Specifies determinations executed at after changes have been persisted in the database<br>
     * - onRead: Specifies determinations executed at application object creation read<br>
     * @name determinations
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {(Object.<String, Array.<ImplementationExit.determination>>|Object.<String, Array.<ImplementationExit.onPersistDetermination>>|Object.<String, Array.<ImplementationExit.readDetermination>>)}
     */
    this.determinations = {};

    /**
     * Specifies sub-nodes of the current node
     * @name nodes
     * @memberOf Schema.SchemaExtensionRootNode
     * @instance
     * @type {(Object.<String, Schema.SchemaExtensionNode>|Object.<String, Schema.SchemaNode>)}
     */
    this.nodes = {};
}

/**
 * Application Object node extension schema
 * @memberOf Schema
 * @namespace SchemaExtensionNode
 */
function SchemaExtensionNode() {

    /**
     * Specifies if the node (incl. attributes is modifiable from outside
     * @name readOnly
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {(Boolean|ImplementationExit.nodeReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Specifies consistency checks on node after modifications
     * @name consistencyChecks
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {Array.<ImplementationExit.nodeConsistencyCheck>}
     */
    this.consistencyChecks = [];

    /**
     * Specifies input checks on node before modifications
     * @name inputChecks
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {Array.<ImplementationExit.nodeInputCheck>}
     */
    this.inputChecks = [];

    /**
     * Specifies attributes on node
     * @name attributes
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {(Object.<String, Schema.SchemaExtensionAttribute>)}
     */
    this.attributes = {};

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {(Object|ImplementationExit.nodeCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies sub-nodes of the current node
     * @name nodes
     * @memberOf Schema.SchemaExtensionNode
     * @instance
     * @type {(Object.<String, Schema.SchemaExtensionNode>|Object.<String, Schema.SchemaNode>)}
     */
    this.nodes = {};
}

/**
 * Application Object attribute extension schema
 * @memberOf Schema
 * @namespace SchemaExtensionAttribute
 */
function SchemaExtensionAttribute() {

    /**
     * Specifies the data type of the attribute
     * @name dataType
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {DataType}
     */
    this.dataType = String;

    /**
     * Specifies that the attribute is mandatory
     * @name required
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {Boolean}
     */
    this.required = Boolean;

    /**
     * Specifies the application object name, the attribute value is a foreign key
     * @name foreignKeyTo
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {String}
     */
    this.foreignKeyTo = String;

    /**
     * Specifies that the attribute is read only and not modifiable from outside
     * @name readOnly
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {(Boolean|ImplementationExit.attributeReadOnlyCheck)}
     */
    this.readOnly = Boolean;

    /**
     * Specifies that the attribute is the (one and only) name attribute usable for human-readable display and fuzzy search purposes of an object (node) instance
     * @name isName
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {String}
     */
    this.isName = Boolean;

    /**
     * Specifies that the attribute is a description attribute usable for human-readable fuzzy search purposes of an object (node) instance
     * @name isDescription
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {String}
     */
    this.isDescription = Boolean;

    /**
     * Specifies that the min value of the attribute value if it has type Number (Integer or Double)
     * @name minValue
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {Number}
     */
    this.minValue = 0;

    /**
     * Specifies that the max length of the attribute value if it has type String
     * @name maxLength
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {Number}
     */
    this.maxLength = 0;

    /**
     * Specifies that the max value of the attribute value if it has type Number (Integer or Double)
     * @name maxValue
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {Number}
     */
    this.maxValue = 0;

    /**
     * Specifies the enumeration values which will be used for validation.
     * @name enum
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {Array.<String>|Object}
     */
    this.enum = {};

    /**
     * Specifies a json schema which will be used for validation. Note: ensure to use the respective json data type.
     * @name jsonSchema
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {Object}
     * @see {@link https://github.com/epoberezkin/ajv/blob/master/KEYWORDS.md Key word documentation}
     */
    this.jsonSchema = {};

    /**
     * Specifies consistency checks on attribute after modifications
     * @name consistencyChecks
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {(Array.<ImplementationExit.attributeConsistencyCheck>)}
     */
    this.consistencyChecks = [];

    /**
     * Specifies input checks on attribute before modifications
     * @name inputChecks
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {(Array.<ImplementationExit.attributeInputCheck>)}
     */
    this.inputChecks = [];

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {(Object|ImplementationExit.attributeCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Attribute is constant (not changeable after node creation)
     * @name isConstant
     * @memberOf Schema.SchemaExtensionAttribute
     * @instance
     * @type {boolean}
     */
    this.isConstant = false;
}

/**
 * Application Object action extension schema
 * @memberOf Schema
 * @namespace SchemaExtensionAction
 */
function SchemaExtensionAction() {

    /**
     * Specifies the enabled check for the action
     * @name enabledCheck
     * @memberOf Schema.SchemaExtensionAction
     * @instance
     * @type {(ImplementationExit.enabledCheck|ImplementationExit.staticEnabledCheck)}
     */
    this.enabledCheck = function () {
    };

    /**
     * Specifies the execution check for the action for create, update, del action
     * @name executionCheck
     * @memberOf Schema.SchemaExtensionAction
     * @instance
     * @type {ImplementationExit.executionCheck}
     */
    this.executionCheck = function () {
    };

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaExtensionAction
     * @instance
     * @type {(Object|ImplementationExit.actionCustomProperties|ImplementationExit.staticActionCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaExtensionAction
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies if action is exposed to outside consumers (e.g. Rest, WS)
     * Default is true (exposed) for non-internal actions
     * @name isExposed
     * @memberOf Schema.SchemaExtensionAction
     * @instance
     * @type {boolean}
     */
    this.isExposed = true;
}

/**
 * Application Object custom extension schema
 * @memberOf Schema
 * @namespace SchemaExtensionCustomAction
 */
function SchemaExtensionCustomAction() {

    /**
     * Specifies the enabled check for the action
     * @name enabledCheck
     * @memberOf Schema.SchemaExtensionCustomAction
     * @instance
     * @type {(ImplementationExit.enabledCheck|ImplementationExit.staticEnabledCheck)}
     */
    this.enabledCheck = function () {
    };

    /**
     * Specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients
     * @name customProperties
     * @memberOf Schema.SchemaExtensionCustomAction
     * @instance
     * @type {(Object|ImplementationExit.actionCustomProperties|ImplementationExit.staticActionCustomProperties)}
     */
    this.customProperties = {};

    /**
     * Specifies the execution logic of the custom action including checks
     * @name execute
     * @memberOf Schema.SchemaExtensionCustomAction
     * @instance
     * @type {ImplementationExit.actionExecute}
     */
    this.execute = Boolean;

    /**
     * Specifies other application objects that are impacted by action execution
     * @name impacts
     * @memberOf Schema.SchemaExtensionCustomAction
     * @instance
     * @type {Array.<String>}
     */
    this.impacts = "";

    /**
     * Specifies the describing label
     * @name label
     * @memberOf Schema.SchemaExtensionCustomAction
     * @instance
     * @type {String}
     */
    this.label = "";

    /**
     * Specifies if the extension custom action execution can have side effects
     * @name readOnly
     * @memberOf Schema.SchemaExtensionCustomAction
     * @instance
     * @type {(Boolean|ImplementationExit.actionReadOnlyCheck)}
     */
    this.readOnly = Boolean;
}
