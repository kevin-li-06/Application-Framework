"use strict";

module.exports = {
    Root : {
        table : "sap.aof.example.db.iam::t_identity",
        readOnly : true,
        attributes : {
            TYPE_CODE : {
                required : true
            },
            SOURCE_TYPE_CODE : {
                required : true
            },
            NAME : {
                required : true,
                isName : true
            },
            STAGED : {
                readOnly : true
            }
        }
    }
};