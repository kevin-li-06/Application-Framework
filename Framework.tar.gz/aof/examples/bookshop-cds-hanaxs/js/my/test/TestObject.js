"use strict";

module.exports = {
    actions: {
        foo: {
            authorizationCheck: false,
            execute: function (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) {
                oWorkObject.date = new Date().toISOString();
                return oWorkObject;
            }
        }
    },
    Root: {
        determinations: {
            onCreate: [initObject]
        }
    }
};

function initObject(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) {
    oWorkObject.status = "open";
    oWorkObject.date = new Date().toISOString();
}