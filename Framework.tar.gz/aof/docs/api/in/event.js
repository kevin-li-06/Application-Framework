"use strict";

/**
 * Event object published to event listeners
 * @namespace Event
 */
function Event() {
}

/**
 * Application Object metadata
 * @type {Metadata}
 */
Event.prototype.metadata = Object;

/**
 * Application Object name of event
 * @type {String}
 */
Event.prototype.applicationObject = String;

/**
 * Triggering action of event
 * @type {String}
 */
Event.prototype.action = String;

/**
 * Technical action (create, update, delete) of event
 * @type {String}
 */
Event.prototype.technicalAction = String;

/**
 * Application object instance key of event
 * @type {String}
 */
Event.prototype.key = String;

/**
 * Application object instance data of event
 * @type {Object}
 */
Event.prototype.object = Object;

/**
 * Application object instance data before action execution of event
 * @type {Object}
 */
Event.prototype.objectBefore = Object;

/**
 * Application object action response of event
 * @type {Object}
 */
Event.prototype.response = Object;

/**
 * Application object caller context (only for BeforeCommit events)
 * @type {Object}
 */
Event.prototype.callerContext = Object;

/**
 * External session UUID passed from outside triggering the event
 * @type {String}
 */
Event.prototype.sessionUUID = String;
