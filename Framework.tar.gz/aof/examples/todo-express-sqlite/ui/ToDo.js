sap.ui.define([
    "sap/aof/ApplicationObject",
    "sap/aof/ReadSource"
], function (ApplicationObject, ReadSource) {
    "use strict";

    var ToDo = ApplicationObject.extend("todo.ToDo", {
        objectName: "todo.rest.ToDo",
        readSource: ReadSource.getDefaultAOFSource(),
        invalidation: {
            entitySets: ["ToDo_Root", "Root"]
        }
    });

    ToDo.disableXSRFToken = true;
    return ToDo;
});