"use strict";

/**
 * Application Object Framework (AOF) library for SAP UI5 containing reusable models and helper functions
 * @namespace UI
 */

function UI() {

    /**
     * Enumeration for Message Type
     * @enum {String}
     */
    UI.MessageType = {
        /**
         * 'E' : A error message occurred
         */
        Error: "E",
        /**
         * 'W' : A warning message occurred
         */
        Warning: "W",
        /**
         * 'I' : A info message occurred
         */
        Info: "I",
        /**
         * 'D' : A debug message occurred
         */
        Debug: "D",
        /**
         * 'S' : S success message occurred
         */
        Success: "S"
    };

    /**
     * @constructor
     * @memberof UI
     * @augments sap.ui.model.json.JSONModel
     * @fires UI.PropertyModel.modelInitialized
     * @param sApplicationObjectName {String} Name of the application object
     * @param vKey {*} Key of the application object instance
     * @param oScope {Object} Scope object definition, e.g. <br>
     * { nodes : ["Root"], actions : ["update", { "customAction" : { "A" : 1 } }], staticActions : [ { "create" : { "OBJECT_ID" : 1 } } } ]
     * @param oScope.nodes {Array.<String>} Nodes for which properties are read
     * @param oScope.actions {(Array.<String>|Array.<String, Object>)} Actions for which properties are read, either provided as action names or as action name/parameter objects
     * @param oScope.staticActions {Array.<String, Object>} Static Actions for which staticProperties are read, provided as name/parameter objects
     * @param bSync {Boolean} Properties are fetched synchronously
     * @param fnModelInitialized {Function} Event triggered after model initialization
     * @param oPropertyDefault {Object} Default data for properties
     * @class PropertyModel
     */
    function PropertyModel() {
    }

    /**
     * Formatter instance callback function
     * @memberof UI
     * @callback UI.PropertyModel.formatter
     * @param vKey {*} Key of the object instance to be checked for properties
     * @return {Boolean}
     */
    PropertyModel.prototype.formatter = function (vKey) {
        return Boolean;
    };

    /**
     * Formatter instance callback function
     * @memberof UI
     * @callback UI.PropertyModel.staticFormatter
     * @param vKey {*} Key of the root object node instance to be checked
     * @param [vNodeKey] {*} Key of the object node instance to be checked for proeprties if not root node
     * @return {Boolean}
     */
    PropertyModel.prototype.staticFormatter = function (vKey, vNodeKey) {
        return Boolean;
    };

    /**
     * Property Model was initialized
     *
     * @memberof UI.PropertyModel
     * @event modelInitialized
     */

    /**
     * Property Model cache was updated
     *
     * @memberof UI.PropertyModel
     * @event modelCacheUpdated
     */

    /**
     * Property Model cache was invalidated
     *
     * @memberof UI.PropertyModel
     * @event modelCacheInvalidated
     */

    /**
     * Returns a formatter evaluating to a boolean value,expressing if the node is read-only or not
     * @method getNodeReadOnlyFormatter
     * @memberof UI.PropertyModel
     * @instance
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sNodeName {String} Name of the node to be checked for read-only property
     * @returns {UI.PropertyModel.formatter} Function taking a node key as parameter and returning a boolean value
     */
    PropertyModel.prototype.getNodeReadOnlyFormatter = function (sNodeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the node is changeable (not read-only) or not
     * @method getNodeChangeableFormatter
     * @memberof UI.PropertyModel
     * @instance
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sNodeName {String} Name of the node to be checked for changeable (not read-only) property
     * @returns {UI.PropertyModel.formatter} Function taking a node key as parameter and returning a boolean value
     */
    PropertyModel.prototype.getNodeChangeableFormatter = function (sNodeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the node attribute is read-only or not
     * @method getAttributeReadOnlyFormatter
     * @memberof UI.PropertyModel
     * @instance
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sNodeName {String} Name of the node containing the attribute
     * @param sAttributeName {String} Name of the node attribute to be checked for read-only property
     * @returns {UI.PropertyModel.formatter} Function taking a node key as parameter and returning a boolean value
     */
    PropertyModel.prototype.getAttributeReadOnlyFormatter = function (sNodeName, sAttributeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the node attribute is changeable (not read-only) or not
     * @method getAttributeChangeableFormatter
     * @memberof UI.PropertyModel
     * @instance
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sNodeName {String} Name of the node containing the attribute
     * @param sAttributeName {String} Name of the node attribute to be checked for changeable (not read-only) property
     * @returns {UI.PropertyModel.formatter} Function taking a node key as parameter and returning a boolean value
     */
    PropertyModel.prototype.getAttributeChangeableFormatter = function (sNodeName, sAttributeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the action is enabled or not
     * @method getActionEnabledFormatter
     * @memberof UI.PropertyModel
     * @instance
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sActionName {String} Name of the action to be checked for enabled property
     * @returns {UI.PropertyModel.formatter} Function taking a node key as parameter and returning a boolean value
     */
    PropertyModel.prototype.getActionEnabledFormatter = function (sActionName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the static action is enabled or not
     * @method getStaticActionEnabledFormatter
     * @memberof UI.PropertyModel
     * @instance
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sActionName {String} Name of the action to be checked for enabled property
     * @returns {UI.PropertyModel.formatter} Function returning a boolean value
     */
    PropertyModel.prototype.getStaticActionEnabledFormatter = function (sActionName) {
        return Function;
    };

    /**
     * Returns all properties
     * @method getProperties
     * @memberof UI.PropertyModel
     * @instance
     * @returns {Object}
     */
    PropertyModel.prototype.getProperties = function () {
        return {};
    };

    /**
     * Synchronized the read properties and optionally invalidated the property cache
     * @method sync
     * @memberof UI.PropertyModel
     * @instance
     * @param vKey {*} Key to be invalidated
     * @param bSuppressInvalidateCache {Boolean} Supress cache invalidation
     */
    PropertyModel.prototype.sync = function (vKey, bSuppressInvalidateCache) {
    };

    /**
     * Returns a Promise resolving when the property model is initialized
     * @method getDataInitializedPromise
     * @memberof UI.PropertyModel
     * @instance
     * @return {Promise}
     */
    PropertyModel.prototype.getDataInitializedPromise = function () {
        return new Promise();
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the application Object node is read-only or not
     * @method getNodeReadOnlyStaticFormatter
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sApplicationObjectName {String} Name of the application object name to be checked
     * @param sNodeName {String} Name of the node to be checked for read-only property
     * @returns {UI.PropertyModel.staticFormatter} Function taking a root key and a node key as parameter and returning a boolean value
     */
    PropertyModel.getNodeReadOnlyStaticFormatter = function (sApplicationObjectName, sNodeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the application Object node is changeable (not read-only) or not
     * @method getNodeChangeableStaticFormatter
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sApplicationObjectName {String} Name of the application object name to be checked
     * @param sNodeName {String} Name of the node to be checked for changeable (not read-only) property
     * @returns {UI.PropertyModel.staticFormatter} Function taking a root key and a node key as parameter and returning a boolean value
     */
    PropertyModel.getNodeChangeableStaticFormatter = function (sApplicationObjectName, sNodeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the application Object node attribute is read-only or not
     * @method getAttributeReadOnlyStaticFormatter
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sApplicationObjectName {String} Name of the application object name to be checked
     * @param sNodeName {String} Name of the node to be checked
     * @param sAttributeName {String} Name of the node attribute to be checked for read-only property
     * @returns {UI.PropertyModel.staticFormatter} Function taking a root key and a node key as parameter and returning a boolean value
     */
    PropertyModel.getAttributeReadOnlyStaticFormatter = function (sApplicationObjectName, sNodeName, sAttributeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the application Object node attribute is changeable (not read-only) or not
     * @method getAttributeChangeableStaticFormatter
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sApplicationObjectName {String} Name of the application object name to be checked
     * @param sNodeName {String} Name of the node to be checked for changeable (not read-only) property
     * @param sAttributeName {String} Name of the node attribute to be checked changeable (not read-only) property
     * @returns {UI.PropertyModel.staticFormatter} Function taking a root key and a node key as parameter and returning a boolean value
     */
    PropertyModel.getAttributeChangeableStaticFormatter = function (sApplicationObjectName, sNodeName, sAttributeName) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the application Object action is enabled or not
     * @method getActionEnabledStaticFormatter
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sApplicationObjectName {String} Name of the application object name to be checked
     * @param sActionName {String} Name of the node to be checked for enabled property
     * @param oParameter {Object} Action parameters used for property calculation
     * @returns {UI.PropertyModel.staticFormatter} Function taking a root key and a node key as parameter and returning a boolean value
     */
    PropertyModel.getActionEnabledStaticFormatter = function (sApplicationObjectName, sActionName, oParameter) {
        return Function;
    };

    /**
     * Returns a formatter evaluating to a boolean value, expressing if the application Object static action is enabled or not
     * @method getStaticActionEnabledStaticFormatter
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheUpdated
     * @param sApplicationObjectName {String} Name of the application object name to be checked
     * @param sActionName {String} Name of the node to be checked for enabled property
     * @param oParameter {Object} Action parameters used for property calculation
     * @returns {UI.PropertyModel.staticFormatter} Function taking a root key and a node key as parameter and returning a boolean value
     */
    PropertyModel.getStaticActionEnabledStaticFormatter = function (sApplicationObjectName, sActionName, oParameter) {
        return Function;
    };

    /**
     * Returns the Property Model cache
     * @method getCacheModel
     * @memberof UI.PropertyModel
     * @static
     * @returns {sap.ui.model.json.JSONModel}
     */
    PropertyModel.getCacheModel = function () {
        return Object;
    };

    /**
     * Returns the cached properties for an Application Object
     * @method getCachedProperties
     * @memberof UI.PropertyModel
     * @static
     * @param sApplicationObjectName {String} Name of application object
     * @returns {Object}
     */
    PropertyModel.getCachedProperties = function (sApplicationObjectName) {
        return Object;
    };

    /**
     * Invalidates cached properties. Either all, per Application Object type or for one Application Object instance.
     * @method invalidateCachedProperties. Properties are re-read on demand.
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheInvalidated
     * @param [sApplicationObjectName] {String} Name of application object
     * @param [vKey] {*} Key of the application object instance to be invalidated
     */
    PropertyModel.invalidateCachedProperties = function (sApplicationObjectName, vKey) {
    };

    /**
     * Invalidates all cached properties. Properties are re-read on demand.
     * @method refresh
     * @memberof UI.PropertyModel
     * @static
     * @fires UI.PropertyModel.modelCacheInvalidated
     */
    PropertyModel.refresh = function () {
    };

    /**
     * @constructor
     * @memberof UI
     * @augments sap.ui.model.json.JSONModel
     * @class MetaModel
     */
    function MetaModel() {
    }

    /**
     * Meta Model was initialized
     *
     * @memberof UI.MetaModel
     * @event modelInitialized
     */

    /**
     * Get Application Object metadata
     * @method getApplicationObjectMetadata
     * @memberof UI.MetaModel
     * @static
     * @fires UI.MetaModel.modelInitialized
     * @param sObjectName {String} Name of Application Object name
     * @param fnResult {Function} Callback function called when Meta Model is initialized
     * @return {Object} Application Object metadata
     */
    MetaModel.getApplicationObjectMetadata = function (sObjectName, fnResult) {
        return Object;
    };

    /**
     * Create Property binding based on Application Object metadata
     * @method bindProperty
     * @memberof UI.MetaModel
     * @static
     * @param sPath {String} Binding path
     * @param oContext {Object} Binding context
     * @param mParameters {Object} Binding parameters
     * @returns {JSONPropertyBinding}
     */
    MetaModel.bindProperty = function (sPath, oContext, mParameters) {
        return;
    };

    /**
     * Returns the endpoint URL for the Application Object
     * @method getEndpoint
     * @memberof UI.MetaModel
     * @static
     * @param sApplicationObjectName {String} Name of the application object
     * @returns {String} URL of the Application Object
     */
    MetaModel.getEndpoint = function (sApplicationObjectName) {
        return String;
    };

    /**
     * Application Object (shall not be instantiated directly, but needs to be inherited via static extend function)
     * @constructor
     * @memberof UI
     * @augments sap.ui.model.json.JSONModel
     * @class ApplicationObject
     * @param vKey {*|Object} Initialization parameter:<br>
     * - Object key for creating a model for an existing instance<br>
     * - Handle key, e.g. -1 for creating a new instance<br>
     * - Default data object for creation a new instance based on default data
     * @param oSettings {Object} Application Object settings
     * @param oSettings.continuousUse {Boolean} The model is continuously used for several modifications and data re-read after backend call. If set to true, the model is refreshed via reading new data from backend after each action execution.
     * @param oSettings.readSource {Object} Read Source settings propagated to read source implementation as additional settings (see Read Source)
     * @param oSettings.concurrencyEnabled {Boolean} Specifies if concurrency mode is enabled, so that the concurrency token is retrieved and checked for each modifying backend communication.
     * Backend Application Object must be concurrency enabled by flagging at least one attribute on Root node with "concurrencyControl = true"
     * @param oSettings.deriveBindingType {Boolean} Automatically derives the data type during establishing of a property binding from the application object metadata (if no type was specified explicitly)<br>
     * - This could lead to unexpected behaviour when specifying a formatter, which changes the type (e.g. formatter converting a integer to a boolean)<br>
     * - Use explicit 'type = null' for property binding, to prevent automatic type derivation for this specific binding
     * @param oSettings.nodes {Array.<String>} Nodes for which properties are read during model initialization and model sync for the current specified instance key
     * @param oSettings.actions {(Array.<String>|Array.<String, Object>)} Actions for which properties are read during model initialization and model sync for the current specified instance key, either provided as action names or as action name/parameter objects
     * @param oSettings.staticActions {Array.<String, Object>} Static Actions for which staticProperties are read during model initialization and model sync for the specified default data object (3rd option of first constructor parameter), provided as name/parameter objects
     * @param oSettings.textModel {sap.ui.model.resource.ResourceModel} Text model to be used to map the message keys to message texts
     * @param oSettings.changeDetectionProperty {String} Enables a change detection property, which can be bound, to be notified when model data is touched. Use "hasPendingChanges" to detect if data was changed compared to data read before.
     * @param oSettings.propertyDefaults {Object} Property defaults used to default the internal Property Model
     */
    function ApplicationObject() {
    }

    /**
     * Called to initialize a action parameter model, that can be bound
     * @callback UI.ApplicationObject.initParameter
     * @param oActionMetadata {Object} An empty parameter object, that can be modified to initialize the parameter JSON Model
     * @param [vArgument] {...*} Multiple arbitrary arguments, that
     */
    ApplicationObject.prototype.initParameter = function (oParameter, oArgument) {
        return new Promise();
    };

    /**
     * Called for custom UI action execution
     * @callback UI.ApplicationObject.actionExecute
     * @param vKey {*} Key of the Application Object instance
     * @param oObjectInstance {UI.ApplicationObject} Application Object instance
     * @param oParameter {Object} An action parameter object
     * @param oActionMetadata {Object} Metadata of the called action
     * @param oSettings {Object} Action call settings
     * @returns {Object|Promise} Returns a result object or an promise resolving to an result object
     */
    ApplicationObject.prototype.actionExecute = function (vKey, oObjectInstance, oParameter, oActionMetadata, oSettings) {
        return Object;
    };

    /**
     * Called determination during instantiation of Application Object for new instances
     * @callback UI.ApplicationObject.determinationOnCreate
     * @param oData {Object} Data to be used as Application Object creation data
     * @param oObjectInstance {UI.ApplicationObject} Application Object instance
     * @returns {Object} Data to be used as Application Object creation data
     */
    ApplicationObject.prototype.determinationOnCreate = function (oData, oObjectInstance) {
        return Object;
    };

    /**
     * Called determination during instantiation of Application Object for existing instances
     * @callback UI.ApplicationObject.determinationOnRead
     * @param oData {Object} Data to be used as Application Object update data
     * @param oObjectInstance {UI.ApplicationObject} Application Object instance
     * @param bBeforeImage {Boolean} Flag to differentiate between current and before image
     * @returns {Object} Data to be used as Application Object update data
     */
    ApplicationObject.prototype.determinationOnRead = function (oData, oObjectInstance, bBeforeImage) {
        return Object;
    };

    /**
     * Called determination after execution of an Application Object action
     * @callback UI.ApplicationObject.determinationOnPersist
     * @param vKey {*} Key of the Application Object instance
     * @param oChangeRequest {Object} Change request send to the backend during action execution
     * @param oData {Object} Application Object instance data
     * @param oActionMetadata {Object} Metadata of the called action
     * @param oObjectInstance {UI.ApplicationObject} Application Object instance
     */
    ApplicationObject.prototype.determinationOnPersist = function (vKey, oChangeRequest, oData, oActionMetadata, oObjectInstance) {
    };

    /**
     * Called to normalize the Application Object data before calculating the change request
     * @callback UI.ApplicationObject.determinationOnNormalizeData
     * @param oData {Object} Application Object instance data
     * @param oObjectInstance {UI.ApplicationObject} Application Object instance
     * @param bBeforeImage {Boolean} Flag to differentiate between current and before image
     * @returns {Object} Application Object instance data to be used for change request
     */
    ApplicationObject.prototype.determinationOnNormalizeData = function (oData, oObjectInstance, bBeforeImage) {
        return Object;
    };

    /**
     * Determination called after successful processing of creation action to update handles on a de-normalized object structure
     * @callback UI.ApplicationObject.determinationOnUpdateHandles
     * @param oData {Object} Application Object instance data
     * @param mGeneratedKeys {Object} Key mapping from handle key to new key
     * @returns {Object} Application Object instance data to be used for further processing
     */
    ApplicationObject.prototype.determinationOnUpdateHandles = function (oData, mGeneratedKeys) {
        return Object;
    };

    /**
     * Application Object Type inheriting from the UI Application Object base
     * @method extend
     * @memberof UI.ApplicationObject
     * @static
     * @param sApplicationObjectType {String} Name of the Application Object type
     * @param oMetadata {Object} Application Object type specific metdata
     * @param oMetadata.objectName {String} Backend path to Application Object
     * @param oMetadata.readSource {UI.ReadSource.readSourceCallback} Function to be used for retrieving the data, e.g. by generating it via ReadSource.getDefaultAOFSource()<br>
     * @param oMetadata.invalidation {Object} Invalidation Configuration
     * @param oMetadata.invalidation.entitySets {Array.<String>} Array of OData entity Sets that needs to be invalidated by Model Synchronizer
     * @param oMetadata.actions {Object.<String, Object>} Enhancement of Application Object actions or definition of custom Application Object UI actions
     * @param oMetadata.actions.actionName {Object.<String, Object>} For each action available in the Application Object or define in the UI model as UI action
     * @param oMetadata.actions.initParameter {UI.ApplicationObject.initParameter}  Callback function to determine the default action parameters, when retrieving the action parameter model
     * @param oMetadata.actions.impacts {Array.<Object>} An array of impact definitions for other application objects that can be specified using the following structure
     * @param oMetadata.actions.impacts.objectName {String} Name of the impacted application object
     * @param oMetadata.actions.impacts.objectKey {String} Foreign key attribute in the application object matching the impacted application object's primary key
     * @param oMetadata.actions.impacts.impactedAttributes {Array} Array of attributes, that are impacted by the application object change (used for selective read)
     * @param oMetadata.actions.impacts.entity {Object} Definition of the impacted entity
     * @param oMetadata.actions.impacts.entity.entitySet {String} Name of impacted entity set
     * @param oMetadata.actions.impacts.entity.key {*} Key of the impacted entity
     * @param oMetadata.actions.execute {UI.ApplicationObject.actionExecute} For UI actions a execute method can be implemented to process the logic
     * @param oMetadata.determinations {Object} Specifies determination points that can be implemented
     * @param oMetadata.determinations.onCreate {UI.ApplicationObject.determinationOnCreate} Called on creation of a new UI Application Object Model instance (no key, but default data is passed in the constructor). Return a value or a deferred object promise.
     * @param oMetadata.determinations.onRead {UI.ApplicationObject.determinationOnRead} Called after reading the before data from the data source, to alter the default data before setting the before image. Sub-nodes may not be available at all time. Return a value or a deferred object promise.
     * @param oMetadata.determinations.onPersist {UI.ApplicationObject.determinationOnPersist} Called after every successful call to the backend (Create, Update, Delete, Custom Actions)
     * @param oMetadata.determinations.onNormalizeData {UI.ApplicationObject.determinationOnNormalizeData} Called for normalizing a structurally different model in binding to the data model used in backend. Called before sending changes to the backend or when pending changes are calculated. Returns the normalized data.
     * @param oMetadata.determinations.onUpdateHandles {UI.ApplicationObject.determinationOnUpdateHandles} When data structure differs (see onNormalizeData) the updating handles in the model has to be done in this determination. Returns the data where the temporary handles have been replaced by generated keys.
     * @returns {Object} Application Object type
     */
    ApplicationObject.extend = function (sApplicationObjectType, oMetadata) {
        return Object;
    };

    /**
     * Return the Application Object metadata
     * @method getApplicationObjectMetadata
     * @memberof UI.ApplicationObject
     * @static
     * @returns {Object}
     */
    ApplicationObject.getApplicationObjectMetadata = function () {
        return Object;
    };

    /**
     * Returns the Application Object name
     * @method getObjectName
     * @memberof UI.ApplicationObject
     * @static
     * @returns {String}
     */
    ApplicationObject.getObjectName = function () {
        return String;
    };

    /**
     * Returns the Application Object endpoint url
     * @method getEndpointURL
     * @memberof UI.ApplicationObject
     * @static
     * @returns {String}
     */
    ApplicationObject.getEndpointURL = function () {
        return String;
    };

    /**
     * Read Application Object data via read source
     * @method readData
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Key of the Application Object instance
     * @param oSettings {Object} Read source additional settings
     */
    ApplicationObject.readData = function (vKey, oSettings) {
        return new Promise();
    };

    /**
     * Checks if session UUID belongs to own session. A session UUID is uniquely drawn and assigned with a date
     * for each Application Object instance or for an static action execution.
     * @method isOwnSession
     * @memberof UI.ApplicationObject
     * @static
     * @param sSessionUUID {String} Session UUID to be checked
     * @returns {Boolean}
     */
    ApplicationObject.isOwnSession = function (sSessionUUID) {
        return Boolean;
    };

    /**
     * Returns the last updated session date for an session UUID
     * @method getSessionDate
     * @memberof UI.ApplicationObject
     * @static
     * @param sSessionUUID Session UUID
     * @returns {Date}
     */
    ApplicationObject.getSessionDate = function (sSessionUUID) {
        return new Date();
    };

    /**
     * Clear global list of all registered sessions in Application Object based on passed date.
     * @method clearSessions
     * @memberof UI.ApplicationObject
     * @static
     * @param [oReferenceDate] {Date} All session are cleared if "null" is passed as date. Otherwise if date is not specified (= undefined) the current date or if specified the passed date is used to clear all session older than the date.
     */
    ApplicationObject.clearSessions = function (oReferenceDate) {
    };

    /**
     * Returns the current valid XSRF token
     * @method getXSRFToken
     * @memberof UI.ApplicationObject
     * @static
     * @returns {String}
     */
    ApplicationObject.getXSRFToken = function () {
        return String;
    };

    /**
     * Disable usage and initialization of XSRF token
     * @memberof UI.ApplicationObject
     * @type {boolean}
     */
    ApplicationObject.disableXSRFToken = false;

    /**
     * Create a new Application Object instance
     * @method create
     * @memberof UI.ApplicationObject
     * @static
     * @param oChangeRequest {Object} Change request (incl. the key) for backend creation
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.create = function (oChangeRequest, oSettings) {
        return new Promise();
    };

    /**
     * Copy an Application Object instance from an existing (persisted) Application Object instance
     * @method copy
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Application Object key to be copied
     * @param oCopyRequest {Object} Copy request (incl. handle key) for backend creation
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.copy = function (vKey, oCopyRequest, oSettings) {
        return new Promise();
    };

    /**
     * Update an Application Object instance
     * @method update
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Application Object key to be updated
     * @param oChangeRequest {Object} Change request containing the changed data
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.update = function (vKey, oChangeRequest, oSettings) {
        return new Promise();
    };

    /**
     * Modify (create or update) an Application Object instance (same as save)
     * @method modify
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Application Object key to be created or updated
     * @param oChangeRequest {Object} Change request containing the to be created or changed data
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.modify = function (vKey, oChangeRequest, oSettings) {
        return new Promise();
    };

    /**
     * Save an Application Object instance (same as modify)
     * @method save
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Key of the application object instance to be saved
     * @param oChangeRequest {Object} Change request containing the to be saved data
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.save = function (vKey, oChangeRequest, oSettings) {
        return new Promise();
    };

    /**
     * Deletes an Application Object instance
     * @method del
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Key of the application object instance to be deleted
     * @param [oChangeRequest] {Object} Delete change request (not for action call but only for listeners)
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.del = function (vKey, oChangeRequest, oSettings) {
        return new Promise();
    };

    /**
     * Executes an action on an Application Object Instance
     * @method _customAction_
     * @memberof UI.ApplicationObject
     * @static
     * @param vKey {*} Key of the application object instance to call action on
     * @param oParameter {Object} Action parameters
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     * @returns _customAction_Model {Function} Returns a Action Parameter model of type sap.ui.model.json.JSONModel
     */
    ApplicationObject._customAction_ = function (vKey, oParameter, oSettings) {
        return function () {
        };
    };

    /**
     * Returns an action parameter Model (is sub-function of _customAction_)
     * @method _customAction_Model
     * @memberof UI.ApplicationObject
     * @static
     * @returns sap.ui.model.json.JSONModel
     */
    ApplicationObject._customAction_Model = function () {
        return null;
    };

    /**
     * Executes an static action on an Application Object
     * @method _staticCustomAction_
     * @memberof UI.ApplicationObject
     * @static
     * @param oParameter {Object} Action parameters
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject._staticCustomAction_ = function (oParameter, oSettings) {
        return new Promise();
    };

    /**
     * Returns a static action parameter Model (is sub-function of _staticCustomAction_)
     * @method _staticCustomAction_Model
     * @memberof UI.ApplicationObject
     * @static
     * @returns sap.ui.model.json.JSONModel
     */
    ApplicationObject._staticCustomAction_Model = function () {
        return null;
    };

    /**
     * Create a new Application Object instance from current instance data
     * @method create
     * @memberof UI.ApplicationObject
     * @instance
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @param oSettings.suppressBackendSync {Boolean} Suppress backend synchronization after creation
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype.create = function (oSettings) {
        return new Promise();
    };

    /**
     * Copy an Application Object instance from an existing (persisted) Application Object instance
     * @method copy
     * @memberof UI.ApplicationObject
     * @instance
     * @param oCopyData {Object} Default data for the copy, containing the handle key
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype.copy = function (oCopyData, oCopySettings) {
        return new Promise();
    };

    /**
     * Update an Application Object instance from current instance data
     * @method update
     * @memberof UI.ApplicationObject
     * @instance
     * @param oSettings {(Object|Boolean)} Backend request settings or ignore occurring concurrency conflict
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @param oSettings.suppressBackendSync {Boolean} Suppress backend synchronization after creation
     * @param oSettings.ignoreConcurrencyConflict {Boolean} Ignore occurring concurrency conflict
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype.update = function (oSettings) {
        return new Promise();
    };

    /**
     * Modify (create or update) an Application Object instance (same as save) from current instance data
     * @method modify
     * @memberof UI.ApplicationObject
     * @instance
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @param oSettings.suppressBackendSync {Boolean} Suppress backend synchronization after creation
     * @param oSettings.ignoreConcurrencyConflict {Boolean} Ignore occurring concurrency conflict
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype.modify = function (oSettings) {
        return new Promise();
    };

    /**
     * Save an Application Object instance (same as modify) from current instance data
     * @method save
     * @memberof UI.ApplicationObject
     * @instance
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @param oSettings.suppressBackendSync {Boolean} Suppress backend synchronization after creation
     * @param oSettings.ignoreConcurrencyConflict {Boolean} Ignore occurring concurrency conflict
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype.save = function (oSettings) {
        return new Promise();
    };

    /**
     * Deletes an Application Object instance from current instance
     * @method del
     * @memberof UI.ApplicationObject
     * @instance
     * @param bIgnoreConcurrencyConflict {Boolean} Ignore occurring concurrency conflict
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype.del = function (bIgnoreConcurrencyConflict, oSettings) {
        return new Promise();
    };

    /**
     * Executes an action on an Application Object Instance
     * @method _customAction_
     * @memberof UI.ApplicationObject
     * @instance
     * @param oParameter {Object} Action parameters
     * @param oSettings {(Object|Boolean)} Backend request settings or ignore occurring concurrency conflict
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @param oSettings.suppressBackendSync {Boolean} Suppress backend synchronization after creation
     * @param oSettings.ignoreConcurrencyConflict {Boolean} Ignore occurring concurrency conflict
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype._customAction_ = function (oParameter, oSettings) {
        return function () {
        };
    };

    /**
     * Returns an action parameter Model (is sub-function of _customAction_)
     * @method _customAction_Model
     * @memberof UI.ApplicationObject
     * @instance
     * @returns sap.ui.model.json.JSONModel
     */
    ApplicationObject.prototype._customAction_Model = function () {
        return null;
    };

    /**
     * Executes an static action on an Application Object
     * @method _staticCustomAction_
     * @memberof UI.ApplicationObject
     * @instance
     * @param oParameter {Object} Action parameters
     * @param oSettings {Object} Backend request settings
     * @param oSettings.processSync {Boolean} Execute the call synchronous
     * @param oSettings.headers {Object} Additional request headers
     * @returns oResponse {Promise} Promise resolving to response
     * @returns oResponse.GENERATED_KEYS {Object} Map of handle key to generated key
     * @returns oResponse.MESSAGES {Array.<UI.Message>} Array of messages
     */
    ApplicationObject.prototype._staticCustomAction_ = function (oParameter, oSettings) {
        return function () {
        };
    };

    /**
     * Returns a static action parameter Model (is sub-function of _staticCustomAction_)
     * @method _staticCustomAction_Model
     * @memberof UI.ApplicationObject
     * @instance
     * @returns sap.ui.model.json.JSONModel
     */
    ApplicationObject.prototype._staticCustomAction_Model = function () {
        return null;
    };

    /**
     * Return Application Object type for current Application Object instance
     * @method getApplicationObject
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Object} Application Object type
     */
    ApplicationObject.prototype.getApplicationObject = function () {
        return Object;
    };

    /**
     * Returns the Application Object endpoint url
     * @method getEndpointURL
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {String}
     */
    ApplicationObject.prototype.getEndpointURL = function () {
        return String;
    };

    /**
     * Checks if session UUID belongs to own session. A session UUID is uniquely drawn and assigned with a date for each Application Object instance or for an static action execution.
     * @method isOwnSession
     * @memberof UI.ApplicationObject
     * @instance
     * @param sSessionUUID {String} Session UUID to be checked
     * @returns {Boolean}
     */
    ApplicationObject.prototype.isOwnSession = function (sSessionUUID) {
        return Boolean;
    };

    /**
     * Returns the last updated session date for an session UUID
     * @method getSessionDate
     * @memberof UI.ApplicationObject
     * @instance
     * @param sSessionUUID {String} Session UUID
     * @returns {String}
     */
    ApplicationObject.prototype.getSessionDate = function (sSessionUUID) {
        return String;
    };

    /**
     * Clear global list of all registered sessions in Application Object based on passed date.
     * @method clearSessions
     * @memberof UI.ApplicationObject
     * @instance
     * @param [oReferenceDate] {Date} All session are cleared if "null" is passed as date. Otherwise if date is not specified (= undefined) the current date or if specified the passed date is used to clear all session older than the date.
     */
    ApplicationObject.prototype.clearSessions = function (oReferenceDate) {
    };

    /**
     * Read Application Object data via read source
     * @method readData
     * @memberof UI.ApplicationObject
     * @instance
     * @param oSettings {Object} Read source additional settings
     * @returns {Promise}
     */
    ApplicationObject.prototype.readData = function (oSettings) {
        return new Promise();
    };

    /**
     * Date the last time data was read for the Application Object instance
     * @method getLastReadDate
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Date}
     */
    ApplicationObject.prototype.getLastReadDate = function () {
        return new Date();
    };

    /**
     * Return current valid session UUID
     * @method getSessionUUID
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {String} Curretn session UUID
     */
    ApplicationObject.prototype.getSessionUUID = function () {
        return String;
    };

    /**
     * Return current Application Object instance key
     * @method getKey
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {*} Current Application Object instance key
     */
    ApplicationObject.prototype.getKey = function () {
        return null;
    };

    /**
     * Return Application Object instance initial key (i.e. a key handle which is replaced after create action)
     * @method getInitKey
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {*} Initial key
     */
    ApplicationObject.prototype.getInitKey = function () {
        return null;
    };

    /**
     * Return the Application Object metadata
     * @method getApplicationObjectMetadata
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Object}
     */
    ApplicationObject.prototype.getApplicationObjectMetadata = function () {
        return Object;
    };

    /**
     * Returns the Application Object name
     * @method getObjectName
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {String}
     */
    ApplicationObject.prototype.getObjectName = function () {
        return String;
    };

    /**
     * Returns a Promise which is resolved, when the Application Object instance is initialized. I.e. the data has be read from the backend and all determination did ran.
     * @method getDataInitializedPromise
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Promise} Promise resolving to the data when Application Object instance initialization is done
     */
    ApplicationObject.prototype.getDataInitializedPromise = function () {
        return new Promise();
    };

    /**
     * Returns a Promise which is resolved, when the Application Object instance Property Model is initialized.
     * @method getPropertyModelInitializedPromise
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Promise} Promise resolving to the data when Property Model instance initialization is done
     */
    ApplicationObject.prototype.getPropertyModelInitializedPromise = function () {
        return new Promise();
    };

    /**
     * Calculates if the Application Object instance has pending changed to be
     * @method hasPendingChanges
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Boolean} True if has pending changes
     */
    ApplicationObject.prototype.hasPendingChanges = function () {
        return Boolean;
    };

    /**
     * Returns the change request data of the Application Object instance. Changes are calculated on delta basis for attributes and
     * on complete basis for nodes. Omitted nodes are assumed to be deleted in backend.
     * @method getChangeRequest
     * @memberof UI.ApplicationObject
     * @instance
     * @param bComplete
     * @returns {Object} Change request object
     */
    ApplicationObject.prototype.getChangeRequest = function (bComplete) {
        return Object;
    };

    /**
     * Returns the user changes to the Application Object instance (in contrast to the before data)
     * @method getUserChanges
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Object} User changes object
     */
    ApplicationObject.prototype.getUserChanges = function () {
        return Object;
    };

    /**
     * Returns of the Application Object instance is new (not created in backend)
     * @method isNew
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Boolean}
     */
    ApplicationObject.prototype.isNew = function () {
        return Boolean;
    };

    /**
     * Sets a data property in the Application Object instance
     * @method setProperty
     * @memberof UI.ApplicationObject
     * @instance
     * @param sPath {String} UI5 property binding path
     * @para vValue {*} Value to be set at the path
     * @param oContext {Object} UI5 binding context object
     * @returns {Boolean}
     */
    ApplicationObject.prototype.setProperty = function (sPath, vValue, oContext) {
        return Boolean;
    };

    /**
     * Returns a data property of the Application Object instance data. Delegates to Property Model or Meta Model depending on the path
     * @method getProperty
     * @memberof UI.ApplicationObject
     * @instance
     * @param sPath {String} UI5 property binding path
     * @param oContext {Object} UI5 binding context object
     * @returns {*}
     */
    ApplicationObject.prototype.getProperty = function (sPath, oContext) {
        return null;
    };

    /**
     * Set the data of the Application Object instance
     * @method setData
     * @memberof UI.ApplicationObject
     * @instance
     * @param oData
     * @param bMerge
     */
    ApplicationObject.prototype.setData = function (oData, bMerge) {
    };

    /**
     * Returns the current data of the Application Object instance
     * @method getData
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Object}
     */
    ApplicationObject.prototype.getData = function () {
        return Object;
    };

    /**
     * Revert all local changes and return to before data of the Application Object instance
     * @method revertChanges
     * @memberof UI.ApplicationObject
     * @instance
     */
    ApplicationObject.prototype.revertChanges = function () {
    };

    /**
     * Synchronize Application Object instance data by re-reading data again from backend
     * @method sync
     * @memberof UI.ApplicationObject
     * @instance
     */
    ApplicationObject.prototype.sync = function () {
    };

    /**
     * Resolves s concurrency conflict automatically by merge concurrent changes with local changes
     * @method mergeConcurrentChanges
     * @memberof UI.ApplicationObject
     * @instance
     */
    ApplicationObject.prototype.mergeConcurrentChanges = function () {
    };

    /**
     * Resolves a concurrency conflict manually in the Application Object instance
     * @method resolveConflictManually
     * @memberof UI.ApplicationObject
     * @instance
     */
    ApplicationObject.prototype.resolveConflictManually = function () {
    };

    /**
     * Updates a node object based on node name and primary key
     * @method updateNode
     * @memberof UI.ApplicationObject
     * @instance
     * @param oNode {Object} Node object containing the changes and the primary key
     * @param sNodeName {String} Name of the node to be updated
     */
    ApplicationObject.prototype.updateNode = function (oNode, sNodeName) {
    };

    /**
     * Adds a new child node object to a specified node path and index
     * @method addChild
     * @memberof UI.ApplicationObject
     * @instance
     * @param oChild {Object} Node object to be added
     * @param sNodePath {String} Parent node name or deep node path (in UI5 binding syntax)
     * @param [iIndex] {Integer} Append is performed in case index is omitted, other wise a insert at is executed
     * @returns {*} Returns newly generated key handle
     */
    ApplicationObject.prototype.addChild = function (oChild, sNodePath, iIndex) {
        return null;
    };

    /**
     * Removes a child node in the Application Object instance hierarchy. Deletion is based on object reference equality.
     * @method removeChild
     * @memberof UI.ApplicationObject
     * @instance
     * @param oChild {Object} Child node object to be removed
     */
    ApplicationObject.prototype.removeChild = function (oChild) {
    };

    /**
     * Returns the UI5 OData model used by the defined read source
     * @method getReadSourceModel
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {sap.ui.model.odata.v2.ODataModel}
     */
    ApplicationObject.prototype.getReadSourceModel = function () {
        return Object;
    };

    /**
     * Returns the next valid key handle (negative number) in case key is of type Number
     * @method getNextHandle
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Number} Next valid key handle
     */
    ApplicationObject.prototype.getNextHandle = function () {
        return null;
    };

    /**
     * Returns Application Object data at time after instantiation before executing changes
     * @method getBeforeData
     * @memberof UI.ApplicationObject
     * @instance
     * @returns {Object} Before data
     */
    ApplicationObject.prototype.getBeforeData = function () {
        return Object;
    };

    /**
     * Release Application Object instance from Model Synchronizer (is added automatically during instantiation)
     * @method releaseFromSync
     * @memberof UI.ApplicationObject
     * @instance
     */
    ApplicationObject.prototype.releaseFromSync = function () {

    };

    /**
     * Application Object Change: object created
     *
     * @memberof UI.ApplicationObjectChange
     * @event objectChanged
     */

    /**
     * Application Object Change: object copied
     *
     * @memberof UI.ApplicationObjectChange
     * @event objectCreated
     */

    /**
     * Application Object Change: object copied
     *
     * @memberof UI.ApplicationObjectChange
     * @event objectCopied
     */

    /**
     * Application Object Change: object updated
     *
     * @memberof UI.ApplicationObjectChange
     * @event objectUpdated
     */

    /**
     * Application Object Change: object deleted
     *
     * @memberof UI.ApplicationObjectChange
     * @event objectDeleted
     */

    /**
     * Application Object Change: object custom action executed
     *
     * @memberof UI.ApplicationObjectChange
     * @event objectCustomActionExecuted
     */

    /**
     * @constructor
     * @memberof UI
     * @augments sap.ui.base.ManagedObject
     * @class ApplicationObjectChange
     */
    function ApplicationObjectChange() {
    }

    /**
     * Schema validation scope
     * @enum {String}
     */
    ApplicationObjectChange.EventActionName = {
        /**
         * All actions
         */
        All: "",
        /**
         * Create action
         */
        Create: "create",
        /**
         * Copy action
         */
        Copy: "copy",
        /**
         * Update action
         */
        Update: "update",
        /**
         * Delete action
         */
        Del: "del",
        /**
         * Custom action
         */
        Action: "action"
    };

    /**
     * Notify listeners about a Application Object change
     * @method fireChange
     * @memberof UI.ApplicationObjectChange
     * @static
     * @param oChange {Object} Change object information
     * @param oChange.object {Object} Application Object type
     * @param oChange.key {*} vKey Key of the Application Object instance
     * @param oChange.actionName {String} Application Object action executed
     * @param [oChange.changeRequest] {Object} Change request object data for instance action execution
     * @param [oChange.instance] {UI.ApplicationObject} Application Object instance for instance action execution
     * @param [oChange.dataUpdate] {Object} Data read after action execution to update the model
     */
    ApplicationObjectChange.fireChange = function (oChange) {
    };

    /**
     * Attach callback function to an Application Object change event
     * @method attachChange
     * @memberof UI.ApplicationObjectChange
     * @static
     * @param sActionName {UI.ApplicationObjectChange.EventActionName}
     * @param fnFunction {Function} UI5 event function with oEvent as parameter
     */
    ApplicationObjectChange.attachChange = function (sActionName, fnFunction) {
    };

    /**
     * Deatach callback function from an Application Object change event
     * @method detachChange
     * @memberof UI.ApplicationObjectChange
     * @static
     * @param sActionName {UI.ApplicationObjectChange.EventActionName}
     * @param fnFunction {Function} UI5 event function with oEvent as parameter
     */
    ApplicationObjectChange.detachChange = function (sActionName, fnFunction) {
    };

    /**
     * @constructor
     * @memberof UI
     * @augments sap.ui.base.Object
     * @class ReadSource
     */
    function ReadSource() {
    }

    /**
     * Read source callback function
     * @memberof UI
     * @callback UI.ReadSource.readSourceCallback
     * @param vKey {*} Key of the object instance to be checked for properties
     * @param sObjectName {String} Name of the application object
     * @param oMetadata {Object} Metadat object of the application object
     * @param oAdditionalSettings {Object} Additional settings to bve merged with the read source initialization settings
     * @return {Promise.<Object, String>} Object data read from read source and optionally the current concurrency token
     */
    ReadSource.prototype.readSourceCallback = function (vKey, sObjectName, oMetadata, oAdditionalSettings) {
        return new Promise();
    };

    /**
     * Returns the default OData read source
     * @method getDefaultODataSource
     * @memberof UI.ReadSource
     * @static
     * @param sEntitySetName {String} OData entity set name to be read from the OData model
     * @param oSettings {Object} settings to configure the read process
     * @param oSettings.deepChildPaths {Object} Defined deep child paths, e.g. { SubNode1 : "SubNode1/Node1" } oSettings.excludeNodes = ["Node1"];
     * @param oSettings.includeNodes {Array} Include additional nodes, e.g. [{ name : "Node1", parentNode : "Root" }];
     * @param oSettings.projection {Array} Select on specific attributes, e.g. ["Attr1", "Attr2"];
     * @param oSettings.async {Boolean} Call request asynchronously
     * @param oSettings.onlyRoot {Boolean} Only request root information
     * @param oSettings.model {sap.ui.model.odata.v2.ODataModel} ODataModel to be used for read source
     * @param oODataModel {sap.ui.model.odata.v2.ODataModel} ODataModel to be used for read source
     * @returns {UI.ReadSource.readSourceCallback} Read source function taking the following parameters (vKey, sObjectName, oMetadata, oAdditionalSettings)
     */
    ReadSource.getDefaultODataSource = function (sEntitySetName, oSettings, oODataModel) {
        return function (vKey, sObjectName, oMetadata, oAdditionalSettings) {
        };
    };

    /**
     * Returns the default AOF read source
     * @method getDefaultAOFSource
     * @memberof UI.ReadSource
     * @static
     * @param oSettings {Object} settings to configure the read process
     * @param oSettings.cache {Boolean} Flag to control the cache behaviour of the ajax call
     * @param oSettings.async {Boolean} Flag to control the async processing of the ajax call
     * @param oSettings.headers {Object} Header object pass to the ajax call
     * @returns {UI.ReadSource.readSourceCallback} Read source function taking the following parameters (vKey, sObjectName, oMetadata, oAdditionalSettings)
     */
    ReadSource.getDefaultAOFSource = function (oSettings) {
        return function (vKey, sObjectName, oMetadata, oAdditionalSettings) {
        };
    };

    /**
     * @constructor
     * @memberof UI
     * @augments sap.ui.base.ManagedObject
     * @class ModelSynchronizer
     */
    function ModelSynchronizer() {
    }

    /**
     * Add Application Object instance to the Model Synchronizer (is done automatically during Application Object instantiation)
     * @method addApplicationObject
     * @memberof UI.ModelSynchronizer
     * @static
     * @param sApplicationObjectKey {*} Key of the Application Object instance
     * @param oInstance {UI.ApplicationObject} Application Object instance
     */
    ModelSynchronizer.addApplicationObject = function (sApplicationObjectKey, oInstance) {
    };

    /**
     * Remove Application Object instance from the Model Synchronizer. Can also be performed by call function releaseFromSync on Application Object instance.
     * @method removeApplicationObject
     * @memberof UI.ModelSynchronizer
     * @static
     * @param sApplicationObjectKey {*} Key of the Application Object instance
     * @param oInstance {UI.ApplicationObject} Application Object instance
     */
    ModelSynchronizer.removeApplicationObject = function (sApplicationObjectKey, oInstance) {
    };

    /**
     * Adds an dependent object model to the Model Synchronization
     * @method addAODependency
     * @memberof UI.ModelSynchronizer
     * @static
     * @param oApplicationObject {Object} Application Object type
     * @param oDependentModel {sap.ui.model.json.JSONModel} Arbitrary model to by synchronized with Application Object changes
     * @param fnSyncFunction {Function} Callback function to be called when synchronization happens
     */
    ModelSynchronizer.addAODependency = function (oApplicationObject, oDependentModel, fnSyncFunction) {

    };

    /**
     * Removes an dependent object model from the Model Synchronization
     * @method removeAODependency
     * @memberof UI.ModelSynchronizer
     * @static
     * @param oApplicationObject {Object} Application Object type
     * @param oDependentModel {sap.ui.model.json.JSONModel} Arbitrary model to by synchronized with Application Object changes
     * @param fnSyncFunction {Function} Callback function to be called when synchronization happens
     */
    ModelSynchronizer.removeAODependency = function (oApplicationObject, oDependentModel, fnSyncFunction) {

    };

    /**
     * Adds an OData model to the Model Synchronization
     * @method addODataModel
     * @memberof UI.ModelSynchronizer
     * @static
     * @param oODataModel {sap.ui.model.odata.v2.ODataModel} OData model added to Model Synchronization
     */
    ModelSynchronizer.addODataModel = function (oODataModel) {

    };

    /**
     * Removes an OData model from the Model Synchronization
     * @method removeODataModel
     * @memberof UI.ModelSynchronizer
     * @static
     * @param oODataModel {sap.ui.model.odata.v2.ODataModel} OData model removed from Model Synchronization
     */
    ModelSynchronizer.removeODataModel = function (oODataModel) {
    };

    /**
     * Returns all registered OData models
     * @method getODataModels
     * @memberof UI.ModelSynchronizer
     * @static
     * @returns {Array.<sap.ui.model.odata.v2.ODataModel>} Array of registered OData models
     */
    ModelSynchronizer.getODataModels = function () {
        return [];
    };

    /**
     * Updates the registered model on the Model Synchronizer with the change
     * @method update
     * @memberof UI.ModelSynchronizer
     * @static
     * @param oInstance {UI.ApplicationObject} Application Object instance changed
     * @param sActionName {String} Application Object action executed
     * @param [oApplicationObject] {Object} Application Object Type. Optional if derived from oInstance.
     * @param [vKey] {*} Key of the Application Object instance. Optional if derived from oInstance.
     * @param [oData] {Object} Data of the Application Object instance. Optional if derived from oInstance.
     */
    ModelSynchronizer.update = function (oInstance, sActionName, oApplicationObject, vKey, oData) {
    };

    /**
     * Creates a new ClipboardModel.
     * A ClipboardModel can store application object instances in an local browser storage.
     * As it inherits from UI5 JSONModel it can be used to bind properties against it.
     * The ClipboardModel contains an artificial property "changed", that can be bound to detect changes.
     *
     * @constructor
     * @memberof UI
     * @augments sap.ui.model.json.JSONModel
     * @class ClipboardModel
     */
    function ClipboardModel() {
    }

    /**
     * Object added event.
     *
     * @memberof UI.ClipboardModel
     * @event objectAdded
     */

    /**
     * Object removed event.
     *
     * @memberof UI.ClipboardModel
     * @event objectRemoved
     */

    /**
     * Object revalidated event.
     *
     * @memberof UI.ClipboardModel
     * @event objectRevalidated
     */

    /**
     * Returns a default shared singleton instance of the ClipboardModel
     * @method sharedInstance
     * @memberof UI.ClipboardModel
     * @static
     * @returns {Object}
     */
    ClipboardModel.sharedInstance = function () {
        return Object;
    };

    /**
     * Returns a formatter to be used in a binding against an application object instance, to determine if an instance is in the clipboard model or not.
     * @method getInSharedClipboardFormatter
     * @memberof UI.ClipboardModel
     * @static
     * @returns {Function}
     */
    ClipboardModel.getInSharedClipboardFormatter = function () {
        return function () {
        };
    };

    /**
     * Returns a formatter to be used in a binding to determine if the clipboard is empty or not.
     * The ClipboardModel holds a artificial property "isEmpty", that can be bound
     * <br>
     * Example:
     * <pre><code>
     *   ...
     *   enabled : {
     *     path : "clipboard>/isEmpty",
     *     formatter : ClipboardModel.getSharedClipboardNotEmptyFormatter()
     *   }
     *   ...
     * </code></pre>
     *
     * @method getSharedClipboardNotEmptyFormatter
     * @memberof UI.ClipboardModel
     * @static
     * @param oApplicationObject {Object} ApplicationObject type
     * @returns {Function}
     */
    ClipboardModel.getSharedClipboardNotEmptyFormatter = function (oApplicationObject) {
        return function () {
        };
    };

    /**
     * Adds the OData model to be used for reading the Application Object instance identification name
     * @param oDataModel {sap.ui.model.odata.v2.ODataModel} OData Model
     */
    ClipboardModel.prototype.setODataModel = function(oDataModel) {
    };

    /**
     * Adds an application object instance to the ClipboardModel, when not already existing
     * @method add
     * @memberof UI.ClipboardModel
     * @instance
     * @fires UI.ClipboardModel.objectAdded
     * @param oApplicationObject {Object} ApplicationObject type
     * @param vKey {*} ApplicationObject key
     * @param [sName] {String} Name of the application object instance to be used until name was read during revalidation
     * @returns {Promise}
     */
    ClipboardModel.prototype.add = function (oApplicationObject, vKey, sName) {
        return new Promise();
    };

    /**
     * Removes application object instances from the ClipboardModel, when existing. Omitting the key, will remove all instances
     * of a application object type. Ommiting all parameters will clear the ClipboardModel.
     * @method remove
     * @memberof UI.ClipboardModel
     * @instance
     * @fires UI.ClipboardModel.objectRemoved
     * @param [oApplicationObject] {Object} ApplicationObject type
     * @param [vKey] {*} ApplicationObject key
     */
    ClipboardModel.prototype.remove = function (oApplicationObject, vKey) {
    };

    /**
     * Toggles the containment of an ApplicationObject instance in the ClipboardModel
     * @method toggle
     * @memberof UI.ClipboardModel
     * @instance
     * @param oApplicationObject {Object} ApplicationObject type
     * @param vKey {*} ApplicationObject key
     */
    ClipboardModel.prototype.toggle = function (oApplicationObject, vKey) {
    };

    /**
     * @method revalidate
     * @memberof UI.ClipboardModel
     * @instance
     * @fires UI.ClipboardModel.objectRevalidated
     * @param oApplicationObject {Object} ApplicationObject type
     * @param vKey {*} ApplicationObject key
     */
    ClipboardModel.prototype.revalidate = function (oApplicationObject, vKey) {
    };

    /**
     * Checks if a application object instance is in the ClipboardModel
     * @method isInClipboard
     * @memberof UI.ClipboardModel
     * @instance
     * @param oApplicationObject {Object} ApplicationObject type
     * @param vKey {*} ApplicationObject key
     * @returns {boolean}
     */
    ClipboardModel.prototype.isInClipboard = function (oApplicationObject, vKey) {
        return true;
    };

    /**
     * Returns if the ClipboardModel is empty
     * @method isClipboardEmpty
     * @memberof UI.ClipboardModel
     * @instance
     * @param [oApplicationObject] {Object} ApplicationObject type
     * @returns {boolean}
     */
    ClipboardModel.prototype.isClipboardEmpty = function (oApplicationObject) {
        return true;
    };

    /**
     * Returns the object data for a application object instance
     * @method getObjectForKey
     * @memberof UI.ClipboardModel
     * @instance
     * @param oApplicationObject {Object} ApplicationObject type
     * @param vKey {*} ApplicationObject key
     * @returns {Object} Data of the application object instance
     */
    ClipboardModel.prototype.getObjectForKey = function (oApplicationObject, vKey) {
        return Object;
    };

    /**
     * Returns the application object keys for an application object and an optional filter condition
     * @method getObjectKeys
     * @memberof UI.ClipboardModel
     * @instance
     * @param oApplicationObject {Object} ApplicationObject type
     * @param [vFilterKey] {*} ApplicationObject key
     * @returns {Array} Array of application object keys matching the filter key
     */
    ClipboardModel.prototype.getObjectKeys = function (oApplicationObject, vFilterKey) {
        return [];
    };

    /**
     * Backend Message
     * @memberof UI
     * @class Message
     */
    function Message() {
    }

    /**
     * Severity of the message
     * @name TYPE
     * @memberof UI.Message
     * @instance
     * @type {UI.MessageType}
     */
    Message.prototype.TYPE = String;

    /**
     * Technical message key of message
     * @name MESSAGE
     * @memberof UI.Message
     * @instance
     * @type {String}
     */
    Message.prototype.MESSAGE = String;

    /* Future: Resolved message text
     * @name MESSAGE_TEXT
     * @memberof UI.Message
     * @instance
     * @type {String}
     */
    Message.prototype.MESSAGE_TEXT = String;

    /**
     * Reference node key of the message
     * @name REF_KEY
     * @memberof UI.Message
     * @instance
     * @type {String}
     */
    Message.prototype.REF_KEY = String;

    /**
     * Reference node of the message
     * @name REF_NODE
     * @memberof UI.Message
     * @instance
     * @type {String}
     */
    Message.prototype.REF_NODE = String;

    /**
     * Reference field of the message
     * @name REF_FIELD
     * @memberof UI.Message
     * @instance
     * @type {String}
     */
    Message.prototype.REF_FIELD = String;

    /**
     * Up to four parameters of the message
     * @name PARAMETERS
     * @memberof UI.Message
     * @instance
     * @type {Array}
     */
    Message.prototype.PARAMETERS = [];
}