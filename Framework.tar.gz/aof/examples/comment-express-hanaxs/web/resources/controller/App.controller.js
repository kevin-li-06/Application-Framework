sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/aof/test/model/Comment"
], function (Controller, Comment) {
    "use strict";

    return Controller.extend("sap.ui.aof.test.controller.App", {

        onAddComment: function () {
            var oComment = new Comment({
                OBJECT_ID: 0
            }, {
                actions: ["create"],
                nodes: ["Root"]
            });
            oComment.setProperty("/COMMENT", "Test: " + new Date().toLocaleString());
            oComment.setProperty("/OBJECT_ID", 1);

            var oCommentDialog = this.getOwnerComponent().commentDialog;
            oCommentDialog.setModel(oComment, "instance");
            oCommentDialog.open(this.getView(), function () {
                oComment.save();
            });
        }
    });
});