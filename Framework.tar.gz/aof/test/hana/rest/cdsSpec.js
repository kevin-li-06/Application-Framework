"use strict";

require("jasmine-before-all");

var fs = require("fs");
var supertestAsPromised = require("supertest");
var Promise = require("bluebird");
var uuid = require("uuid");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");
var Server = require("../js/testServer_cds.js");

var oContext;
var oRequest;

const CR = '\r';
const LF = '\n';
const CRLF = CR + LF;

describe("SAP/AOF/ODATA", function () {

    beforeAll((done) => {
        oContext = {
            handlerConfiguration: {
                dbConfiguration: {
                    storeInfo: {
                        hana: require("../../hana/js/default-services.json").hana
                    }
                }
            }
        };
        oRequest = supertestAsPromised(Server);
        setTimeout(() => {
            done();
        }, 1000)
    });

    afterAll((done) => {
        done();
    });

    function callRead(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        return oRequest.get(sPath);
    }

    function callWrite(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        oRequest = bUpdate ? oRequest.patch(sPath) : oRequest.post(sPath);
        oRequest = oRequest.set("Content-Type", "application/json").send(oPayload);
        _.each(oHeaders || {}, (sValue, sKey) => {
            oRequest.set(sKey, sValue);
        });
        return oRequest;
    }

    function callMultipart(oRequest, sPath, sPayload) {
        return oRequest.post(sPath)
            .accept('multipart/mixed')
            .type('multipart/mixed;boundary=boundary')
            .parse(multipartMixedToTextParser)
            .send(sPayload)
    }

    function multipartMixedToTextParser(res, callback) {
        let text = '';
        res.setEncoding('utf8');

        res.on('data', (chunk) => {
            text += chunk;
        });

        res.on('end', () => {
            // eslint-disable-next-line no-param-reassign
            res.text = text;
            callback(null, text);
        });
    }

    it("reads entity root node", (done) => {
        return callRead(oRequest, "/service/Orders").then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.value.length > 0).toEqual(true);
        }).then(() => {
            done();
        });
    });

    it("reads entity item node", (done) => {
        return callRead(oRequest, "/service/Orders_Items").then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.value.length > 0).toEqual(true);
        }).then(() => {
            done();
        });
    });

    it("reads entity line node", (done) => {
        return callRead(oRequest, "/service/Orders_Lines").then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.value.length > 0).toEqual(true);
        }).then(() => {
            done();
        });
    });

    it("creates entity root node", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            return callRead(oRequest, `/service/Orders(${oResponse.body.ID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body.buyer).toBeDefined("Tom Buyer A");
                expect(oResponse.body.ID).toBeDefined();
            });
        }).then(() => {
            done();
        });
    });

    it("creates entity item node", (done) => {
        callWrite(oRequest, "/service/Orders_Items", {
            "amount": 1,
            "order_ID": "2872e977-c1e8-4149-bdff-bcb3efecdbdd",
            "book": "Bible"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            return callRead(oRequest, `/service/Orders_Items(${oResponse.body.ID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body.book).toBeDefined("Bible B");
                expect(oResponse.body.ID).toBeDefined();
            });
        }).then(() => {
            done();
        });
    });

    it("creates entity line node", (done) => {
        callWrite(oRequest, "/service/Orders_Lines", {
            "text": "Hello World",
            "item_ID": "7329a50e-56d1-4803-8ab5-31b4d109e2d2"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            return callRead(oRequest, `/service/Orders_Lines(${oResponse.body.ID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body.text).toBeDefined("Hello World C");
                expect(oResponse.body.ID).toBeDefined();
            });
        }).then(() => {
            done();
        });
    });

    it("updates entity root node", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            return callWrite(oRequest, `/service/Orders(${oResponse.body.ID})`, {
                "buyer": "Tom Buyer 2"
            }, true).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                return callRead(oRequest, `/service/Orders(${oResponse.body.ID})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.buyer).toBeDefined("Tom Buyer 2 A");
                });
            });
        }).then(() => {
            done();
        });
    });

    it("updates entity item node", (done) => {
        callWrite(oRequest, "/service/Orders_Items", {
            "amount": 1,
            "order_ID": "2872e977-c1e8-4149-bdff-bcb3efecdbdd",
            "book": "Bible"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            return callWrite(oRequest, `/service/Orders_Items(${oResponse.body.ID})`, {
                "amount": 2,
                "book": "Bible 2"
            }, true).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                return callRead(oRequest, `/service/Orders_Items(${oResponse.body.ID})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.amount).toEqual(2);
                    expect(oResponse.body.book).toEqual("Bible 2 B");
                });
            });
        }).then(() => {
            done();
        });
    });

    it("updates entity line node", (done) => {
        callWrite(oRequest, "/service/Orders_Lines", {
            "text": "Hello World",
            "item_ID": "7329a50e-56d1-4803-8ab5-31b4d109e2d2"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            return callWrite(oRequest, `/service/Orders_Lines(${oResponse.body.ID})`, {
                "text": "Hello World 2"
            }, true).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                return callRead(oRequest, `/service/Orders_Lines(${oResponse.body.ID})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.text).toBeDefined("Hello World 2 C");
                });
            });
        }).then(() => {
            done();
        });
    });

    it("deletes entity root node", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sID = oResponse.body.ID;
            return oRequest.del(`/service/Orders(${sID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                return callRead(oRequest, `/service/Orders(${sID})`).then((oResponse) => {
                    expect(oResponse.body.error.message).toEqual(`Orders(${sID}) not found`);
                });
            });
        }).then(() => {
            done();
        });
    });

    it("deletes entity item node", (done) => {
        callWrite(oRequest, "/service/Orders_Items", {
            "amount": 1,
            "order_ID": "2872e977-c1e8-4149-bdff-bcb3efecdbdd",
            "book": "Bible"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sID = oResponse.body.ID;
            return oRequest.del(`/service/Orders_Items(${sID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                return callRead(oRequest, `/service/Orders_Items(${sID})`).then((oResponse) => {
                    expect(oResponse.body.error.message).toEqual(`Orders_Items(${sID}) not found`);
                });
            });
        }).then(() => {
            done();
        });
    });

    it("deletes entity line node", (done) => {
        callWrite(oRequest, "/service/Orders_Lines", {
            "text": "Hello World",
            "item_ID": "7329a50e-56d1-4803-8ab5-31b4d109e2d2"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sID = oResponse.body.ID;
            return oRequest.del(`/service/Orders_Lines(${sID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                return callRead(oRequest, `/service/Orders_Lines(${sID})`).then((oResponse) => {
                    expect(oResponse.body.error.message).toEqual(`Orders_Lines(${sID}) not found`);
                });
            });
        }).then(() => {
            done();
        });
    });

    it("tests execution of determination", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sOrderID = oResponse.body.ID;
            return callRead(oRequest, `/service/Orders(${sOrderID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body.createdById).toBeDefined();
                expect(oResponse.body.createdAt).toBeDefined();
                expect(oResponse.body.changedById).toBeDefined();
                expect(oResponse.body.changedAt).toBeDefined();
                const sChangedAt = oResponse.body.changedAt;
                return callWrite(oRequest, "/service/Orders_Items", {
                    "amount": 1,
                    "order_ID": sOrderID,
                    "book": "Bible"
                }).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.ID).toBeDefined();
                    return callRead(oRequest, `/service/Orders_Items(${oResponse.body.ID})`).then((oResponse) => {
                        expect(oResponse.body).toBeDefined();
                        expect(oResponse.body.ID).toBeDefined();
                    });
                }).then(() => {
                    return callRead(oRequest, `/service/Orders(${sOrderID})`).then((oResponse) => {
                        expect(oResponse.body).toBeDefined();
                        expect(oResponse.body.changedAt).toBeDefined();
                        expect(oResponse.body.changedAt).not.toEqual(sChangedAt);
                    });
                });
            });
        }).then(() => {
            done();
        });
    });

    it("tests static action execution", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sOrderID = oResponse.body.ID;
            return callWrite(oRequest, "/service/staticCancelOrder", {
                "orderID": sOrderID
            }).then((oResponse) => {
                expect(oResponse.body.value).toEqual(true);
            });
        }).then(() => {
            done();
        });
    });

    it("tests static action with object type return value", (done) => {
        return callWrite(oRequest, "/service/createOrder", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            const sID = oResponse.body.ID;
            const sDate = oResponse.body.createdAt;
            expect(oResponse.body).toEqual({
                "@odata.context": '$metadata#Orders/$entity',
                ID: sID,
                buyer: 'Tom Buyer A',
                date: '2018-02-12',
                status: 'Open',
                createdById: 'ANONYMOUS',
                createdAt: sDate,
                changedById: 'ANONYMOUS',
                changedAt: sDate
            });
        }).then(() => {
            done();
        });
    });

    it("tests instance action execution", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sOrderID = oResponse.body.ID;
            return callWrite(oRequest, `/service/Orders(${sOrderID})/Service.cancelOrder`, {}).then((oResponse) => {
                expect(oResponse.body.value).toEqual(true);
            });
        }).then(() => {
            done();
        });
    });

    it("tests batch create entity object", (done) => {
        let sPayload = fs.readFileSync("./test/hana/rest/batch/bookshopBatchCreate.txt", "utf8");
        callMultipart(oRequest, "/service/$batch", sPayload.split(LF).join(CRLF)).then((oResponse) => {
            expect(oResponse.statusCode).toEqual(200);
            expect(oResponse.body).toBeDefined();
            expect((oResponse.body.match(/HTTP\/1.1 201 Created/g) || []).length).toEqual(3);
        }).then(() => {
            done();
        });
    });

    it("tests batch update entity object", (done) => {
        let sOrderId;
        let sOrderItemId;
        let sOrderLineId;
        return callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            sOrderId = oResponse.body.ID;
            return callWrite(oRequest, "/service/Orders_Items", {
                "amount": 1,
                "order_ID": "2872e977-c1e8-4149-bdff-bcb3efecdbdd",
                "book": "Bible"
            })
        }).then((oResponse) => {
            sOrderItemId = oResponse.body.ID;
            return callWrite(oRequest, "/service/Orders_Lines", {
                "text": "Hello World",
                "item_ID": "7329a50e-56d1-4803-8ab5-31b4d109e2d2"
            })
        }).then((oResponse) => {
            sOrderLineId = oResponse.body.ID;
            let sPayload = fs.readFileSync("./test/hana/rest/batch/bookshopBatchUpdate.txt", "utf8");
            sPayload = sPayload.replace("$$OrderId$$", sOrderId);
            sPayload = sPayload.replace("$$OrderItemId$$", sOrderItemId);
            sPayload = sPayload.replace("$$OrderLineId$$", sOrderLineId);
            return callMultipart(oRequest, "/service/$batch", sPayload.split(LF).join(CRLF)).then((oResponse) => {
                expect(oResponse.statusCode).toEqual(200);
                expect(oResponse.body).toBeDefined();
                expect((oResponse.body.match(/HTTP\/1.1 200 OK/g) || []).length).toEqual(3);
            }).then(() => {
                return callRead(oRequest, `/service/Orders(${sOrderId})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.buyer).toEqual("Tom Buyer 2 A");
                });
            }).then(() => {
                return callRead(oRequest, `/service/Orders_Items(${sOrderItemId})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.book).toEqual("Bible 2 B B");
                });
            }).then(() => {
                return callRead(oRequest, `/service/Orders_Lines(${sOrderLineId})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.text).toEqual("Hello World 2 C");
                });
            });
        }).then(() => {
            done();
        });
    });

    it("tests batch delete entity object", (done) => {
        let sOrderId;
        let sOrderItemId;
        let sOrderLineId;
        return callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            sOrderId = oResponse.body.ID;
            return callWrite(oRequest, "/service/Orders_Items", {
                "amount": 1,
                "order_ID": "2872e977-c1e8-4149-bdff-bcb3efecdbdd",
                "book": "Bible"
            })
        }).then((oResponse) => {
            sOrderItemId = oResponse.body.ID;
            return callWrite(oRequest, "/service/Orders_Lines", {
                "text": "Hello World",
                "item_ID": "7329a50e-56d1-4803-8ab5-31b4d109e2d2"
            })
        }).then((oResponse) => {
            sOrderLineId = oResponse.body.ID;
            let sPayload = fs.readFileSync("./test/hana/rest/batch/bookshopBatchDelete.txt", "utf8");
            sPayload = sPayload.replace("$$OrderId$$", sOrderId);
            sPayload = sPayload.replace("$$OrderItemId$$", sOrderItemId);
            sPayload = sPayload.replace("$$OrderLineId$$", sOrderLineId);
            return callMultipart(oRequest, "/service/$batch", sPayload.split(LF).join(CRLF)).then((oResponse) => {
                //console.log(oResponse.body);
                expect(oResponse.statusCode).toEqual(200);
                expect(oResponse.body).toBeDefined();
                expect((oResponse.body.match(/HTTP\/1.1 204 No Content/g) || []).length).toEqual(3);
            });
        }).then(() => {
            done();
        });
    });

    it("tests batch transaction rollback", (done) => {
        let sOrderId;
        let sOrderItemId;
        let sOrderLineId;
        return callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            sOrderId = oResponse.body.ID;
            return callWrite(oRequest, "/service/Orders_Items", {
                "amount": 1,
                "order_ID": "2872e977-c1e8-4149-bdff-bcb3efecdbdd",
                "book": "Bible"
            })
        }).then((oResponse) => {
            sOrderItemId = oResponse.body.ID;
            return callWrite(oRequest, "/service/Orders_Lines", {
                "text": "Hello World",
                "item_ID": "7329a50e-56d1-4803-8ab5-31b4d109e2d2"
            })
        }).then((oResponse) => {
            sOrderLineId = oResponse.body.ID;
            const sFakeOrderLineId = uuid.v4();
            let sPayload = fs.readFileSync("./test/hana/rest/batch/bookshopBatchUpdate.txt", "utf8");
            sPayload = sPayload.replace("$$OrderId$$", sOrderId);
            sPayload = sPayload.replace("$$OrderItemId$$", sOrderItemId);
            sPayload = sPayload.replace("$$OrderLineId$$", sFakeOrderLineId); // Order Line is invalid => rollback batch
            return callMultipart(oRequest, "/service/$batch", sPayload.split(LF).join(CRLF)).then((oResponse) => {
                expect(oResponse.statusCode).toEqual(500);
                expect(oResponse.body).toBeDefined();
                expect(JSON.parse(oResponse.body)).toEqual({
                    error: {
                        code: null,
                        message: `Application Object Node for entity 'Service.Orders_Lines' and key '${sFakeOrderLineId}' was not found`
                    }
                });
            }).then(() => {
                return callRead(oRequest, `/service/Orders(${sOrderId})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.buyer).toEqual("Tom Buyer A");
                });
            }).then(() => {
                return callRead(oRequest, `/service/Orders_Items(${sOrderItemId})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.book).toEqual("Bible B B");
                });
            }).then(() => {
                return callRead(oRequest, `/service/Orders_Lines(${sOrderLineId})`).then((oResponse) => {
                    expect(oResponse.body).toBeDefined();
                    expect(oResponse.body.text).toEqual("Hello World C");
                });
            });
        }).then(() => {
            done();
        });
    });

    it("tests enum check", (done) => {
        callWrite(oRequest, "/service/Orders", {
            "buyer": "Tom Buyer",
            "date": "2018-02-12"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            expect(oResponse.body.status).toBeDefined();
            return callRead(oRequest, `/service/Orders(${oResponse.body.ID})`).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body.buyer).toBeDefined("Tom Buyer A");
                expect(oResponse.body.ID).toBeDefined();
                expect(oResponse.body.status).toBeDefined("Open");
            });
        }).then(() => {
            const sOrderIDHandle = uuid.v4();
            return callWrite(oRequest, "/service/Orders", {
                "ID": sOrderIDHandle,
                "buyer": "Tom Buyer",
                "date": "2018-02-12",
                "status": "XYZ"
            }).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body).toEqual({
                    error: {
                        code: null,
                        message: `[{"severity":2,"messageKey":"MSG_AOF_INVALID_ENUM_VALUE","refKey":"_${sOrderIDHandle.substr(1)}","refNode":"Root","refAttribute":"status","parameters":["XYZ"],"refObject":"Service.Orders"}]`
                    }
                });
            });
        }).then(() => {
            done();
        });
    });

    it("tests entity creation with service mappings", (done) => {
        callWrite(oRequest, "/service/TestObject", {
            "person1": "Tom Buyer",
            "person2": "Tom Buyer",
            "time1": "2018-03-27T11:38:06.485Z",
            "time2": "2018-03-27T11:38:06.485Z",
            "user1": "test1234",
            "user2": "test1234"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sID = oResponse.body.ID;
            const sTime = oResponse.body.created_at;
            const sUser = oResponse.body.created_byId;
            expect(oResponse.body).toEqual({
                "@odata.context": "$metadata#TestObject/$entity",
                ID: sID,
                status: "open",
                person1: "Tom Buyer",
                time1: sTime,
                user1: sUser,
                now1: sTime,
                person2: "Tom Buyer",
                time2: sTime,
                user2: sUser,
                now2: sTime,
                created_byId: sUser,
                created_at: sTime,
                changed_byId: sUser,
                changed_at: sTime
            });
        }).then(() => {
            done();
        });
    });

    it("tests entity action execution with service mappings", (done) => {
        callWrite(oRequest, "/service/TestObject", {
            "person1": "Tom Buyer",
            "person2": "Tom Buyer",
            "time1": "2018-03-27T11:38:06.485Z",
            "time2": "2018-03-27T11:38:06.485Z",
            "user1": "test1234",
            "user2": "test1234"
        }).then((oResponse) => {
            expect(oResponse.body).toBeDefined();
            expect(oResponse.body.ID).toBeDefined();
            const sID = oResponse.body.ID;
            return callWrite(oRequest, `/service/TestObject(${sID})/Service.foo`, {
                "testObject": {
                    "person1": "Tom Buyer",
                    "person2": "Tom Buyer",
                    "time1": "2018-03-27T11:38:06.485Z",
                    "time2": "2018-03-27T11:38:06.485Z",
                    "user1": "test1234",
                    "user2": "test1234"
                }
            }).then((oResponse) => {
                expect(oResponse.body).toBeDefined();
                expect(oResponse.body.ID).toBeDefined();
                const sID = oResponse.body.ID;
                const sCreateTime = oResponse.body.created_at;
                const sCreateUser = oResponse.body.created_byId;
                const sChangeTime = oResponse.body.changed_at;
                const sChangeUser = oResponse.body.changed_byId;
                expect(oResponse.body).toEqual({
                    "@odata.context": '../$metadata#Service.TestObject/$entity',
                    ID: sID,
                    status: "open",
                    person1: "Tom Buyer",
                    time1: sCreateTime,
                    user1: sCreateUser,
                    now1: sChangeTime,
                    person2: "Tom Buyer",
                    time2: sCreateTime,
                    user2: sChangeUser,
                    now2: sChangeTime,
                    created_byId: sCreateUser,
                    created_at: sCreateTime,
                    changed_byId: sChangeUser,
                    changed_at: sChangeTime
                });
            });
        }).then(() => {
            done();
        });
    });
});