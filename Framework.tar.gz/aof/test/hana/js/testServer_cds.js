"use strict";

const express = require("express");
const http = require("http");
const cds = require("@sap/cds");

const AOF = require("../../../");

const PORT = process.env.PORT || 3000;
var oOptions = require("./default-services.json").hana;

var app = express();
var server = http.Server(app);

AOF.middleware(app, {
    schemaScope: AOF.Schema.Scope.Cds,
    metadata: "/bookshop/metadata",
    applicationObjects: {
        "Service.Orders": "/bookshop/Orders"
    },
    extensions: {
        cds: {
            name: "@sap/cds",
            lib: cds,
            startPath: "/test/hana/js",
            services: {
                "/service": "../srv/service"
            }
        }
    }
}, {hana: oOptions});

cds.connect("hana", oOptions);

/*server.listen(PORT, function () {
    console.log("Test server running on http://localhost:" + PORT);
});*/

process.on('unhandledRejection', r => console.log(r));

module.exports = server;