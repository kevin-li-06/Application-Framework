sap.ui.define([
    "sap/aof/ApplicationObject",
    "sap/aof/ReadSource"
], function (ApplicationObject, ReadSource) {
    "use strict";

    return ApplicationObject.extend("sap.app.Todo", {
        objectName: "sap.app.rest.Todo",
        readSource: ReadSource.getDefaultAOFSource(),
        invalidation: {
            entitySets: ["Todo_Root", "Root"]
        }
    });
});