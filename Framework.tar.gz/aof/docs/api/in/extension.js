"use strict";

/**
 * Interface for a Application Object extension implementation, referenced in the AOF middleware options
 * @namespace Extension
 */
function Extension() {
}

/**
 * Initialize a registered extension
 * @param sExtension {String} Name of extension
 * @param oApp {Object} Express App
 * @param oOptions {Object} AOF middleware options
 * @param vStoreInfo {*} Store information
 */
Extension.prototype.init = function (sExtension, oApp, oOptions, vStoreInfo) {
};

/**
 * Enhance the request for an activated extension (although request is not handled by this extension)
 * Can be used to enhance the request with additional extension data
 * @param sExtension {String} Name of extension
 * @param sObjectName {String} Application object name
 * @param oRequest {Object} HTTP request
 * @param oResponse {Object} HTTP response
 * @param oOptions {Object} AOF middleware options
 * @returns {Promise}
 */
Extension.prototype.enhance = function (sExtension, sObjectName, oRequest, oResponse, oOptions) {
    return new Promise();
};

/**
 * Handle the request for an activated extension
 * @param sExtension {String} Name of extension
 * @param sObjectName {String} Application object name
 * @param oRequest {Object} HTTP request
 * @param oResponse {Object} HTTP response
 * @param oOptions {Object} AOF middleware options
 */
Extension.prototype.expose = function (sExtension, sObjectName, oRequest, oResponse, oOptions) {
    return new Promise();
};
