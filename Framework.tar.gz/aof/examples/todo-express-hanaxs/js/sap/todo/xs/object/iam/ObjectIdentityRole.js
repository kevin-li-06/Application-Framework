"use strict";

var Check = require("@sap/aof").Check;
var Message = require("./message");

module.exports.Role = {
    TodoOwner: "sap.todo.xs.object.todo.Todo.Owner",
    TodoReader: "sap.todo.xs.object.todo.Todo.Reader",
    TodoWriter: "sap.todo.xs.object.todo.Todo.Writer",
    TagOwner: "sap.todo.xs.object.tag.Tag.Owner"
};

module.exports.ObjectType = {
    Todo: "sap.todo.xs.object.todo.Todo",
    Tag: "sap.todo.xs.object.tag.Tag"
};

module.exports.node = function (sObjectType, sRole, bReadOnly) {
    return {
        table: "sap.aof.example.db.iam::t_object_identity_role",
        historyTable: "sap.aof.example.db.iam::t_object_identity_role_h",
        sequence: "sap.aof.example.db.iam::s_object_identity_role",
        view: "sap.aof.example.db.iam::v_object_identity_role",
        parentKey: "OBJECT_ID",
        readOnly: bReadOnly,
        consistencyChecks: [Check.duplicateCheck("IDENTITY", Message.DUPLICATE_IDENTITY)],
        attributes: {
            OBJECT_TYPE_CODE: {
                constantKey: sObjectType
            },
            ROLE_CODE: {
                constantKey: sRole
            },
            IDENTITY: {
                foreignKeyTo: "sap.todo.xs.object.iam.Identity.Root"
            }
        }
    };
};