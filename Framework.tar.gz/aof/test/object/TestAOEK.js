"use strict";

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        del: {
            authorizationCheck: false,
            historyEvent: "TEST_DELETED"
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test",
        externalKey: true,
        attributes: {
            TITLE: {
                required: true
            }
        }
    }
};