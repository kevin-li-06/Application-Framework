#!/usr/bin/env bash

export HDI__HOST=inno-next.mo.sap.corp
export HDI__PORT=30015
export HDI___SYS_DI__USER=SYSTEM
export HDI___SYS_DI__PASSWORD=Toor1234

export HDI__SAP_APP_TODO__USER=DEPLOYMENT_USER
export HDI__SAP_APP_TODO__PASSWORD=Test1234

hdi grant-container-schema-privilege SAP_APP_TODO EXECUTE SAP_APP_TODO_USER
hdi grant-container-schema-privilege SAP_APP_TODO SELECT SAP_APP_TODO_USER
hdi grant-container-schema-privilege SAP_APP_TODO INSERT SAP_APP_TODO_USER
hdi grant-container-schema-privilege SAP_APP_TODO UPDATE SAP_APP_TODO_USER
hdi grant-container-schema-privilege SAP_APP_TODO DELETE SAP_APP_TODO_USER
hdi grant-container-schema-privilege SAP_APP_TODO "CREATE ANY" SAP_APP_TODO_USER