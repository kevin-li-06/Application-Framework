"use strict";

/**
 * Adapter implementations (e.g. OData DB adapter)
 * @namespace Adapter
 */
function Adapter() {
}

/**
 * Creates a XSOData adapter for SQLite database
 * @param oStore {Object} Store object
 * @returns {Object} DB Adapter
 */
Adapter.prototype.sqliteXSODataDbAdapter = function (oStore) {
    return Object;
};

/**
 * Creates a XSOData adapter for Postgres database
 * @param oStore {Object} Store object
 * @returns {Object} DB Adapter
 */
Adapter.prototype.postgresXSODataDbAdapter = function (oStore) {
    return Object;
};
