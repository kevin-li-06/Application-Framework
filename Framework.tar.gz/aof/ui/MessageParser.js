sap.ui.define([
    "sap/ui/core/message/MessageParser",
    "sap/ui/core/message/Message",
    "sap/ui/core/MessageType"
], function (MessageParser, Message, MessageType) {
    "use strict";

    var mMessageTypeMapping = {
        "E": MessageType.Error,
        "W": MessageType.Warning,
        "I": MessageType.Information,
        "S": MessageType.Success
    };

    var aPreviousMessage = [];

    function mapMessage(oAOFMessage, oProcessor, oTextModel) {
        var sAOFMessageText = oAOFMessage.MESSAGE_TEXT || "";
        if (!sAOFMessageText && oAOFMessage.MESSAGE) {
            if (oTextModel) {
                sAOFMessageText = oTextModel.getResourceBundle().getText(oAOFMessage.MESSAGE, oAOFMessage.PARAMETERS || []);
            } else {
                sAOFMessageText = oAOFMessage.MESSAGE;
            }
        }
        // We can only map root fields at the moment
        var sTarget = oAOFMessage.REF_NODE === "Root" ? "/" + oAOFMessage.REF_FIELD : "/" + oAOFMessage.REF_NODE;
        return new Message({
            type: mMessageTypeMapping[oAOFMessage.TYPE] || MessageType.None,
            code: oAOFMessage.MESSAGE,
            message: sAOFMessageText,
            description: sAOFMessageText,
            target: sTarget,
            processor: oProcessor
        });
    }

    return MessageParser.extend("sap.aof.MessageParser", {
        constructor: function (oSettings) {
            MessageParser.prototype.constructor.apply(this, arguments);
            this.textModel = oSettings.textModel || "";
            this.aPreviousMessages = [];
        },
        parse: function (oResponse) {
            oResponse = oResponse || {};
            var oProcessor = this.getProcessor();
            var oTextModel = this.textModel;
            var aNewMessages = jQuery.map(oResponse.MESSAGES || oResponse.messages || [], function (oMessage) {
                return mapMessage(oMessage, oProcessor, oTextModel);
            });
            this.getProcessor().fireMessageChange({
                oldMessages: this.aPreviousMessages,
                newMessages: aNewMessages
            });
            this.aPreviousMessages = aNewMessages;
        }
    });
});