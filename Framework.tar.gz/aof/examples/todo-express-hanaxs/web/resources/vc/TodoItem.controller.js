sap.ui.define([
    "sap/todo/aof/example/vc/BaseController",
    "sap/todo/aof/example/type/IntBooleanType",
    "sap/ui/core/ListItem",
    "sap/ui/model/Sorter",
    "sap/m/Tokenizer",
    "sap/m/Token"
], function (BaseController, IntBooleanType, ListItem, Sorter, Tokenizer, Token) {
    "use strict";

    return BaseController.extend("sap.todo.aof.example.vc.TodoItem", {

        types: {
            IntBooleanType: new IntBooleanType()
        },

        formatter: {
            hasPendingChanges: function (iTodoId, dChanged) {
                var oTodo = this.getObjectModel();
                return oTodo.hasPendingChanges();
            }
        },

        onInit: function () {
            BaseController.prototype.onInit.apply(this, arguments);

            var that = this;

            var oTagInput = this.byId("tags");
            oTagInput.attachSuggest(function (oEvent) {
                var sSuggestValue = oEvent.getParameter("suggestValue");
                if (sSuggestValue.length > 0) {
                    oEvent.getSource().bindAggregation("suggestionItems", {
                        path: "data>/Tag_Root",
                        template: new ListItem({
                            key: "{data>NAME}",
                            text: "{data>NAME}",
                            additionalText: "{data>ID}"
                        }),
                        filters: [],
                        sorter: new Sorter("NAME", false),
                        parameters: {
                            select: "ID,NAME",
                            custom: {
                                searchText: jQuery.sap.encodeURL(sSuggestValue)
                            }
                        }
                    });
                } else {
                    oEvent.getSource().removeAllSuggestionItems();
                }
            });

            oTagInput.addValidator(function (oEvent) {
                oTagInput.setValue("");

                var oTodo = that.getObjectModel();
                var sName = oEvent.text.substring(0, oTodo.getApplicationObjectMetadata().nodes.Tags.maxLength);
                var sTodoItemPath = that.getView().getBindingContext("object").getPath();

                if (!oTodo.hasTag(sName, sTodoItemPath)) {
                    var oNewTag = {};
                    oNewTag.KEY = sName;
                    oNewTag.NAME = sName;
                    oNewTag.TAG_ID = -1;
                    oTodo.addTag(oNewTag, sTodoItemPath);
                    return new Token({key: sName, text: sName});
                } else {
                    return false;
                }
            });

            oTagInput.attachTokenChange(function (oEvent) {
                var oTodo = that.getObjectModel();
                var sType = oEvent.getParameter("type");
                if (sType === Tokenizer.TokenChangeType.Removed) {
                    var oToken = oEvent.getParameter("token");
                    if (oToken) {
                        var oTag = oToken.getBindingContext("object").getObject();
                        oTodo.removeTag(oTag);
                    }
                }
            });
        },

        onSavePressed: function (oEvent) {
            this.getOwnerComponent().getRootDetailController().onSavePressed(oEvent);
        },

        onDeletePressed: function (oEvent) {
            this.getOwnerComponent().getRootDetailController().onDeletePressed(oEvent);
        },

        onCancelPressed: function (oEvent) {
            this.getOwnerComponent().getRootDetailController().onCancelPressed(oEvent);
        },

        onNavBack: function () {
            this.getOwnerComponent().getAppView().backDetail();
        }
    });
});