'use strict';

var expect = require('chai').expect;
var sinon = require('sinon');

var Promise = require('bluebird');
var _ = require('underscore');

var sqlite;
try {
    sqlite = require('sqlite3').verbose();
} catch (ex) {
    console.log(ex);
    console.log("run?: sudo npm ln sqlite3");
    return;
}
var pg = require('pg');

var AOF = require('../../../index');
var SQLiteStore = require('../../../lib/db/sqlite/store');
var PostgresStore = require('../../../lib/db/postgres/store');

var oDB;
var oCallerContext = {
    store: {},
    user: {
        id: '4711'
    }
};

describe('core-framework', () => {
    before(() => {
        return new Promise((resolve, reject) => {
            Promise.promisifyAll(sqlite.Database.prototype);
            oDB = new sqlite.Database(':memory:', (error) => {
                expect(error).to.be.null;
                oCallerContext.store = new SQLiteStore({db: oDB});
                oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test" (ID integer primary key, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))')
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_2" (ID integer primary key not null, INT_01 integer, DOUBLE_01 double, TEXT_01 nvarchar(5000), TEXT_02 nvarchar(100), BOOL_01 integer, TS_01 timestamp, DATE_01 date)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null, ANOTHERONE nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_3" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, ANOTHER_TYPE_CODE nvarchar(240) not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_ext_node" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, CUST1 nvarchar(240), CUST2 nvarchar(240), CUST3 nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_h" (HISTORY_DB_EVENT nvarchar(8) not null, HISTORY_BIZ_EVENT nvarchar(600) not null, HISTORY_AT  timestamp not null, HISTORY_ACTOR nvarchar(256) not null, ID integer not null, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_5" (ID integer primary key not null, PARENT_ID integer not null, OBJECT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_concurrency" (ID integer primary key not null, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000), CHANGED_AT timestamp not null, CHANGED_BY nvarchar(256) not null)');
                    })
                    .then(() => {
                        oDB.on('trace', (sql) => {
                            //console.log('SQLite: ' + sql);
                        });
                        resolve();
                    }).catch((e) => {
                    reject(e);
                });
            });
        });
    });

    after(() => {
        if (oCallerContext.store) {
            oCallerContext.store.close();
        }
        AOF.removeObjectExtension('test.object.TestAO');
    });

    it('loads application metadata from library', () => {
        return AOF.getMetadata('test.object.TestAO', oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
        })
    });

    it('error on invalid application metadata from library', () => {
        var oMetadata;
        return AOF.getMetadata('test.object.Invalid_Object', oCallerContext).then(() => {
            this.fail(Error('metadata loading of invalid library shall fail'));
        }).catch((oException) => {
            expect(oException.toString().indexOf('Error: Application object definition \'test.object.Invalid_Object\' not valid. The following errors occurred:') >= 0).to.eql(true);
            expect(oMetadata).not.to.be.ok;
        });
    });

    it('allows accessing application object from metadata', () => {
        return AOF.getMetadata('test.object.TestAO', oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
            return oMetadata.getApplicationObject().then((oApplicationObjectMetadata) => {
                return AOF.getApplicationObject('test.object.TestAO', oCallerContext).then((oApplicationObjectAOF) => {
                    expect(oApplicationObjectMetadata).not.to.eql(oApplicationObjectAOF);
                });
            });
        });
    });

    it('allows accessing metadata from application object', () => {
        return AOF.getApplicationObject('test.object.TestAO', oCallerContext).then((oApplicationObject) => {
            expect(oApplicationObject).to.be.ok;
            var oMetadataObject = oApplicationObject.getMetadata();
            return AOF.getMetadata('test.object.TestAO', oCallerContext).then((oMetadataAOF) => {
                expect(oMetadataObject).to.eql(oMetadataAOF);
            });
        });
    });

    it('allows accessing an extended application object', () => {
        AOF.setObjectExtension('test.object.TestAO', 'test.object.TestAOExt');
        AOF.setObjectExtension('test.object.TestAO', 'test.object.TestAOExt2');

        var oExtensionDef = {
            actions: {
                extCustomAction2: {
                    authorizationCheck: false,
                    execute: () => {
                        return 'Hello World'
                    }
                }
            }
        };
        AOF.setObjectExtension('test.object.TestAO', oExtensionDef);
        AOF.removeObjectExtension('test.object.TestAO', oExtensionDef);
        AOF.setObjectExtension('test.object.TestAO', oExtensionDef, 0);

        return AOF.getApplicationObject('test.object.TestAO', oCallerContext).then((oApplicationObject) => {
            expect(oApplicationObject).to.be.ok;
            expect(oApplicationObject).respondTo('extCustomAction');
            expect(oApplicationObject).respondTo('extCustomAction2');

            return oApplicationObject.create({
                ID: -1,
                DESCRIPTION: 'X'
            }).then((oResponse) => {
                expect(oResponse.messages).to.eql([]);
                var vKey = oResponse.generatedKeys[-1];

                return oApplicationObject.read(vKey).then((oObject) => {
                    expect(oObject.TITLE).to.eql('Hello Extensibility!');
                    expect(oObject.Node3.length).to.eql(1);
                    expect(oObject.Node3[0].OBJECT_ID).to.eql(1);
                    expect(oObject.Node3[0].SOMETEXT).to.eql('TEST_NODE3');

                    return oApplicationObject.extCustomAction2(vKey);
                }).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                    expect(oResponse.result).to.eql('Hello World');
                    expect(oResponse.generatedKeys).to.eql({});
                    expect(oResponse.concurrencyToken).to.eql('{"TITLE":"Hello Extensibility!"}');
                    expect(oResponse.customAction, 'extCustomAction2');
                }).then(() => {
                    AOF.removeObjectExtension('test.object.TestAO', 'test.object.TestAOExt');
                    AOF.removeObjectExtension('test.object.TestAO', 'test.object.TestAOExt2');
                });
            });
        });
    });

    it('allows accessing application object in privileged mode', () => {
        return AOF.getApplicationObject('test.object.TestAO', oCallerContext).then((oApplicationObject) => {
            expect(oApplicationObject).to.be.ok;
            return AOF.getApplicationObject('test.object.TestAO', oCallerContext, true).then((oApplicationObjectPrivileged) => {
                expect(oApplicationObjectPrivileged).to.be.ok;
                expect(oApplicationObjectPrivileged).not.to.eql(oApplicationObject);
                return AOF.getApplicationObject('test.object.TestAO', oCallerContext, true).then((oApplicationObjectPrivilegedCached) => {
                    expect(oApplicationObjectPrivileged).not.to.eql(oApplicationObjectPrivilegedCached);
                });
            });
        });
    });

    it('allows to read object with root path', () => {
        AOF.setRootPath('test/object');
        return AOF.getMetadata('TestAO', oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
            AOF.setRootPath('');
        }).catch((e) => {
            AOF.setRootPath('');
            return Promise.reject(e);
        });
    });

    it('allows to read object with mapped folder path for name', () => {
        AOF.setRootPath('test');
        AOF.registerApplicationObject('com.sap.aof.test.TestAO', 'object/TestAO');
        return AOF.getMetadata('com.sap.aof.test.TestAO', oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
            AOF.setRootPath('');
        }).catch((e) => {
            AOF.setRootPath('');
            return Promise.reject(e);
        });
    });

    it('allows to register and read named object ', () => {
        AOF.registerApplicationObject(require('../../object/TestAOName'));
        return AOF.getMetadata('my.custom.name.TestAOName', oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
            AOF.setRootPath('');
        }).catch((e) => {
            AOF.setRootPath('');
            return Promise.reject(e);
        });
    });

    it('allows to read object by passing direct library', () => {
        return AOF.getMetadata(require('../../object/TestAOName'), oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
            AOF.setRootPath('');
        }).catch((e) => {
            AOF.setRootPath('');
            return Promise.reject(e);
        });
    });

    it('allows to add additional exports to AO library available for client', () => {
        return AOF.getApplicationObject('test.object.TestAOExports', oCallerContext).then((oApplicationObject) => {
            expect(oApplicationObject.exports).to.be.ok;
            expect(oApplicationObject.exports.mapper).to.be.ok;
            expect(oApplicationObject.exports.mapper.in).to.be.ok;
            expect(oApplicationObject.exports.mapper.out).to.be.ok;
            expect(oApplicationObject.getMetadata().exports.mapper).to.be.ok;
            expect(oApplicationObject.getMetadata().exports.mapper.in).to.be.ok;
            expect(oApplicationObject.getMetadata().exports.mapper.out).to.be.ok;
        });
    });

    it('allows json in postgres', () => {
        const dbConnectionParams = {
            host: 'localhost',
            port: 5432,
            user: 'postgres',
            password: 'postgres',
            database: 'aof',
            max: 10
        };

        const oPool = new pg.Pool(dbConnectionParams);
        var oDB;
        return Promise.resolve().then(() => {
            return oPool.connect();
        }).then((oDBClient) => {
            oDB = oDBClient;
            return oDB.query('DROP SEQUENCE IF EXISTS "s_test_json"');
        }).then(() => {
            return oDB.query('DROP TABLE IF EXISTS "t_test_json"');
        }).then(() => {
            return oDB.query('CREATE SEQUENCE "s_test_json"');
        }).then(() => {
            return oDB.query('CREATE TABLE "t_test_json" (ID integer PRIMARY KEY, A_JSON json, A_JSONB jsonb)')
        }).then(() => {
            return oDB.query('DROP SEQUENCE IF EXISTS "s_test_item_json"');
        }).then(() => {
            return oDB.query('DROP TABLE IF EXISTS "t_test_item_json"');
        }).then(() => {
            return oDB.query('CREATE SEQUENCE "s_test_item_json"');
        }).then(() => {
            return oDB.query('CREATE TABLE "t_test_item_json" (ID integer PRIMARY KEY, PARENT_ID integer, A_JSON json, A_JSONB jsonb)')
        }).then(() => {
            var oCallerContextNew = _.clone(oCallerContext);
            oCallerContextNew.store = new PostgresStore({db: oDB});

            var oJSON = {
                A: 1,
                B: 'Hello World',
                C: [{
                    D: 2,
                    E: 'Test'
                }],
                F: {
                    G: 3,
                    H: 'Test2'
                }
            };
            var oJSONUpdate = {
                A: 4,
                B: 'Hello World - Update',
                C: [{
                    D: 5,
                    E: 'Test - Update'
                }],
                F: {
                    G: 6,
                    H: 'Test2 - Update'
                }
            };

            return AOF.getApplicationObject('test.object.TestAOJSON', oCallerContextNew).then((oApplicationObject) => {
                return oApplicationObject.create({
                    id: -1,
                    a_json: oJSON,
                    a_jsonb: oJSON,
                    Items: [{
                        id: -2,
                        a_json: oJSON,
                        a_jsonb: oJSON
                    }]
                }).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                    var vKey = oResponse.generatedKeys[-1];
                    return oApplicationObject.read(vKey).then((oResult) => {
                        expect(oResult.a_json).to.eql(oJSON);
                        expect(oResult.a_jsonb).to.eql(oJSON);
                    }).then(() => {
                        return oApplicationObject.update({
                            id: vKey,
                            a_json: oJSONUpdate,
                            a_jsonb: oJSONUpdate
                        }).then((oResult) => {
                            return oApplicationObject.read(vKey).then((oResult) => {
                                expect(oResult.a_json).to.eql(oJSONUpdate);
                                expect(oResult.a_jsonb).to.eql(oJSONUpdate);
                            });
                        });
                    });
                });
            });
        }).then(() => {
            if (oDB) {
                oDB.release();
            }
        });
    });

    it('tests event listeners', () => {
        var bBeforeCommit = false;
        var bAfterCommit = false;
        var bBulkAfterCommit = false;

        var beforeCommitNotify = (oEvent) => {
            expect(oEvent).to.be.ok;
            expect(oEvent.metadata).to.be.ok;
            bBeforeCommit = true;
        };
        var afterCommitNotify = (oEvent) => {
            expect(oEvent).to.be.ok;
            expect(oEvent.metadata).to.be.ok;
            bAfterCommit = true;
        };
        var bulkAfterCommitNotify = (aEvent) => {
            expect(aEvent).to.be.ok;
            bBulkAfterCommit = aEvent.length > 1;
        };

        AOF.attachListener(beforeCommitNotify, 'test.object.TestAO', AOF.EventTime.BeforeCommit);
        AOF.attachListener(afterCommitNotify, 'test.object.TestAO', AOF.EventTime.AfterCommit);
        AOF.attachListener(bulkAfterCommitNotify, 'test.object.TestAO', AOF.EventTime.AfterCommit, true);

        return AOF.getApplicationObject('test.object.TestAO', oCallerContext).then((oApplicationObject) => {
            return oApplicationObject.create({
                ID: -1,
                TITLE: 'X',
                DESCRIPTION: 'X'
            }).then((oResponse) => {
                expect(oResponse.messages).to.eql([]);
                expect(oResponse.generatedKeys).to.be.ok;
                expect(bBeforeCommit).to.eql(true);
            }).then(() => {
                return oApplicationObject.create({
                    ID: -1,
                    TITLE: 'X',
                    DESCRIPTION: 'X'
                }).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                });
            }).then(() => {
                return oCallerContext.store.commit().then(() => {
                    expect(bAfterCommit).to.eql(true);
                    expect(bBulkAfterCommit).to.eql(true);
                }).then(() => {
                    AOF.detachListener(beforeCommitNotify, 'test.object.TestAO', AOF.EventTime.BeforeCommit);
                    AOF.detachListener(afterCommitNotify, 'test.object.TestAO', AOF.EventTime.AfterCommit);
                    AOF.detachListener(bulkAfterCommitNotify, 'test.object.TestAO', AOF.EventTime.AfterCommit);
                });
            });
        });
    });

    it('tests read only actions', () => {
        var bBeforeCommit = false;

        var beforeCommitNotify = (oEvent) => {
            expect(oEvent).to.be.ok;
            bBeforeCommit = true;
        };

        return AOF.getApplicationObject('test.object.TestAOROAction', oCallerContext).then((oApplicationObject) => {
            var vKey;
            return oApplicationObject.create({
                ID: -1,
                TITLE: 'X',
                DESCRIPTION: 'X'
            }).then((oResponse) => {
                expect(oResponse.messages).to.eql([]);
                expect(oResponse.generatedKeys).to.be.ok;
                vKey = oResponse.generatedKeys[-1];
                AOF.attachListener(beforeCommitNotify, 'test.object.TestAOROAction', AOF.EventTime.BeforeCommit);
            }).then(() => {
                return oApplicationObject.instanceAction(vKey, {}).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                    expect(oResponse.result).to.eql(true); // = oWorkObject !== null, but read-only clone
                });
            }).then(() => {
                expect(bBeforeCommit).to.eql(false);
                return oApplicationObject.staticCustomAction({}).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                });
            }).then(() => {
                expect(bBeforeCommit).to.eql(false);
                AOF.detachListener(beforeCommitNotify, 'test.object.TestAOROAction', AOF.EventTime.BeforeCommit);
            });
        });
    });

    it('tests disabling of module load', () => {
        AOF.disableModuleLoad(true);
        return AOF.getApplicationObject('test.object.TestAO', oCallerContext).then((oMetadata) => {
            AOF.disableModuleLoad(false);
            expect(oMetadata).not.to.be.ok;
        }).catch((e) => {
            AOF.disableModuleLoad(false);
            expect(e.message).to.eql('Loading Application Objects by name or path is disabled');
            return Promise.resolve();
        });
    });

    it('tests instantiation of AOF framework', () => {
        var aof1 = AOF();
        var aof2 = AOF();
        return aof1.getApplicationObject('test.object.TestAO', oCallerContext).then((oMetadata) => {
            expect(oMetadata).to.be.ok;
            return aof2.getApplicationObject('test.object.TestAO', oCallerContext).then((oMetadata) => {
                expect(oMetadata).to.be.ok;
            });
        });
    });
});
