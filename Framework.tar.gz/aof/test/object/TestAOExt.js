"use strict";

module.exports = {
    Root: {
        determinations: {
            onCreate: [(vKey, oWorkObject) => {
                oWorkObject.TITLE = "Hello Extensibility!";
            }]
        },
        attributes: {
            DESCRIPTION: {
                required: true
            },
            TITLE: {
                readOnly: true
            }
        }
    }
};
