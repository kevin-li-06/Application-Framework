var expect = require("chai").expect;
var _ = require("underscore");
var pg = require("pg");

const dbConnectionParams = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postgres",
    database: "aof"
};

var PostgresStore = require("../../../../lib/db/postgres/store");

var store;
var Metadata = require("../../../../lib/core/metadata");

describe("db-postgres", () => {
    const oPool = new pg.Pool(dbConnectionParams);
    var oDB;

    before(() => {
        return Promise.resolve().then(() => {
            return oPool.connect();
        }).then((oDBClient) => {
            oDB = oDBClient;
            return oDB.query('DROP TABLE IF EXISTS "Test"');
        }).then(() => {
            return oDB.query('CREATE TABLE "Test" (ID integer primary key, TITLE varchar(100) not null, DESCRIPTION varchar(1000))')
        }).then(() => {
            store = new PostgresStore({db: oDB});
        });
    });

    after(() => {
        if (oDB) {
            oDB.release();
        }
    });

    it("loads table metadata", () => {
        return store.getNodeMetadata({
            table: "Test"
        }, oDB).then((oMetadata) => {
            expect(oMetadata.table).to.equal("Test");
            expect(oMetadata.schema).to.equal("public");
            expect(oMetadata.primaryKeys).to.eql(["id"]);
            expect(oMetadata.attributes.id).to.eql({
                name: "id",
                dataType: Metadata.DataType.Integer,
                dbDataType: "integer",
                isPrimaryKey: true,
                required: true
            });
            expect(oMetadata.attributes.title).to.eql({
                name: "title",
                dataType: Metadata.DataType.String,
                dbDataType: "character varying",
                maxLength: 100,
                isPrimaryKey: false,
                required: true
            });
            expect(oMetadata.attributes.description).to.eql({
                name: "description",
                dataType: Metadata.DataType.String,
                dbDataType: "character varying",
                maxLength: 1000,
                isPrimaryKey: false,
                required: false
            });
        });
    });
});
