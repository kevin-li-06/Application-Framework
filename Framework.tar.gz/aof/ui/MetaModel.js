sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/json/JSONPropertyBinding"
], function (JSONModel, JSONPropertyBinding) {
    "use strict";

    var MetaModel = JSONModel.extend("sap.aof.MetaModel", {
        metadata: {
            events: {
                "modelInitialized": {}
            }
        }
    });

    MetaModel = new MetaModel({});

    // the intention is to make the metadata cacheable in future
    var fnGetMetadata = getBackendMetadata;

    // !Attention *getMetadata* is already in use by SAPUI5
    MetaModel.getApplicationObjectMetadata = function (sObjectName, fnResult) {
        if (!MetaModel.getProperty("/" + sObjectName)) {
            fnGetMetadata(sObjectName, function (oMetadata) {
                var oMappedMetadata = mapMetadata(oMetadata);
                MetaModel.setProperty("/" + sObjectName, oMappedMetadata);
                if (fnResult) {
                    fnResult(oMappedMetadata);
                    // Avoid triggering result function and event again, in case the metadata are fetched synchronously
                    fnResult = undefined;
                }
                MetaModel.fireEvent("modelInitialized");
            });
        }

        var oMetadata = MetaModel.getProperty("/" + sObjectName);
        if (fnResult) {
            fnResult(oMetadata);
            MetaModel.fireEvent("modelInitialized");
        }
        return oMetadata;
    };

    MetaModel.bindProperty = function (sPath, oContext, mParameters) {
        if (sPath) {
            var aPaths = sPath.split("/");
            if (aPaths.length > 2) {
                var sObjectName = aPaths[1];
                // this method loads object metadata lazy
                MetaModel.getApplicationObjectMetadata(sObjectName);
            }
        }
        return new JSONPropertyBinding(this, sPath, oContext, mParameters);
    };

    MetaModel.getEndpoint = function (sApplicationObjectName) {
        return "/" + sApplicationObjectName.replace(/\./g, "/") + ".js";
    };

    function mapMetadata(oMetadata) {
        // "changeable" as additional metadata
        // as reverse to readOnly as this fits better
        // for binding controls "editable" property
        jQuery.each(oMetadata.nodes, function (sNodeName, oNode) {
            jQuery.each(oNode.attributes, function (sAttributeName, oAttribute) {
                oAttribute.changeable = !oAttribute.readOnly;
            });
        });

        return oMetadata;
    }

    function getBackendMetadata(sObjectName, fnSuccess) {
        var sURL = MetaModel.getEndpoint(sObjectName) + "/metadata";
        var oMetadataRequest = jQuery.ajax({
            url: sURL,
            async: false,
            datatype: "json"
        });

        oMetadataRequest.done(function (oMetadata) {
            fnSuccess(oMetadata);
        });
    }

    return MetaModel;
});