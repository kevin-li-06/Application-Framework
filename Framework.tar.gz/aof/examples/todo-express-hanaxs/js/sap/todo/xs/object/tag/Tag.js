"use strict";

var Determine = require("@sap/aof").Determination;
var ObjectIdentityRole = require("../iam/ObjectIdentityRole");

module.exports = {
    isExtensible: true,
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TAG_CREATED"
        },
        update: {
            authorizationCheck: false,
            historyEvent: "TAG_UPDATED"
        },
        del: {
            authorizationCheck: false,
            historyEvent: "TAG_DELETED"
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.example.db.tag::t_tag",
        historyTable: "sap.aof.example.db.tag::t_tag_h",
        sequence: "sap.aof.example.db.tag::s_tag",
        determinations: {
            onCreate: [createOwner],
            onModify: [Determine.systemAdminData]
        },
        nodes: {
            Owner: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Tag, ObjectIdentityRole.Role.TagOwner, true)
        },
        attributes: {
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true,
                concurrencyControl: true
            },
            CHANGED_BY: {
                readOnly: true
            },
            NAME: {
                required: true,
                isName: true,
                isDescription: true
            }
        }
    }
};

function createOwner(vKey, oWorkObject, oPersistedObject, addMessage, addNextHandle, oContext) {
    return oContext.getUser().then(function (sUser) {
        oWorkObject.Owner = [{
            ID: addNextHandle(),
            IDENTITY: sUser
        }];
    });
}