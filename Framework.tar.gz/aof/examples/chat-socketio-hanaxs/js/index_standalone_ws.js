"use strict";

var winston = require("winston");
var express = require("express");
var http = require("http");
var ws = require("ws");
var xsenv = require("@sap/xsenv");
var xsodata = require("@sap/xsodata");
var aof = require("@sap/aof");

var PORT = process.env.PORT || 3000;
winston.level = process.env.winston_level || "error";

var app = express();
var server = http.Server(app);
var WebSocketServer = ws.Server;
var wss = new WebSocketServer({server: server});

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/index_ws.html");
});
app.get("/index.html", function (req, res) {
    res.sendFile(__dirname + "/index_ws.html");
});

aof.middleware(app, {
    applicationObjects: {
        "sap.chat.Chat": "/sap/chat/Chat"
    },
    extensions: {
        odata: {
            name: "@sap/xsodata",
            lib: xsodata
        },
        websocket: {
            name: "ws",
            lib: wss
        }
    }
}, xsenv.getServices({hana: {tag: 'hana'}}));

server.listen(PORT, function () {
    console.log("Chat application is running on port: " + PORT);
});