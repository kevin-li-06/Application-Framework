**Run Unit-Tests:**

    npm test

**Run HANA Unit-Tests:**

    // Prerequisites (already prepared):
        // Install newest HDI client
        npm install -g git://github.wdf.sap.corp/hdi/hdijs.git#<version>

        // Create HDI Container 'SAP_AOF_TEST'
        test/hana/db/hdi_container.sh 

        // Deploy DB src in HDI Container 'SAP_AOF_TEST'
        test/hana/db/hdi_sync.sh   

        // Create user 'SAP_AOF_TEST_USER' with password 'Test1234'
        create user SAP_AOF_TEST_USER password Test1234;
        alter user SAP_AOF_TEST_USER disable password lifetime;
        grant select on _SYS_BI.BIMC_DIMENSION_VIEW_HDI to SAP_AOF_TEST_USER;
        grant select on _SYS_BI.BIMC_VARIABLE_VIEW_HDI to SAP_AOF_TEST_USER;
        
        // Grant schema privileges in HDI Container 'SAP_AOF_TEST'
        test/hana/db/hdi_grant.sh
        
    // run tests
    npm run test-hana
    
    // debug tests (using node-inspector)
    // npm install -g node-inspector
    node-debug node_modules/jasmine-node/bin/jasmine-node test/hana
    
**Manual REST Tests:**
    
    // Start test server
    cd test/js
    npm install
    cd ../../
    node test/js/testServer
    
    // Create test instance
    POST http://localhost:3000/test/object/testao.js 
    {
    	"ID" : -1,
    	"TITLE" : "Test1",
    	"DESCRIPTION" : "Test1_1",
        "Node1" : [{
        	"ID": -2,
            "SOMETEXT": "Test2"
        }],
    	"Node2" : [{
        	"ID": -3,
            "SOMETEXT": "Test3",
            "Node21" : [{
        	    "ID": -4,
                "SOMETEXT": "Test4",
                "ANOTHERONE" : "Test4_1"
            }]
        }]
    }
    
    // Retrieve ID from generated keys (GENERATED_KEYS) for handle '-1': <id>
    
    // Read instance
    GET http://localhost:3000/test/object/testao.js/<id>
    
    // Read instance via OData
    GET http://localhost:3000/test/object/testao.odata/Root(<id>)?$expand=Node1,Node2,Node2/Node21&$format=json