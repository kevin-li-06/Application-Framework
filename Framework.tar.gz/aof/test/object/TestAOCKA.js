"use strict";

var Message = require("../../lib/core/message");
var Auth = require("../../lib/lib/authorization");

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        copy: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        update: {
            authorizationCheck: false,
            historyEvent: "TEST_UPDATED"
        },
        del: {
            authorizationCheck: false,
            historyEvent: "TEST_DELETED"
        },
        read: {
            authorizationCheck: Auth.instanceAccessCheck("sap.aof.test.db.test::t_test", "ID", "MSG_AUTH_MISSING_AUTH")
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test",
        historyTable: "sap.aof.test.db.test::t_test_h",
        sequence: "sap.aof.test.db.test::s_test",
        attributes: {
            TITLE: {
                required: true,
                concurrencyControl: true
            },
            DESCRIPTION: {
                constantKey: "TEST_ROOT"
            }
        },
        determinations: {
            onRead: [(vKey, oReadObject, oNodeMetadata, oContext) => {
                oReadObject.TITLE += " (OnRead)";
            }]
        },
        nodes: {
            Node1: {
                table: "sap.aof.test.db.test::t_test_node_1",
                sequence: "sap.aof.test.db.test::s_test_node_1",
                parentKey: "PARENT_ID",
                attributes: {
                    SOMETEXT: {
                        constantKey: "TEST_NODE1"
                    }
                }
            },
            Node2: {
                table: "sap.aof.test.db.test::t_test_node_2",
                sequence: "sap.aof.test.db.test::s_test_node_2",
                parentKey: "PARENT_ID",
                attributes: {
                    SOMETEXT: {
                        constantKey: "TEST_NODE2"
                    }
                },
                nodes: {
                    Node21: {
                        table: "sap.aof.test.db.test::t_test_node_2_1",
                        sequence: "sap.aof.test.db.test::s_test_node_2_1",
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                constantKey: "TEST_NODE21_1"
                            },
                            ANOTHERONE: {
                                constantKey: "TEST_NODE21_2"
                            }
                        }
                    }
                }
            },
            Node3: {
                table: "sap.aof.test.db.test::t_test_node_5",
                sequence: "sap.aof.test.db.test::s_test_node_5",
                parentKey: "PARENT_ID",
                attributes: {
                    OBJECT_ID: {
                        foreignKeyTo: "test.object.TestAOCKA.Root"
                    },
                    SOMETEXT: {
                        constantKey: "TEST_NODE3"
                    }
                }
            }
        }
    }
};
