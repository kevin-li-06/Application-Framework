"use strict";

/**
 * Message interface to create and add messages to the currently active message buffer
 * @namespace MessageBuffer
 */
function MessageBuffer() {
}

/**
 * A message can be created and added to the runtime message buffer. A message is always created in context of an application object type.
 * @callback MessageBuffer.addMessage
 * @param severity {MessageSeverity} Severity of the message
 * @param messageKey {String} Technical message key
 * @param [refKey] {String} Reference key of the application object instance
 * @param [refNode] {String} Reference node name of the application object
 * @param [refAttribute] {String} Reference node attribute name of the application object
 * @param [parameter1] {String} First message parameter value, to be used as placeholder replacement in the message text
 * @param [parameter2] {String} Second message parameter value, to be used as placeholder replacement in the message text
 * @param [parameter3] {String} Thrid message parameter value, to be used as placeholder replacement in the message text
 * @param [parameter4] {String} Fourth message parameter value, to be used as placeholder replacement in the message text
 */
MessageBuffer.prototype.addMessage = function (severity, messageKey, refKey, refNode, refAttribute, parameter1, parameter2, parameter3, parameter4) {
};

/**
 * An already existing message objects can be added to the runtime message buffer
 * @param oMessage {Message} Message object to be added
 */
MessageBuffer.prototype.addMessage = function (oMessage) {
};

/**
 * An already existing array of message objects can be added to the runtime message buffer
 * @param aMessage {Array.<Message>} Message objects to be added
 */
MessageBuffer.prototype.addMessage = function (aMessage) {
};
