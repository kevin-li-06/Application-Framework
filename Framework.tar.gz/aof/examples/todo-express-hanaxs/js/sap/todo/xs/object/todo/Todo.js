"use strict";

var AOF = require("@sap/aof");
var Auth = AOF.Authorization;
var Determine = AOF.Determination;
var _ = AOF._;

var Message = AOF.Message;
var TodoMessage = require("./message");
var ObjectIdentityRole = require("../iam/ObjectIdentityRole");
var TagAssign = require("../tag/TagAssign");

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TODO_CREATED"
        },
        update: {
            authorizationCheck: false, // Auth.instanceAccessCheck("sap.aof.example.db.todo::v_auth_todo_update", "TODO_ID", TodoMessage.AUTH_MISSING_TODO),
            historyEvent: "TODO_UPDATED",
            enabledCheck: updateEnabledCheck
        },
        del: {
            authorizationCheck: false, // Auth.instanceAccessCheck("sap.aof.example.db.todo::v_auth_todo_del", "TODO_ID", TodoMessage.AUTH_MISSING_TODO),
            historyEvent: "TODO_DELETED",
            enabledCheck: delEnabledCheck
        },
        read: {
            authorizationCheck: false //authorizationCheck: Auth.instanceAccessCheck("sap.aof.example.db.todo::v_auth_todo_read", "TODO_ID", TodoMessage.AUTH_MISSING_TODO)
        }
    },
    Root: {
        table: "sap.aof.example.db.todo::t_todo",
        historyTable: "sap.aof.example.db.todo::t_todo_h",
        sequence: "sap.aof.example.db.todo::s_todo",
        view: "sap.aof.example.db.todo::v_todo",
        determinations: {
            onCreate: [createOwner],
            onModify: [Determine.systemAdminData, TagAssign.createTags, updateTextSearch, propagateIsDone],
            onUpdate: [addInfoMessage]
        },
        nodes: {
            Items: {
                table: "sap.aof.example.db.todo::t_todo_item",
                historyTable: "sap.aof.example.db.todo::t_todo_item_h",
                sequence: "sap.aof.example.db.todo::s_todo_item",
                parentKey: "TODO_ID",
                attributes: {
                    TEXT: {
                        required: true,
                        isName: true,
                        isDescription: true
                    }
                },
                nodes: {
                    Tags: TagAssign.node(TagAssign.ObjectType.TodoItem, false)
                }
            },
            Owner: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Todo, ObjectIdentityRole.Role.TodoOwner, true),
            Readers: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Todo, ObjectIdentityRole.Role.TodoReader, false),
            Writers: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Todo, ObjectIdentityRole.Role.TodoWriter, false)
        },
        attributes: {
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true,
                concurrencyControl: true
            },
            CHANGED_BY: {
                readOnly: true
            },
            TEXT: {
                required: true,
                isName: true,
                isDescription: true
            }
        }
    }
};

function createOwner(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
    return oContext.getUser().then(function (sUser) {
        oWorkObject.Owner = [{
            ID: getNextHandle(),
            IDENTITY: sUser
        }];
    });
}

function updateTextSearch(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
    oWorkObject.TEXT_SEARCH = oWorkObject.TEXT.substring(0, 5000);
    _.each(oWorkObject.Items || [], function (oItem) {
        oItem.TEXT_SEARCH = oItem.TEXT.substring(0, 5000);
    });
}

function propagateIsDone(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
    if (oWorkObject.IS_DONE === 1) {
        _.each(oWorkObject.Items || [], function (oItem) {
            oItem.IS_DONE = 1;
        });
    } else if (oWorkObject.Items.length > 0) {
        if (!_.find(oWorkObject.Items || [], function (oItem) {
                return oItem.IS_DONE !== 1;
            })) {
            oWorkObject.IS_DONE = 1;
        }
    }
}

function addInfoMessage(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
    addMessage(Message.MessageSeverity.Info, TodoMessage.TODO_INFO_MESSAGE, vKey, "Root");
}

function updateEnabledCheck(vKey, oWorkObject, addMessage, oContext) {
    return oContext.getUser().then(function (sUser) {
        if (oWorkObject.Owner[0].IDENTITY !== sUser && !_.find(oWorkObject.Writers, function (oWriter) {
                return oWriter.IDENTITY === sUser;
            })) {
            addMessage(Message.MessageSeverity.Error, TodoMessage.TODO_NOT_CHANGEABLE, vKey, "Root");
        }
    });
}

function delEnabledCheck(vKey, oWorkObject, addMessage, oContext) {
    return oContext.getUser().then(function (sUser) {
        if (oWorkObject.Owner[0].IDENTITY !== sUser) {
            addMessage(Message.MessageSeverity.Error, TodoMessage.TODO_NOT_DELETABLE, vKey, "Root");
        }
    });
}