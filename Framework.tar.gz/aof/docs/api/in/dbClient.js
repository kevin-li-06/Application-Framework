"use strict";

/**
 * Common DB client, to warp the most basic DB-level operations
 * @namespace DBClient
 */
function DBClient() {
}

/**
 *
 * @namespace DBTable
 * @memberof DBClient
 * @type {Object}
 */
function DBTable() {
}

/**
 * Deletes all data from the specified table
 * @method truncate
 * @memberof DBClient.DBTable
 * @instance
 * @returns {Promise}
 */
DBTable.prototype.truncate = function () {
    return new Promise();
};

/**
 * Reads all data from the specified table
 * @method read
 * @memberof DBClient.DBTable
 * @instance
 * @returns {Promise}
 */
DBTable.prototype.read = function () {
    return new Promise();
};

/**
 * Inserts data into the specified table
 * @method insert
 * @memberof DBClient.DBTable
 * @instance
 * @param vContent {(Object|Array)} Row or array of rows to be inserted
 * @returns {Promise}
 */
DBTable.prototype.insert = function (vContent) {
    return new Promise();
};

/**
 * Inserts data into the specified table
 * @method upsert
 * @memberof DBClient.DBTable
 * @instance
 * @param vContent {(Object|Array)} Row or array of rows to be inserted
 * @returns {Promise}
 */
DBTable.prototype.upsert = function (vContent) {
    return new Promise();
};

/**
 *
 * @namespace DBProcedure
 * @memberof DBClient
 * @type {Object}
 */
function DBProcedure() {
}

/**
 * Executes the specified procedure
 * @method execute
 * @memberof DBClient.DBProcedure
 * @instance
 * @param [vValues] {*} SQL procedure execution parameters (passed as array or as var args)
 * @returns {Promise} Promise resolving to the execution result
 */
DBProcedure.prototype.execute = function (vValues) {
    return new Promise();
};

/**
 *
 * @namespace DBStatement
 * @memberof DBClient
 * @type {Object}
 */
function DBStatement() {
}

/**
 * Executes the specified statement
 * @method execute
 * @memberof DBClient.DBStatement
 * @instance
 * @param [vValues] {*} SQL statement execution parameters
 * @returns {Promise} Promise resolving to the execution result
 */
DBStatement.prototype.execute = function (vValues) {
    return new Promise();
};

/**
 *
 * @namespace DBSequence
 * @memberof DBClient
 * @type {Object}
 */
function DBSequence() {
}

/**
 * Returns the next value for the sequence
 * @method nextval
 * @memberof DBClient.DBSequence
 * @instance
 * @returns {Promise.<Number>} Promise resolving to the next sequence value
 */
DBSequence.prototype.nextval = function () {
    return new Promise();
};

/**
 * Returns the original DB object
 * @returns {Object}
 */
DBClient.prototype.getDB = function () {
    return Object;
};

/**
 * Returns the currently active user schema
 * @returns {Promise.<String>}
 */
DBClient.prototype.getSchema = function () {
    return "";
};

/**
 * Returns an accessor object for the specified table
 * @param sTableName {String} Table to be accessed
 * @returns {DBClient.DBTable}
 */
DBClient.prototype.table = function (sTableName) {
    return Object;
};

/**
 * Returns an accessor object for the specified procedure
 * @param sProcedureName {String} Procedure to be executed
 * @returns {DBClient.DBProcedure}
 */
DBClient.prototype.procedure = function (sProcedureName) {
    return Object;
};

/**
 * Returns an accessor object for the specified SQL statement
 * @param sSQLStatement {String} SQL statement to be executed
 * @returns {DBClient.DBStatement}
 */
DBClient.prototype.statement = function (sSQLStatement) {
    return Object;
};

/**
 * Returns an accessor object for the specified sequence
 * @param sSequenceName {String} Sequence to be used
 * @returns {DBClient.DBSequence}
 */
DBClient.prototype.sequence = function (sSequenceName) {
    return Object;
};

/**
 * Reads all data from specified table
 * @param sTableName {String} Table to read
 * @returns {Promise.<Array>} Promise resolving to read data
 */
DBClient.prototype.read = function (sTableName) {
    return new Promise();
};

/**
 * Commits the current transaction.
 * Is called automatically by the framework and shall not be called in application code.
 * @returns {Promise}
 */
DBClient.prototype.commit = function () {
    return new Promise();
};

/**
 * Rolls back the current transaction.
 * Is called automatically by the framework and shall not be called in application code.
 * @returns {Promise}
 */
DBClient.prototype.rollback = function () {
    return new Promise();
};
