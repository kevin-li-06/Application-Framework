"use strict";

module.exports = {
    actions: {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        },
        instanceAction: {
            authorizationCheck: false,
            execute: (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext) => {
                return oWorkObject !== null;
            },
            readOnly: () => {
                return true;
            }
        },
        staticCustomAction: {
            isStatic: true,
            authorizationCheck: false,
            execute: (oParameters, oBulkAccess, addMessage) => {
            },
            readOnly: true
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test"
    }
};
