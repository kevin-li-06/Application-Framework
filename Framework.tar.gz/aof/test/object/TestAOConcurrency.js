"use strict";

module.exports = {
    isExtensible: true,
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        copy: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        update: {
            authorizationCheck: false,
            historyEvent: "TEST_UPDATED"
        },
        del: {
            authorizationCheck: false,
            historyEvent: "TEST_DELETED"
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test_concurrency",
        sequence: "sap.aof.test.db.test::s_test",
        attributes: {
            CHANGED_AT: {
                concurrencyControl: true
            }
        }
    }
};