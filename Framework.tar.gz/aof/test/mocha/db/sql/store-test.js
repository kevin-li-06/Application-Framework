"use strict";
var expect = require("chai").expect;
var sinon = require("sinon");

var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../../lib/util/underscore");

var sqlite;
try {
    sqlite = require("sqlite3").verbose();
} catch (ex) {
    console.log(ex);
    console.log("run?: sudo npm ln sqlite3");
    return;
}

var SQLiteStore = require("../../../../lib/db/sqlite/store");
var SQLObjectAccess = require("../../../../lib/db/sql/object-access");
var Metadata = require("../../../../lib/core/metadata");
var Message = require("../../../../lib/core/message");

var TEST_TABLE = "sap.aof.test.db.test::t_test";
var TEST_HISTORY_TABLE = "sap.aof.test.db.test::t_test_h";
var TEST_TABLE_NODE_1 = "sap.aof.test.db.test::t_test_node_1";
var TEST_TABLE_NODE_2 = "sap.aof.test.db.test::t_test_node_2";
var TEST_TABLE_NODE_2_1 = "sap.aof.test.db.test::t_test_node_2_1";
var TEST_TABLE_NODE_3 = "sap.aof.test.db.test::t_test_node_3";

var oDB;
var oCallerContext = {
    store: {},
    user: {
        id: "4711"
    }
};

var oDummyActions = {
    create: {
        authorizationCheck: false,
        historyEvent: "TEST_CREATED"
    },
    update: {
        authorizationCheck: false,
        historyEvent: "TEST_UPDATED"
    },
    del: {
        authorizationCheck: false,
        historyEvent: "TEST_DELETED"
    },
    read: {
        authorizationCheck: false
    }
};


var sTimestamp;

function createTimestamp() {
    sTimestamp = new Date().toISOString();
}

describe("db-sql-store", () => {
    before(() => {
        return new Promise((resolve, reject) => {
            Promise.promisifyAll(sqlite.Database.prototype);
            oDB = new sqlite.Database(':memory:', (error) => {
                expect(error).to.be.null;
                oCallerContext.store = new SQLiteStore({ db: oDB });
                oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test" (ID integer primary key, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))')
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_2" (ID integer primary key not null, INT_01 integer, DOUBLE_01 double, TEXT_01 nvarchar(5000), TEXT_02 nvarchar(100), BOOL_01 integer, TS_01 timestamp, DATE_01 date)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_2_1" (ID integer primary key not null, PARENT_ID integer not null, SOMETEXT nvarchar(240) not null, ANOTHERONE nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_3" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, ANOTHER_TYPE_CODE nvarchar(240) not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_ext_node" (ID integer primary key not null, OBJECT_ID integer not null, OBJECT_TYPE_CODE nvarchar(240) not null, CUST1 nvarchar(240), CUST2 nvarchar(240), CUST3 nvarchar(240))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_h" (HISTORY_DB_EVENT nvarchar(8) not null, HISTORY_BIZ_EVENT nvarchar(600) not null, HISTORY_AT  timestamp not null, HISTORY_ACTOR nvarchar(256) not null, ID integer not null, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000))');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_node_5" (ID integer primary key not null, PARENT_ID integer not null, OBJECT_ID integer not null, SOMETEXT nvarchar(240) not null)');
                    })
                    .then(() => {
                        return oDB.runAsync('CREATE TABLE "sap.aof.test.db.test::t_test_concurrency" (ID integer primary key not null, TITLE nvarchar(240) not null, DESCRIPTION nvarchar(1000), CHANGED_AT timestamp not null, CHANGED_BY nvarchar(256) not null)');
                    })
                    .then(() => {
                        oDB.on('trace', (sql) => {
                            //console.log('SQLite: ' + sql);
                        });
                        resolve();
                    }).catch((e) => {
                    reject(e);
                });
            });
        });
    });

    it("module can be required", () => {
        expect(SQLiteStore).to.be.ok;
    });

    it("reads a structured object", () => {
        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var oDBClient = oCallerContext.store.getClient();

            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root", table: TEST_TABLE, primaryKey: "ID" });
            var fnSequenceNode1 = oDBObjectAccess.getSequence({
                name: "Node1",
                table: TEST_TABLE_NODE_1,
                primaryKey: "ID"
            });
            var fnSequenceNode2 = oDBObjectAccess.getSequence({
                name: "Node2",
                table: TEST_TABLE_NODE_2,
                primaryKey: "ID"
            });
            var fnSequenceNode2_1 = oDBObjectAccess.getSequence({
                name: "Node21",
                table: TEST_TABLE_NODE_2_1,
                primaryKey: "ID"
            });

            var sRootId;
            var sNode1Id1;
            var sNode1Id2;
            var sNode2Id1;
            var sNode2Id2;
            var sNode2_1Id1;
            var sNode2_1Id2;
            var sNode2_1Id3;
            var sNode2_1Id4;

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oDBClient.table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                }]);
            }).then(() => {
                return fnSequenceNode1().then((_sNode1Id1) => {
                    sNode1Id1 = _sNode1Id1;
                    return oDBClient.table(TEST_TABLE_NODE_1).insert([{
                        ID: sNode1Id1,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 1 of Node 1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode1().then((_sNode1Id2) => {
                    sNode1Id2 = _sNode1Id2;
                    return oDBClient.table(TEST_TABLE_NODE_1).insert([{
                        ID: sNode1Id2,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 2 of Node 1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2().then((_sNode2Id1) => {
                    sNode2Id1 = _sNode2Id1;
                    return oDBClient.table(TEST_TABLE_NODE_2).insert([{
                        ID: sNode2Id1,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 1 of Node 2'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2().then((_sNode2Id2) => {
                    sNode2Id2 = _sNode2Id2;
                    return oDBClient.table(TEST_TABLE_NODE_2).insert([{
                        ID: sNode2Id2,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 2 of Node 2'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id1) => {
                    sNode2_1Id1 = _sNode2_1Id1;
                    return oDBClient.table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id1,
                        PARENT_ID: sNode2Id1,
                        SOMETEXT: 'Instance 1 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id2) => {
                    sNode2_1Id2 = _sNode2_1Id2;
                    return oDBClient.table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id2,
                        PARENT_ID: sNode2Id1,
                        SOMETEXT: 'Instance 2 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id3) => {
                    sNode2_1Id3 = _sNode2_1Id3;
                    return oDBClient.table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id3,
                        PARENT_ID: sNode2Id2,
                        SOMETEXT: 'Instance 3 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id4) => {
                    sNode2_1Id4 = _sNode2_1Id4;
                    return oDBClient.table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id4,
                        PARENT_ID: sNode2Id2,
                        SOMETEXT: 'Instance 4 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return oDBObjectAccess.read(sRootId).then((oObject) => {
                    expect(oObject).to.eql({
                        ID: sRootId,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description',
                        Node1: [{
                            ID: sNode1Id1,
                            SOMETEXT: 'Instance 1 of Node 1'
                        }, {
                            ID: sNode1Id2,
                            SOMETEXT: 'Instance 2 of Node 1'
                        }],
                        Node2: [{
                            ID: sNode2Id1,
                            SOMETEXT: 'Instance 1 of Node 2',
                            Node21: [{
                                ID: sNode2_1Id1,
                                SOMETEXT: 'Instance 1 of Node 2_1',
                                ANOTHERONE: null
                            }, {
                                ID: sNode2_1Id2,
                                SOMETEXT: 'Instance 2 of Node 2_1',
                                ANOTHERONE: null
                            }]
                        }, {
                            ID: sNode2Id2,
                            SOMETEXT: 'Instance 2 of Node 2',
                            Node21: [{
                                ID: sNode2_1Id3,
                                SOMETEXT: 'Instance 3 of Node 2_1',
                                ANOTHERONE: null
                            }, {
                                ID: sNode2_1Id4,
                                SOMETEXT: 'Instance 4 of Node 2_1',
                                ANOTHERONE: null
                            }]
                        }]
                    });
                });
            })
        });
    });


    it("reads objects bypassing the buffer and with virtual tables", () => {
        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            Root: {
                table: TEST_TABLE
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root", table: TEST_TABLE });
            return fnSequenceRoot().then((sRootId) => {
                return oCallerContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                }]).then(() => {
                    return oDBObjectAccess.read(sRootId, true).then((oObject) => {
                        expect(oObject).to.eql({
                            ID: sRootId,
                            TITLE: 'New node title',
                            DESCRIPTION: 'New node description'
                        });
                    });
                }).then(() => {
                    // this is necessary for configuration where the staging state needs to be considered
                    return oDBObjectAccess.read(sRootId, true, {
                        "sap.aof.test.db.test::t_test": "(select ID, 'Dummy' as TITLE, 'ABC' as DESCRIPTION from \""
                        + TEST_TABLE + '")'
                    }).then((oObject) => {
                        expect(oObject).to.eql({
                            ID: sRootId,
                            TITLE: "Dummy",
                            DESCRIPTION: "ABC"
                        });
                    });
                });
            });
        });
    });

    it("reads objects defined with constant key", () => {
        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                nodes: {
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4712"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4711"
                            }
                        }
                    },
                    Node3b: {
                        table: TEST_TABLE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4710"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4711"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);

            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            var fnSequenceNode3 = oDBObjectAccess.getSequence({ name: "Node3" });

            var sRootId;
            var sNode3Id1;
            var sNode3bId1;
            var sNode3Id2;

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oCallerContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                }]);
            }).then(() => {
                // positive cases (which should be read)
                return fnSequenceNode3().then((_sNode3Id1) => {
                    sNode3Id1 = _sNode3Id1;
                    return oCallerContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                        ID: sNode3Id1,
                        OBJECT_ID: sRootId,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 1 of Node 3'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode3().then((_sNode3bId1) => {
                    sNode3bId1 = _sNode3bId1;
                    return oCallerContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                        ID: sNode3bId1,
                        OBJECT_ID: sRootId,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4710",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 1 of Node 3b'
                    }]);
                });
            }).then(() => {
                // negative case (which should not be read)
                return fnSequenceNode3().then((_sNode3Id2) => {
                    sNode3Id2 = _sNode3Id2;
                    return oCallerContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                        ID: sNode3Id2,
                        OBJECT_ID: sRootId,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4713",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 3 in table 3'
                    }]);
                });
            }).then(() => {
                return oDBObjectAccess.read(sRootId).then((oObject) => {
                    expect(oObject).to.eql({
                        ID: sRootId,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description',
                        Node3: [{
                            ID: sNode3Id1,
                            OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                            ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                            SOMETEXT: 'Instance 1 of Node 3'
                        }],
                        Node3b: [{
                            ID: sNode3bId1,
                            OBJECT_TYPE_CODE: "TYPE_CODE_4710",
                            ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                            SOMETEXT: 'Instance 1 of Node 3b'
                        }]
                    });
                })
            }).then(() => {
                // Existence check should have the same behaviour as read
                return oDBObjectAccess.exists(sNode3Id1, "Node3").then((bExists) => {
                    expect(bExists).to.eql(true);
                    return oDBObjectAccess.exists(sNode3bId1, "Node3b");
                }).then((bExists) => {
                    expect(bExists).to.eql(true);
                    return oDBObjectAccess.exists(sNode3Id2, "Node3");
                }).then((bExists) => {
                    expect(bExists).to.eql(false);
                    return oDBObjectAccess.exists(sNode3Id2, "Node3b");
                }).then((bExists) => {
                    expect(bExists).to.eql(false);
                });
            });
        });
    });

    it("writes objects defined with constant key", () => {

        var sRootId;
        var sNode31Id;
        var sNode32Id;

        var oDBObjectAccess;
        var fnSequenceRoot;
        var fnSequenceNode3;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                nodes: {
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4712"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4711"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            fnSequenceNode3 = oDBObjectAccess.getSequence({ name: "Node3" });
            return fnSequenceRoot();
        }).then((_sRootId) => {
            sRootId = _sRootId;
            return fnSequenceNode3();
        }).then((_sNode31Id) => {
            sNode31Id = _sNode31Id;
            return fnSequenceNode3();
        }).then((_sNode32Id) => {
            sNode32Id = _sNode32Id;
            return oDBObjectAccess.create({
                ID: sRootId,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description',
                Node3: [{
                    ID: sNode31Id,
                    SOMETEXT: 'Instance 1 of Node 3',
                }, {
                    ID: sNode32Id,
                    SOMETEXT: 'Instance 2 of Node 3',
                    OBJECT_TYPE_TYPE: 'ABC',
                    ANOTHER_TYPE_CODE: 'XYZ'
                }]
            }).then(() => {
                return oDBObjectAccess.read(sRootId);
            }).then((oObject) => {
                expect(oObject).to.eql({
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description',
                    Node3: [{
                        ID: sNode31Id,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 1 of Node 3'
                    }, {
                        ID: sNode32Id,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 2 of Node 3'
                    }]
                });
            });
        });
    });

    it("creates updates and deletes a simple object", () => {

        function getLatestHistory(iKey) {
            return oCallerContext.store.getClient().statement('select * from "' + TEST_HISTORY_TABLE + '" where id = ? order by history_at desc limit 1').execute(iKey);
        }

        createTimestamp();

        var oAction = {
            name: "create",
            historyEvent: "TEST_CREATED"
        };

        var oCallerContextMock = {
            getAction: () => {
                return oAction;
            },
            getUser: () => {
                return Promise.resolve(oCallerContext.user.id);
            },
            getRequestTimestamp: () => {
                return sTimestamp;
            },
            getHistoryEvent: () => {
                return oAction.historyEvent;
            }
        };
        var fnMessageMock = () => {
        };

        var iKey;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                historyTable: TEST_HISTORY_TABLE
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequence = oDBObjectAccess.getSequence({ name: "Root" });
            return fnSequence().then((_iKey) => {
                iKey = _iKey;
                var oCreateObject = {
                    ID: iKey,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                };
                return oDBObjectAccess.create(oCreateObject, fnMessageMock, oCallerContextMock).then((vResult) => {
                    expect(vResult).not.to.be.ok;
                    return oDBObjectAccess.read(iKey);
                }).then((oReadObject) => {
                    expect(oCreateObject).to.eql(oReadObject);
                    return getLatestHistory(iKey);
                }).then((aCreateHistory) => {
                    expect(aCreateHistory.length).to.eql(1);
                    expect(aCreateHistory[0]).to.eql({
                        HISTORY_DB_EVENT: "CREATED",
                        HISTORY_BIZ_EVENT: oCallerContextMock.getAction().historyEvent,
                        HISTORY_AT: oCallerContextMock.getRequestTimestamp(),
                        HISTORY_ACTOR: oCallerContext.user.id,
                        ID: iKey,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description'
                    });
                }).then(() => {
                    return Promise.delay(101);
                }).then(() => {
                    createTimestamp();

                    oAction = {
                        name: 'update',
                        historyEvent: 'TEST_UPDATED'
                    };
                    var oUpdateObject = {
                        ID: iKey,
                        TITLE: 'Changed title',
                        DESCRIPTION: 'Changed description'
                    };
                    return oDBObjectAccess.update(oUpdateObject, fnMessageMock, oCallerContextMock).then((vResult) => {
                        expect(vResult).not.to.be.ok;
                        return getLatestHistory(iKey);
                    }).then((aUpdateHistory) => {
                        expect(aUpdateHistory.length).to.eql(1);
                        expect(aUpdateHistory[0]).to.eql({
                            HISTORY_DB_EVENT: "UPDATED",
                            HISTORY_BIZ_EVENT: oCallerContextMock.getAction().historyEvent,
                            HISTORY_AT: oCallerContextMock.getRequestTimestamp(),
                            HISTORY_ACTOR: oCallerContext.user.id,
                            ID: iKey,
                            TITLE: 'Changed title',
                            DESCRIPTION: 'Changed description'
                        });
                        return oDBObjectAccess.read(iKey);
                    }).then(() => {
                        return Promise.delay(101);
                    }).then(() => {
                        createTimestamp();
                        var oDeleteObject = {
                            ID: iKey,
                            TITLE: 'Changed title',
                            DESCRIPTION: 'Changed description'
                        };
                        oAction = {
                            name: 'delete',
                            historyEvent: 'TEST_DELETED'
                        };
                        return oDBObjectAccess.del(oDeleteObject, fnMessageMock, oCallerContextMock);
                    }).then((vResult) => {
                        expect(vResult).not.to.be.ok;
                        return getLatestHistory(iKey);
                    }).then((aDeleteHistory) => {
                        expect(aDeleteHistory.length).to.eql(1);
                        expect(aDeleteHistory[0]).to.eql({
                            HISTORY_DB_EVENT: "DELETED",
                            HISTORY_BIZ_EVENT: oCallerContextMock.getAction().historyEvent,
                            HISTORY_AT: oCallerContextMock.getRequestTimestamp(),
                            HISTORY_ACTOR: oCallerContext.user.id,
                            ID: iKey,
                            TITLE: 'Changed title',
                            DESCRIPTION: 'Changed description'
                        });
                        return oDBObjectAccess.read(iKey);
                    }).then((oReadObject) => {
                        expect(oReadObject).to.eql(null);
                    });
                });
            });
        });
    });

    it("creates a structured object", () => {
        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            var fnSequenceNode1 = oDBObjectAccess.getSequence({ name: "Node1" });
            var fnSequenceNode2 = oDBObjectAccess.getSequence({ name: "Node2" });
            var fnSequenceNode2_1 = oDBObjectAccess.getSequence({ name: "Node21" });

            return Promise.all([
                fnSequenceRoot(),
                fnSequenceNode1(),
                fnSequenceNode1(),
                fnSequenceNode2(),
                fnSequenceNode2_1(),
                fnSequenceNode2_1(),
                fnSequenceNode2(),
                fnSequenceNode2_1(),
                fnSequenceNode2_1()]).then((aId) => {
                var sRootId = aId[0];
                var oWriteObject = {
                    ID: aId[0],
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description',
                    Node1: _.sortBy([{
                        ID: aId[1],
                        SOMETEXT: 'Instance 1 of Node 1'
                    }, {
                        ID: aId[2],
                        SOMETEXT: 'Instance 2 of Node 1'
                    }], 'ID'),
                    Node2: _.sortBy([{
                        ID: aId[3],
                        SOMETEXT: 'Instance 1 of Node 2',
                        Node21: _.sortBy([{
                            ID: aId[4],
                            SOMETEXT: 'Instance 1 of Node 2_1',
                            ANOTHERONE: null
                        }, {
                            ID: aId[5],
                            SOMETEXT: 'Instance 2 of Node 2_1',
                            ANOTHERONE: null
                        }], 'ID')
                    }, {
                        ID: aId[6],
                        SOMETEXT: 'Instance 2 of Node 2',
                        Node21: _.sortBy([{
                            ID: aId[7],
                            SOMETEXT: 'Instance 3 of Node 2_1',
                            ANOTHERONE: null
                        }, {
                            ID: aId[8],
                            SOMETEXT: 'Instance 4 of Node 2_1',
                            ANOTHERONE: null
                        }], 'ID')
                    }], 'ID')
                };
                return oDBObjectAccess.create(oWriteObject).then((vResult) => {
                    expect(vResult).not.to.be.ok;
                    return oDBObjectAccess.read(sRootId);
                }).then((oReadObject) => {
                    oReadObject.Node1 = _.sortBy(oReadObject.Node1, 'ID');
                    oReadObject.Node2[0].Node21 = _.sortBy(oReadObject.Node2[0].Node21, 'ID');
                    oReadObject.Node2[1].Node21 = _.sortBy(oReadObject.Node2[1].Node21, 'ID');
                    oReadObject.Node2 = _.sortBy(oReadObject.Node2, 'ID');
                    expect(oWriteObject).to.eql(oReadObject);
                });
            });
        });
    });

    it("calculates table row delta", () => {
        var mDelta = SQLObjectAccess._calculateRowDelta({
            Node1: {
                table: TEST_TABLE,
                primaryKey: "ID",
                isDatabasePrimaryKey: true,
                rows: [{
                    ID: 4711,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4712,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }, {
                    ID: 4714,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            },
            Node2: {
                table: TEST_TABLE,
                primaryKey: "ID",
                isDatabasePrimaryKey: true,
                rows: [{
                    ID: 4715,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }, {
                    ID: 4716,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            }
        }, {
            Node1: {
                table: TEST_TABLE,
                primaryKey: "ID",
                isDatabasePrimaryKey: true,
                rows: [{
                    ID: 4712,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4713,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4714,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            },
            Node2: {
                table: TEST_TABLE,
                primaryKey: "ID",
                isDatabasePrimaryKey: true,
                rows: []
            }
        });
        expect(mDelta).to.eql({
            "sap.aof.test.db.test::t_test": {
                primaryKey: "ID",
                isDatabasePrimaryKey: true,
                insertRows: [{
                    ID: 4711,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4715,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }, {
                    ID: 4716,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }],
                updateRows: [{
                    ID: 4712,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }],
                deleteRows: [{
                    ID: 4713,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }]
            }
        });
    });

    it("calculates row deltas for primary keys not being the database primary key", () => {
        // When using none database primary keys (logical primary keys) updates happen as delete and insert
        var mDelta = SQLObjectAccess._calculateRowDelta({
            Node1: {
                table: TEST_TABLE,
                primaryKey: "ID",
                isDatabasePrimaryKey: false,
                rows: [{
                    ID: 4711,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4712,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }, {
                    ID: 4714,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            }
        }, {
            Node1: {
                table: TEST_TABLE,
                primaryKey: "ID",
                isDatabasePrimaryKey: false,
                rows: [{
                    ID: 4712,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4713,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4714,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            }
        });
        expect(mDelta).to.eql({
            "sap.aof.test.db.test::t_test": {
                isDatabasePrimaryKey: false,
                primaryKey: "ID",
                insertRows: [{
                    ID: 4711,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4712,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }],
                updateRows: [],
                deleteRows: [{
                    ID: 4713,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }, {
                    ID: 4712,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            }
        });
    });

    it("calculates history table inserts from delta", () => {
        var oTableDeltas = {
            TEST_TABLE: {
                historyTable: TEST_HISTORY_TABLE,
                primaryKey: "ID",
                node: 'Root',
                insertRows: [{
                    ID: 4711,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }],
                updateRows: [{
                    ID: 4712,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }],
                deleteRows: [{
                    ID: 4713,
                    ATTR1: "Value 1",
                    ATTR2: "Value 2"
                }],
                unchangedRows: [{
                    ID: 4714,
                    ATTR1: "Value 3",
                    ATTR2: "Value 4"
                }]
            }
        };
        var oCallerContextMock = {
            getAction: () => {
                return {
                    name: "update",
                    historyEvent: "TEST_UPDATED"
                };
            },
            getUser: () => {
                return Promise.resolve(oCallerContext.user.id);
            },
            getRequestTimestamp: () => {
                return "2014-01-28T07:49:21.602Z";
            },
            getHistoryEvent: () => {
                return "TEST_UPDATED";
            }
        };
        return SQLObjectAccess._calculateHistoryTable(oTableDeltas, oCallerContextMock).then((oHistoryTableDelta) => {
            expect(oHistoryTableDelta).to.eql({
                "sap.aof.test.db.test::t_test_h": {
                    primaryKey: undefined,
                    node: 'Root',
                    insertRows: [{
                        HISTORY_DB_EVENT: "CREATED",
                        HISTORY_BIZ_EVENT: "TEST_UPDATED",
                        HISTORY_AT: "2014-01-28T07:49:21.602Z",
                        HISTORY_ACTOR: oCallerContext.user.id,
                        ID: 4711,
                        ATTR1: "Value 1",
                        ATTR2: "Value 2"
                    }, {
                        HISTORY_DB_EVENT: "UPDATED",
                        HISTORY_BIZ_EVENT: "TEST_UPDATED",
                        HISTORY_AT: "2014-01-28T07:49:21.602Z",
                        HISTORY_ACTOR: oCallerContext.user.id,
                        ID: 4712,
                        ATTR1: "Value 3",
                        ATTR2: "Value 4"
                    }, {
                        HISTORY_DB_EVENT: "DELETED",
                        HISTORY_BIZ_EVENT: "TEST_UPDATED",
                        HISTORY_AT: "2014-01-28T07:49:21.602Z",
                        HISTORY_ACTOR: oCallerContext.user.id,
                        ID: 4713,
                        ATTR1: "Value 1",
                        ATTR2: "Value 2"
                    }]
                }
            });
        });
    });

    it("reads an object containing a transient field", () => {
        var sRootId;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                attributes: {
                    TRANSIENT_ATTRIBUTE_1: {}
                }
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oCallerContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: "New node title",
                    DESCRIPTION: "New node description"
                }]);
            }).then(() => {
                return oDBObjectAccess.read(sRootId).then((oObject) => {
                    expect(oObject).to.eql({
                        ID: sRootId,
                        TITLE: "New node title",
                        DESCRIPTION: "New node description",
                        TRANSIENT_ATTRIBUTE_1: null
                    });
                });
            });
        });
    });

    it("writes an object containing a transient field", () => {
        var sRootId;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                attributes: {
                    TRANSIENT_ATTRIBUTE_1: {}
                }
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oDBObjectAccess.create({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF",
                    TRANSIENT_ATTRIBUTE_1: "XYZ"
                });
            }).then(() => {
                return oDBObjectAccess.read(sRootId);
            }).then((oObject) => {
                expect(oObject).to.eql({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF",
                    TRANSIENT_ATTRIBUTE_1: null
                });
            });
        });
    });

    it("buffers read accesses", () => {
        var sRootId;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            Root: {
                table: TEST_TABLE
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            var oPreviousObject;

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oDBObjectAccess.create({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF"
                });
            }).then(() => {
                return oDBObjectAccess.read(sRootId);
            }).then((oObject) => {
                oPreviousObject = oObject;
                return oDBObjectAccess.read(sRootId)
            }).then((oObject) => {
                expect(oObject).to.equal(oPreviousObject);
                var oClient = oCallerContext.store.getClient();
                sinon.spy(oClient, "statement");
                return oDBObjectAccess.read(sRootId, undefined, undefined, true)
            }).then((oLockedObject) => {
                // new DB read after lock is acquired
                expect(oLockedObject).not.to.equal(oPreviousObject);
                var oClient = oCallerContext.store.getClient();
                expect(oClient.statement.calledWith('select * from "sap.aof.test.db.test::t_test" where "ID" = ? for update')).to.be.ok;
                oClient.statement.restore();

                oPreviousObject = oLockedObject;
                return oDBObjectAccess.read(sRootId, undefined, undefined, true)
            }).then((oLockedObject) => {
                expect(oLockedObject).to.equal(oPreviousObject);
                oPreviousObject = oLockedObject;
                return oDBObjectAccess.read(sRootId);
            }).then((oObject) => {
                // no new DB read after lock is acquired
                expect(oObject).to.equal(oPreviousObject);
            }).then(() => {
                return oDBObjectAccess.update({
                    ID: sRootId,
                    TITLE: "Change",
                    DESCRIPTION: "DEF"
                });
            }).then(() => {
                return oDBObjectAccess.read(sRootId);
            }).then((oObjectAfterUpdate) => {
                expect(oObjectAfterUpdate).not.to.eql(oPreviousObject);
                return oDBObjectAccess.read(sRootId).then((oObjectAfterUpdateBuffered) => {
                    expect(oObjectAfterUpdateBuffered).to.eql(oObjectAfterUpdate);
                });
            });
        });
    });

    it("buffers are all invalidated", () => {
        var sRootId;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            Root: {
                table: TEST_TABLE
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess1 = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var oDBObjectAccess2 = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess1.getSequence({ name: "Root" });

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oDBObjectAccess1.create({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF"
                });
            }).then(() => {
                return oDBObjectAccess1.read(sRootId);
            }).then((oObject1) => {
                expect(oObject1).to.be.ok;
                return oDBObjectAccess2.read(sRootId);
            }).then((oObject2) => {
                expect(oObject2).to.be.ok;
                return oDBObjectAccess1.del({
                    ID: sRootId
                });
            }).then(() => {
                return oDBObjectAccess1.read(sRootId);
            }).then((oObject1) => {
                expect(oObject1).not.to.be.ok;
                return oDBObjectAccess2.read(sRootId);
            }).then((oObject2) => {
                expect(oObject2).not.to.be.ok;
            });
        });
    });

    it("allows accessing keys by node from an object", () => {
        return Metadata.getMetadata("sap.aof.test.db.test.TestAO", oCallerContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);

            var oNodeKeys = oDBObjectAccess.getNodeKeys({
                ID: 4711,
                Node1: [{
                    ID: 4712
                }, {
                    ID: 4713
                }],
                Node2: [{
                    ID: 4711,
                    Node21: [{
                        ID: 4711
                    }]
                }, {
                    ID: 4712,
                    Node21: [{
                        ID: 4712
                    }]
                }]
            });
            expect(oNodeKeys).to.eql({
                Root: [4711],
                Node1: [4712, 4713],
                Node2: [4711, 4712],
                Node21: [4711, 4712]
            });
        });
    });

    it("updates rows in bulk access", () => {
        var oDBObjectAccess;
        var oMetadataAccess;
        var oTestContext;
        var fnSequenceRoot;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkOneNode", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                historyTable: TEST_HISTORY_TABLE
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oCallerContext.user.id);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oCallerContext.store;
                },
            };
        }).then(() => {
            return Promise.all([fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot()]).then((aKeys) => {
                var iBulkId = aKeys[0];
                return Promise.all([
                    oDBObjectAccess.create({
                        ID: aKeys[0],
                        TITLE: "BULKCHANGE1_" + iBulkId,
                        DESCRIPTION: "A"
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aKeys[1],
                        TITLE: "BULKCHANGE1_" + iBulkId,
                        DESCRIPTION: "B"
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aKeys[2],
                        TITLE: "BULKCHANGE2_" + iBulkId,
                        DESCRIPTION: "C"
                    }, undefined, oTestContext)
                ]).then(() => {
                    createTimestamp();
                    oTestContext.getHistoryEvent = () => {
                        return "CHANGED_IN_BULK";
                    };
                    // Get bulk access which implicitely simulates everything, callers cannot decide any more
                    var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext, true, oDBObjectAccess);
                    expect(oBulkAccess).to.be.ok;
                    return oBulkAccess.update({
                        Root: {
                            DESCRIPTION: "Bulk"
                        }
                    }, {
                        condition: "TITLE = ?",
                        conditionParameters: ["BULKCHANGE1_" + iBulkId]
                    }).then((oResponse) => {
                        expect(oResponse.messages).to.eql([]);
                        expect(oResponse.affectedNodes.Root).to.be.ok;
                        expect(oResponse.affectedNodes.Root.operation).to.eql("update");
                        expect(oResponse.affectedNodes.Root.count).to.eql(2);
                        return oDBObjectAccess.read(aKeys[0]);
                    }).then((oObject) => {
                        // check that nothing has been changed
                        expect(oObject.DESCRIPTION).to.eql("A");
                        return oDBObjectAccess.read(aKeys[1]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).to.eql("B");
                        return oDBObjectAccess.read(aKeys[2]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).to.eql("C");
                    });
                }).then(() => {
                    // Get bulk access which is allowed to update
                    var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext, false, oDBObjectAccess);
                    expect(oBulkAccess).to.be.ok;
                    // Use simulation per call
                    return oBulkAccess.update({
                        Root: {
                            DESCRIPTION: "Bulk"
                        }
                    }, {
                        condition: "TITLE = ?",
                        conditionParameters: ["BULKCHANGE1_" + iBulkId]
                    }, true).then((oResponse) => {
                        expect(oResponse.messages).to.eql([]);
                        expect(oResponse.affectedNodes.Root).to.be.ok;
                        expect(oResponse.affectedNodes.Root.operation).to.eql("update");
                        expect(oResponse.affectedNodes.Root.count).to.eql(2);
                        // check that nothing has been changed
                        return oDBObjectAccess.read(aKeys[0]);
                    }).then((oObject) => {
                        // check that nothing has been changed
                        expect(oObject.DESCRIPTION).to.eql("A");
                        return oDBObjectAccess.read(aKeys[1]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).to.eql("B");
                        return oDBObjectAccess.read(aKeys[2]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).to.eql("C");
                    }).then(() => {
                        // real update without simulation
                        return oBulkAccess.update({
                            Root: {
                                DESCRIPTION: "Bulk"
                            }
                        }, {
                            condition: "TITLE = ?",
                            conditionParameters: ["BULKCHANGE1_" + iBulkId]
                        }).then((oResponse) => {
                            expect(oResponse.messages).to.eql([]);
                            expect(oResponse.affectedNodes.Root).to.be.ok;
                            expect(oResponse.affectedNodes.Root.operation).to.eql("update");
                            expect(oResponse.affectedNodes.Root.count).to.eql(2);
                            return oDBObjectAccess.read(aKeys[0]);
                        }).then((oObject) => {
                            // check that nothing has been changed
                            expect(oObject.DESCRIPTION).to.eql("Bulk");
                            return oDBObjectAccess.read(aKeys[1]);
                        }).then((oObject) => {
                            expect(oObject.DESCRIPTION).to.eql("Bulk");
                            return oDBObjectAccess.read(aKeys[2]);
                        }).then((oObject) => {
                            expect(oObject.DESCRIPTION).to.eql("C");
                        });
                    }).then(() => {
                        return oCallerContext.store.getClient().statement("select * from \"" + TEST_HISTORY_TABLE + "\" where history_biz_event = 'CHANGED_IN_BULK' and id in (?,?,?) order by id").execute(aKeys);
                    }).then((aHistory) => {
                        expect(aHistory.length).to.eql(2);
                        var oHistory0 = _.find(aHistory, (oHistory) => {
                            return oHistory.ID === aKeys[0];
                        });
                        expect(oHistory0.ID).to.be.ok;
                        expect(oHistory0.ID).to.eql(aKeys[0]);
                        expect(oHistory0.DESCRIPTION).to.eql("Bulk");
                        expect(oHistory0.TITLE).to.eql("BULKCHANGE1_" + iBulkId);
                        var oHistory1 = _.find(aHistory, (oHistory) => {
                            return oHistory.ID === aKeys[1];
                        });
                        expect(oHistory1.ID).to.be.ok;
                        expect(oHistory1.ID).to.eql(aKeys[1]);
                        expect(oHistory1.DESCRIPTION).to.eql("Bulk");
                        expect(oHistory1.TITLE).to.eql("BULKCHANGE1_" + iBulkId);
                    });
                });
            });
        });
    });

    it("reads rows in bulk access", () => {
        var oDBObjectAccess;
        var oMetadataAccess;
        var oTestContext;
        var fnSequenceRoot;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkOneNode", oCallerContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });

            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oCallerContext.user.id);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oCallerContext.store;
                }
            };
        }).then(() => {
            return Promise.all([fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot()]).then((aKeys) => {
                var iBulkId = aKeys[0];
                return Promise.all([
                    oDBObjectAccess.create({
                        ID: aKeys[0],
                        TITLE: "READ_BULKTITLE",
                        DESCRIPTION: "Description 1"
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aKeys[1],
                        TITLE: "READ_BULKTITLE",
                        DESCRIPTION: "Description 2"
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aKeys[2],
                        TITLE: "NO_READ_BULKTITLE",
                        DESCRIPTION: "Description 3"
                    }, undefined, oTestContext)
                ]);
            }).then(() => {
                // Get bulk access which implicitly simulates everything, callers cannot decide any more
                var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext, false, oDBObjectAccess);
                expect(oBulkAccess).to.be.ok;

                // Both ways should lead to the same (!) result
                return Promise.all([
                    oBulkAccess.read("Root", {
                        condition: "TITLE = 'READ_BULKTITLE'",
                        conditionParameters: []
                    }),
                    oBulkAccess.read({
                        Root: {}
                    }, {
                        condition: "TITLE = 'READ_BULKTITLE'",
                        conditionParameters: []
                    })
                ]);
            }).then((aResponses) => {
                // Test both results in the same way as they should lead to the same results
                for (var iRespNo = 0; iRespNo < 2; ++iRespNo) {
                    expect(aResponses[iRespNo].messages).to.eql([]);
                    expect(aResponses[iRespNo].operation).to.eql("read");
                    expect(aResponses[iRespNo].count).to.eql(2);
                    _.each(aResponses, (oResponse, iIndex) => {
                        var oResult = _.find(oResponse.result, (oResult) => {
                            return oResult.DESCRIPTION === `Description ${iIndex + 1}` &&
                                oResult.TITLE === "READ_BULKTITLE";
                        });
                        expect(oResult).to.be.ok;
                    });
                }
                return Promise.resolve();
            });
        });
    });

    it("reads rows in bulk access and respects constant keys", () => {
        var fnSequenceRoot;
        var fnSequenceNode3;

        var oMetadataAccess;
        var oDBObjectAccess;

        var sRootId;
        var sNode3Id1;
        var sNode3bId1;
        var sNode3Id2;

        var oBulkAccess;

        var oTestContext = {
            getUser: () => {
                return Promise.resolve(oCallerContext.user.id);
            },
            getHistoryEvent: () => {
                return "CREATED";
            },
            getRequestTimestamp: () => {
                return sTimestamp;
            },
            getStoreAccess: () => {
                return oCallerContext.store;
            }
        };

        return oDB.runAsync('DELETE FROM "sap.aof.test.db.test::t_test_node_3"').then(() => {
            return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkOneNode", oCallerContext, {
                actions: oDummyActions,
                Root: {
                    table: TEST_TABLE,
                    nodes: {
                        Node3: {
                            table: TEST_TABLE_NODE_3,
                            parentKey: "OBJECT_ID",
                            attributes: {
                                OBJECT_TYPE_CODE: {
                                    constantKey: "TYPE_CODE_4712"
                                },
                                ANOTHER_TYPE_CODE: {
                                    constantKey: "TYPE_CODE_4711"
                                }
                            }
                        },
                        Node3b: {
                            table: TEST_TABLE_NODE_3,
                            parentKey: "OBJECT_ID",
                            attributes: {
                                OBJECT_TYPE_CODE: {
                                    constantKey: "TYPE_CODE_4710"
                                },
                                ANOTHER_TYPE_CODE: {
                                    constantKey: "TYPE_CODE_4711"
                                }
                            }
                        }
                    }
                }
            });
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            fnSequenceNode3 = oDBObjectAccess.getSequence({ name: "Node3" });

            return fnSequenceRoot();
        }).then((_sId) => {
            sRootId = _sId;
            return oCallerContext.store.getClient().table(TEST_TABLE).insert([{
                ID: sRootId,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description'
            }]);
        }).then(() => {
            return fnSequenceNode3();
        }).then((_sId) => {
            sNode3Id1 = _sId;
            return oCallerContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                ID: sNode3Id1,
                OBJECT_ID: 'ROOT_ID',
                OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                SOMETEXT: 'Instance 1 of Node 3'
            }]);
        }).then(() => {
            return fnSequenceNode3();
        }).then((_sId) => {
            sNode3bId1 = _sId;
            return oCallerContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                ID: sNode3bId1,
                OBJECT_ID: 'ROOT_ID',
                OBJECT_TYPE_CODE: "TYPE_CODE_4710",
                ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                SOMETEXT: 'Instance 1 of Node 3b'
            }]);
        }).then(() => {
            return fnSequenceNode3();
        }).then((_sId) => {
            sNode3Id2 = _sId;
            // negative case (which should not be read)
            return oCallerContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                ID: sNode3Id2,
                OBJECT_ID: 'ROOT_ID',
                OBJECT_TYPE_CODE: "TYPE_CODE_4713",
                ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                SOMETEXT: 'Instance 3 in table 3'
            }]);
        }).then(() => {
            oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext, false, oDBObjectAccess);
            expect(oBulkAccess).to.be.ok;

            return oBulkAccess.read("Node3", {
                condition: "1 = 1",
                conditionParameters: []
            });
        }).then((oResponse) => {
            expect(oResponse.messages).to.eql([]);
            expect(oResponse.operation).to.eql("read");
            expect(oResponse.count).to.eql(1);
            expect(oResponse.result[0].ID).to.eql(sNode3Id1);
            expect(oResponse.result[0].OBJECT_TYPE_CODE).to.eql('TYPE_CODE_4712');
            expect(oResponse.result[0].ANOTHER_TYPE_CODE).to.eql('TYPE_CODE_4711');
        }).then(() => {
            return oBulkAccess.read("Node3b", {
                condition: "1 = 1",
                conditionParameters: []
            });
        }).then((oResponse) => {
            expect(oResponse.messages).to.eql([]);
            expect(oResponse.operation).to.eql("read");
            expect(oResponse.count).to.eql(1);
            expect(oResponse.result[0].ID).to.eql(sNode3bId1);
            expect(oResponse.result[0].OBJECT_TYPE_CODE).to.eql('TYPE_CODE_4710');
            expect(oResponse.result[0].ANOTHER_TYPE_CODE).to.eql('TYPE_CODE_4711');
        });
    });

    it("updates parent nodes in bulk access", () => {
        var oDBObjectAccess;
        var oTestContext;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkParent", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                historyTable: TEST_HISTORY_TABLE,
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    },
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "A"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            var fnSequenceNode2 = oDBObjectAccess.getSequence({ name: "Node2" });
            var fnSequenceNode21 = oDBObjectAccess.getSequence({ name: "Node21" });
            var fnSequenceNode3 = oDBObjectAccess.getSequence({ name: "Node3" });

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oCallerContext.user.id);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oCallerContext.store;
                }
            };
            return Promise.all([
                fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot(),
                fnSequenceNode2(), fnSequenceNode2(),
                fnSequenceNode21(), fnSequenceNode21(),
                fnSequenceNode3(), fnSequenceNode3()
            ]).then((aKey) => {
                var iBulkId = aKey[0];

                var aRootKeys = [aKey[0], aKey[1], aKey[2]];
                var aNode2Keys = [aKey[3], aKey[4]];
                var aNode21Keys = [aKey[5], aKey[6]];
                var aNode3Keys = [aKey[7], aKey[8]];
                return Promise.all([
                    oDBObjectAccess.create({
                        ID: aRootKeys[0],
                        TITLE: "A",
                        DESCRIPTION: "A",
                        Node2: [{
                            ID: aNode2Keys[0],
                            SOMETEXT: "A Node 2",
                            Node21: [{
                                ID: aNode21Keys[0],
                                SOMETEXT: "A Node 21",
                                ANOTHERONE: "A Node 21 - " + iBulkId
                            }]
                        }]
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aRootKeys[1],
                        TITLE: "B",
                        DESCRIPTION: "B",
                        Node2: [{
                            ID: aNode2Keys[1],
                            SOMETEXT: "B Node 2",
                            Node21: [{
                                ID: aNode21Keys[1],
                                SOMETEXT: "B Node 21",
                                ANOTHERONE: "B Node 21 - " + iBulkId
                            }]
                        }]
                    }, undefined, oTestContext)
                ]).then(() => {
                    oTestContext.getHistoryEvent = () => {
                        return "CHANGED_IN_BULK";
                    };
                    var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext);
                    expect(oBulkAccess).to.be.ok;
                    return oBulkAccess.update({
                        Node21: {
                            SOMETEXT: "BB Node 21",
                            Node2: {
                                Root: {
                                    DESCRIPTION: "BB"
                                }
                            }
                        }
                    }, {
                        // using the (optional) table alias "node" condition: "xyz.ANOTHERONE = ?",
                        condition: "ANOTHERONE = ?",
                        conditionParameters: ["B Node 21 - " + iBulkId],
                        //conditionNodeAlias: "xyz"
                    }).then((oResponse) => {
                        expect(oResponse.messages).to.eql([]);
                        expect(oResponse.affectedNodes.Root.count).to.eql(1);
                        expect(oResponse.affectedNodes.Node2.count).to.eql(0);
                        expect(oResponse.affectedNodes.Node21.count).to.eql(1);
                        return oDBObjectAccess.read(aRootKeys[0]);
                    }).then((oObjectA) => {
                        expect(oObjectA.TITLE).to.eql("A");
                        expect(oObjectA.DESCRIPTION).to.eql("A");
                        expect(oObjectA.Node2[0].SOMETEXT).to.eql("A Node 2");
                        expect(oObjectA.Node2[0].Node21[0].SOMETEXT).to.eql("A Node 21");
                        expect(oObjectA.Node2[0].Node21[0].ANOTHERONE).to.eql("A Node 21 - " + iBulkId);
                        return oDBObjectAccess.read(aRootKeys[1]);
                    }).then((oObjectB) => {
                        expect(oObjectB.TITLE).to.eql("B");
                        expect(oObjectB.DESCRIPTION).to.eql("BB");
                        expect(oObjectB.Node2[0].SOMETEXT).to.eql("B Node 2");
                        expect(oObjectB.Node2[0].Node21[0].SOMETEXT).to.eql("BB Node 21");
                        expect(oObjectB.Node2[0].Node21[0].ANOTHERONE).to.eql("B Node 21 - " + iBulkId);
                        return oCallerContext.store.getClient().statement(
                            "select * from \"" + TEST_HISTORY_TABLE
                            + "\" where history_biz_event = 'CHANGED_IN_BULK' and id in (?) order by id").execute(
                            aRootKeys[1]);
                    }).then((aHistory) => {
                        expect(aHistory.length).to.eql(1);
                        expect(aHistory[0].TITLE).to.eql("B");
                        expect(aHistory[0].DESCRIPTION).to.eql("BB");
                    }).then(() => {
                        oTestContext.getHistoryEvent = () => {
                            return "CREATED";
                        };
                        return oDBObjectAccess.create({
                            ID: aRootKeys[2],
                            TITLE: "B",
                            DESCRIPTION: "B",
                            Node3: [{
                                ID: aNode3Keys[1],
                                SOMETEXT: "B Node 3",
                                ANOTHER_TYPE_CODE: "XYZ - " + iBulkId
                            }]
                        }, undefined, oTestContext);
                    }).then(() => {
                        return oBulkAccess.update({
                            Node3: {
                                SOMETEXT: "BB Node 3",
                                Root: {
                                    TITLE: "BB"
                                }
                            }
                        }, {
                            condition: "another_type_code = ?",
                            conditionParameters: ["XYZ - " + iBulkId]
                        });
                    }).then(() => {
                        return oDBObjectAccess.read(aRootKeys[2]);
                    }).then((oObjectB) => {
                        expect(oObjectB.TITLE).to.eql("BB");
                        expect(oObjectB.Node3[0].SOMETEXT).to.eql("BB Node 3");
                        expect(oObjectB.Node3[0].ANOTHER_TYPE_CODE).to.eql("XYZ - " + iBulkId);
                    });
                });
            });
        });
    });

    it("updates nodes in bulk considering constant keys", () => {
        var oTestContext;
        var oDBObjectAccessA;
        var oDBObjectAccessB;
        var oMetadataA;
        var oMetadataB;
        var fnSequenceRoot;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkA", oCallerContext, {
            Root: {
                table: TEST_TABLE_NODE_3,
                attributes: {
                    OBJECT_TYPE_CODE: {
                        constantKey: "A"
                    }
                }
            }
        }).then((_oMetadataA) => {
            oMetadataA = _oMetadataA;
            oDBObjectAccessA = oCallerContext.store.getObjectAccess(oMetadataA);
            fnSequenceRoot = oDBObjectAccessA.getSequence({ name: "Root" });

            return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkB", oCallerContext, {
                Root: {
                    table: TEST_TABLE_NODE_3,
                    attributes: {
                        OBJECT_TYPE_CODE: {
                            constantKey: "B"
                        }
                    }
                }
            })
        }).then((_oMetadataB) => {
            oMetadataB = _oMetadataB;
            oDBObjectAccessB = oCallerContext.store.getObjectAccess(oMetadataB);
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oCallerContext.user.id);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oCallerContext.store;
                }
            };
        }).then(() => {
            return Promise.all([
                fnSequenceRoot(), fnSequenceRoot()
            ]).then((aKeys) => {
                return Promise.all([
                    oDBObjectAccessA.create({
                        ID: aKeys[0],
                        OBJECT_ID: 11,
                        ANOTHER_TYPE_CODE: "AA",
                        SOMETEXT: "Instance A"
                    }, undefined, oTestContext),
                    oDBObjectAccessB.create({
                        ID: aKeys[1],
                        OBJECT_ID: 11,
                        ANOTHER_TYPE_CODE: "BB",
                        SOMETEXT: "Instance B"
                    }, undefined, oTestContext)
                ]).then(() => {
                    var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataA, oTestContext);
                    return oBulkAccess.update({
                        Root: {
                            SOMETEXT: "Instance Bulk Change"
                        }
                    }, {
                        condition: "OBJECT_ID = ?",
                        conditionParameters: [11]
                    }).then((oResponse) => {
                        expect(oResponse.messages).to.eql([]);
                        return oDBObjectAccessA.read(aKeys[0]);
                    }).then((oObjectA) => {
                        expect(oObjectA.SOMETEXT).to.eql("Instance Bulk Change");
                        return oDBObjectAccessB.read(aKeys[1]);
                    }).then((oObjectB) => {
                        expect(oObjectB.SOMETEXT).to.eql("Instance B");
                        return oBulkAccess.update({
                            Root: {
                                ID: 37237
                            }
                        }, {
                            condition: "OBJECT_ID = ?",
                            conditionParameters: [11]
                        });
                    }).then((oResponse) => {
                        expect(oResponse.messages).to.eql([{
                            severity: Message.MessageSeverity.Fatal,
                            messageKey: 'MSG_AOF_BULK_PK_UPDATE_NOT_ALLOWED',
                            refKey: undefined,
                            refObject: 'sap.aof.test.db.test.TestAOBulkA',
                            refNode: 'Root',
                            refAttribute: undefined,
                            parameters: []
                        }]);
                        return oBulkAccess.update({
                            Root: {
                                OBJECT_TYPE_CODE: "X"
                            }
                        }, {
                            condition: "OBJECT_ID = ?",
                            conditionParameters: [11]
                        });
                    }).then((oResponse) => {
                        expect(oResponse.messages).to.eql([{
                            severity: Message.MessageSeverity.Fatal,
                            messageKey: 'MSG_AOF_BULK_CK_UPDATE_NOT_ALLOWED',
                            refKey: undefined,
                            refObject: 'sap.aof.test.db.test.TestAOBulkA',
                            refNode: 'Root',
                            refAttribute: undefined,
                            parameters: []
                        }]);
                    });
                });
            });
        });
    });

    it("deletes nodes and their subnodes rows in bulk access", () => {
        var oMetadataAccess;
        var oDBObjectAccess;
        var oTestContext;
        var fnSequenceRoot;
        var fnSequenceNode2;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkOneNode", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                historyTable: TEST_HISTORY_TABLE,
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            fnSequenceNode2 = oDBObjectAccess.getSequence({ name: "Node2" });

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oCallerContext.user.id);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oCallerContext.store;
                }
            };
        }).then(() => {
            return Promise.all([
                fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot(),
                fnSequenceNode2(), fnSequenceNode2()
            ]).then((aKey) => {
                var aRootKeys = [aKey[0], aKey[1], aKey[2]];
                var aNode2Keys = [aKey[3], aKey[4]];
                return Promise.all([
                    oDBObjectAccess.create({
                        ID: aRootKeys[0],
                        TITLE: "BULKCHANGE1",
                        DESCRIPTION: "A",
                        Node2: [{
                            ID: aNode2Keys[0],
                            SOMETEXT: "A Node 2"
                        }]
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aRootKeys[1],
                        TITLE: "BULKCHANGE1",
                        DESCRIPTION: "B"
                    }, undefined, oTestContext),
                    oDBObjectAccess.create({
                        ID: aRootKeys[2],
                        TITLE: "BULKCHANGE2",
                        DESCRIPTION: "C",
                        Node2: [{
                            ID: aNode2Keys[1],
                            SOMETEXT: "C Node 2"
                        }]
                    }, undefined, oTestContext)
                ]).then(() => {
                    oTestContext.getHistoryEvent = () => {
                        return "DELETED_IN_BULK";
                    };
                    var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext);
                    expect(oBulkAccess).to.be.ok;
                    return oBulkAccess.del({
                        Root: {}
                    }, {
                        condition: "title = ?",
                        conditionParameters: ["BULKCHANGE1"]
                    });
                }).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                    return oDBObjectAccess.read(aRootKeys[0]);
                }).then((oObjectA) => {
                    expect(oObjectA).to.eql(null);
                    return oDBObjectAccess.read(aRootKeys[1]);
                }).then((oObjectB) => {
                    expect(oObjectB).to.eql(null);
                    return oDBObjectAccess.read(aRootKeys[2]);
                }).then((oObjectC) => {
                    expect(oObjectC.DESCRIPTION).to.eql("C");
                }).then(() => {
                    return oCallerContext.store.getClient().statement(
                        "select * from \"" + TEST_HISTORY_TABLE
                        + "\" where history_biz_event = 'DELETED_IN_BULK' and id in (?,?,?) order by id asc").execute(
                        aRootKeys);
                }).then((aHistory) => {
                    aHistory = _.sortBy(aHistory, 'ID');
                    expect(aHistory.length).to.eql(2);
                    var oHistory0 = _.find(aHistory, (oHistory) => {
                        return oHistory.ID === aRootKeys[0];
                    });
                    expect(oHistory0).to.be.ok;
                    expect(oHistory0.ID).to.eql(aRootKeys[0]);
                    expect(oHistory0.HISTORY_DB_EVENT).to.eql("DELETED");
                    expect(oHistory0.DESCRIPTION).to.eql("A");
                    var oHistory1 = _.find(aHistory, (oHistory) => {
                        return oHistory.ID === aRootKeys[1];
                    });
                    expect(oHistory1).to.be.ok;
                    expect(oHistory1.ID).to.eql(aRootKeys[1]);
                    expect(oHistory1.HISTORY_DB_EVENT).to.eql("DELETED");
                    expect(oHistory1.DESCRIPTION).to.eql("B");
                    return oCallerContext.store.getClient().statement("select * from \"" + TEST_TABLE_NODE_2 + "\" where id in (?,?) order by id")
                        .execute(aNode2Keys);
                }).then((aNode2) => {
                    expect(aNode2.length).to.eql(1);
                    expect(aNode2[0].ID).to.eql(aNode2Keys[1]);
                    expect(aNode2[0].SOMETEXT).to.eql("C Node 2");
                });
            });
        });
    });

    it("deletes child nodes in bulk while updating parent nodes", () => {
        var oMetadataAccess;
        var oDBObjectAccess;
        var oTestContext;

        return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkParent", oCallerContext, {
            Root: {
                table: TEST_TABLE,
                historyTable: TEST_HISTORY_TABLE,
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBObjectAccess = oCallerContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBObjectAccess.getSequence({ name: "Root" });
            var fnSequenceNode2 = oDBObjectAccess.getSequence({ name: "Node2" });
            var fnSequenceNode21 = oDBObjectAccess.getSequence({ name: "Node21" });

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oCallerContext.user.id);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oCallerContext.store;
                }
            };

            return Promise.all([
                fnSequenceRoot(),
                fnSequenceNode2(), fnSequenceNode2(),
                fnSequenceNode21(), fnSequenceNode21()
            ]).then((aKey) => {
                var iBulkId = aKey[0];

                var aRootKeys = [aKey[0]];
                var aNode2Keys = [aKey[1], aKey[2]];
                var aNode21Keys = [aKey[3], aKey[4]];
                return oDBObjectAccess.create({
                    ID: aRootKeys[0],
                    TITLE: "A",
                    DESCRIPTION: "A",
                    Node2: [{
                        ID: aNode2Keys[0],
                        SOMETEXT: "A Node 2.1 - " + iBulkId,
                        Node21: [{
                            ID: aNode21Keys[0],
                            SOMETEXT: "A Node 2.1 / 1",
                            ANOTHERONE: "X"
                        }]
                    }, {
                        ID: aNode2Keys[1],
                        SOMETEXT: "A Node 2.2 - " + iBulkId,
                        Node21: [{
                            ID: aNode21Keys[1],
                            SOMETEXT: "A Node 2.2 / 1",
                            ANOTHERONE: "X"
                        }]
                    }]
                }, undefined, oTestContext).then(() => {
                    oTestContext.getHistoryEvent = () => {
                        return "BULK_DELETE_AND_UPDATE";
                    };
                    var oBulkAccess = oCallerContext.store.getBulkAccess(oMetadataAccess, oTestContext);
                    return oBulkAccess.del({
                        Node2: {
                            Root: {
                                DESCRIPTION: "After Delete Node 2.1"
                            }
                        }
                    }, {
                        condition: "sometext = ?",
                        conditionParameters: ["A Node 2.1 - " + iBulkId]
                    });
                }).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                    return oDBObjectAccess.read(aRootKeys[0]);
                }).then((oObject) => {
                    expect(oObject.DESCRIPTION).to.eql("After Delete Node 2.1");
                    expect(oObject.Node2.length).to.eql(1);
                    expect(oObject.Node2[0].ID).to.eql(aNode2Keys[1]);
                    expect(oObject.Node2[0].SOMETEXT).to.eql("A Node 2.2 - " + iBulkId);
                    expect(oObject.Node2[0].Node21[0].ID).to.eql(aNode21Keys[1]);
                    // Subnode of Node 2.1 needs to be gone as well
                    return oCallerContext.store.getClient().statement("select * from \"" + TEST_TABLE_NODE_2_1 + "\" where id in (?,?) order by id")
                        .execute(aNode21Keys);
                }).then((aNode21) => {
                    expect(aNode21.length).to.eql(1);
                    expect(aNode21[0].ID).to.eql(aNode21Keys[1]);
                });
            });
        });
    });

    it("deletes objects marked as 'cascading delete' when deleting root nodes in bulk", () => {
        var AOF = require("../../../../lib/core/framework");
        var iKey;
        var iBulkId = new Date().getTime();

        return AOF.getApplicationObject("test.object.TestAO", oCallerContext).then((TestAO) => {
            expect(TestAO).to.be.ok;
            AOF.getApplicationObject("test.object.TestAOFK", oCallerContext).then((TestAOFK) => {
                expect(TestAOFK).to.be.ok;
                return TestAO.create({
                    ID: -1,
                    TITLE: "A reference title",
                    DESCRIPTION: "A" + iBulkId
                }).then((oResponse) => {
                    iKey = oResponse.generatedKeys[-1];
                    return TestAOFK.create({
                        ID: -1,
                        OBJECT_ID: iKey,
                        OBJECT_TYPE_CODE: "ABC",
                        ANOTHER_TYPE_CODE: "ABC",
                        SOMETEXT: "Sometext"
                    });
                }).then((oResponse) => {
                    expect(oResponse).to.be.ok;
                    expect(oResponse.messages).to.eql([]);
                    createTimestamp();
                    var oTestContext = {
                        getUser: () => {
                            return Promise.resolve({ id: 42 });
                        },
                        getHistoryEvent: () => {
                            return "BULK_DELETE_CASCADE";
                        },
                        getRequestTimestamp: () => {
                            return sTimestamp;
                        },
                        getStoreAccess: () => {
                            return oCallerContext.store;
                        },
                        getDB: () => {
                            return oCallerContext.store.getDB();
                        },
                        getMetadata: (sObjectName) => {
                            return AOF.getMetadata(sObjectName, oCallerContext);
                        }
                    };
                    var oBulkAccess = oCallerContext.store.getBulkAccess(TestAO.getMetadata(), oTestContext);
                    return oBulkAccess.del({
                        Root: {}
                    }, {
                        condition: "description = ?",
                        conditionParameters: ["A" + iBulkId]
                    });
                }).then((oResponse) => {
                    expect(oResponse.messages).to.eql([]);
                    return oCallerContext.store.getClient().statement(
                        'select * from "sap.aof.test.db.test::t_test_node_3" where object_id = ?').execute(iKey);
                }).then((aFKRefs) => {
                    expect(aFKRefs).to.eql([]);
                    TestAO.close();
                    TestAOFK.close();
                });
            });
        });
    });

});

