sap.ui.define([
    "sap/todo/aof/example/vc/BaseController",
    "sap/todo/aof/example/model/Todo",
    "sap/todo/aof/example/type/IntBooleanType",
    "sap/ui/model/Sorter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device",
    "sap/ui/core/ListItem",
    "sap/m/ListMode",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (BaseController, Todo, IntBooleanType, Sorter, JSONModel, Device, ListItem, ListMode, MessageToast, MessageBox) {
    "use strict";

    return BaseController.extend("sap.todo.aof.example.vc.Todo", {

        types: {
            IntBooleanType: new IntBooleanType()
        },

        formatter: {
            hasPendingChanges: function (iTodoId, dChanged) {
                var oTodo = this.getObjectModel();
                return oTodo.hasPendingChanges();
            },
            isModeDelete: function (bEditable) {
                return bEditable ? ListMode.Delete : ListMode.None;
            }
        },

        onInit: function () {
            BaseController.prototype.onInit.apply(this, arguments);

            this.setViewData({
                edit: false
            });

            this.attachRoutes("todo", this.onTodoMatched);
            if (!Device.system.phone) {
                this.attachRoutes("todoList", this.onTodoListMatched);
            }

            var that = this;
            this.byId("suggestUser").setFilterFunction(function (sValue, oItem) {
                return that.handleUserSuggestFilter(sValue, oItem);
            });

            sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
        },

        onTodoMatched: function (oEvent) {
            var iTodoId = parseInt(oEvent.getParameter("arguments").todoId);
            var oTodo = new Todo(iTodoId, {
                actions: ["update", "del"],
                nodes: ["Root", "Items"],
                continuousUse: true,
                concurrencyEnabled: true,
                changeDetectionProperty: "changed",
                textModel: this.getTextModel()
            });

            var that = this;
            oTodo.getDataInitializedPromise().fail(function () {
                MessageToast.show(that.getText("MSG_TODO_NOT_FOUND"));
                that.navBack();
            });

            this.setObjectModel(oTodo);
            this.removeAllMessages();
        },

        onTodoListMatched: function () {
            this.setObjectModel(null);
        },

        handleUserSuggestFilter: function (sValue, oItem) {
            var oTodo = this.getObjectModel();
            var sItemKey = oItem.getKey();
            if (oTodo.getProperty("/Owner/0/IDENTITY") === sItemKey) {
                return false;
            }
            return jQuery.grep(oTodo.getProperty("/Sharing"), function (oSharing) {
                    return oSharing.IDENTITY === sItemKey;
                }).length === 0;
        },

        handleUserSuggest: function (oEvent) {
            var sSuggestValue = oEvent.getParameter("suggestValue");
            oEvent.getSource().bindAggregation("suggestionItems", {
                path: "data>/User_Root",
                template: new ListItem({
                    key: "{data>USER_NAME}",
                    text: "{data>NAME}",
                    additionalText: "{data>USER_NAME}"
                }),
                sorter: new Sorter("NAME", false),
                filters: [],
                parameters: {
                    custom: {
                        searchText: jQuery.sap.encodeURL(sSuggestValue)
                    },
                    select: "USER_NAME,NAME"
                }
            });
        },

        addSharing: function (oEvent) {
            var oSuggestUser = this.byId("suggestUser");
            var oSelectedItem = oEvent.getParameters().selectedItem;
            if (!oSelectedItem) {
                var aResult = jQuery.grep(oSuggestUser.getSuggestionItems(), function (oSuggestionItem) {
                    return oSuggestionItem.getText() === oSuggestUser.getValue();
                });
                if (aResult.length > 0) {
                    oSelectedItem = aResult[0];
                }
            }
            if (oSelectedItem) {
                var sIdentity = oSelectedItem && oSelectedItem.getKey();
                var sIdentityName = oSelectedItem && oSelectedItem.getText();
                var oTodo = this.getObjectModel();
                oTodo.addSharing({
                    IDENTITY: sIdentity,
                    IDENTITY_NAME: sIdentityName,
                    ROLE_CODE: "sap.todo.xs.object.todo.Todo.Reader"
                });
            }
            oSuggestUser.setValue("");
            oSuggestUser.focus();
        },

        removeSharing: function (oEvent) {
            var oItem = oEvent.getParameter("listItem");
            var oSharing = oItem.getBindingContext("object").getObject();
            var oTodo = this.getObjectModel();
            oTodo.removeSharing(oSharing);
        },

        onEditPressed: function (oEvent) {
            var bEdit = !this.getViewProperty("/edit");
            this.setViewProperty("/edit", bEdit);
            var oList = this.byId("todoItemList");
            if (bEdit) {
                oList.setMode(ListMode.Delete);
            } else {
                oList.setMode(ListMode.None);
            }
        },

        onDetailPress: function (oEvent) {
        },

        onDelete: function (oEvent) {
            var oItem = oEvent.getParameter("listItem");
            this.deleteItem(oItem);
        },

        onSwipeDelete: function (oEvent) {
            var oList = oEvent.getSource().getParent();
            this.deleteItem(oList.getSwipedItem());
            oList.swipeOut();
        },

        deleteItem: function (oItem) {
            var oTodoItem = oItem.getBindingContext("object").getObject();
            this.getObjectModel().removeItem(oTodoItem);
        },

        onRefresh: function () {
            this.byId("todoItemList").getBinding("items").refresh();
        },

        onSelect: function (oEvent) {
            this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
        },

        showDetail: function (oItem) {
            var oTodoItemBindingContext = oItem.getBindingContext("object");
            this.navTo(oTodoItemBindingContext);
        },

        refresh: function () {
            this.onRefresh();
        },

        onDialogOK: function () {
            var that = this;
            var oTodoItemModel = this.oDialog.getModel("item");
            var sText = oTodoItemModel.getProperty("/TEXT");
            var oTodo = this.getObjectModel();
            oTodo.addItem({
                TEXT: sText,
                IS_DONE: 0
            });
            oTodo.setProperty("/IS_DONE", 0);
            that.oDialog.close();
        },

        onDialogCancel: function () {
            this.oDialog.setModel(null, "item");
            this.oDialog.close();
        },

        onIsDoneSelected: function () {
        },

        onCreateTodoItemPressed: function (oEvent) {
            if (!this.oDialog) {
                this.oDialog = sap.ui.xmlfragment("sap.todo.aof.example.vc.fragments.TodoItemCreateDialog", this);
                this.getView().addDependent(this.oDialog);
            }

            var oTodoItemModel = new JSONModel({"TEXT": ""});
            this.oDialog.setModel(oTodoItemModel, "item");
            this.oDialog.open();

            setTimeout(function () {
                sap.ui.getCore().byId("todo-item-text").focus();
            }, 250);
        },

        onSavePressed: function (oEvent) {
            this.save();
        },

        onDeletePressed: function (oEvent) {
            var that = this;
            this.showConfirmation(MessageBox.Icon.QUESTION, that.getText("MSG_TODO_DELETE_MSG"), that.getText("MSG_TODO_DELETE"), function (oAction) {
                if (oAction === MessageBox.Action.OK) {
                    that.setBusy(true);
                    that.getObjectModel().del().done(function () {
                        MessageToast.show(that.getText("MSG_TODO_DELETED"));
                        that.getOwnerComponent().clearDetailView();
                    }).always(function () {
                        that.setBusy(false);
                    });
                }
            });
        },

        save: function (bIgnoreConcurrencyConflict) {
            var that = this;
            this.removeAllMessages();
            this.setBusy(true);
            this.getObjectModel().save(bIgnoreConcurrencyConflict).done(function () {
                MessageToast.show(that.getText("TODO_SAVED"));
            }).fail(function (oResponse) {
                if (oResponse) {
                    if (oResponse.concurrencyConflict) {
                        that.handleConcurrencyConflict();
                    } else {
                        MessageToast.show(that.getText("TODO_SAVE_FAILED"));
                    }
                }
            }).always(function () {
                that.setBusy(false);
            });
        },

        onCancelPressed: function () {
            this.navBack();
        },

        handleConcurrentChanges: function (oObject) {
            if (this.getObjectModel().hasPendingChanges()) {
                this.handleConcurrencyConflict();
            } else {
                var that = this;
                this.showMessage(MessageBox.Icon.Information, this.getText("MSG_TODO_CONCURRENT_CHANGED_MSG"), this.getText("MSG_TODO_CONCURRENT_CHANGED"), function () {
                    that.getObjectModel().sync();
                });
            }
        },

        handleConcurrencyConflict: function () {
            if (!this.oConcurrencyConflictDialog) {
                this.oConcurrencyConflictDialog = sap.ui.xmlfragment("sap.todo.aof.example.vc.fragments.TodoConcurrencyConflictDialog", this);
                this.getView().addDependent(this.oConcurrencyConflictDialog);
            }
            this.oConcurrencyConflictDialog.open();
        },

        onDialogConcurrencyConflictForce: function () {
            this.save(true);
            this.oConcurrencyConflictDialog.close();
        },

        onDialogConcurrencyConflictMerge: function () {
            this.getObjectModel().mergeConcurrentChanges();
            this.oConcurrencyConflictDialog.close();
            MessageToast.show(this.getText("TODO_CHANGES_MERGED"));
        },

        onDialogConcurrencyConflictCancel: function () {
            this.oConcurrencyConflictDialog.close();
        },

        onDialogConcurrencyConflictShowLatestVersion: function () {
            this.getOwnerComponent().navigateToInNewWindow("todo", {
                todoId: this.getObjectModel().getKey()
            });
        },

        navTo: function (oBindingContext) {
            if (!this.oTodoItemPage) {
                this.oTodoItemPage = this.createView("sap.todo.aof.example.vc.TodoItem");
                this.getView().addDependent(this.oTodoItemPage);
            }
            this.oTodoItemPage.setBindingContext(oBindingContext, "object");
            this.oTodoItemPage.setModel(this.getObjectModel(), "object");
            this.showPage(this.oTodoItemPage);
        }
    });
});