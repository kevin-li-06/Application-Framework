"use strict";

/**
 * Response of the Application Object Facade
 * @namespace Response
 */
function Response() {
}

/**
 * Response object
 * @type {Object}
 */
Response.prototype.object = Object;

/**
 * Response action result (only available for action call responses)
 * @type {*}
 */
Response.prototype.result = Object;

/**
 * Array of messages
 * @type {Array<Message>}
 */
Response.prototype.messages = Object;

/**
 * Result messages contains at least one error messages
 * @type {boolean}
 */
Response.prototype.hasErrors = false;

/**
 * Response minimum message severity
 * @type {MessageSeverity}
 */
Response.prototype.minMessageSeverity = 0;

/**
 * Map of generated keys to key handles, e.g. generatedKeys[-1] = 1. Handles are represented by negative numbers and replaced by unique keys (e.g. positive numbers) during processing
 * @type {Object}
 */
Response.prototype.generatedKeys = {};

/**
 * Currently valid concurrency token (if concurrency control is enabled for Application Object)
 * @type {String}
 */
Response.prototype.concurrencyToken = "";