sap.ui.define([
    "sap/m/routing/Router",
    "sap/ui/core/routing/History"
], function (Router, History) {
    "use strict";

    return Router.extend("sap.todo.aof.example.Router", {

        _fnRoutingCallback: undefined,
        _fnCloseCallback: undefined,

        onNavBack: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                this.navTo("home");
            }
        },

        getContext: function () {
            var oHistory = History.getInstance();
            if (typeof oHistory.iHistoryPosition === "number") {
                return oHistory.aHistory[oHistory.iHistoryPosition];
            }
            else {
                return undefined;
            }
        },

        navTo: function (sRoute, oData, bNoHistory, bNoBusy) {
            var oRouter = this;
            var aArguments = arguments;

            var fnNavigate = function () {
                Router.prototype.navTo.apply(oRouter, aArguments);
            };

            var sContext = this.getContext();

            if (this._fnRoutingCallback) {
                this._fnRoutingCallback(fnNavigate, sRoute, sContext);
            } else {
                fnNavigate();
            }
        },

        parse: function (sNewHash) {
            var oRouter = this;
            var fnNavigate = function () {
                Router.prototype.parse.apply(oRouter, [sNewHash]);
            };

            if (this._fnRoutingCallback) {
                this._fnRoutingCallback(fnNavigate);
            } else {
                fnNavigate();
            }
        },

        setRoutingCallback: function (fnCallback) {
            this._fnRoutingCallback = fnCallback;
        },

        setCloseCallback: function (fnCallback) {
            //remove current handler
            if (this._fnCloseCallback) {
                jQuery(window).off('beforeunload', this._fnCloseCallback);
            }
            //set new handler
            this._fnCloseCallback = fnCallback;
            jQuery(window).on('beforeunload', this._fnCloseCallback);
        }
    });
});