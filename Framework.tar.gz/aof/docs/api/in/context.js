"use strict";

/**
 * Runtime context available in Application Object implementation exist
 * @namespace Context
 */
function Context() {
}

/**
 * Returns the caller context passed in, when creating a runtime facade for an application object
 * @returns {Object} Caller context provided during framework instantiation
 */
Context.prototype.getCallerContext = function () {
    return Object;
};

/**
 * Get access to the Store implementation class
 * @returns {StoreAccess} Store access object providing an public interface
 */
Context.prototype.getStoreAccess = function () {
    return Object;
};

/**
 * Get access to the current DB instance
 * @returns {Object} Provided DB object
 */
Context.prototype.getDB = function () {
    return Object;
};

/**
 * Get access to a common wrapper for the current DB instance
 * @returns {DBClient} Common DB Client (e.g. SQL Client)
 */
Context.prototype.getDBClient = function () {
    return Object;
};

/**
 * Retrieve current application user (is returned as parameter of resolved Promise)
 * @returns {Promise.<String>} Promise resolving to the current application user
 */
Context.prototype.getUser = function () {
    return new Promise();
};

/**
 * Get access to the user information available from the JWT token
 * @returns {Object} User information object derived from JWT token
 */
Context.prototype.getUserInfo = function () {
    return Object;
};

/**
 * Get access to the authentication information available from the JWT token
 * @returns {Object} Auth information object derived from JWT token
 */
Context.prototype.getAuthInfo = function () {
    return Object;
};

/**
 * Get current called action metadata object.
 * @returns {Action} Action metadata object of the currently processed action
 * @returns name {String} Name of the currently processed action
 */
Context.prototype.getAction = function () {
    return Object;
};

/**
 * Get current request timestamp (unique for transaction)
 * @returns {Date} Request timestamp as date
 */
Context.prototype.getRequestTimestamp = function () {
    return new Date();
};

/**
 * Get the history event name for the current action
 * @returns {String} History event of the currently processed action
 */
Context.prototype.getHistoryEvent = function () {
    return "";
};

/**
 * Set new history event name for the current action
 * @param sNewHistoryEvent {String} New history event to be set for currently processed action
 */
Context.prototype.setHistoryEvent = function (sNewHistoryEvent) {
};

/**
 * Access to the object currently processed (only for read-only access!)
 * @returns {Object} Application object currently processed
 */
Context.prototype.getProcessedObject = function () {
    return Object;
};

/**
 * Get access to the metadata of another application object (is returned as parameter of resolved Promise)
 * @param sObjectName
 * @returns {Promise<Metadata>} Promise resolving to metadata access object
 */
Context.prototype.getMetadata = function (sObjectName) {
    return new Promise();
};

/**
 * Get runtime access to another application object (is returned as parameter of resolved Promise).
 * @param sObjectName {String} Name of Application Object to get a runtime object for
 * @param [bPrivilegedAuthMode] {Boolean} Allows to access the object in privileged mode, so that no authorization checks are performed (default is true)
 * @returns {Promise.<ApplicationObject>} Promise resolving to the Application Object runtime object
 */
Context.prototype.getApplicationObject = function (sObjectName, bPrivilegedAuthMode) {
    return new Promise();
};
