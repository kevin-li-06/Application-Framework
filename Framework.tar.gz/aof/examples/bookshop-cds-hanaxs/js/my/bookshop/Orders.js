"use strict";

module.exports = {
    actions: {
        cancelOrder: {
            authorizationCheck: false,
            execute: function (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) {
                oWorkObject.status = "canceled";
                return {
                    success: false
                };
            }
        },
        staticCancelOrder: {
            isStatic: true,
            authorizationCheck: false,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getApplicationObject("CatalogService.Orders").then((oOrder) => {
                    return oOrder.update({
                        ID: oParameters.orderID,
                        status: "canceled"
                    }).then((oResponse) => {
                        return {
                            success: !oResponse.hasError
                        };
                    });
                });
            }
        },
        closeOrder: {
            authorizationCheck: false,
            execute: function (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) {
                oWorkObject.status = "closed";
                return oWorkObject;
            }
        },
        createOrder: {
            isStatic: true,
            authorizationCheck: false,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getApplicationObject("CatalogService.Orders").then((oOrder) => {
                    return oOrder.create(oParameters).then((oResponse) => {
                        return oResponse.object;
                    });
                });
            }
        },
        createOrders: {
            isStatic: true,
            authorizationCheck: false,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getApplicationObject("CatalogService.Orders").then((oOrder) => {
                    return Promise.all([
                        oOrder.create(oParameters),
                        oOrder.create(oParameters)
                    ]).then((aResult) => {
                        return aResult.map((oResult) => {
                            return oResult.object;
                        });
                    });
                });
            }
        }
    },
    Root: {
        determinations: {
            onCreate: [initOrder]
        }
    }
};

function initOrder(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) {
    oWorkObject.status = "open";
}