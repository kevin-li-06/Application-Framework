![aof](docs/assets/aof_logo.png)

Easy, Fast and Holistic Development of Data Model Oriented Applications

> AOF (Application Object Framework) allows application developers to concentrate on business logic organized around a data model. It provides a feature set, proven in real-world applications and provides a holistic approach reaching from database to user interface. 

![AOF in a Nutshell](docs/assets/aof_in_a_nutshell.png)

## AOF Landing Page

[AOF Home](https://github.wdf.sap.corp/pages/xs2/aof/)

## GitHub

[xs2/aof](https://github.wdf.sap.corp/xs2/aof)

[Latest Documentation](https://github.wdf.sap.corp/xs2/aof/blob/master/docs/Documentation.md)

## API Documentation

* [Module](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/AOF.html)
* [Object Consumption](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/ApplicationObject.html)
* [Object Definition](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/Schema.SchemaObject.html)
* [Object Implementation](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/ImplementationExit.html)
* [Object Metadata](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/Metadata.html)
* [Object Schema](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/Schema.html)
* [UI5 Lib](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/UI.html)
* [Web Sockets](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/WebSocket.html)
* [Framework Extension](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/Extension.html)
* [All](https://github.wdf.sap.corp/pages/xs2/aof/jsdoc/index.html)

## Getting Started

### Optional: Configure NPM for internal SAP registry

    // Milestone repository
    npm config set registry "https://nexus.wdf.sap.corp:8443/nexus/content/groups/build.milestones.npm/" --scope=@sap
    npm config rm proxy
    npm config rm https-proxy
    npm config set strict-ssl false

### Install

    npm install @sap/aof --save

### Minimalistic Example

#### Object Definition (lib/Todo.js)

```javascript
module.exports = {
    actions: {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    },
    Root: {
        table: "todo",
        attributes: {
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true
            },
            CHANGED_BY: {
                readOnly: true
            },
            TEXT: {
                required: true
            }
        }
    }
};
```

#### Middleware Registration (index.js)

##### HANA

```javascript
var hdbext = require("@sap/hdbext");
var xsenv = require("@sap/xsenv");
var aof = require("@sap/aof");
var app = express();
...
var oConfig = xsenv.getServices({hana: {tag: 'hana'}});
app.use("/",
    hdbext.middleware(oConfig.hana)
);
...
aof.middleware(app, {
    metadata: "/todo/rest/metadata",
    applicationObjects: {
        "lib.Todo": "/todo/rest/todo"
    }
}, oConfig);
...
```

##### Postgres

```javascript
var pg = require("pg");
var aof = require("@sap/aof");
var app = express();

...
var pgPool = new pg.Pool(dbConnectionParams);
...
aof.middleware(app, {
    metadata: "/todo/rest/metadata",
    applicationObjects: {
        "lib.Todo": "/todo/rest/todo"
    }
}, {
    postgres: {
        pgPool: pgPool
    }
});
...
```


##### SQLLite

```javascript
var aof = require("@sap/aof");
var app = express();
...
aof.middleware(app, {
    metadata: "/todo/rest/metadata",
    applicationObjects: {
        "lib.Todo": "/todo/rest/todo"
    }
}, {
    sqlite : {
        db : db
    }
});
...
```

#### Test HTTP Endpoints
 
* Get Metadata: 
    ```
    GET http://localhost:3000/todo/rest/metadata/todo/rest/todo
    ```

* Create Todo Item: 
    ```
    POST http://localhost:3000/todo/rest/todo
    {
        "ID" : -1,
        "TEXT" : "My Todo!"
    }
    ```

* Retrieve Todo Item: 
    ```
    GET http://localhost:3000/todo/rest/todo/<ID>
    ```

## Running Examples

[Examples](examples)

## Step-by-step How-To tutorial

[Building an AOF application](docs/howto/HowTo.md)

## Run Unit-Tests

* Install sqlite3 globally
    ```
    npm install sqlite3 -g
    ```

* Link sqlite3
    ```
    npm ln sqlite3
    ```

* Run Tests
    ```
    npm test
    ```

* Run Integration Tests (HANA)
    ```
    npm run test-hana
    ```

## Project generation

* Install AOF globally
    ```
    npm install @sap/aof -g
    ```
    
* Change into project directory

* Initialize AOF project
    ```
    sap-aof init
    ```

* Install AOF project
    ```
    sap-aof install
    ```

* Start AOF project
    ```
    sap-aof start
    ```

* Run AOF project 

## Documentation

[AOF documentation](docs/Documentation.md)

## Supported Databases

* HANA >= SPS 11
* Postgres
* SQLite (Experimental)
