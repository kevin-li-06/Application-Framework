"use strict";

require("jasmine-before-all");

var supertestAsPromised = require("supertest");
var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");
var AOF = require("../../../");
var Adapter = require("../../../lib/rest/adapter");
var Server = require("../js/testServer.js");

var sUser = "SAP_AOF_APP";
var oStoreInfo;
var oRequest;

describe("SAP/AOF/REST", () => {

    beforeAll(() => {
        oStoreInfo = {
            hana: require("../../hana/js/default-services.json").hana
        };
        oRequest = supertestAsPromised(Server);
    });

    afterAll(() => {
    });

    function createResponseMock() {
        return {
            writeHead: function (sStatus, oHeaders) {
                this.status = sStatus;
                this.contentType = oHeaders["Content-Type"];
            },
            write: function (sBody) {
                this.body = sBody;
            }
        };
    }

    function callWrite(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        oRequest = bUpdate ? oRequest.put(sPath) : oRequest.post(sPath);
        oRequest = oRequest.set("Content-Type", "application/json").send(oPayload);
        _.each(oHeaders || {}, (sValue, sKey) => {
            oRequest.set(sKey, sValue);
        });
        return oRequest;
    }

    function callDel(oRequest, sPath, oHeaders) {
        return oRequest.delete(sPath);
    }

    function callRead(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        return oRequest.get(sPath).set("Accept", "application/json");
    }

    it("CRUDs a simple object from outside without errors", (done) => {
        callWrite(oRequest, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title"
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            var iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            return callRead(oRequest, "/test/object/TestAO.js/" + iId).then((oResponse) => {
                expect(oResponse.statusCode).toBe(_.HTTP.OK);
                expect(oResponse.body).toEqual({
                    "ID": iId,
                    "TITLE": "Test Title",
                    "DESCRIPTION": "Test Title",
                    "Node1": [],
                    "Node2": []
                });
            }).then(function () {
                return callWrite(oRequest, "/test/object/TestAO.js/" + iId, {
                    DESCRIPTION: "Test Description (Update)"
                }, true).then((oResponse) => {
                    expect(oResponse.statusCode).toBe(_.HTTP.OK);
                    expect(oResponse.body.MESSAGES).toEqual([]);
                });
            }).then(function () {
                return callRead(oRequest, "/test/object/TestAO.js/" + iId).then((oResponse) => {
                    expect(oResponse.statusCode).toBe(_.HTTP.OK);
                    expect(oResponse.body).toEqual({
                        "ID": iId,
                        "TITLE": "Test Title",
                        "DESCRIPTION": "Test Description (Update)",
                        "Node1": [],
                        "Node2": []
                    });
                });
            }).then(function () {
                return callWrite(oRequest, "/test/object/TestAO.js/" + iId + "/copy", {
                    ID: -1,
                    DESCRIPTION: "Test Description Copy"
                }).then((oResponse) => {
                    expect(oResponse.body.MESSAGES).toEqual([]);
                    expect(oResponse.statusCode).toBe(_.HTTP.OK);
                    var iCopyId = oResponse.body.GENERATED_KEYS[-1];
                    expect(iCopyId).toBeDefined();
                });
            }).then(function () {
                return callDel(oRequest, "/test/object/TestAO.js/" + iId).then((oResponse) => {
                    expect(oResponse.body.MESSAGES).toEqual([]);
                    expect(oResponse.statusCode).toBe(_.HTTP.OK);
                });
            }).then(function () {
                return callRead(oRequest, "/test/object/TestAO.js/" + iId).then((oResponse) => {
                    expect(oResponse.statusCode).toBe(_.HTTP.NOT_FOUND);
                });
            }).then((e) => {
                done(e);
            });
        });
    });

    it("executes a static custom action", (done) => {
        callWrite(oRequest, "/test/object/TestAO.js/staticCustomAction", {
            PARAMETER1: "Test Parameter"
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.OK);
            expect(oResponse.body.MESSAGES.length).toEqual(1);
            expect(oResponse.body.MESSAGES[0].MESSAGE).toEqual("Test Parameter");

            done();
        });
    });

    it("handles optimistic concurrency locking", (done) => {
        var sGoodEtag = '{"CHANGED_AT":"2014-05-20T14:58:00.123Z"}';

        callWrite(oRequest, "/test/object/TestAOConcurrency.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            CHANGED_AT: "2014-05-20T14:58:00.123Z",
            CHANGED_BY: sUser
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            var iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            return callRead(oRequest, "/test/object/TestAOConcurrency.js/" + iId).then((oResponse) => {
                expect(oResponse.statusCode).toBe(_.HTTP.OK);
                var sEtag = oResponse.headers["etag"];
                expect(sEtag).toBe(sGoodEtag);
            }).then(function () {
                var sOutdatedEtag = '{"CHANGED_AT":"2014-05-20T14:57:50.000Z"}';
                return callWrite(oRequest, "/test/object/TestAOConcurrency.js/" + iId, {
                    ID: iId,
                    DESCRIPTION: "Test Description(Update)"
                }, true, {
                    "If-Match": sOutdatedEtag
                }).then((oResponse) => {
                    expect(oResponse.statusCode).toBe(_.HTTP.PRECONDITION_FAILED);
                    var sEtag = oResponse.headers["etag"];
                    expect(sEtag).toBe(sGoodEtag);
                });
            }).then(function () {
                return callWrite(oRequest, "/test/object/TestAOConcurrency.js/" + iId, {
                    ID: iId,
                    DESCRIPTION: "Test Description (Update)",
                    CHANGED_AT: "2014-05-20T14:59:50.000Z"
                }, true, {
                    "If-Match": sGoodEtag
                }).then((oResponse) => {
                    expect(oResponse.statusCode).toBe(_.HTTP.OK);
                    var sEtag = oResponse.headers["etag"];
                    expect(sEtag).toBe('{"CHANGED_AT":"2014-05-20T14:59:50.000Z"}');
                });
            }).then(function () {
                return callWrite(oRequest, "/test/object/TestAOConcurrency.js/" + iId, {
                    ID: iId,
                    DESCRIPTION: "Test Description (Update)",
                    CHANGED_AT: "2014-05-20T14:59:55.000Z"
                }, true, {
                    "If-Match": "*"
                }).then((oResponse) => {
                    expect(oResponse.statusCode).toBe(_.HTTP.OK);
                    var sEtag = oResponse.headers["etag"];
                    expect(sEtag).toBe('{"CHANGED_AT":"2014-05-20T14:59:55.000Z"}');

                    done();
                });
            });
        });
    });

    it("correctly derives metadata access from HTTP request", function () {
        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/metadata"
        });
        expect(oInfo.isMetadataRequest).toBe(true);
    });

    it("correctly derives properties access from HTTP request", function () {
        var oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/2/properties",
            query: {
                "action": [
                    "update",
                    "customAction",
                    '{ "customAction2" : { "XYZ" : "B" } }'
                ],
                "node": [
                    "Root",
                    "Node1"
                ]
            }
        });
        expect(oInfo.isMetadataRequest).toBe(false);
        expect(oInfo.isPropertiesRequest).toBe(true);
        expect(oInfo.keys).toEqual([2]);
        expect(oInfo.requestedActions).toEqual(["update", "customAction", {
            name: "customAction2",
            parameters: {
                XYZ: "B"
            }
        }]);
        expect(oInfo.requestedNodes).toEqual(["Root", "Node1"]);
        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/properties",
            query: {
                "action": [
                    "all"
                ],
                "key": [
                    "11",
                    "12"
                ]
            }
        });

        expect(oInfo.requestedActions).toBe(true);
        expect(oInfo.requestedNodes).toEqual([]);
        expect(oInfo.keys).toEqual([11, 12]);
        oInfo = Adapter._getRequestInfo({
            method: _.HTTP.GET,
            url: "/test.js/staticProperties",
            query: {
                action: [
                    '{ "create" : { "REF_ID" : 1 } }',
                    '{ "betterCreate" : { "REF_ID_BETTER" : 1 } }'
                ]
            }
        });
        expect(oInfo.requestedActions).toEqual([{
            name: "create",
            parameters: {
                REF_ID: 1
            }
        }, {
            name: "betterCreate",
            parameters: {
                REF_ID_BETTER: 1
            }
        }]);
        expect(oInfo.requestedNodes).toEqual([]);
    });

    it("correctly returns metadata requested from outside", (done) => {
        return callRead(oRequest, "/test/object/TestAO.js/metadata").then((oResponse) => {
            expect(oResponse).toBeDefined();
            oResponse = oResponse.body;
            expect(oResponse.type).toBe("Standard");
            expect(oResponse.nodes.Root.readOnly).toBe(false);
            expect(oResponse.nodes.Root.attributes).toEqual({
                ID: {
                    name: "ID",
                    dataType: AOF.DataType.Integer,
                    isAlternativeKey: false,
                    isConstant: true,
                    required: true,
                    maxLength: 10,
                    isPrimaryKey: true,
                    readOnly: false,
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TITLE: {
                    name: "TITLE",
                    dataType: AOF.DataType.String,
                    isAlternativeKey: false,
                    isConstant: false,
                    required: true,
                    maxLength: 240,
                    isPrimaryKey: false,
                    readOnly: false,
                    concurrencyControl: true,
                    label: "",
                    isName: true,
                    isDescription: true
                },
                DESCRIPTION: {
                    name: "DESCRIPTION",
                    dataType: AOF.DataType.String,
                    isAlternativeKey: false,
                    isConstant: false,
                    required: false,
                    maxLength: 1000,
                    isPrimaryKey: false,
                    readOnly: false,
                    label: "",
                    isName: false,
                    isDescription: false
                }
            });
            expect(oResponse.actions.create).toBeDefined();
            expect(oResponse.actions.copy).toBeDefined();
            expect(oResponse.actions.copy.isStatic).toBe(false);
            expect(oResponse.actions.staticCustomAction).toBeDefined();
            // internal action cannot be called and thus should not be exposed in metadata
            expect(oResponse.actions.internalCustomAction === undefined).toBe(true);

            done();
        });
    });

    it("correctly returns properties requested from outside", (done) => {
        callWrite(oRequest, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            Node2: [{
                ID: -2,
                SOMETEXT: "Blafasel"
            }]
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            var iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            var iNode2Id = oResponse.body.GENERATED_KEYS[-2];
            expect(iNode2Id).toBeDefined();
            return callRead(oRequest, "/test/object/TestAO.js/properties?node=all&action=update&key=" + iId).then((oResponse) => {
                expect(oResponse).toBeDefined();
                oResponse = oResponse.body;
                expect(oResponse[iId].nodes.Root[iId]).toEqual({
                    readOnly: false,
                    messages: [],
                    attributes: {
                        ID: {
                            readOnly: false,
                            messages: []
                        },
                        TITLE: {
                            readOnly: false,
                            messages: []
                        },
                        DESCRIPTION: {
                            readOnly: false,
                            messages: []
                        }
                    }
                });
                expect(oResponse[iId].nodes.Node2[iNode2Id]).toEqual({
                    readOnly: false,
                    messages: [],
                    attributes: {
                        ID: {
                            readOnly: false,
                            messages: []
                        },
                        SOMETEXT: {
                            readOnly: false,
                            messages: []
                        }
                    }
                });
                expect(oResponse[iId].actions.del === undefined).toBe(true);
                expect(oResponse[iId].actions.update).toEqual({
                    readOnly: false,
                    enabled: true,
                    messages: []
                });
                done();
            });
        });
    });

    it("correctly returns static properties requested from outside", (done) => {
        var sAction = encodeURI(JSON.stringify({
            create: {
                REF_ID: 1
            }
        }));

        return callRead(oRequest, "/test/object/TestAO.js/staticProperties?action=" + sAction).then((oResponse) => {
            expect(oResponse).toBeDefined();
            oResponse = oResponse.body;
            expect(oResponse.actions.create).toEqual({
                readOnly: false,
                enabled: true,
                messages: []
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.js/staticProperties?node=Root").then((oResponse) => {
                expect(oResponse).toBeDefined();
                oResponse = oResponse.body;
                expect(oResponse.nodes.Root).toEqual({
                    readOnly: false,
                    attributes: {
                        ID: {
                            readOnly: false
                        },
                        TITLE: {
                            readOnly: false
                        },
                        DESCRIPTION: {
                            readOnly: false
                        }
                    }
                });

                done();
            });
        });
    });

    it("correctly calls request and response mapper functions", (done) => {
        var oMapper = {
            requestMapper: (oRequest) => {
                return {
                    ID: -1,
                    TITLE: "ABC"
                };
            },
            responseMapper: (oResponse, sAction) => {
                return {
                    status: _.HTTP.BAD_REQUEST,
                    contentType: "text/html",
                    body: "<html><p>Hallo!</p></html>"
                };
            }
        };

        var oResponseMock = createResponseMock();
        Adapter._handleRequest("test.object.TestAO", {
            method: _.HTTP.POST,
            url: "test.js",
            storeInfo: oStoreInfo,
            AOF: AOF
        }, oResponseMock, oMapper).then(function () {
            expect(oResponseMock.status).toBe(_.HTTP.BAD_REQUEST);
            expect(oResponseMock.contentType).toBe("text/html");
            expect(oResponseMock.body).toBe("<html><p>Hallo!</p></html>");

            done();
        });
    });
});