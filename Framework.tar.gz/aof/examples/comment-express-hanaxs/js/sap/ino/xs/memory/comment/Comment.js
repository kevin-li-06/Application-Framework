"use strict";

var auth = require("@sap/aof").Authorization;
var determine = require("@sap/aof").Determination;
var check = require("@sap/aof").Check;

var Message = require("./message");
var ObjectIdentityRole = require("../iam/ObjectIdentityRole");

// dataType, maxLength, isPrimaryKey, required can be omitted when derived from table metadata
module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "COMMENT_CREATED"
        },
        update: {
            authorizationCheck: auth.instanceAccessCheck("sap.aof.example.db.comment::v_auth_comment", "COMMENT_ID", Message.AUTH_MISSING_COMMENT_UPDATE),
            historyEvent: "COMMENT_UPDATED"
        },
        del: {
            authorizationCheck: auth.instanceAccessCheck("sap.aof.example.db.comment::v_auth_comment", "COMMENT_ID", Message.AUTH_MISSING_COMMENT_DELETE),
            historyEvent: "COMMENT_DELETED"
        },
        read: {
            authorizationCheck: auth.parentInstanceAccessCheck("sap.aof.example.db.comment::v_auth_comment", "COMMENT_ID", "OBJECT_ID", Message.AUTH_MISSING_COMMENT_READ),
        }
    },
    Root: {
        table: "sap.aof.example.db.comment::t_comment",
        historyTable: "sap.aof.example.db.comment::t_comment_h",
        sequence: "sap.aof.example.db.comment::s_comment",
        determinations: {
            onCreate: [createOwner],
            onModify: [determine.systemAdminData]
        },
        nodes: {
            Owner: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Comment, ObjectIdentityRole.Role.CommentOwner, true)
        },
        attributes: {
            ID: {
                dataType: "INTEGER",
                maxLength: 10,
                isPrimaryKey: true,
                required: true
            },
            OBJECT_ID: {
                dataType: "INTEGER",
                maxLength: 10,
                required: true,
                readOnly: check.readOnlyAfterCreateCheck(Message.COMMENT_OBJECT_UNCHANGEABLE)
            },
            CREATED_AT: {
                dataType: "TIMESTAMP",
                maxLength: 27,
                required: true,
                readOnly: true
            },
            CREATED_BY: {
                dataType: "NVARCHAR",
                maxLength: 256,
                required: true,
                readOnly: true
            },
            CHANGED_AT: {
                dataType: "TIMESTAMP",
                maxLength: 27,
                required: true,
                readOnly: true
            },
            CHANGED_BY: {
                dataType: "NVARCHAR",
                maxLength: 256,
                required: true,
                readOnly: true
            },
            COMMENT: {
                dataType: "NCLOB",
                maxLength: 2147483647,
                required: true
            },
            OBJECT_TYPE_CODE: {
                dataType: "NVARCHAR",
                maxLength: 100,
                constantKey: "COMMENT",
                required: true
            },
            TYPE_CODE: {
                dataType: "NVARCHAR",
                maxLength: 20,
                constantKey: "COMMUNITY_COMMENT"
            }
        }
    }
};

function createOwner(vKey, oWorkObject, oPersistedObject, fnMessage, fnNextHandle, oContext) {
    return oContext.getUser().then(function (sUser) {
        oWorkObject.Owner = [{
            ID: fnNextHandle(),
            IDENTITY: sUser
        }];
    });
}