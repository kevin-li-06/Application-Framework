"use strict";

require("jasmine-before-all");
var io = require("../js/node_modules/socket.io-client");
var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");

var PORT = 3001;
var oServer;

describe("SAP/AOF/SOCKET/GROUP", function () {

    beforeAll((done) => {
        oServer = require("../js/testServer_group.js");
        oServer.listen(PORT, function () {
            done();
        });
    });

    afterAll((done) => {
        oServer.close();
        done();
    });

    var oSocket;

    beforeEach((done) => {
        oSocket = io.connect("http://localhost:" + PORT + "/test/object/TestAO");
        oSocket.on("connect", function () {
            setTimeout(() => {
                done();
            }, 250)
        });
    });

    afterEach((done) => {
        if (oSocket) {
            oSocket.disconnect();
        }
        done();
    });

    it("access single application object via web sockets", (done) => {
        oSocket.emit("create", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title"
        });
        oSocket.on("create", (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) => {
            expect(oResponse).toBeDefined();
            var iId = oResponse.generatedKeys[-1];
            oSocket.emit("wsSubscribe", iId);
            oSocket.emit("update", {
                ID: iId,
                TITLE: "Test Title Update"
            });
            oSocket.on("update", (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) => {
                expect(oResponse).toBeDefined();
                oSocket.emit("wsUnsubscribe", iId);
                done();
            });
        });
    });
});