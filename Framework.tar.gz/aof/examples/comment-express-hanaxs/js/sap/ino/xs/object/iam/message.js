"use strict";

module.exports.DUPLICATE_IDENTITY = "MSG_DUPLICATE_IDENTITY";