var expect = require("chai").expect;
var _ = require("underscore");

var sqlite;
try {
    sqlite = require("sqlite3").verbose();
} catch (ex) {
    console.log(ex);
    console.log("run?: sudo npm ln sqlite3");
    return;
}

var Promise = require("bluebird");
Promise.promisifyAll(sqlite.Database.prototype);

var SqliteClient = require("../../../../lib/db/sqlite/client");

describe("db-sqlite-client", () => {
    var oDB = null;

    beforeEach(() => {
        return new Promise((resolve, reject) => {
            oDB = new sqlite.Database(':memory:', (error) => {
                expect(error).to.be.null;
                oDB.run('CREATE TABLE "t_test" (ID integer PRIMARY KEY, A_VARCHAR varchar(50), A_NVARCHAR nvarchar(50), A_TINYINT tinyint, A_SMALLINT smallint, A_INT integer, A_BIGINT bigint, A_DECIMAL decimal, A_REAL real, A_DOUBLE double, A_FLOAT float, A_CLOB CLOB, A_BLOB BLOB, A_NCLOB TEXT, A_DATE DATE, A_TIME TIME, A_TIMESTAMP TIMESTAMP)',
                    (error) => {
                        if (error) {
                            reject(error);
                        } else {
                            resolve();
                        }
                    });
            });
        });
    });

    it("provides table read access", () => {
        var oClient = new SqliteClient(oDB);
        var oTable = oClient.table('t_test');
        expect(oTable).to.be.ok;

        return oDB.runAsync('INSERT INTO "t_test" (ID, A_VARCHAR, A_NVARCHAR) VALUES (42,\'X\', \'Y\')')
            .then(() => {
                return oTable.read()
                    .then((aResult) => {
                        expect(_.omit(aResult[0], _.isNull)).to.eql({"ID": 42, "A_VARCHAR": "X", "A_NVARCHAR": "Y"});
                    })
                    .then(() => {
                        return oTable.read();
                    })
                    .then((aResult) => {
                        expect(_.omit(aResult[0], _.isNull)).to.eql({"ID": 42, "A_VARCHAR": "X", "A_NVARCHAR": "Y"});
                    });
            });
    });

    describe("fills table content", () => {
        var oTable;

        beforeEach(() => {
            var oClient = new SqliteClient(oDB);
            oTable = oClient.table('t_test');
            expect(oTable).to.be.ok;
        });

        it("inserts undefined and null without exception", () => {
            return oTable.insert({
                A_VARCHAR: null,
                A_NVARCHAR: undefined,
            });
        });

        it("inserts characters", () => {
            return oTable.insert({
                A_VARCHAR: "ABC",
                A_NVARCHAR: "Müller"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].A_VARCHAR).to.eql("ABC");
                    expect(aContent[0].A_NVARCHAR).to.eql("Müller");
                });
            });
        });

        it("inserts numerics", () => {
            return oTable.insert({
                A_TINYINT: 1,
                A_SMALLINT: 31000,
                A_INT: 1000000000,
                A_BIGINT: 100000000000,
                A_DECIMAL: 1.13,
                A_REAL: 3.14,
                A_DOUBLE: 0.12345,
                A_FLOAT: 0.12345
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].A_TINYINT).to.eql(1);
                    expect(aContent[0].A_SMALLINT).to.eql(31000);
                    expect(aContent[0].A_INT).to.eql(1000000000);
                    expect(aContent[0].A_BIGINT.toString()).to.eql("100000000000");

                    expect(aContent[0].A_DECIMAL).to.eql(1.13);
                    expect(Math.round((aContent[0].A_REAL * 100)) / 100).to.eql(3.14);
                    expect(aContent[0].A_DOUBLE).to.eql(0.12345);
                    expect(aContent[0].A_FLOAT).to.eql(0.12345);
                });
            });
        });

        it("inserts blobs", () => {
            return oTable.insert({
                A_CLOB: "ABC",
                A_NCLOB: "検索BuscaSök搜尋TìmkiếmبحثІздеу",
                A_BLOB: "MyString"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].A_CLOB).to.eql("ABC");
                    expect(aContent[0].A_NCLOB).to.eql("検索BuscaSök搜尋TìmkiếmبحثІздеу");
                    expect(aContent[0].A_BLOB).to.eql("MyString");
                });
            });
        });

        it("inserts dates", () => {
            return oTable.insert({
                A_DATE: "2009-01-02",
                A_TIME: "8:00",
                A_TIMESTAMP: "2009-01-02T08:00:12.123Z"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].A_DATE).to.eql("2009-01-02");
                    expect(aContent[0].A_TIME).to.eql("8:00");
                    expect(aContent[0].A_TIMESTAMP).to.eql("2009-01-02T08:00:12.123Z");
                });
            });
        });

        it("inserts bulk data", () => {
            return oTable.insert([{
                A_INT: 4711,
                A_TIMESTAMP: "2009-01-02T08:00:12.123Z",
                A_NVARCHAR: "ABC",
            }, {
                A_INT: 4712,
                A_NVARCHAR: "DEF",
                A_VARCHAR: "XYZ",
                A_TIMESTAMP: "2010-01-02T08:00:12.123Z"
            }]).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent.length).to.eql(2);
                    var oContent = _.findWhere(aContent, {A_NVARCHAR: "ABC"});
                    expect(oContent.A_INT).to.eql(4711);
                    expect(oContent.A_TIMESTAMP).to.eql("2009-01-02T08:00:12.123Z");

                    var oContent = _.findWhere(aContent, {A_NVARCHAR: "DEF"});
                    expect(oContent.A_INT).to.eql(4712);
                    expect(oContent.A_TIMESTAMP).to.eql("2010-01-02T08:00:12.123Z");
                    expect(oContent.A_VARCHAR).to.eql("XYZ");
                });
            });
        });
    });

    describe("upserts table content", () => {
        var oTable;

        beforeEach(() => {
            var oClient = new SqliteClient(oDB);
            oTable = oClient.table('t_test');
            expect(oTable).to.be.ok;
        });

        it("upsert = insert", () => {
            return oTable.upsert({
                ID: 42,
                A_VARCHAR: "Insert"
            }).then(() => {
                return oTable.read().then((aContent) => {
                    expect(aContent[0].ID).to.eql(42);
                    expect(aContent[0].A_VARCHAR).to.eql("Insert");
                });
            });
        });

        it("upsert = update", () => {
            return oTable.insert({
                ID: 43,
                A_VARCHAR: "My Insert",
            }).then(() => {
                return oTable.read();
            }).then((aContent) => {
                expect(aContent[0].A_VARCHAR).to.eql("My Insert");
            }).then(() => {
                return oTable.upsert([{
                    ID: 43,
                    A_VARCHAR: "My Upsert"
                }]);
            }).then(() => {
                return oTable.read();
            }).then((aContent) => {
                expect(aContent.length).to.eql(1);
                expect(aContent[0].A_VARCHAR).to.eql("My Upsert");
            });
        });
    });

    describe("execute a prepared statement", () => {
        it("execute a prepared statement with some parameters [1,2]", () => {
            var oClient = new SqliteClient(oDB);
            oDB.runAsync("create table dummy (DUMMY CHAR(1))"
            ).then(() => {
                return oDB.runAsync("INSERT INTO dummy (DUMMY) VALUES ('X')")
            }).then(() => {
                return oClient.statement([
                    "select * from (",
                    "    select 1 as N from dummy union all",
                    "    select 2 as N from dummy union all",
                    "    select 3 as N from dummy",
                    ") where",
                    "    n >= ? and n <= ?"
                ].join(" ")).execute([1, 2])
            }).then((aResult) => {
                expect(aResult).to.eql([{"N": 1}, {"N": 2}]);
                return oClient.statement("select * from dummy where DUMMY = ?").execute('X');
            }).then((aResult) => {
                expect(aResult).to.eql([{"DUMMY": "X"}]);
            });
        });
    });
});
