#!/usr/bin/env bash

export HDI__HOST=inno-next.mo.sap.corp
export HDI__PORT=30015
export HDI___SYS_DI__USER=SYSTEM
export HDI___SYS_DI__PASSWORD=Toor1234

export HDI__SAP_AOF_EXAMPLE_CHAT__USER=DEPLOYMENT_USER
export HDI__SAP_AOF_EXAMPLE_CHAT__PASSWORD=Test1234

hdi delete -r SAP_AOF_EXAMPLE_CHAT src/
hdi write -r SAP_AOF_EXAMPLE_CHAT src/
hdi make SAP_AOF_EXAMPLE_CHAT @ src/