var expect = require("chai").expect;

var sqlite;
try {
    sqlite = require("sqlite3").verbose();
} catch (ex) {
    console.log(ex);
    console.log("run?: sudo npm ln sqlite3");
    return;
}

var waterfall = require("async-waterfall");

var SQLiteStore = require("../../../../lib/db/sqlite/store");

var store;
var Metadata = require("../../../../lib/core/metadata");

describe("db-sqlite", () => {

    var db = null;
    before(() => {
        return new Promise((resolve, reject) => {
            db = new sqlite.Database(':memory:', (error) => {
                expect(error).to.be.null;
                db.run('CREATE TABLE "test" (ID integer primary key, TITLE varchar(100) not null, DESCRIPTION nvarchar(1000))', (error) => {
                    store = new SQLiteStore({db: db});
                    if (error) {
                        reject(error);
                    } else {
                        resolve();
                    }
                });
            });
        });
    });

    it("loads table metadata", () => {
        return store.getNodeMetadata({
            table: "test"
        }, db).then((oMetadata) => {
            expect(oMetadata.table).to.equal("test");
            expect(oMetadata.primaryKeys).to.eql(["ID"]);
            expect(oMetadata.attributes.ID).to.eql({
                name: "ID",
                dataType: Metadata.DataType.Integer,
                dbDataType: "INTEGER",
                isPrimaryKey: true,
                required: true
            });
            expect(oMetadata.attributes.TITLE).to.eql({
                name: "TITLE",
                dataType: Metadata.DataType.String,
                dbDataType: "VARCHAR",
                maxLength: 100,
                isPrimaryKey: false,
                required: true
            });
            expect(oMetadata.attributes.DESCRIPTION).to.eql({
                name: "DESCRIPTION",
                dataType: Metadata.DataType.String,
                dbDataType: "NVARCHAR",
                maxLength: 1000,
                isPrimaryKey: false,
                required: false
            });
        });
    });
});
