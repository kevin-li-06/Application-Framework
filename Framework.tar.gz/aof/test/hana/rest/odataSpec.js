"use strict";

require("jasmine-before-all");

var fs = require("fs");
var supertestAsPromised = require("supertest");
var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");
var Server = require("../js/testServer.js");

var ODataAdapter = require("../../../lib/rest/extensions/sap-xsodata");

var AOF = require("../../../");

var oContext;
var oOptions;
var oRequest;

describe("SAP/AOF/ODATA", function () {

    beforeAll((done) => {
        oContext = {
            handlerConfiguration: {
                dbConfiguration: {
                    storeInfo: {
                        hana: require("../../hana/js/default-services.json").hana
                    }
                }
            }
        };
        oOptions = {
            AOF: AOF
        };
        oRequest = supertestAsPromised(Server);
        done();
    });

    afterAll((done) => {
        done();
    });

    function callWrite(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        oRequest = bUpdate ? oRequest.put(sPath) : oRequest.post(sPath);
        oRequest = oRequest.set("Content-Type", "application/json").send(oPayload);
        _.each(oHeaders || {}, (sValue, sKey) => {
            oRequest.set(sKey, sValue);
        });
        return oRequest;
    }

    function callRead(oRequest, sPath, oPayload, bUpdate, oHeaders) {
        return oRequest.get(sPath).set("x-forwarded-host", "localhost:3000");
    }

    it("generates entity simple xsodata metadata", (done) => {
        fs.readFile(__dirname + "/data/comment.xsodata", "utf8", (err, data) => {
            ODataAdapter.generateXSODataMetadata({"test/object/Comment": ""}, "test.object.comment", false, oOptions, oContext).then((sXSODataMetadata) => {
                expect(sXSODataMetadata).toEqual(data);
                done();
            });
        });
    });

    it("generates entity complex xsodata metadata", (done) => {
        fs.readFile(__dirname + "/data/testao.xsodata", "utf8", (err, data) => {
            ODataAdapter.generateXSODataMetadata({"test/object/TestAO": ""}, "test.object.testao", false, oOptions, oContext).then((sXSODataMetadata) => {
                expect(sXSODataMetadata).toBe(data);
                done();
            });
        });
    });

    it("generates entities xsodata metadata with foreign key", (done) => {
        fs.readFile(__dirname + "/data/testaofk.xsodata", "utf8", (err, data) => {
            var oApplicationObjects = {
                "test.object.TestAO": "/test/object/TestAO",
                "test.object.TestAOFK": "/test/object/TestAOFK"
            };
            ODataAdapter.generateXSODataMetadata(oApplicationObjects, "test.object.aof", true, oOptions, oContext).then((sXSODataMetadata) => {
                expect(sXSODataMetadata).toBe(data);
                done();
            });
        });
    });

    it("generates entities xsodata metadata with foreign key and cyclic reference", (done) => {
        fs.readFile(__dirname + "/data/testaocka.xsodata", "utf8", (err, data) => {
            var oApplicationObjects = {
                "test.object.TestAOCKA": "/test/object/TestAOCKA"
            };
            ODataAdapter.generateXSODataMetadata(oApplicationObjects, "test.object.aof", true, oOptions, oContext).then((sXSODataMetadata) => {
                expect(sXSODataMetadata).toBe(data);
                done();
            });
        });
    });

    it("fetches the entity metadata", (done) => {
        fs.readFile(__dirname + "/data/testao.odatametadata", "utf8", (err, data) => {
            callRead(oRequest, "/test/object/TestAO.xsodata/$metadata").then((oResponse) => {
                expect(oResponse.text).toEqual(data);
                done();
            });
        });
    });

    it("queries entity instances", (done) => {
        var iId;
        var iNode2Id;
        callWrite(oRequest, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            Node2: [{
                ID: -2,
                SOMETEXT: "Blafasel"
            }]
        }).then((oResponse) => {
            expect(oResponse.statusCode).toEqual(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            iNode2Id = oResponse.body.GENERATED_KEYS[-2];
            expect(iNode2Id).toBeDefined();
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root?$orderby=TITLE%20desc&$format=json").then((oResponse) => {
                expect(oResponse.body.d).toBeDefined();
                expect(oResponse.body.d.results).toBeDefined();
                expect(oResponse.body.d.results.length > 0).toBe(true);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root?$skip=0&$top=1&$format=json").then((oResponse) => {
                expect(oResponse.body.d).toBeDefined();
                expect(oResponse.body.d.results).toBeDefined();
                expect(oResponse.body.d.results.length).toBe(1);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root?$filter=ID%20eq%20" + iId + "&$format=json").then((oResponse) => {
                expect(oResponse.body.d).toBeDefined();
                expect(oResponse.body.d.results).toBeDefined();
                expect(oResponse.body.d.results.length).toBe(1);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root?$filter=ID%20eq%20" + iId + "&$inlinecount=allpages&$format=json").then((oResponse) => {
                expect(oResponse.body.d).toBeDefined();
                expect(oResponse.body.d.results).toBeDefined();
                expect(oResponse.body.d.results.length).toBe(1);
                expect(oResponse.body.d).toEqual({
                    results: [{
                        ID: iId,
                        TITLE: 'Test Title',
                        DESCRIPTION: 'Test Title',
                        __metadata: {
                            uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')',
                            type: 'test.object.testao.RootType'
                        },
                        Node1: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')/Node1'}},
                        Node2: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')/Node2'}}
                    }], __count: '1'
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")?$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        ID: iId,
                        TITLE: 'Test Title',
                        DESCRIPTION: 'Test Title',
                        __metadata: {
                            uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')',
                            type: 'test.object.testao.RootType'
                        },
                        Node1: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')/Node1'}},
                        Node2: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')/Node2'}}
                    }
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/$count").then((oResponse) => {
                expect(oResponse.text > 0).toBe(true);
            });
        }).then(function () {
            done();
        })
    });

    it("queries more entity instances", (done) => {
        var iId;
        var iNode2Id;
        callWrite(oRequest, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            Node2: [{
                ID: -2,
                SOMETEXT: "Blafasel"
            }]
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            iNode2Id = oResponse.body.GENERATED_KEYS[-2];
            expect(iNode2Id).toBeDefined();
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/Node1?$format=json").then((oResponse) => {
                expect(oResponse.body.d).toBeDefined();
                expect(oResponse.body.d.results).toBeDefined();
                expect(oResponse.body.d.results.length).toBe(0);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/Node2?$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        results: [{
                            ID: iNode2Id,
                            PARENT_ID: iId,
                            SOMETEXT: 'Blafasel',
                            __metadata: {
                                uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')',
                                type: 'test.object.testao.Node2Type'
                            },
                            Node21: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')/Node21'}},
                            Root: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')/Root'}}
                        }]
                    }
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Node2(" + iNode2Id + ")/Node21?$format=json").then((oResponse) => {
                expect(oResponse.body.d).toBeDefined();
                expect(oResponse.body.d.results).toBeDefined();
                expect(oResponse.body.d.results.length).toBe(0);
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")?$expand=Node2&$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        ID: iId,
                        TITLE: 'Test Title',
                        DESCRIPTION: 'Test Title',
                        __metadata: {
                            uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')',
                            type: 'test.object.testao.RootType'
                        },
                        Node1: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')/Node1'}},
                        Node2: {
                            results: [{
                                ID: iNode2Id,
                                PARENT_ID: iId,
                                SOMETEXT: 'Blafasel',
                                __metadata: {
                                    uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')',
                                    type: 'test.object.testao.Node2Type'
                                },
                                Node21: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')/Node21'}},
                                Root: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')/Root'}}
                            }]
                        }
                    }
                });
            });
        }).then(function () {
            done();
        });
    });

    it("queries more anf more entity instances", (done) => {
        var iId;
        var iNode2Id;
        callWrite(oRequest, "/test/object/TestAO.js", {
            ID: -1,
            TITLE: "Test Title",
            DESCRIPTION: "Test Title",
            Node2: [{
                ID: -2,
                SOMETEXT: "Blafasel"
            }]
        }).then((oResponse) => {
            expect(oResponse.statusCode).toBe(_.HTTP.CREATED);
            expect(oResponse.body.MESSAGES).toEqual([]);
            iId = oResponse.body.GENERATED_KEYS[-1];
            expect(iId).toBeDefined();
            iNode2Id = oResponse.body.GENERATED_KEYS[-2];
            expect(iNode2Id).toBeDefined();
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/TITLE?$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        TITLE: 'Test Title'
                    }
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/TITLE/$value").then((oResponse) => {
                expect(oResponse.text).toEqual('Test Title');
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")?$select=TITLE,ID&$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        TITLE: 'Test Title',
                        ID: iId,
                        __metadata: {
                            uri: 'http://localhost:3000/test/object/TestAO.odata/Root(' + iId + ')',
                            type: 'test.object.testao.RootType'
                        }
                    }
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/Node2(" + iNode2Id + ")?$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        ID: iNode2Id,
                        PARENT_ID: iId,
                        SOMETEXT: 'Blafasel',
                        __metadata: {
                            uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')',
                            type: 'test.object.testao.Node2Type'
                        },
                        Node21: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')/Node21'}},
                        Root: {__deferred: {uri: 'http://localhost:3000/test/object/TestAO.odata/Node2(' + iNode2Id + ')/Root'}}
                    }
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/Node2(" + iNode2Id + ")/SOMETEXT?$format=json").then((oResponse) => {
                expect(oResponse.body).toEqual({
                    d: {
                        SOMETEXT: 'Blafasel'
                    }
                });
            });
        }).then(function () {
            return callRead(oRequest, "/test/object/TestAO.odata/Root(" + iId + ")/Node2(" + iNode2Id + ")/SOMETEXT/$value").then((oResponse) => {
                expect(oResponse.text).toEqual("Blafasel");
            });
        }).then(function () {
            done();
        });
    });
});