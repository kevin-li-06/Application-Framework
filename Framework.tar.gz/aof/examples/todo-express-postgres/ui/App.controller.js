sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/odata/v2/ODataModel",
    "todo/ToDo"
], function (Controller, ODataModel, ApplicationObject) {
    "use strict";

    return Controller.extend("todo.App", {

        onInit: function () {
            var oDataModel = new ODataModel("/todo/rest/ToDo.odata", false);
            oDataModel.bDisableHeadRequestForToken = true;
            oDataModel.setSizeLimit(20);
            this.getView().setModel(oDataModel);
            var oOutput = this.byId("output");
        },

        onCreate: function (oEvent) {
            var oOutput = this.byId("output");
            var oName = this.byId("name");
            var sName = oName.getValue();
            oName.setValue("");
            if (sName) {
                var oObject = new ApplicationObject({
                    id: -1,
                    text: sName
                });
                oObject.save().done(function (oResponse) {
                    oOutput.getBinding("items").refresh();
                });
            }
        },

        onCloseToDo: function(oEvent) {
            var oOutput = this.byId("output");
            var sKey = oEvent.getSource().getBindingContext().getObject().id;
            ApplicationObject.setClosed(sKey).done(function(){
                oOutput.getBinding("items").refresh();
            });
        }
    });
});