"use strict"

var check = require("@sap/aof").Check;
var Message = require("./message");

module.exports.Role = {
    CommentOwner: "COMMENT_OWNER"
};

module.exports.ObjectType = {
    Comment: "COMMENT"
};

// dataType, maxLength, isPrimaryKey, required can be omitted when derived from table metadata
module.exports.node = function (sObjectType, sRole, bReadOnly) {
    return {
        table: "sap.aof.example.db.iam::t_object_identity_role",
        historyTable: "sap.aof.example.db.iam::t_object_identity_role_h",
        sequence: "sap.aof.example.db.iam::s_object_identity_role",
        parentKey: "OBJECT_ID",
        readOnly: bReadOnly,
        consistencyChecks: [check.duplicateCheck("IDENTITY", Message.DUPLICATE_IDENTITY)],
        attributes: {
            ID : {
                dataType: "INTEGER",
                maxLength: 10,
                isPrimaryKey: true,
                required: true
            },
            OBJECT_TYPE_CODE: {
                dataType: "NVARCHAR",
                maxLength: 100,
                constantKey: sObjectType,
                required: true
            },
            ROLE_CODE: {
                dataType: "NVARCHAR",
                maxLength: 20,
                constantKey: sRole,
                required: true
            },
            IDENTITY: {
                dataType: "NVARCHAR",
                maxLength: 256,
                foreignKeyTo: "sap.ino.xs.memory.iam.Identity.Root",
                required: true
            }
        }
    };
};