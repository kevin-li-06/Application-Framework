"use strict";

/**
 * Message object
 * @namespace Message
 */
function Message() {
}

/**
 * Message severity
 * @type {MessageSeverity}
 */
Message.prototype.severity = 0;

/**
 * Message key
 * @type {String}
 */
Message.prototype.severity = "";


/**
 * Message reference key
 * @type {String}
 */
Message.prototype.refKey = "";

/**
 * Message reference object
 * @type {String}
 */
Message.prototype.refObject = "";

/**
 * Message reference node
 * @type {String}
 */
Message.prototype.refNode = "";

/**
 * Message reference attribute
 * @type {String}
 */
Message.prototype.refAttribute = "";

/**
 * Message parameters
 * @type {String[]}
 */
Message.prototype.parameters = "";