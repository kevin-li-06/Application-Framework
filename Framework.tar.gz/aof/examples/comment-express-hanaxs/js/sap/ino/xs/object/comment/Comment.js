"use strict";

var auth = require("@sap/aof").Authorization;
var determine = require("@sap/aof").Determination;
var check = require("@sap/aof").Check;

var Message = require("./message");
var ObjectIdentityRole = require("../iam/ObjectIdentityRole");

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "COMMENT_CREATED"
        },
        update: {
            authorizationCheck: auth.instanceAccessCheck("sap.aof.example.db.comment::v_auth_comment", "COMMENT_ID", Message.AUTH_MISSING_COMMENT_UPDATE),
            historyEvent: "COMMENT_UPDATED"
        },
        del: {
            authorizationCheck: auth.instanceAccessCheck("sap.aof.example.db.comment::v_auth_comment", "COMMENT_ID", Message.AUTH_MISSING_COMMENT_DELETE),
            historyEvent: "COMMENT_DELETED"
        },
        read: {
            authorizationCheck: auth.parentInstanceAccessCheck("sap.aof.example.db.comment::v_auth_comment", "COMMENT_ID", "ID", Message.AUTH_MISSING_COMMENT_READ),
        }
    },
    Root: {
        table: "sap.aof.example.db.comment::t_comment",
        historyTable: "sap.aof.example.db.comment::t_comment_h",
        sequence: "sap.aof.example.db.comment::s_comment",
        view: "sap.aof.example.db.comment::v_comment",
        determinations: {
            onCreate: [createOwner],
            onModify: [determine.systemAdminData]
        },
        nodes: {
            Owner: ObjectIdentityRole.node(ObjectIdentityRole.ObjectType.Comment, ObjectIdentityRole.Role.CommentOwner, true)
        },
        attributes: {
            OBJECT_ID: {
                readOnly: check.readOnlyAfterCreateCheck(Message.COMMENT_OBJECT_UNCHANGEABLE)
            },
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true
            },
            CHANGED_BY: {
                readOnly: true
            },
            OBJECT_TYPE_CODE: {
                constantKey: "COMMENT"
            },
            TYPE_CODE: {
                constantKey: "COMMUNITY_COMMENT"
            }
        }
    }
};

function createOwner(vKey, oWorkObject, oPersistedObject, fnMessage, fnNextHandle, oContext) {
    return oContext.getUser().then(function (sUser) {
        oWorkObject.Owner = [{
            ID: fnNextHandle(),
            IDENTITY: sUser
        }];
    });
}