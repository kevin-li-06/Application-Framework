"use strict";

/**
 * Access class for the public interface of the inner store implementation
 * @namespace StoreAccess
 */
function StoreAccess() {
}

/**
 * Start the store transaction
 * @return {Promise} Result Promise
 */
StoreAccess.prototype.start = function () {
    return new Promise();
};

/**
 * Commit the store transaction and notify listeners with commit events
 * @return {Promise} Result Promise
 */
StoreAccess.prototype.commit = function () {
    return new Promise();
};

/**
 * Rollback the store transaction
 * @return {Promise} Result Promise
 */
StoreAccess.prototype.rollback = function () {
    return new Promise();
};

/**
 * Close the store
 * @return {Promise} Result Promise
 */
StoreAccess.prototype.close = function () {
    return new Promise();
};

/**
 * Returns the current DB Client access
 * @returns {DBClient}
 */
StoreAccess.prototype.getClient = function () {
    return Object;
};

/**
 * Returns the current DB connection
 * @returns {Object}
 */
StoreAccess.prototype.getDB = function () {
    return Object;
};

/**
 * Returns the currently active user schema
 * @returns {Promise.<String>}
 */
StoreAccess.prototype.getSchema = function () {
    return new Promise();
};

/**
 * Subscribe to a store event
 * @param fnListener {Function} Listener function to be subscribed
 * @param sEvent {String} Event name, one of [TransactionFinished, InvalidateBuffers]
 */
StoreAccess.prototype.subscribe = function (fnListener, sEvent) {
};

/**
 * Unsubscribe from a store event
 * @param fnListener {Function} Listener function to be unsubscribed
 * @param [sEvent] {String} Event name, one of [TransactionFinished, InvalidateBuffers]
 */
StoreAccess.prototype.unsubscribe = function (fnListener, sEvent) {
};

/**
 * Unsubscribe from a store event
 * @param fnListener {Function} Listener function to be unsubscribed
 * @param [sEvent] {String} Event name, one of [TransactionFinished, InvalidateBuffers]
 */
/**
 * Notify registered listeners for an event
 * @param sEvent {String} Event name, one of [TransactionFinished, InvalidateBuffers]
 * @param oParameters {Object} Additional parameters to be send to the registered listeners
 */
StoreAccess.prototype.notifyEvent = function (sEvent, oParameters) {
};

/**
 * Calculate where used keys of referenced application object via foreign key attributes
 * @param oContext {Context} Runtime context object
 * @param vKey {*} Key of the Application Object node
 * @param oFKRootMetadata {Metadata.NodeMetadata} Node metadata of the foreign key root node
 * @param aFKAttribute {Array} Foreign key node attributes
 * @return {Promise.<Array>} Array of where used keys
 */
StoreAccess.prototype.getWhereUsedKeys = function (oContext, vKey, oFKRootMetadata, aFKAttribute) {
    return new Promise();
};

/**
 * Executes an access check based on provided parameters
 * @param oContext {Context} Runtime context object
 * @param vKey {*} Key of the Application Object root node
 * @param sAuthView {String} Authorization view to checked
 * @param sAuthKeyAttribute {String} Attribute name of authorized keys
 * @param sCondition {String} Additional where condition to be checked
 * @return {Promise.<Boolean>} Boolean result of the access check
 */
StoreAccess.prototype.accessCheck = function (oContext, vKey, sAuthView, sAuthKeyAttribute, sCondition) {
    return new Promise();
};

/**
 * Executes an alternative key check based on provided parameters
 * @param oContext {Context} Runtime context object
 * @param oNodeMetadata {Metadata.NodeMetadata} Node metadata of the node to be checked
 * @param sKeyName {String} Key name of the node to be checked
 * @param vKeyValue {*} Key value of the node to be checked
 * @param sAltKeyName {String} Alternative key name of the node to be checked
 * @param vAltKeyValue {*} Alternative Key value of the node to be checked
 * @param bIgnoreCase {Boolean} Flag to indicate ignoring case-sensitivity for comparison
 * @return {Promise.<Boolean>} Boolean result of the alternative key check
 */
StoreAccess.prototype.alternativeKeyCheck = function (oContext, oNodeMetadata, sKeyName, vKeyValue, sAltKeyName, vAltKeyValue, bIgnoreCase) {
    return new Promise();
};

/**
 * Executes a key check based on provided parameters
 * @param oContext {Context} Runtime context object
 * @param sEntity {String} Technical entity to be checked
 * @param sKeyName {String} Foreign key name to be checked in entity
 * @param vKeyValue {*}  Foreign key value to be checked in entity
 * @return {Promise.<Boolean>} Boolean result of the key check
 */
StoreAccess.prototype.keyCheck = function (oContext, sEntity, sKeyName, vKeyValue) {
    return new Promise();
};

/**
 * Function to fill the node bulk operation filters (condition and parameters)
 * @param oContext {Context} Runtime context object
 * @param oCascadeFilter {Object} Cascade filter object to set the condition
 * @param oNodeMetadata {Metadata.NodeMetadata} Node metadata of the node to be checked
 * @param oOperation {Object} Operation descriptiopn
 * @param aFKAttribute {Array}  Foreign key node attributes
 */
StoreAccess.prototype.fillNodeBulkOperationFilter = function (oContext, oCascadeFilter, oNodeMetadata, oOperation, aFKAttribute) {
};
