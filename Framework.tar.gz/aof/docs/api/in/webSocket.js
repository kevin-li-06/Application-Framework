"use strict";

/**
 * Web Socket interface based on Socket.io
 * @namespace WebSocket
 */
function WebSocket() {
}

/**
 * This callback is called for each registered web socket event
 * @callback WebSocket.eventCallback
 * @param vKey {*} Key of the application object instance
 * @param oObject {Object} Application object instance data
 * @param oObjectBefore {Object} Application object instance data before action execution
 * @param [oResponse] {Object} Application object action execution response
 * @param [oResponse.object] {Object} Application object instance data
 * @param [oResponse.messages] {Array} Array of messages
 * @param [oResponse.generatedKeys] {Object} Map of generated keys to key handles, e.g. generatedKeys[-1] = 1. Handles are represented by negative numbers and replaced by unique keys (e.g. positive numbers) during processing
 * @param [oResponse.concurrencyToken] {String} Currently valid concurrency token (if concurrency control is enabled for Application Object)
 * @param [oResponse.result] {Object} Result of the action execution
 * @param [oResponse.action] {Object} Name of the core action executed
 * @param [oResponse.technicalAction] {Object} Name of the technical action (create, update, delete) executed
 * @param [sSessionUUID] {String} External session UUID passed from outside triggering the notification
 */

/**
 * Register of Application Object web socket events.
 * @param sAction {String} Name of the Application Object action executed. Generic "change" action to register to all change events.
 * @param sAction=wsConnect {String} Special Application Object action called when web socket client connects
 * @param sAction=wsDisconnect {String} Special Application Object action called when web socket client disconnects
 * @param fnEventCallback {WebSocket.eventCallback}
 */
WebSocket.prototype.on = function (sAction, fnEventCallback) {
};

/**
 * Execute an Application Object action via web socket. Actions can be any core action of the
 * Application Object Framework including the custom actions.
 * @param sAction {String} Name of the Application Object action to be executed
 * @param sAction=wsSubscribe {String} Special action for registering for an Application Object group (e.g. group based on key)
 * @param sAction=wsUnsubscribe {String} Special action for deregistering from an Application Object group (e.g. group based on key)
 * @param [vParameter] {...Object} Action parameters for action execution
 */
WebSocket.prototype.emit = function (sAction, vParameter) {
};
