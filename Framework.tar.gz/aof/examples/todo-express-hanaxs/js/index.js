"use strict";

var winston = require("winston");
var express = require("express");
var passport = require("passport");
var http = require("http");
var hdbext = require("@sap/hdbext");
var xs2sec = require("@sap/xssec");
var xsenv = require("@sap/xsenv");
var xsodata = require("@sap/xsodata");
var socketio = require("socket.io");
var aof = require("@sap/aof");

var PORT = process.env.PORT || 3000;
winston.level = process.env.winston_level || "error";

var app = express();
var server = http.Server(app);
var io = socketio(server);

passport.use("JWT", new xs2sec.JWTStrategy(xsenv.getServices({uaa: {tag: 'xsuaa'}}).uaa));
app.use(passport.initialize());

var oConfig = xsenv.getServices({hana: {tag: 'hana'}});

// > Remove XS_APPLICATIONUSER to suppress error 455: "the predefined session variable cannot be set via SET command: XS_APPLICATIONUSER" <
var fnGetRequestOptions = hdbext.connectionOptions.getRequestOptions;
hdbext.connectionOptions.getRequestOptions = function(req) { var opt = fnGetRequestOptions(req); delete opt.session.XS_APPLICATIONUSER; return opt; };
// > Only for test purposes! <

var fnPassportMiddleware = passport.authenticate("JWT", {session: false});
var fnHDBMiddleware = hdbext.middleware(oConfig.hana);

app.use("/",
    fnHDBMiddleware,
    fnPassportMiddleware
);

aof.middleware(app, {
    metadata: "/sap/todo/xs/rest/metadata",
    odata: "/sap/todo/xs/rest/aof",
    applicationObjects: {
        "sap.todo.xs.object.todo.Todo": "/sap/todo/xs/rest/Todo",
        "sap.todo.xs.object.tag.Tag": "/sap/todo/xs/rest/Tag",
        "sap.todo.xs.object.iam.Identity": "/sap/todo/xs/rest/Identity",
        "sap.todo.xs.object.iam.User": "/sap/todo/xs/rest/User"
    },
    extensions: {
        odata: {
            name: "@sap/xsodata",
            lib: xsodata,
            parameters: {
                search: {
                    name: "searchText",
                    fuzzy: 0.2
                },
                views: {
                    "sap.todo.xs.object.todo.Todo.Root" : "sap.aof.example.db.todo::v_todo",
                },
                filters: {
                    filterName: {
                        publicTodos: {
                            condition: "sap.aof.example.db.todo::v_todo_public",
                            nodes: ["sap.todo.xs.object.todo.Todo.Root"]
                        },
                        doneTodos: {
                            condition: "sap.aof.example.db.todo::v_todo_done",
                            nodes: ["sap.todo.xs.object.todo.Todo.Root"]
                        }
                    },
                    filterItemsDonePercentGE: {
                        condition: "sap.aof.example.db.todo::v_todo_item_done_percent",
                        nodes: ["sap.todo.xs.object.todo.Todo.Root"],
                        compare: ">="
                    },
                    filterItemsContainsTags: {
                        condition: "sap.aof.example.db.todo::v_todo_item_contains_tags",
                        nodes: ["sap.todo.xs.object.todo.Todo.Root"],
                        separator: ",",
                        compare: "in",
                        match: "all"
                    },
                    filterItemsSearchTag: {
                        condition: "sap.aof.example.db.todo::v_todo_item_search_tag",
                        nodes: ["sap.todo.xs.object.todo.Todo.Root"],
                        compare: "search",
                        fuzzy: 0.2
                    },
                    filterSearch: {
                        condition: "sap.aof.example.db.todo::v_todo_search",
                        nodes: ["sap.todo.xs.object.todo.Todo.Root"],
                        compare: "search",
                        fuzzy: 0.2
                    }
                }
            }
        },
        websocket: {
            name: "socket.io",
            lib: io,
            checkAuth: true,
            checkAuthDelete: "all",
            middleware: [
                fnPassportMiddleware
            ]
        }
    }
}, oConfig);

server.listen(PORT, function () {
    console.log("Todo application is running on port: " + PORT);
});