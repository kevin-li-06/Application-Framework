"use strict";

let AOF = require("../../");
let _ = AOF._;

module.exports = {
    actions: {
        cancelOrder: {
            authorizationCheck: false,
            execute: function () {
                return true;
            }
        },
        staticCancelOrder: {
            authorizationCheck: false,
            isStatic: true,
            execute: function () {
                return true;
            }
        },
        createOrder: {
            isStatic: true,
            authorizationCheck: false,
            execute: function (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) {
                return oContext.getApplicationObject("Service.Orders").then((oOrder) => {
                    return oOrder.create(oParameters).then((oResponse) => {
                        return oResponse.object;
                    });
                });
            }
        }
    },
    Root: {
        determinations: {
            onModify: [initOrder, appendText]
        }
    }
};

function appendText(vKey, oWorkObject, oPersistedObject, fnMessage, fnHandle, oContext) {
    oWorkObject.buyer += " A";
    _.each(oWorkObject.Items || [], (oItem) => {
        oItem.book += " B";
        _.each(oItem.Lines || [], (oLine) => {
            oLine.text += " C";
        });
    });
}

function initOrder(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) {
    oWorkObject.status = "Open";
}