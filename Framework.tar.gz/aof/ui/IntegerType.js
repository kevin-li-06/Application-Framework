sap.ui.define([
    "sap/ui/model/type/Integer"
], function (IntegerType) {
    "use strict";

    return IntegerType.extend("sap.aof.IntegerType", {

        formatValue : function(oValue, sInternalType) {
            return IntegerType.prototype.formatValue.apply(this, [oValue || 0, sInternalType]);
        },

        parseValue : function(oValue, sInternalType) {
            return IntegerType.prototype.parseValue.apply(this, [oValue || 0, sInternalType]);
        },

        validateValue : function(oValue) {
            return IntegerType.prototype.validateValue.apply(this, [oValue]);
        }
    });
});