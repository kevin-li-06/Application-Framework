"use strict";

module.exports = {};