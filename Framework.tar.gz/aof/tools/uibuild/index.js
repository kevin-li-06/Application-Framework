"use strict";

var fs = require("fs");
var path = require("path");

var UglifyJS = require("uglify-js");

var _ = require("../../lib/util/underscore");
var _s = require("underscore.string");

var sLibrary = "sap.aof";
var sVersion = require("../../package.json").version;

var iStartYear = 2015;
var iCurrentYear = new Date().getFullYear();
var sYear = iStartYear === iCurrentYear ? iCurrentYear : iStartYear + "-" + iCurrentYear;

var sSourceDirectory = "../../ui";
var sBuildDirectory = "../../lib/ui";

var sCopyright =
    "/*!\n" +
    " * SAP Application Object Framework (AOF) UI Library\n" +
    " *\n" +
    " * (c) Copyright " + sYear + " SAP SE. All rights reserved\n" +
    " */\n";

var oPreload = {
    "version": "2.0",
    "name": sLibrary + ".library-preload",
    "dependencies": ["sap.ui.core.library-preload"],
    "modules": {}
};

var sAllContent = "";

var aFile = readFiles(sSourceDirectory);
var oResult = UglifyJS.minify(aFile);
fs.writeFileSync(sBuildDirectory + "/library-all.js", sCopyright + oResult.code);

aFile = sortFilesByDependency(aFile);

_.each(aFile, function (sFile) {
    var oResult = UglifyJS.minify(sFile);
    fs.writeFileSync(sBuildDirectory + "/" + path.basename(sFile), sCopyright + oResult.code);
    oPreload.modules[sLibrary.replace(/\./g, "/") + "/" + path.basename(sFile, ".js").replace(/\./g, "/") + ".js"] = sCopyright + oResult.code;

    var sContent = fs.readFileSync(sFile);
    fs.writeFileSync(sBuildDirectory + "/" + path.basename(sFile, ".js") + "-dbg.js", sCopyright + sContent);
    sAllContent += sContent + "\n\n";
});

fs.writeFileSync(sBuildDirectory + "/library-all-dbg.js", sCopyright + sAllContent);
fs.writeFileSync(sBuildDirectory + "/library-preload.json", JSON.stringify(oPreload, null, 4));

console.log("Build of \"" + sLibrary + " (" + sVersion + ")\" successfully finished.");

function sortFilesByDependency(aFile) {
    var aSortedFile = [];
    _.each(aFile, function (sFile) {
        var sContent = fs.readFileSync(sFile, "utf-8");
        var rDependency = new RegExp("\"" + sLibrary.replace(/\./g, "\\/") + "\/(.*)\"", "g");
        var aMatch;
        while (aMatch = rDependency.exec(sContent)) {
            var sDependency = sSourceDirectory + "/" + aMatch[1] + ".js";
            var iIndex = _.indexOf(aSortedFile, sDependency);
            if (iIndex >= 0) {
                aSortedFile.splice(iIndex, 1);
            }
            aSortedFile.unshift(sDependency);
        }
        if (!_.contains(aSortedFile, sFile)) {
            aSortedFile.push(sFile);
        }
    });
    return aSortedFile;
}

function readFiles(sDirectory) {
    var aFile = [];
    _.each(fs.readdirSync(sDirectory), function (sFile) {
        if (_s.endsWith(sFile, ".js")) {
            var sFilePath = sDirectory + '/' + sFile;
            aFile.push(sFilePath);
        }
    });
    return aFile;
}