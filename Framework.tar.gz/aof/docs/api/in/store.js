"use strict";

/**
 * Store implementations
 * @namespace Store
 */
function Store() {
}

/**
 * Access to the SQLite Store
 * @returns {StoreAccess} SQLite Store
 */
Store.prototype.SQLite = function () {
    return Object;
};

/**
 * Access to the Postgres Store
 * @returns {StoreAccess} Postgres Store
 */
Store.prototype.Postgres = function () {
    return Object;
};
