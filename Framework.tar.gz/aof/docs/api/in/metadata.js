"use strict";

/**
 * Metadata access interface, to read Application Object metadata for node, actions and attribute.
 * Metadata is derived from the Application Object definition, based on the schema definitions.
 * @namespace Metadata
 * @see {@link Schema.SchemaObject} Node Metadata is derived from object schema definition
 */
function Metadata() {
}

/**
 * Registers and metadata enrichment object
 * @param oMetadataEnrichment {Metadata.MetadataEnrichment} Metadata Enrichment Object
 */
Metadata.prototype.enrichMetadata = function (oMetadataEnrichment) {
};

/**
 * Metadata enrichment object
 * @namespace MetadataEnrichment
 * @memberof Metadata
 * @type {Object}
 */
function MetadataEnrichment() {
}

/**
 * Enrich metadata object
 * @memberof Metadata.MetadataEnrichment
 * @param oObject {ObjectMetadata} Metadata object
 */
MetadataEnrichment.prototype.enrichObject = function (oObject) {
};

/**
 * Enrich metadata node
 * @memberof Metadata.MetadataEnrichment
 * @param oNode {NodeMetadata} Metadata node
 * @param oObject {ObjectMetadata} Metadata context object of Metadata attribute
 */
MetadataEnrichment.prototype.enrichNode = function (oNode, oObject) {
};

/**
 * Enrich metadata attribute
 * @memberof Metadata.MetadataEnrichment
 * @param oAttribute {AttributeMetadata} Metadata attribute
 * @param oNode {NodeMetadata} Metadata context node of Metadata attribute
 * @param oObject {ObjectMetadata} Metadata context object of Metadata attribute
 */
MetadataEnrichment.prototype.enrichAttribute = function (oAttribute, oNode, oObject) {
};

/**
 * Metadata interface on object level
 * @namespace ObjectMetadata
 * @memberof Metadata
 * @type {Object}
 * @see {@link Schema.SchemaObject} Object metadata is derived from object schema definition
 */
function ObjectMetadata() {
}

/**
 * Name of Application Object
 * @name name
 * @memberof Metadata.ObjectMetadata
 * @instance
 * @type {String}
 */
ObjectMetadata.prototype.name = String;

/**
 * Tyoe of Application Object
 * @name type
 * @memberof Metadata.ObjectMetadata
 * @instance
 * @type {ObjectType}
 */
ObjectMetadata.prototype.type = String;

/**
 * Is concurrency control enabled for application object
 * @name isConcurrencyControlEnabled
 * @memberof Metadata.ObjectMetadata
 * @instance
 * @type {boolean}
 */
ObjectMetadata.prototype.isConcurrencyControlEnabled = false;

/**
 * Cascade delete configuration for application object
 * @name cascadeDelete
 * @memberof Metadata.ObjectMetadata
 * @instance
 * @type {Array.<String>}
 */
ObjectMetadata.prototype.cascadeDelete = [];

/**
 * Specifies the describing label
 * @name label
 * @memberOf Metadata.ObjectMetadata
 * @instance
 * @type {String}
 */
ObjectMetadata.prototype.label = [];

/**
 * Metadata interface on node level
 * @namespace NodeMetadata
 * @memberof Metadata
 * @type {Object}
 * @see {@link Schema.SchemaNode} Node metadata is derived from node schema definition
 * @see {@link Schema.SchemaRootNode} Root node metadata is derived from root node schema definition
 */
function NodeMetadata() {
}

/**
 * Metadata interface on action level
 * @namespace ActionMetadata
 * @memberof Metadata
 * @type {Object}
 * @see {@link Schema.SchemaAction} Action metadata is derived from action schema definition
 * @see {@link Schema.SchemaCustomAction} Custom action metadata is derived from custom action schema definition
 */
function ActionMetadata() {
}

/**
 * Metadata interface on attribute level
 * @namespace AttributeMetadata
 * @memberof Metadata
 * @type {Object}
 * @see {@link Schema.SchemaAttribute} Attribute metadata is derived from attribute schema definition
 */
function AttributeMetadata() {
}

/**
 * Qualified node name
 * @name qualifiedName
 * @memberof Metadata.NodeMetadata
 * @instance
 * @type {String}
 */
NodeMetadata.prototype.qualifiedName = String;

/**
 * Map of node attributes names to attribute metadata definition
 * @name attributes
 * @memberof Metadata.NodeMetadata
 * @instance
 * @type {Object.<String, Metadata.AttributeMetadata>}
 */
NodeMetadata.prototype.attributes = {};

/**
 * Access to complete Application Object metadata
 * @name objectMetadata
 * @memberof Metadata.NodeMetadata
 * @instance
 * @type {Metadata}
 */
NodeMetadata.prototype.objectMetadata = {};

/**
 * Returns the object metadata
 * @returns {Metadata.ObjectMetadata} Object metadata
 */
Metadata.prototype.getObjectMetadata = function () {
    return Object;
};

/**
 * Returns the node key value for a specified node and the node data
 * @param sNodeName {String} Node name
 * @param oNodeData {Object} Node data containing the key
 * @returns {*} Node key value
 */
Metadata.prototype.getNodeKeyValue = function getNodeKeyValue(sNodeName, oNodeData) {
    return "";
};

/**
 * Sets the node key value for a specified node and the node data
 * @param sNodeName {String} Node name
 * @param vKey {*} Node key value to be set
 * @param oNodeData {Object} Node data to be updated with the key
 */
Metadata.prototype.setNodeKeyValue = function (sNodeName, vKey, oNodeData) {
};

/**
 * Returns the node metadata
 * @param sNodeName {String} Node name
 * @returns {Metadata.NodeMetadata} Node metadata object
 */
Metadata.prototype.getNodeMetadata = function (sNodeName) {
    return Object;
};

/**
 * Returns an array of all node metadata objects
 * @returns {Array.<Metadata.NodeMetadata>} Array of all node metadata objects
 */
Metadata.prototype.getAllNodeMetadata = function () {
    return Array;
};

/**
 * Returns an array of all sub-nodes metadata to a specific node
 * @param vNode {(String|Object)} Node name or node metadata object
 * @returns {Array.<Metadata.NodeMetadata>} Array of sub-node metadata object
 */
Metadata.prototype.getSubNodeMetadata = function (vNode) {
    return Array;
};

/**
 * Returns the parent node metadata for a specific node
 * @param vNode {(String|Object)} Node name or node metadata object
 * @returns {Metadata.NodeMetadata} Node metadata object of parent node
 */
Metadata.prototype.getParentNodeMetadata = function (vNode) {
    return Object;
};

/**
 * Returns all actions of an application object
 * @returns {Object.<String, Metadata.ActionMetadata>} Map of action names to action metadata definition
 */
Metadata.prototype.getActions = function () {
    return Object;
};

/**
 * Returns the exports of the application object library module
 * @type {Object}
 */
Metadata.prototype.exports = Object;
