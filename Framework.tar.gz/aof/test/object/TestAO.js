"use strict";

var Message = require("../../lib/core/message");

module.exports = {
    isExtensible: true,
    cascadeDelete: ["test.object.TestAOFK"],
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        copy: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        update: {
            authorizationCheck: false,
            historyEvent: "TEST_UPDATED"
        },
        del: {
            authorizationCheck: false,
            historyEvent: "TEST_DELETED"
        },
        read: {
            authorizationCheck: false
        },
        instanceAction: {
            authorizationCheck: false,
            execute: (vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext) => {
                oWorkObject.TITLE += oParameters.TEXT;
            },
            historyEvent: "TEST_UPDATED"
        },
        staticCustomAction: {
            isStatic: true,
            authorizationCheck: false,
            execute: (oParameters, oBulkAccess, addMessage) => {
                addMessage(Message.MessageSeverity.Info, oParameters.PARAMETER1);
            }
        },
        internalCustomAction: {
            isStatic: true,
            isInternal: true,
            authorizationCheck: false,
            execute: () => {
            }
        },
        readOnlyCustomAction: {
            isStatic: true,
            readOnly: true,
            authorizationCheck: false,
            execute: (oParameters, oBulkAccess, addMessage) => {
                addMessage(Message.MessageSeverity.Info, oParameters.PARAMETER1);
            }
        },
        notExposedAction: {
            isExposed: false,
            isStatic: true,
            authorizationCheck: false,
            execute: (oParameters, oBulkAccess, addMessage) => {
                addMessage(Message.MessageSeverity.Info, oParameters.PARAMETER1);
            }
        },
        wsConnect: {
            authorizationCheck: false,
            isStatic: true,
            execute: (oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) => {
                return {
                    action: "wsConnect"
                };
            }
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test",
        historyTable: "sap.aof.test.db.test::t_test_h",
        sequence: "sap.aof.test.db.test::s_test",
        attributes: {
            TITLE: {
                required: true,
                concurrencyControl: true,
                isName: true,
                isDescription: true
            }
        },
        nodes: {
            Node1: {
                table: "sap.aof.test.db.test::t_test_node_1",
                sequence: "sap.aof.test.db.test::s_test_node_1",
                parentKey: "PARENT_ID"
            },
            Node2: {
                table: "sap.aof.test.db.test::t_test_node_2",
                sequence: "sap.aof.test.db.test::s_test_node_2",
                parentKey: "PARENT_ID",
                nodes: {
                    Node21: {
                        table: "sap.aof.test.db.test::t_test_node_2_1",
                        sequence: "sap.aof.test.db.test::s_test_node_2_1",
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }
    }
};
