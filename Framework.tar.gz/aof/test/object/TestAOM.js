"use strict";

module.exports = {
    actions: {
        create: {
            authorizationCheck: false,
            historyEvent: "TEST_CREATED"
        },
        read: {
            authorizationCheck: false
        },
        customAction: {
            massActionName: "doCustomMassAction",
            authorizationCheck: false,
            execute: (vKey, oParams, oWorkObject, fnMessage, oContext, fnNextHandle) => {
                oWorkObject.DESCRIPTION = oParams.NEW_DESCRIPTION + " " + vKey;
                return "Result_" + vKey;
            }
        }
    },
    Root: {
        table: "sap.aof.test.db.test::t_test",
        sequence: "sap.aof.test.db.test::s_test",
        attributes: {
            TITLE: {
                required: true
            }
        }
    }
};
