sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/aof/MetaModel",
    "sap/aof/PropertyModel",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/app/Todo"
], function (Controller, MetaModel, PropertyModel, ODataModel, ApplicationObject) {
    "use strict";

    return Controller.extend("sap.app.App", {

        setToDoneEnabled: PropertyModel.getActionEnabledStaticFormatter("sap.app.rest.Todo", "setToDone"),

        onInit: function () {
            this.getView().setModel(MetaModel, "meta");

            var oDataModel = new ODataModel("/sap/app/rest/Todo.odata", false);
            oDataModel.bDisableHeadRequestForToken = true;
            oDataModel.setUseBatch(false);
            oDataModel.setSizeLimit(20);
            this.getView().setModel(oDataModel);

            var oOutput = this.byId("output");
            var oSocket = io("/sap/app/rest/Todo");
            oSocket.on("change", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
                oOutput.getBinding("items").refresh();
            });
        },

        onSetToDone: function (oEvent) {
            var iKey = oEvent.getSource().getBindingContext().getProperty("ID");
            ApplicationObject.setToDone(iKey);
        },

        onDelete: function (oEvent) {
            var iKey = oEvent.getParameter("listItem").getBindingContext().getProperty("ID");
            ApplicationObject.del(iKey);
        },

        onCreate: function (oEvent) {
            var oName = this.byId("name");
            var sName = oName.getValue();
            oName.setValue("");
            if (sName) {
                var oObject = new ApplicationObject({
                    ID: -1,
                    NAME: sName,
                    IS_DONE: 0
                });
                oObject.save();
            }
        }
    });
});