sap.ui.define([
    "sap/aof/ApplicationObject",
    "sap/aof/ReadSource"
], function (ApplicationObject, ReadSource) {
    "use strict";

    return ApplicationObject.extend("sap.ui.aof.test.model.Comment", {
        objectName: "sap.ino.xs.rest.common.Comment",
        readSource: ReadSource.getDefaultAOFSource(),
        invalidation: {
            entitySets: ["Root"]
        }
    });
});