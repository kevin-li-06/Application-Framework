"use strict";

var tables = require("./lib/db/tables");

var express = require("express");
var sqlite3 = require("sqlite3").verbose();
var aof = require("@sap/aof");
var xsodata = require("@sap/xsodata");

var PORT = process.env.PORT || 3000;

var app = express();
var db = new sqlite3.Database(':memory:', function onSQLiteInit(error) {
    console.log(error ? "Error when starting SQLite:" + error : "SQLLite succesfully started");
    if (error) {
        return;
    }
    tables.setUp(db, function (error) {
        if (error) {
            console.log(error);
            return;
        }

        db.on('trace', function (sql) {
            console.log('SQLite: ' + sql);
        });

        app.use('/', express.static('ui'));
        app.use(function (req, res, next) {
            req.user = {
                id: 42
            };
            next();
        });

        aof.middleware(app, {
            metadata: "/todo/rest/metadata",
            applicationObjects: {
                "todo": "/todo/rest/Todo"
            },
            rootPath: "lib",
            extensions: {
                odata: {
                    name: "@sap/xsodata",
                    lib: xsodata,
                    dbAdapter: aof.Adapter.sqliteXSODataDbAdapter
                }
            }
        }, {
            sqlite: {
                db: db
            }
        });

        app.listen(PORT, function () {
            console.log("ToDo AOF example running on port " + PORT);
        });
    });
});