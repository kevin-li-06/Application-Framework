sap.ui.define([
    "sap/ui/base/Object"
], function (Object) {
    "use strict";

    return Object.extend("sap.aof.ui.test.view.CommentDialog", {

        setModel : function() {
            this._getDialog().setModel.apply(this._getDialog(), arguments);
        },

        _getDialog: function () {
            if (!this._oDialog) {
                this._oDialog = sap.ui.xmlfragment("sap.ui.aof.test.view.CommentDialog", this);
            }
            return this._oDialog;
        },

        open: function (oView, fnPost) {
            this.fnPost = fnPost;
            var oDialog = this._getDialog();
            oView.addDependent(oDialog);
            oDialog.open();
        },

        onPostDialog: function () {
            this.fnPost();
            this.fnPost = null;
            this._getDialog().close();
        },

        onCloseDialog: function () {
            this.fnPost = null;
            this._getDialog().close();
        }
    });
});