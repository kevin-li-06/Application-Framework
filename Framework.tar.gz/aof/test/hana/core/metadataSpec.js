"use strict";

var Promise = require("bluebird");
Promise.longStackTraces();

require("jasmine-before-all");

var _ = require("../../../lib/util/underscore");
var Metadata = require("../../../lib/core/metadata");
var StoreFactory = require("../../../lib/db/store-factory");
var HANAStore = require("../../../lib/db/hana/store");

var oContext;

describe("SAP/AOF/CORE/METADATA", () => {

    var TEST_TABLE = 'sap.aof.test.db.test::t_test';

    var oDummyActions = {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: false
        },
        del: {
            authorizationCheck: false
        },
        read: {
            authorizationCheck: false
        }
    };

    beforeAll((done) => {
        oContext = {
            storeInfo: {
                hana: require("../../hana/js/default-services.json").hana
            }
        };
        HANAStore.createDB(oContext.storeInfo.hana)
            .then((oDB) => {
                oContext.db = oDB;
                return StoreFactory(oContext);
            })
            .then((oStore) => {
                oContext.store = oStore;
                done();
            });
    });

    afterAll((done) => {
        if (oContext.store) {
            oContext.store.rollback();
            oContext.store.close();
        }
        if (oContext.db) {
            oContext.db.close();
        }
        done();
    });

    it("retrieves node metadata from table", (done) => {
        oContext.store.getNodeMetadata({
            table: TEST_TABLE
        }).then((oMetadata) => {
            expect(oMetadata).toEqual({
                table: TEST_TABLE,
                primaryKeys: ['ID'],
                attributes: {
                    ID: {
                        name: 'ID',
                        dataType: Metadata.DataType.Integer,
                        dbDataType: "INTEGER",
                        required: true,
                        scale: 0,
                        maxLength: 10,
                        isPrimaryKey: true
                    },
                    TITLE: {
                        name: 'TITLE',
                        dataType: Metadata.DataType.String,
                        dbDataType: "NVARCHAR",
                        required: true,
                        maxLength: 240,
                        isPrimaryKey: false
                    },
                    DESCRIPTION: {
                        name: 'DESCRIPTION',
                        dataType: Metadata.DataType.String,
                        dbDataType: "NVARCHAR",
                        required: false,
                        maxLength: 1000,
                        isPrimaryKey: false
                    }
                }
            });
            done();
        });
    });

    it("maps table metadata", () => {

        var aTableColumnMetadata = [{
            COLUMN_NAME: 'COL1',
            DATA_TYPE_NAME: 'NVARCHAR',
            IS_NULLABLE: 'FALSE',
            LENGTH: 200,
            SCALE: null,
            IS_PRIMARY_KEY: 'TRUE'
        }, {
            COLUMN_NAME: 'COL2',
            DATA_TYPE_NAME: 'INTEGER',
            IS_NULLABLE: 'TRUE',
            SCALE: 0,
            IS_PRIMARY_KEY: 'FALSE'
        }];

        var oTableBoNodeMetadata = HANAStore._mapNodeFromTable(TEST_TABLE, aTableColumnMetadata);

        expect(oTableBoNodeMetadata).toEqual({
            table: TEST_TABLE,
            primaryKeys: ['COL1'],
            attributes: {
                COL1: {
                    name: 'COL1',
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    maxLength: 200,
                    required: true,
                    isPrimaryKey: true
                },
                COL2: {
                    name: 'COL2',
                    dataType: Metadata.DataType.Integer,
                    dbDataType: "INTEGER",
                    required: false,
                    scale: 0,
                    isPrimaryKey: false
                }
            }
        });
    });

    it("builds application object metadata based on table metadata", (done) => {

        var fnOnCreate = () => {
        };
        var fnOnPrepareCopy = () => {
        };
        var fnOnCopy = () => {
        };
        var fnOnUpdate = () => {
        };
        var fnOnModify = () => {
        };
        var fnOnDelete = () => {
        };
        var fnOnRead = () => {
        };
        var fnOnPersist = () => {
        };

        var fnCheckRoot = () => {
        };
        var fnCheckNode1 = () => {
        };
        var fnCheckNode2 = () => {
        };
        var fnCheckNode21 = () => {
        };
        var fnCheckAttr = () => {
        };

        var fnCheckReadOnly = () => {
        };

        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                historyTable: "sap.aof.test.db.test::t_test_h",
                determinations: {
                    onCreate: [fnOnCreate],
                    onPrepareCopy: [fnOnPrepareCopy],
                    onCopy: [fnOnCopy],
                    onUpdate: [fnOnUpdate],
                    onModify: [fnOnModify],
                    onDelete: [fnOnDelete],
                    onRead: [fnOnRead],
                    onPersist: [fnOnPersist]
                },
                consistencyChecks: [fnCheckRoot],
                inputChecks: [fnCheckRoot],
                attributes: {
                    TITLE: {
                        consistencyChecks: [fnCheckAttr],
                        inputChecks: [fnCheckAttr]
                    },
                    DESCRIPTION: {
                        foreignKeyTo: "DummyDescriptionAO"
                    }
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnCheckNode1],
                        inputChecks: [fnCheckNode1],
                        attributes: {
                            ID: {
                                // this is redundant to table information, but should be allowed as well
                                isPrimaryKey: true
                            }
                        }
                    },
                    Node2: {
                        table: "sap.aof.test.db.test::t_test_node_2",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnCheckNode2],
                        inputChecks: [fnCheckNode2],
                        readOnly: fnCheckReadOnly,
                        nodes: {
                            Node21: {
                                table: "sap.aof.test.db.test::t_test_node_2_1",
                                parentKey: "PARENT_ID",
                                consistencyChecks: [fnCheckNode21],
                                inputChecks: [fnCheckNode21],
                                attributes: {
                                    SOMETEXT: {
                                        consistencyChecks: [fnCheckAttr],
                                        inputChecks: [fnCheckAttr],
                                        readOnly: fnCheckReadOnly
                                    },
                                    ANOTHERONE: {
                                        readOnly: true
                                    }
                                }
                            }
                        }
                    },
                    Node3: {
                        table: "sap.aof.test.db.test::t_test_node_3",
                        parentKey: "OBJECT_ID",
                        readOnly: true,
                        externalKey: true,
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "AOF_TYPE"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "AOF_SUB_TYPE",
                                readOnly: true
                            }
                        }
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    executionCheck: () => {

                    },
                    persist: () => {

                    },
                    historyEvent: "TEST_CREATED"
                },
                copy: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    executionCheck: () => {
                    },
                    persist: () => {
                    },
                    historyEvent: "TEST_COPIED"
                },

                update: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    historyEvent: "TEST_UPDATED"
                },
                del: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    historyEvent: "TEST_DELETED"
                },
                read: {
                    authorizationCheck: false
                },
                customAction: {
                    authorizationCheck: false,
                    enabledCheck: () => {
                    },
                    execute: () => {
                    },
                    historyEvent: "TEST_CUSTOM_ACTION_DONE"
                }
            }
        };

        Metadata._getObjectMetadata("sap.aof.test.db.test.TestAO", oContext, oDefinition).then((oMetadata) => {
            var oExpectedMetadata = {
                schemaScope: "",
                type: Metadata.ObjectType.Standard,
                name: "sap.aof.test.db.test.TestAO",
                isExtensible: false,
                isConcurrencyControlEnabled: false,
                cascadeDelete: [],
                label: "",
                actions: {
                    create: {
                        name: Metadata.Action.Create,
                        authorizationCheck: oDefinition.actions.create.authorizationCheck,
                        enabledCheck: oDefinition.actions.create.enabledCheck,
                        executionCheck: oDefinition.actions.create.executionCheck,
                        persist: oDefinition.actions.create.persist,
                        isFrameworkAction: true,
                        isExposed: true,
                        label: "",
                        isStatic: true,
                        isInternal: false,
                        historyEvent: "TEST_CREATED",
                        readOnly: false
                    },
                    copy: {
                        name: Metadata.Action.Copy,
                        authorizationCheck: oDefinition.actions.copy.authorizationCheck,
                        enabledCheck: oDefinition.actions.copy.enabledCheck,
                        executionCheck: oDefinition.actions.copy.executionCheck,
                        persist: oDefinition.actions.copy.persist,
                        isFrameworkAction: true,
                        isExposed: true,
                        label: "",
                        isStatic: false,
                        isInternal: false,
                        historyEvent: "TEST_COPIED",
                        readOnly: false
                    },
                    update: {
                        name: Metadata.Action.Update,
                        authorizationCheck: oDefinition.actions.update.authorizationCheck,
                        enabledCheck: oDefinition.actions.update.enabledCheck,
                        isFrameworkAction: true,
                        isExposed: true,
                        label: "",
                        isStatic: false,
                        isInternal: false,
                        historyEvent: "TEST_UPDATED",
                        readOnly: false
                    },
                    del: {
                        name: Metadata.Action.Del,
                        authorizationCheck: oDefinition.actions.del.authorizationCheck,
                        enabledCheck: oDefinition.actions.del.enabledCheck,
                        isFrameworkAction: true,
                        isExposed: true,
                        label: "",
                        isStatic: false,
                        isInternal: false,
                        historyEvent: "TEST_DELETED",
                        readOnly: false
                    },
                    read: {
                        name: Metadata.Action.Read,
                        authorizationCheck: oDefinition.actions.read.authorizationCheck,
                        isFrameworkAction: true,
                        isExposed: true,
                        label: "",
                        isStatic: false,
                        isInternal: false,
                        readOnly: true
                    },
                    customAction: {
                        name: 'customAction',
                        authorizationCheck: oDefinition.actions.customAction.authorizationCheck,
                        enabledCheck: oDefinition.actions.customAction.enabledCheck,
                        execute: oDefinition.actions.customAction.execute,
                        isFrameworkAction: false,
                        isExposed: true,
                        label: "",
                        isStatic: false,
                        isInternal: false,
                        historyEvent: "TEST_CUSTOM_ACTION_DONE",
                        readOnly: false
                    }
                },
                nodes: {
                    Root: {
                        name: Metadata.Node.Root,
                        parentNode: undefined,
                        subNodes: ["Node1", "Node2", "Node3"],
                        table: "sap.aof.test.db.test::t_test",
                        historyTable: "sap.aof.test.db.test::t_test_h",
                        sequence: "sap.aof.test.db.test::s_test",
                        primaryKey: "ID",
                        externalKey: false,
                        isDatabasePrimaryKey: true,
                        persistedAttributes: ['DESCRIPTION', 'ID', 'TITLE'],
                        transientAttributes: [],
                        concurrencyControlAttributes: [],
                        hiddenAttributes: {},
                        label: "",
                        nameAttribute: null,
                        alternativeKeyAttribute: null,
                        constantKeys: {},
                        determinations: {
                            onCreate: [fnOnCreate],
                            onPrepareCopy: [fnOnPrepareCopy],
                            onCopy: [fnOnCopy],
                            onUpdate: [fnOnUpdate],
                            onModify: [fnOnModify],
                            onDelete: [fnOnDelete],
                            onRead: [fnOnRead],
                            onPersist: [fnOnPersist]
                        },
                        readOnly: false,
                        consistencyChecks: [fnCheckRoot],
                        inputChecks: [fnCheckRoot],
                        attributes: {
                            ID: {
                                name: 'ID',
                                dataType: Metadata.DataType.Integer,
                                dbDataType: "INTEGER",
                                isConstant: true,
                                isAlternativeKey: false,
                                required: true,
                                scale: 0,
                                maxLength: 10,
                                isPrimaryKey: true,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            TITLE: {
                                name: 'TITLE',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [fnCheckAttr],
                                inputChecks: [fnCheckAttr],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            DESCRIPTION: {
                                name: 'DESCRIPTION',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: false,
                                maxLength: 1000,
                                isPrimaryKey: false,
                                readOnly: false,
                                persisted: true,
                                foreignKeyTo: "DummyDescriptionAO",
                                foreignKeyIntraObject: false,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            }
                        }
                    },
                    Node1: {
                        name: 'Node1',
                        parentNode: "Root",
                        parentKey: "PARENT_ID",
                        subNodes: [],
                        primaryKey: "ID",
                        externalKey: true,
                        isDatabasePrimaryKey: true,
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        persistedAttributes: ['ID', 'PARENT_ID', 'SOMETEXT'],
                        transientAttributes: [],
                        concurrencyControlAttributes: [],
                        hiddenAttributes: {},
                        label: "",
                        nameAttribute: null,
                        alternativeKeyAttribute: null,
                        constantKeys: {},
                        consistencyChecks: [fnCheckNode1],
                        inputChecks: [fnCheckNode1],
                        readOnly: false,
                        attributes: {
                            ID: {
                                name: 'ID',
                                dataType: Metadata.DataType.Integer,
                                dbDataType: "INTEGER",
                                isConstant: true,
                                isAlternativeKey: false,
                                required: true,
                                scale: 0,
                                maxLength: 10,
                                isPrimaryKey: true,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            SOMETEXT: {
                                name: 'SOMETEXT',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            }
                        }
                    },
                    Node2: {
                        name: "Node2",
                        parentNode: "Root",
                        parentKey: "PARENT_ID",
                        subNodes: ["Node21"],
                        table: "sap.aof.test.db.test::t_test_node_2",
                        primaryKey: 'ID',
                        externalKey: true,
                        isDatabasePrimaryKey: true,
                        persistedAttributes: ['ID', 'PARENT_ID', 'SOMETEXT'],
                        transientAttributes: [],
                        concurrencyControlAttributes: [],
                        hiddenAttributes: {},
                        label: "",
                        nameAttribute: null,
                        alternativeKeyAttribute: null,
                        constantKeys: {},
                        consistencyChecks: [fnCheckNode2],
                        inputChecks: [fnCheckNode2],
                        readOnly: false,
                        checkReadOnly: fnCheckReadOnly,
                        attributes: {
                            ID: {
                                name: 'ID',
                                dataType: Metadata.DataType.Integer,
                                dbDataType: "INTEGER",
                                isConstant: true,
                                isAlternativeKey: false,
                                required: true,
                                scale: 0,
                                maxLength: 10,
                                isPrimaryKey: true,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            SOMETEXT: {
                                name: 'SOMETEXT',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            }
                        }
                    },
                    Node21: {
                        name: "Node21",
                        parentNode: "Node2",
                        parentKey: "PARENT_ID",
                        subNodes: [],
                        table: "sap.aof.test.db.test::t_test_node_2_1",
                        primaryKey: 'ID',
                        externalKey: true,
                        isDatabasePrimaryKey: true,
                        persistedAttributes: ['ANOTHERONE', 'ID', 'PARENT_ID', 'SOMETEXT'],
                        transientAttributes: [],
                        concurrencyControlAttributes: [],
                        hiddenAttributes: {},
                        label: "",
                        nameAttribute: null,
                        alternativeKeyAttribute: null,
                        constantKeys: {},
                        consistencyChecks: [fnCheckNode21],
                        inputChecks: [fnCheckNode21],
                        readOnly: false,
                        attributes: {
                            ID: {
                                name: 'ID',
                                dataType: Metadata.DataType.Integer,
                                dbDataType: "INTEGER",
                                isConstant: true,
                                isAlternativeKey: false,
                                required: true,
                                scale: 0,
                                maxLength: 10,
                                isPrimaryKey: true,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            SOMETEXT: {
                                name: 'SOMETEXT',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [fnCheckAttr],
                                inputChecks: [fnCheckAttr],
                                checkReadOnly: fnCheckReadOnly,
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            ANOTHERONE: {
                                name: 'ANOTHERONE',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: false,
                                maxLength: 240,
                                isPrimaryKey: false,
                                readOnly: true,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            }
                        }
                    },
                    Node3: {
                        name: "Node3",
                        parentNode: "Root",
                        parentKey: "OBJECT_ID",
                        subNodes: [],
                        table: "sap.aof.test.db.test::t_test_node_3",
                        primaryKey: "ID",
                        externalKey: true,
                        isDatabasePrimaryKey: true,
                        persistedAttributes: ['ANOTHER_TYPE_CODE', 'ID', 'OBJECT_ID', 'OBJECT_TYPE_CODE', 'SOMETEXT'],
                        transientAttributes: [],
                        concurrencyControlAttributes: [],
                        hiddenAttributes: {},
                        label: "",
                        nameAttribute: null,
                        alternativeKeyAttribute: null,
                        constantKeys: {
                            OBJECT_TYPE_CODE: "AOF_TYPE",
                            ANOTHER_TYPE_CODE: "AOF_SUB_TYPE"
                        },
                        consistencyChecks: [],
                        inputChecks: [],
                        readOnly: true,
                        attributes: {
                            ID: {
                                name: 'ID',
                                dataType: Metadata.DataType.Integer,
                                dbDataType: "INTEGER",
                                isConstant: true,
                                isAlternativeKey: false,
                                required: true,
                                scale: 0,
                                maxLength: 10,
                                isPrimaryKey: true,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            OBJECT_TYPE_CODE: {
                                name: 'OBJECT_TYPE_CODE',
                                dataType: Metadata.DataType.String,
                                isConstant: true,
                                isAlternativeKey: false,
                                dbDataType: "NVARCHAR",
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                constantKey: "AOF_TYPE",
                                readOnly: true,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            ANOTHER_TYPE_CODE: {
                                name: 'ANOTHER_TYPE_CODE',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: true,
                                isAlternativeKey: false,
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                constantKey: "AOF_SUB_TYPE",
                                readOnly: true,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            },
                            SOMETEXT: {
                                name: 'SOMETEXT',
                                dataType: Metadata.DataType.String,
                                dbDataType: "NVARCHAR",
                                isConstant: false,
                                isAlternativeKey: false,
                                required: true,
                                maxLength: 240,
                                isPrimaryKey: false,
                                readOnly: false,
                                persisted: true,
                                consistencyChecks: [],
                                inputChecks: [],
                                label: "",
                                isName: false,
                                isDescription: false
                            }
                        }
                    }
                }
            };
            _.sortByKeys(oMetadata);
            _.sortByKeys(oExpectedMetadata);
            expect(oMetadata).toEqual(oExpectedMetadata);
            done();
        });
    });

    it("allows overriding the primary key from the database", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        isPrimaryKey: true
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.primaryKey).toBe("TITLE");
            expect(oMetadata.nodes.Root.isDatabasePrimaryKey).toBe(false);
            expect(oMetadata.nodes.Root.attributes.TITLE.isPrimaryKey).toBe(true);
            expect(oMetadata.nodes.Root.attributes.ID.isPrimaryKey).toBe(false);
            done();
        });
    });

    it("allows definition of transient attributes", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    DESCRIPTION: {
                        required: true
                    },
                    TRANSIENT_ATTRIBUTE_1: {
                        required: true
                    },
                    TRANSIENT_ATTRIBUTE_2: {
                        required: false,
                        readOnly: true
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes).toEqual({
                ID: {
                    name: "ID",
                    dataType: Metadata.DataType.Integer,
                    dbDataType: "INTEGER",
                    isAlternativeKey: false,
                    isConstant: true,
                    required: true,
                    scale: 0,
                    maxLength: 10,
                    isPrimaryKey: true,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TITLE: {
                    name: "TITLE",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isAlternativeKey: false,
                    isConstant: false,
                    required: true,
                    maxLength: 240,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                DESCRIPTION: {
                    name: "DESCRIPTION",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isAlternativeKey: false,
                    isConstant: false,
                    required: true,
                    maxLength: 1000,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TRANSIENT_ATTRIBUTE_1: {
                    name: "TRANSIENT_ATTRIBUTE_1",
                    isAlternativeKey: false,
                    isConstant: false,
                    isPrimaryKey: false,
                    readOnly: false,
                    required: true,
                    persisted: false,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TRANSIENT_ATTRIBUTE_2: {
                    name: "TRANSIENT_ATTRIBUTE_2",
                    isAlternativeKey: false,
                    isConstant: false,
                    isPrimaryKey: false,
                    readOnly: true,
                    required: false,
                    persisted: false,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                }
            });

            expect(oMetadata.nodes.Root.persistedAttributes.sort()).toEqual(["DESCRIPTION", "ID", "TITLE"]);
            expect(oMetadata.nodes.Root.transientAttributes.sort()).toEqual(["TRANSIENT_ATTRIBUTE_1", "TRANSIENT_ATTRIBUTE_2"]);

            done();
        });
    });

    it("allows definition of concurrent attributes", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test_concurrency",
                attributes: {
                    CHANGED_AT: {
                        concurrencyControl: true
                    },
                    // Title is just used to test that multiple concurrency attributes can be used
                    TITLE: {
                        concurrencyControl: true
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.concurrencyControlAttributes).toEqual(["CHANGED_AT", "TITLE"]);
            expect(oMetadata.nodes.Root.attributes.CHANGED_AT.concurrencyControl).toBe(true);
            expect(oMetadata.isConcurrencyControlEnabled).toBe(true);
            done();
        });
    });

    it("authorization check needs to be explicitly set", (done) => {
        var oDefinition = {
            actions: {
                create: {},
                update: {},
                del: {},
                copy: {},
                customAction: {
                    execute: () => {
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(1).toBe(0);
            done();
        }).catch((e) => {
            expect(e.message).toEqual("Action 'create' needs authorizationCheck to be defined");
            done();
        });
    });

    it("handles custom action, node and attributes properties", (done) => {
        var oDefinition = {
            actions: {
                myAction: {
                    authorizationCheck: false,
                    execute: () => {
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.myAction.customProperties).toEqual(oDefinition.actions.myAction.customProperties);
            expect(oMetadata.nodes.Root.customProperties).toEqual(oDefinition.Root.customProperties);
            expect(oMetadata.nodes.Root.attributes.TITLE.customProperties).toEqual(oDefinition.Root.attributes.TITLE.customProperties);
        }).then(() => {
            var oDefinition = {
                actions: {
                    myAction: {
                        authorizationCheck: false,
                        execute: () => {
                        },
                        customProperties: () => {
                        }
                    }
                },
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    attributes: {
                        TITLE: {
                            customProperties: () => {
                            }
                        }
                    },
                    customProperties: () => {
                    }
                }
            };

            Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
                expect(oMetadata.actions.myAction.customProperties).toEqual(oDefinition.actions.myAction.customProperties);
                expect(oMetadata.nodes.Root.customProperties).toEqual(oDefinition.Root.customProperties);
                expect(oMetadata.nodes.Root.attributes.TITLE.customProperties).toEqual(oDefinition.Root.attributes.TITLE.customProperties);

                done();
            })
        });
    });

    it("returns activation check used for configuration activation", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                activationCheck: () => {
                }
            }
        };
        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.activationCheck).toBe(oDefinition.Root.activationCheck);
            done();
        });
    });

    it("allows explicit attribute definition flag", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                explicitAttributeDefinition: true,
                attributes: {
                    TITLE: {}
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        parentKey: "PARENT_ID"
                    },
                    Node3: {
                        table: "sap.aof.test.db.test::t_test_node_3",
                        parentKey: "OBJECT_ID",
                        explicitAttributeDefinition: true,
                        attributes: {
                            SOMETEXT: {}
                        }
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.ID).toBeDefined();
            expect(oMetadata.nodes.Root.attributes.TITLE).toBeDefined();
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION === undefined).toBe(true);

            expect(oMetadata.nodes.Node1.attributes.ID).toBeDefined();
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT).toBeDefined();

            expect(oMetadata.nodes.Node3.attributes.ID).toBeDefined();
            expect(oMetadata.nodes.Node3.attributes.SOMETEXT).toBeDefined();
            expect(oMetadata.nodes.Node3.attributes.OBJECT_TYPE_CODE === undefined).toBe(true);
            expect(oMetadata.nodes.Node3.attributes.ANOTHER_TYPE_CODE === undefined).toBe(true);

            done();
        });
    });

    it("allows to define an object as extensible", (done) => {
        var oDefinition = {
            isExtensible: true,
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test"
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.isExtensible).toBeDefined();
            expect(oMetadata.isExtensible).toBe(true);
            done();
        });
    });

    it("allows to extend an object", (done) => {

        var fnCoreConsistencyCheckNode2 = () => {
        };

        var fnCoreAttrConsistencyCheckNode1 = () => {
        };

        var fnCoreInputCheckNode2 = () => {
        };

        var fnCoreAttrInputCheckNode1 = () => {
        };

        var fnCoreDetCreate = () => {
        };

        var fnCoreDetModify = () => {
        };

        var fnCoreDetDelete = () => {
        };

        var oCoreActionChecks = {
            updateEnabledCheck: () => {
            },
            customActionEnabledCheck: () => {
            },
            deleteEnabledCheck: () => {
            },
            updateExecutionCheck: () => {
            },
            deleteExecutionCheck: () => {
            }
        };

        var oCoreActionExecutes = {
            customActionExecute: () => {
            },
            customAction2Execute: () => {
            }
        };

        var oCoreReadOnly = {
            nodeReadOnly: () => {
                return false;
            },
            attributeReadOnly: () => {
                return true;
            }
        };

        var oCoreProperties = {
            nodeProperties: () => {
                return {
                    val1: "a",
                    val2: "b"
                };
            },
            actionProperties: () => {
                return {
                    val3: "c",
                    val4: "d"
                };
            },
            attributeProperties: () => {
                return {
                    val5: "e",
                    val6: "f"
                };
            }
        };

        spyOn(oCoreActionChecks, 'updateEnabledCheck');
        spyOn(oCoreActionChecks, 'customActionEnabledCheck');
        spyOn(oCoreActionChecks, 'deleteEnabledCheck');
        spyOn(oCoreActionChecks, 'updateExecutionCheck');
        spyOn(oCoreActionChecks, 'deleteExecutionCheck');
        spyOn(oCoreActionExecutes, 'customActionExecute');
        spyOn(oCoreActionExecutes, 'customAction2Execute');

        var oCoreDefinition = {
            isExtensible: true,
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    enabledCheck: oCoreActionChecks.updateEnabledCheck,
                    executionCheck: oCoreActionChecks.updateExecutionCheck,
                    authorizationCheck: false
                },
                del: {
                    enabledCheck: oCoreActionChecks.deleteEnabledCheck,
                    executionCheck: oCoreActionChecks.deleteExecutionCheck,
                    authorizationCheck: false
                },
                customAction: {
                    enabledCheck: oCoreActionChecks.customActionEnabledCheck,
                    execute: oCoreActionExecutes.customActionExecute,
                    authorizationCheck: false,
                    customProperties: {
                        x: 4712,
                        y: "DEF"
                    }
                },
                customAction2: {
                    execute: oCoreActionExecutes.customAction2Execute,
                    customProperties: oCoreProperties.actionProperties,
                    authorizationCheck: false
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
                determinations: {
                    onCreate: [fnCoreDetCreate],
                    onModify: [fnCoreDetModify],
                    onDelete: [fnCoreDetDelete]
                },
                attributes: {
                    TITLE: {
                        isName: false,
                        isDescription: true,
                        readOnly: true,
                        customProperties: {
                            o: 4713,
                            p: "KLM"
                        }
                    }
                },
                customProperties: {
                    x: 4711,
                    y: "ABC"
                }
            },
            nodes: {
                Node1: {
                    table: "sap.aof.test.db.test::t_test_node_1",
                    parentKey: "PARENT_ID",
                    readOnly: true,
                    attributes: {
                        SOMETEXT: {
                            consistencyChecks: [fnCoreAttrConsistencyCheckNode1],
                            inputChecks: [fnCoreAttrInputCheckNode1],
                            readOnly: oCoreReadOnly.attributeReadOnly,
                            customProperties: oCoreProperties.attributeProperties
                        }
                    },
                    customProperties: oCoreProperties.nodeProperties
                },
                Node2: {
                    table: "sap.aof.test.db.test::t_test_node_2",
                    parentKey: "PARENT_ID",
                    readOnly: oCoreReadOnly.nodeReadOnly,
                    consistencyChecks: [fnCoreConsistencyCheckNode2],
                    inputChecks: [fnCoreInputCheckNode2]
                },
                Ext: {
                    table: "sap.aof.test.db.test::t_test_ext_node",
                    parentKey: "OBJECT_ID",
                    explicitAttributeDefinition: true,
                    attributes: {
                        OBJECT_TYPE_CODE: {
                            constantKey: "TEST_OBJECT"
                        }
                    }
                }
            }
        };

        var fnExtensionConsistencyCheckRoot = () => {
        };

        var fnExtensionConsistencyCheckNode2 = () => {
        };

        var fnExtensionAttrConsistencyCheckRoot = () => {
        };

        var fnExtensionAttrConsistencyCheckNode1 = () => {
        };

        var fnExtensionInputCheckRoot = () => {
        };

        var fnExtensionInputCheckNode2 = () => {
        };

        var fnExtensionAttrInputCheckRoot = () => {
        };

        var fnExtensionAttrInputCheckNode1 = () => {
        };

        var fnExtensionDetCreate = () => {
        };

        var fnExtensionDetPersist = () => {
        };

        var oExtActionChecks = {
            createEnabledCheck: () => {
            },
            updateEnabledCheck: () => {
            },
            customActionEnabledCheck: () => {
            },
            createExecutionCheck: () => {
            },
            updateExecutionCheck: () => {
            }
        };

        var oExtActionExecutes = {
            customActionExecute: () => {
            }
        };

        var oExtReadOnly = {
            nodeReadOnly: () => {
                return true;
            },
            attributeReadOnly: () => {
                return false;
            },
            attributeReadOnly2: () => {
                return true;
            }
        };

        var oExtProperties = {
            nodeProperties: () => {
                return {
                    extVal1: "z",
                    extVal2: "x"
                };
            },
            actionProperties: () => {
                return {
                    extVal3: "y",
                    extVal4: "w"
                };
            },
            attributeProperties: () => {
                return {
                    extVal5: "v",
                    extVal6: "q"
                };
            }
        };

        spyOn(oExtActionChecks, 'createEnabledCheck');
        spyOn(oExtActionChecks, 'updateEnabledCheck');
        spyOn(oExtActionChecks, 'customActionEnabledCheck');
        spyOn(oExtActionChecks, 'createExecutionCheck');
        spyOn(oExtActionChecks, 'updateExecutionCheck');
        spyOn(oExtActionExecutes, 'customActionExecute');

        var oExtensionDefinition = {
            actions: {
                create: {
                    enabledCheck: oExtActionChecks.createEnabledCheck,
                    executionCheck: oExtActionChecks.createExecutionCheck
                },
                update: {
                    enabledCheck: oExtActionChecks.updateEnabledCheck,
                    executionCheck: oExtActionChecks.updateExecutionCheck,
                    customProperties: oExtProperties.actionProperties
                },
                customAction: {
                    enabledCheck: oExtActionChecks.customActionEnabledCheck,
                    execute: oExtActionExecutes.customActionExecute,
                    customProperties: {
                        x: 4711,
                        extZ: 4712,
                        extW: "ZYX"
                    }
                }
            },
            Root: {
                consistencyChecks: [fnExtensionConsistencyCheckRoot],
                inputChecks: [fnExtensionInputCheckRoot],
                determinations: {
                    onCreate: [fnExtensionDetCreate],
                    onPersist: [fnExtensionDetPersist]
                },
                readOnly: true,
                attributes: {
                    DESCRIPTION: {
                        isName: true,
                        isDescription: true,
                        required: true,
                        readOnly: oExtReadOnly.attributeReadOnly2
                    },
                    TITLE: {
                        isDescription: false,
                        consistencyChecks: [fnExtensionAttrConsistencyCheckRoot],
                        inputChecks: [fnExtensionAttrInputCheckRoot],
                        customProperties: oExtProperties.attributeProperties
                    }
                },
                customProperties: oExtProperties.nodeProperties,
                nodes: {
                    Node1: {
                        readOnly: false,
                        attributes: {
                            SOMETEXT: {
                                required: true,
                                consistencyChecks: [fnExtensionAttrConsistencyCheckNode1],
                                inputChecks: [fnExtensionAttrInputCheckNode1],
                                readOnly: oExtReadOnly.attributeReadOnly,
                                customProperties: {
                                    extU: 4715,
                                    extB: "OK"
                                }
                            }
                        },
                        customProperties: {
                            extX: 4711,
                            extY: "ABC"
                        }
                    },
                    Node2: {
                        consistencyChecks: [fnExtensionConsistencyCheckNode2],
                        inputChecks: [fnExtensionInputCheckNode2],
                        readOnly: oExtReadOnly.nodeReadOnly,
                        attributes: {
                            SOMETEXT: {
                                readOnly: true
                            }
                        }
                    },
                    Ext: {
                        attributes: {
                            CUST1: {
                                foreignKeyTo: "sap.ino.xs.object.User.Root",
                                required: true,
                                readOnly: true,
                                maxLength: 200
                            }
                        }
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oCoreDefinition, [oExtensionDefinition]).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION.required).toBe(true);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.required).toBe(true);
            expect(oMetadata.nodes.Root.attributes.TITLE.isName).toBe(false);
            expect(oMetadata.nodes.Root.attributes.TITLE.isDescription).toBe(false);
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION.isName).toBe(true);
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION.isDescription).toBe(true);
            expect(oMetadata.nodes.Root.nameAttribute).toBe("DESCRIPTION");

            expect(oMetadata.nodes.Root.consistencyChecks[0]).toBe(fnExtensionConsistencyCheckRoot);
            expect(oMetadata.nodes.Node2.consistencyChecks[0]).toBe(fnCoreConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.consistencyChecks[1]).toBe(fnExtensionConsistencyCheckNode2);

            expect(oMetadata.nodes.Root.inputChecks[0]).toBe(fnExtensionInputCheckRoot);
            expect(oMetadata.nodes.Node2.inputChecks[0]).toBe(fnCoreInputCheckNode2);
            expect(oMetadata.nodes.Node2.inputChecks[1]).toBe(fnExtensionInputCheckNode2);

            expect(oMetadata.nodes.Root.attributes.TITLE.consistencyChecks[0]).toBe(fnExtensionAttrConsistencyCheckRoot);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.consistencyChecks[0]).toBe(fnCoreAttrConsistencyCheckNode1);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.consistencyChecks[1]).toBe(fnExtensionAttrConsistencyCheckNode1);

            expect(oMetadata.nodes.Root.attributes.TITLE.inputChecks[0]).toBe(fnExtensionAttrInputCheckRoot);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.inputChecks[0]).toBe(fnCoreAttrInputCheckNode1);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.inputChecks[1]).toBe(fnExtensionAttrInputCheckNode1);

            expect(oMetadata.nodes.Root.determinations.onCreate[0]).toBe(fnCoreDetCreate);
            expect(oMetadata.nodes.Root.determinations.onCreate[1]).toBe(fnExtensionDetCreate);
            expect(oMetadata.nodes.Root.determinations.onModify[0]).toBe(fnCoreDetModify);
            expect(oMetadata.nodes.Root.determinations.onDelete[0]).toBe(fnCoreDetDelete);
            expect(oMetadata.nodes.Root.determinations.onPersist[0]).toBe(fnExtensionDetPersist);

            // Enabled checks
            oMetadata.actions.create.enabledCheck();
            oMetadata.actions.update.enabledCheck();
            oMetadata.actions.del.enabledCheck();
            oMetadata.actions.customAction.enabledCheck();

            expect(oCoreActionChecks.updateEnabledCheck).toHaveBeenCalled();
            expect(oCoreActionChecks.deleteEnabledCheck).toHaveBeenCalled();
            expect(oCoreActionChecks.customActionEnabledCheck).toHaveBeenCalled();
            expect(oExtActionChecks.createEnabledCheck).toHaveBeenCalled();
            expect(oExtActionChecks.updateEnabledCheck).toHaveBeenCalled();
            expect(oExtActionChecks.customActionEnabledCheck).toHaveBeenCalled();

            // Execution checks
            oMetadata.actions.create.executionCheck();
            oMetadata.actions.update.executionCheck();
            oMetadata.actions.del.executionCheck();

            expect(oCoreActionChecks.updateExecutionCheck).toHaveBeenCalled();
            expect(oCoreActionChecks.deleteExecutionCheck).toHaveBeenCalled();
            expect(oExtActionChecks.createExecutionCheck).toHaveBeenCalled();
            expect(oExtActionChecks.updateExecutionCheck).toHaveBeenCalled();

            // Execute
            oMetadata.actions.customAction.execute();
            oMetadata.actions.customAction2.execute();

            expect(oCoreActionExecutes.customActionExecute).toHaveBeenCalled();
            expect(oCoreActionExecutes.customAction2Execute).toHaveBeenCalled();
            expect(oExtActionExecutes.customActionExecute).toHaveBeenCalled();

            // Read Only on node
            expect(oMetadata.nodes.Root.readOnly).toBe(true);
            expect(oMetadata.nodes.Node1.readOnly).toBe(true);
            expect(oMetadata.nodes.Node2.checkReadOnly()).toBe(true);

            // Read Only on attribute
            expect(oMetadata.nodes.Root.attributes.TITLE.readOnly).toBe(true);
            expect(oMetadata.nodes.Root.attributes.DESCRIPTION.checkReadOnly()).toBe(true);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.checkReadOnly()).toBe(true);
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.readOnly).toBe(true);

            // Custom Properties on node
            expect(oMetadata.nodes.Root.customProperties()).toEqual({
                x: 4711,
                y: "ABC",
                extVal1: "z",
                extVal2: "x"
            });

            expect(oMetadata.nodes.Node1.customProperties()).toEqual({
                val1: "a",
                val2: "b",
                extX: 4711,
                extY: "ABC"
            });

            // Custom Properties on action
            expect(oMetadata.actions.update.customProperties()).toEqual({
                extVal3: 'y',
                extVal4: 'w'
            });
            expect(oMetadata.actions.customAction.customProperties()).toEqual({
                x: 4712,
                y: 'DEF',
                extZ: 4712,
                extW: 'ZYX'
            });
            expect(oMetadata.actions.customAction2.customProperties()).toEqual({
                val3: 'c',
                val4: 'd'
            });

            // Custom Properties on attribute
            expect(oMetadata.nodes.Root.attributes.TITLE.customProperties()).toEqual({
                o: 4713,
                p: 'KLM',
                extVal5: 'v',
                extVal6: 'q'
            });
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.customProperties()).toEqual({
                val5: 'e',
                val6: 'f',
                extU: 4715,
                extB: 'OK'
            });

            // New attributes
            expect(oMetadata.nodes.Ext.attributes.CUST1).toBeDefined();
            expect(oMetadata.nodes.Ext.attributes.CUST1.foreignKeyTo).toBe("sap.ino.xs.object.User.Root");
            expect(oMetadata.nodes.Ext.attributes.CUST1.required).toBe(true);
            expect(oMetadata.nodes.Ext.attributes.CUST1.readOnly).toBe(true);
            expect(oMetadata.nodes.Ext.attributes.CUST1.dataType).toBe(Metadata.DataType.String);
            expect(oMetadata.nodes.Ext.attributes.CUST1.maxLength).toBe(200);

            done();
        });
    });

    it("allows to define type for object", (done) => {
        var ObjectType = Metadata.ObjectType;
        var oDefinition = {
            type: ObjectType.Configuration,
            Root: {
                table: "sap.aof.test.db.test::t_test"
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.type).toBe(ObjectType.Configuration);

            oDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test"
                }
            };

            Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
                expect(oMetadata.type).toBe(ObjectType.Standard);
                done();
            });
        });
    });

    it("allows to define additional attribute constraints", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test_2",
                attributes: {
                    INT_01: {
                        minValue: 2,
                        maxValue: 3
                    },
                    DOUBLE_01: {
                        minValue: 2.3,
                        maxValue: 3.5
                    },
                    TEXT_01: {
                        maxLength: 444
                    },
                    TEXT_02: {
                        maxLength: 444
                    },
                    TS_01: {
                        minValue: 545
                    },
                    DATE_01: {
                        maxValue: 6565
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.INT_01.minValue).toBe(2);
            expect(oMetadata.nodes.Root.attributes.INT_01.maxValue).toBe(3);
            expect(oMetadata.nodes.Root.attributes.DOUBLE_01.minValue).toBe(2.3);
            expect(oMetadata.nodes.Root.attributes.DOUBLE_01.maxValue).toBe(3.5);
            expect(oMetadata.nodes.Root.attributes.TEXT_01.maxLength).toBe(444);
            expect(oMetadata.nodes.Root.attributes.TEXT_02.maxLength).toBe(100);
            expect(oMetadata.nodes.Root.attributes.TS_01.minValue === undefined).toBe(true);
            expect(oMetadata.nodes.Root.attributes.DATE_01.minValue === undefined).toBe(true);

            done();
        });
    });

    it("allows to define an object-internal foreign key reference", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                foreignKeyTo: "DummyDescriptionAO",
                                foreignKeyIntraObject: true,
                            }
                        }
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.foreignKeyIntraObject).toBe(true);
            done();
        });
    });

    it("allows to define cascade delete objects", (done) => {
        var oDefinition = {
            cascadeDelete: ["sap.ino.xs.object.ObjectA", "sap.ino.xs.object.ObjectB"],
            Root: {
                table: "sap.aof.test.db.test::t_test"
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.cascadeDelete).toEqual(["sap.ino.xs.object.ObjectA", "sap.ino.xs.object.ObjectB"]);
            done();
        });
    });

    it("allows to define static custom actions", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test"
            },
            actions: {
                myStaticAction: {
                    isStatic: true,
                    historyEvent: "STATIC_ACTION_DONE",
                    authorizationCheck: (oParameters, addMessage, oContext) => {
                    },
                    enabledCheck: (oParameters, addMessage, oContext) => {
                    },
                    execute: (oParameters, addMessage, oContext) => {
                    },
                    customProperties: (oParameters, addMessage, oContext) => {
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.myStaticAction.isStatic).toBe(true);
            expect(oMetadata.actions.myStaticAction.historyEvent).toBe("STATIC_ACTION_DONE");
            expect(oMetadata.actions.myStaticAction.authorizationCheck).toBe(oDefinition.actions.myStaticAction.authorizationCheck);
            expect(oMetadata.actions.myStaticAction.enabledCheck).toBe(oDefinition.actions.myStaticAction.enabledCheck);
            expect(oMetadata.actions.myStaticAction.execute).toBe(oDefinition.actions.myStaticAction.execute);
            expect(oMetadata.actions.myStaticAction.customProperties).toBe(oDefinition.actions.myStaticAction.customProperties);

            done();
        });
    });

    it("allows to define actions as internal", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test"
            },
            actions: {
                create: {
                    authorizationCheck: false,
                    isInternal: true
                },
                myInternalAction: {
                    authorizationCheck: false,
                    isInternal: true,
                    execute: () => {
                    }
                },
                myAction: {
                    authorizationCheck: false,
                    execute: () => {
                    }
                },
                myStaticAction: {
                    authorizationCheck: false,
                    isStatic: true,
                    execute: () => {
                    }
                },
                myInternalStaticAction: {
                    authorizationCheck: false,
                    isStatic: true,
                    isInternal: true,
                    execute: () => {
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.create.isInternal).toBe(true);
            expect(oMetadata.actions.myInternalAction.isInternal).toBe(true);
            expect(oMetadata.actions.myInternalStaticAction.isInternal).toBe(true);
            expect(oMetadata.actions.myAction.isInternal).toBe(false);
            expect(oMetadata.actions.myStaticAction.isInternal).toBe(false);

            done();
        });

    });

    it("allows to define a isName property for at max one attribute and multiple isDescription attribute on any node", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        isName: true,
                        isDescription: true
                    }
                },
                nodes: {
                    Node1: {
                        table: "sap.aof.test.db.test::t_test_node_1",
                        historyTable: "sap.aof.test.db.test::t_test_node_1_h",
                        parentKey: "PARENT_ID",
                        attributes: {
                            SOMETEXT: {
                                isName: true,
                                isDescription: true
                            }
                        }
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.nodes.Root.attributes.TITLE.isName).toBe(true);
            expect(oMetadata.nodes.Root.nameAttribute).toBe("TITLE");
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.isName).toBe(true);
            expect(oMetadata.nodes.Node1.nameAttribute).toBe("SOMETEXT");
            expect(oMetadata.nodes.Root.attributes.TITLE.isDescription).toBe(true);
            expect(oMetadata.nodes.Node1.attributes.SOMETEXT.isDescription).toBe(true);

            oDefinition = {
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    attributes: {
                        TITLE: {
                            isName: true,
                            isDescription: true
                        },
                        DESCRIPTION: {
                            isName: true,
                            isDescription: true
                        }
                    }
                },
                actions: {
                    create: {
                        authorizationCheck: false
                    }
                }
            };

            Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then(() => {
                expect(1).toBe(0);
                done();
            }).catch((e) => {
                expect(e.toString()).toBe("Error: Define only one name attribute for node 'Root'");
                done();
            });
        });
    });

    it("defines objects to be invalidated by custom actions", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test"
            },
            actions: {
                customAction: {
                    enabledCheck: (oParameters, addMessage, oContext) => {
                    },
                    execute: (oParameters, addMessage, oContext) => {
                    },
                    authorizationCheck: false,
                    impacts: ["sap.ino.xs.object.idea.Idea"]
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.customAction.impacts).toEqual(["sap.ino.xs.object.idea.Idea"]);
            done();
        });
    });

    it("handles mass-enabled custom action", (done) => {
        var oDefinition = {
            actions: {
                myAction: {
                    massActionName: "myMassAction",
                    impacts: ["sap.ino.xs.object.idea.Idea"],
                    historyEvent: "COACH_ASSIGNED",
                    authorizationCheck: false,
                    execute: () => {
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                attributes: {
                    TITLE: {
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                customProperties: {
                    prop1: "val1",
                    prop2: "val2"
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.actions.myAction.massActionName).toBe("myMassAction");
            expect(_.size(oMetadata.actions)).toBe(_.size(oDefinition.actions) + 1);
            expect(oMetadata.actions.myMassAction.name).toBe("myMassAction");
            expect(oMetadata.actions.myMassAction.isFrameworkAction).toBe(false);
            expect(oMetadata.actions.myMassAction.isInternal).toBe(false);
            expect(oMetadata.actions.myMassAction.isStatic).toBe(true);
            expect(oMetadata.actions.myMassAction.isMassAction).toBe(true);
            expect(oMetadata.actions.myMassAction.historyEvent).toBe("COACH_ASSIGNED");
            expect(oMetadata.actions.myMassAction.authorizationCheck).toBe(false);
            expect(oMetadata.actions.myMassAction.impacts).toBe(oMetadata.actions.myAction.impacts);
            expect(_.isPlainObject(oMetadata.actions.myMassAction.customProperties)).toBe(true);
            expect(oMetadata.actions.myAction.customProperties).toEqual(oMetadata.actions.myMassAction.customProperties);
            expect(_.isFunction(oMetadata.actions.myMassAction.execute)).toBe(true);

            var oDefinition2 = {
                actions: {
                    myAction: {
                        massActionName: "myMassAction",
                        authorizationCheck: false,
                        execute: () => {
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    },
                    myMassAction: {
                        authorizationCheck: false,
                        execute: () => {
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                },
                Root: {
                    table: "sap.aof.test.db.test::t_test",
                    attributes: {
                        TITLE: {
                            customProperties: {
                                prop1: "val1",
                                prop2: "val2"
                            }
                        }
                    },
                    customProperties: {
                        prop1: "val1",
                        prop2: "val2"
                    }
                }
            };

            Metadata._getObjectMetadata("whateverAO", oContext, oDefinition2).then(() => {
                expect(1).toBe(0);
                done();
            }).catch((e) => {
                expect(e.message).toEqual("Mass action 'myMassAction' conflicts with standard action");

                var oDefinition3 = {
                    actions: {
                        myAction: {
                            isStatic: true,
                            massActionName: "myMassAction",
                            authorizationCheck: false,
                            execute: () => {
                            },
                            customProperties: {
                                prop1: "val1",
                                prop2: "val2"
                            }
                        }
                    },
                    Root: {
                        table: "sap.aof.test.db.test::t_test",
                        attributes: {
                            TITLE: {
                                customProperties: {
                                    prop1: "val1",
                                    prop2: "val2"
                                }
                            }
                        },
                        customProperties: {
                            prop1: "val1",
                            prop2: "val2"
                        }
                    }
                };

                Metadata._getObjectMetadata("whateverAO", oContext, oDefinition3).then(() => {
                    expect(1).toBe(0);
                }).catch((e) => {
                    expect(e.message).toEqual("Mass action 'myMassAction' is not allowed for static action");
                    done();
                });
            });
        })
    });

    it("allows definition of read view resulting in transient attributes", (done) => {
        var oDefinition = {
            Root: {
                table: "sap.aof.test.db.test::t_test",
                view: "sap.aof.test.db.test::v_test"
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(_.sortByKeys(oMetadata.nodes.Root.attributes)).toEqual(_.sortByKeys({
                ID: {
                    name: "ID",
                    dataType: Metadata.DataType.Integer,
                    dbDataType: "INTEGER",
                    isAlternativeKey: false,
                    isConstant: true,
                    required: true,
                    scale: 0,
                    maxLength: 10,
                    isPrimaryKey: true,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TITLE: {
                    name: "TITLE",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isAlternativeKey: false,
                    isConstant: false,
                    required: true,
                    maxLength: 240,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                DESCRIPTION: {
                    name: "DESCRIPTION",
                    dataType: Metadata.DataType.String,
                    dbDataType: "NVARCHAR",
                    isAlternativeKey: false,
                    isConstant: false,
                    required: false,
                    maxLength: 1000,
                    isPrimaryKey: false,
                    readOnly: false,
                    persisted: true,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                },
                TEST: {
                    name: "TEST",
                    dataType: Metadata.DataType.Integer,
                    dbDataType: "INTEGER",
                    isAlternativeKey: false,
                    isConstant: false,
                    isPrimaryKey: false,
                    readOnly: false,
                    required: false,
                    maxLength: 10,
                    scale: 0,
                    persisted: false,
                    consistencyChecks: [],
                    inputChecks: [],
                    label: "",
                    isName: false,
                    isDescription: false
                }
            }));

            expect(oMetadata.nodes.Root.persistedAttributes.sort()).toEqual(["DESCRIPTION", "ID", "TITLE"]);
            expect(oMetadata.nodes.Root.transientAttributes.sort()).toEqual(["TEST"]);

            done();
        });
    });

    it("allows to define labels", (done) => {
        var oDefinition = {
            label: "Object",
            Root: {
                table: "sap.aof.test.db.test::t_test",
                label: "Node",
                attributes: {
                    "ID": {
                        label: "Attribute"
                    }
                }
            },
            actions: {
                create: {
                    authorizationCheck: false,
                    label: "Action"
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oDefinition).then((oMetadata) => {
            expect(oMetadata.label).toEqual("Object");
            expect(oMetadata.nodes.Root.label).toEqual("Node");
            expect(oMetadata.nodes.Root.attributes.ID.label).toEqual("Attribute");
            expect(oMetadata.actions.create.label).toEqual("Action");

            done();
        }).catch((oException) => {
            done(oException);
        });
    });

    it("supports custom extension nodes", (done) => {
        var oCoreDefinition = {
            isExtensible: true,
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test"
            },
            nodes: {
                Node1: {
                    table: "sap.aof.test.db.test::t_test_node_1",
                    sequence: "sap.aof.test.db.test::s_test_node_1",
                    parentKey: "PARENT_ID"
                }
            }
        };

        var fnExtensionConsistencyCheckNode2 = () => {
        };

        var fnExtensionAttrConsistencyCheckNode2 = () => {
        };

        var fnExtensionInputCheckNode2 = () => {
        };

        var fnExtensionAttrInputCheckNode2 = () => {
        };

        var oExtReadOnly = {
            nodeReadOnly: () => {
                return true;
            },
            attributeReadOnly: () => {
                return true;
            }
        };

        var oExtProperties = {
            nodeProperties: () => {
                return {
                    extVal1: "z",
                    extVal2: "x"
                };
            },
            attributeProperties: () => {
                return {
                    extVal3: "v",
                    extVal4: "q"
                };
            }
        };

        var oExtensionDefinition = {
            Root: {
                nodes: {
                    Node2: {
                        table: "sap.aof.test.db.test::t_test_node_2_1",
                        sequence: "sap.aof.test.db.test::s_test_node_2_1",
                        parentKey: "PARENT_ID",
                        consistencyChecks: [fnExtensionConsistencyCheckNode2],
                        inputChecks: [fnExtensionInputCheckNode2],
                        readOnly: oExtReadOnly.nodeReadOnly,
                        customProperties: oExtProperties.nodeProperties,
                        attributes: {
                            SOMETEXT: {
                                required: true,
                                consistencyChecks: [fnExtensionAttrConsistencyCheckNode2],
                                inputChecks: [fnExtensionAttrInputCheckNode2],
                                readOnly: oExtReadOnly.attributeReadOnly,
                                customProperties: {
                                    x: 4711,
                                    y: "OK"
                                }
                            },
                            "ANOTHERONE": {
                                readOnly: true,
                                customProperties: oExtProperties.attributeProperties,
                                foreignKeyTo: "sap.ino.xs.object.User.Root"
                            }
                        }
                    }
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oCoreDefinition, [oExtensionDefinition]).then((oMetadata) => {
            expect(oMetadata.nodes.Node2).toBeDefined();
            expect(oMetadata.nodes.Node2.table).toEqual("sap.aof.test.db.test::t_test_node_2_1");
            expect(oMetadata.nodes.Node2.primaryKey).toEqual("ID");
            expect(oMetadata.nodes.Node2.sequence).toEqual("sap.aof.test.db.test::s_test_node_2_1");
            expect(oMetadata.nodes.Node2.consistencyChecks[0]).toEqual(fnExtensionConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.inputChecks[0]).toEqual(fnExtensionInputCheckNode2);

            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.consistencyChecks[0]).toEqual(fnExtensionAttrConsistencyCheckNode2);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.consistencyChecks).toEqual([]);
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.inputChecks[0]).toEqual(fnExtensionAttrInputCheckNode2);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.inputChecks).toEqual([]);

            // Read Only on node
            expect(oMetadata.nodes.Node2.checkReadOnly()).toEqual(true);

            // Read Only on attribute
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.checkReadOnly()).toEqual(true);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.readOnly).toEqual(true);
            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.foreignKeyTo).toEqual("sap.ino.xs.object.User.Root");

            // Custom Properties on node
            expect(oMetadata.nodes.Node2.customProperties()).toEqual({
                extVal1: "z",
                extVal2: "x"
            });

            // Custom Properties on attribute
            expect(oMetadata.nodes.Node2.attributes.SOMETEXT.customProperties).toEqual({
                x: 4711,
                y: "OK"
            });

            expect(oMetadata.nodes.Node2.attributes.ANOTHERONE.customProperties()).toEqual({
                extVal3: "v",
                extVal4: "q"
            });

            done();
        }).catch((oException) => {
            done(oException);
        });
    });

    it("supports custom extension actions", (done) => {
        var oCoreDefinition = {
            isExtensible: true,
            actions: {
                create: {
                    authorizationCheck: false
                },
                update: {
                    authorizationCheck: false
                },
                del: {
                    authorizationCheck: false
                },
                customAction: {
                    authorizationCheck: false,
                    execute: () => {
                    }
                }
            },
            Root: {
                table: "sap.aof.test.db.test::t_test",
                sequence: "sap.aof.test.db.test::s_test",
            }
        };

        var oExtActionChecks = {
            customAction2EnabledCheck: () => {
            }
        };

        var oExtActionExecutes = {
            customAction2Execute: () => {
            }
        };

        var oExtProperties = {
            actionProperties: () => {
                return {
                    extVal3: "y",
                    extVal4: "w"
                };
            }
        };

        spyOn(oExtActionChecks, 'customAction2EnabledCheck');
        spyOn(oExtActionExecutes, 'customAction2Execute');

        var oExtensionDefinition = {
            actions: {
                customAction2: {
                    authorizationCheck: false,
                    enabledCheck: oExtActionChecks.customAction2EnabledCheck,
                    execute: oExtActionExecutes.customAction2Execute,
                    customProperties: oExtProperties.actionProperties
                }
            }
        };

        Metadata._getObjectMetadata("whateverAO", oContext, oCoreDefinition, [oExtensionDefinition]).then((oMetadata) => {
            expect(oMetadata.actions.customAction2).toBeDefined();

            // Enabled checks
            oMetadata.actions.customAction2.enabledCheck();

            expect(oExtActionChecks.customAction2EnabledCheck).toHaveBeenCalled();

            // Execute
            oMetadata.actions.customAction2.execute();

            expect(oExtActionExecutes.customAction2Execute).toHaveBeenCalled();

            // Custom Properties on action
            expect(oMetadata.actions.customAction2.customProperties()).toEqual({
                extVal3: "y",
                extVal4: "w"
            });

            done();
        }).catch((oException) => {
            done(oException);
        });
    });
});