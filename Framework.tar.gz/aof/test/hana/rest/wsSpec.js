"use strict";

require("jasmine-before-all");
var ws = require("../js/node_modules/ws");
var Promise = require("bluebird");
Promise.longStackTraces();

var _ = require("../../../lib/util/underscore");

var PORT = 3003;
var oServer;

describe("SAP/AOF/WS", function () {

    beforeAll((done) => {
        oServer = require("../js/testServer_ws.js");
        oServer.listen(PORT, function () {
            done();
        });
    });

    afterAll((done) => {
        oServer.close();
        done();
    });

    var oSocket;

    beforeEach((done) => {
        oSocket = new ws.connect("ws://localhost:" + PORT + "/test/object/TestAO");
        oSocket.on("open", function () {
            oSocket.on("message", (sMessage) => {
                var oMessage = JSON.parse(sMessage);
                var sAction = oMessage.action;
                // Action = connect
                done();
            });
        });
        oSocket.on("error", function () {
            done();
        });
    });

    afterEach((done) => {
        if (oSocket) {
            oSocket.close();
        }
        done();
    });

    it("access application Object via web sockets", (done) => {
        oSocket.removeAllListeners("message");
        oSocket.send(JSON.stringify({
            action: "create",
            parameters: [{
                ID: -1,
                TITLE: "Test Title",
                DESCRIPTION: "Test Title",
                Node2: [{
                    ID: -2,
                    SOMETEXT: "Blafasel"
                }]
            }]
        }));
        oSocket.on("message", (sMessage) => {
            var oMessage = JSON.parse(sMessage);
            var sAction = oMessage.action;
            var oObject = oMessage.object;
            var oResponse = oMessage.response;
            expect(sAction).toBe("create");
            expect(oResponse).toBeDefined();
            var iId = oResponse.generatedKeys[-1];
            var iNode2Id = oResponse.generatedKeys[-2];
            expect(oObject).toEqual({
                DESCRIPTION: 'Test Title',
                ID: iId,
                TITLE: 'Test Title',
                Node1: [],
                Node2: [{
                    ID: iNode2Id,
                    SOMETEXT: 'Blafasel',
                    Node21: []
                }]
            });
            oSocket.removeAllListeners("message");
            oSocket.send(JSON.stringify({
                action: "update",
                parameters: [{
                    ID: iId,
                    TITLE: "Test Title Update",
                    DESCRIPTION: "Test Title Update",
                    Node2: [{
                        ID: iNode2Id,
                        SOMETEXT: "Blafasel Update"
                    }, {
                        ID: -3,
                        SOMETEXT: "Blafasel Test"
                    }]
                }]
            }));
            oSocket.on("message", (sMessage) => {
                var oMessage = JSON.parse(sMessage);
                var sAction = oMessage.action;
                var oObject = oMessage.object;
                var oResponse = oMessage.response;
                expect(sAction).toBe("update");
                expect(oResponse).toBeDefined();
                var iNode2_2Id = oResponse.generatedKeys[-3];
                expect(oObject).toEqual({
                    DESCRIPTION: 'Test Title Update',
                    ID: iId,
                    TITLE: 'Test Title Update',
                    Node1: [],
                    Node2: [{
                        ID: iNode2Id,
                        SOMETEXT: 'Blafasel Update',
                        Node21: []
                    }, {
                        ID: iNode2_2Id,
                        SOMETEXT: 'Blafasel Test',
                        Node21: []
                    }]
                });
                oSocket.removeAllListeners("message");
                oSocket.send(JSON.stringify({
                    action: "instanceAction",
                    parameters: [iId, {
                        TEXT: " Action"
                    }]
                }));
                oSocket.on("message", (sMessage) => {
                    var oMessage = JSON.parse(sMessage);
                    var sAction = oMessage.action;
                    var oObject = oMessage.object;
                    var oResponse = oMessage.response;
                    expect(sAction).toBe("instanceAction");
                    expect(oMessage.technicalAction).toBe("update");
                    expect(oResponse).toBeDefined();
                    expect(oObject).toEqual({
                        DESCRIPTION: 'Test Title Update',
                        ID: iId,
                        TITLE: 'Test Title Update Action',
                        Node1: [],
                        Node2: [{
                            ID: iNode2_2Id,
                            SOMETEXT: 'Blafasel Test',
                            Node21: []
                        }, {
                            ID: iNode2Id,
                            SOMETEXT: 'Blafasel Update',
                            Node21: []
                        }]
                    });
                    oSocket.removeAllListeners("message");
                    oSocket.send(JSON.stringify({
                        action: "del",
                        parameters: [iId]
                    }));
                    oSocket.on("message", (sMessage) => {
                        var oMessage = JSON.parse(sMessage);
                        var sAction = oMessage.action;
                        var oObject = oMessage.object;
                        var oResponse = oMessage.response;
                        expect(sAction).toBe("del");
                        expect(oResponse).toBeDefined();
                        expect(oObject).toEqual({
                            DESCRIPTION: 'Test Title Update',
                            ID: iId,
                            TITLE: 'Test Title Update Action',
                            Node1: [],
                            Node2: [{
                                ID: iNode2_2Id,
                                SOMETEXT: 'Blafasel Test',
                                Node21: []
                            }, {
                                ID: iNode2Id,
                                SOMETEXT: 'Blafasel Update',
                                Node21: []
                            }]
                        });
                        done();
                    });
                });
            });
        });
    });
});