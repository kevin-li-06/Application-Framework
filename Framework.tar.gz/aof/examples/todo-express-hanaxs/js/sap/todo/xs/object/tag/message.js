"use strict";

module.exports.DUPLICATE_TAG = "MSG_DUPLICATE_TAG";
module.exports.DUPLICATE_TAG_ASSIGN = "MSG_DUPLICATE_TAG_ASSIGN";