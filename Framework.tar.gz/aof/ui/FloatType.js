sap.ui.define([
    "sap/ui/model/type/Float"
], function (FloatType) {
    "use strict";
    
    return FloatType.extend("sap.aof.FloatType", {

        formatValue : function(oValue, sInternalType) {
            return FloatType.prototype.formatValue.apply(this, [oValue || 0, sInternalType]);
        },

        parseValue : function(oValue, sInternalType) {
            return FloatType.prototype.parseValue.apply(this, [oValue || 0, sInternalType]);
        },

        validateValue : function(oValue) {
            return FloatType.prototype.validateValue.apply(this, [oValue]);
        }
    });
});