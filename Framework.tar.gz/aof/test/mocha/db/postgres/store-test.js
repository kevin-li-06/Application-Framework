var expect = require("chai").expect;
var _ = require("underscore");
var pg = require("pg");

const dbConnectionParams = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postgres",
    database: "aof",
    max: 10
};

var PostgresStore = require("../../../../lib/db/postgres/store");

describe("db-postgres-store", () => {
    const oPool = new pg.Pool(dbConnectionParams);
    var oDB;
    var oStore;

    beforeEach(() => {
        return Promise.resolve().then(() => {
            return oPool.connect();
        }).then((oDBClient) => {
            oDB = oDBClient;
            oStore = new PostgresStore({db: oDB});
            return oDB.query('DROP VIEW IF EXISTS "v_test_view"');
        }).then(() => {
            return oDB.query('DROP TABLE IF EXISTS "t_test_view"');
        }).then(() => {
            return oDB.query('CREATE TABLE "t_test_view" (ID integer PRIMARY KEY, A_VARCHAR varchar(50))')
        }).then(() => {

        }).then(() => {
            return oDB.query('CREATE VIEW "v_test_view" AS SELECT *, CAST(\'transient\' as varchar) as transient FROM "t_test_view"')
        });
    });

    afterEach(() => {
        if (oDB) {
            oDB.release();
        }
    });

    it("fetches metadata from table and view", () => {
        return oStore.getNodeMetadata({
            table: "t_test_view",
            view: "v_test_view"
        }, true).then((oNodeMetadata) => {
            expect(oNodeMetadata).to.eql({
                attributes: {
                    id: {
                        dataType: "Integer",
                        dbDataType: "integer",
                        isPrimaryKey: true,
                        name: "id",
                        required: true
                    },
                    a_varchar: {
                        dataType: "String",
                        dbDataType: "character varying",
                        isPrimaryKey: false,
                        maxLength: 50,
                        name: "a_varchar",
                        required: false,
                    },
                    transient: {
                        dataType: "String",
                        dbDataType: "character varying",
                        isPrimaryKey: false,
                        name: "transient",
                        required: false,
                        transient: true
                    }
                },
                primaryKeys: [
                    "id"
                ],
                schema: "public",
                table: "t_test_view"
            });
        });
    });
});
