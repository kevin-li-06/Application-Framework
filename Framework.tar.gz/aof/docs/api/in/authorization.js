"use strict";

/**
 * Authorization re-use library to be used for Application Object action authorizationCheck definitions
 * @namespace Authorization
 */
function Authorization() {
}

/**
 * Checks whether the object key is in the list of objects for which the application user is authorized. Example:
 * Check the authorization to update an object.
 * @param sAuthEntity {String} Name of the entity which contains the accessible keys
 * @param vAuthKeyAttribute {*} Attribute name of accessible keys
 * @param sAuthFailMsg {String} Message to be written if the check fails
 * @returns {Promise.<Boolean>} Promise resolving to true if check succeeded
 */
Authorization.prototype.instanceAccessCheck = function (sAuthEntity, vAuthKeyAttribute, sAuthFailMsg) {
    return new Promise();
};

/**
 * Checks whether the parent key, to which the path parent attribute path points, is in the list of objects for which the
 * application user is authorized. Example: Check the authorization to create an object for another object.
 * @param sAuthEntity {String} Name of the entity which contains the accessible keys
 * @param vAuthKeyAttribute {*} Attribute name of accessible keys
 * @param vAuthParentKeyAttribute {*} Attribute name of the parent object key in the request object
 * @param sAuthFailMsg {String} Message to be written if the check fails
 * @param bAuthKeyOptional {Boolean} Is auth key optional and access is granted
 * @returns {Promise.<Boolean>} Promise resolving to true if check succeeded
 */
Authorization.prototype.parentInstanceAccessCheck = function (sAuthEntity, vAuthKeyAttribute, vAuthParentKeyAttribute, sAuthFailMsg, bAuthKeyOptional) {
    return new Promise();
};

/**
 * Checks the auth key and an additional condition
 * @param sAuthEntity {String} Name of the entity which contains the accessible keys
 * @param vAuthKeyAttribute {*} Attribute name of accessible keys
 * @param sCondition {String} Additional freestyle condition to be checked
 * @param sAuthFailMsg {String} Message to be written if the check fails
 * @param sRefNode {String} Node the message is referencing to
 * @param sRefAttribute {String} Attribute the message is referencing to
 * @returns {Promise.<Boolean>} Promise resolving to true if check succeeded
 */
Authorization.prototype.conditionCheck = function (sAuthEntity, vAuthKeyAttribute, sCondition, sAuthFailMsg, sRefNode, sRefAttribute) {
    return new Promise();
};

/**
 * Checks whether the user has a certain privilege assigned.
 * @param sPrivilege {String} Name of the privilege
 * @param sAuthFailMsg {String} Message to be written if the check fails
 * @returns {Promise.<Boolean>} Promise resolving true if check succeeded
 */
Authorization.prototype.privilegeCheck = function (sPrivilege, sAuthFailMsg) {
    return new Promise();
};

/**
 * Checks if all passed authorization checks passes
 * @param aAccessChecks {Array} Array of authorization checks to be checked
 * @returns {Promise.<Boolean>} Promise resolving true if all checks succeeded
 */
Authorization.prototype.compositeAccessCheck = function (aAccessChecks) {
    return new Promise();
};

/**
 * Checks if all at least one authorization checks passes
 * @param aAccessChecks {Array} Array of authorization checks to be checked
 * @returns {Promise.<Boolean>} Promise resolving true if at least one check succeeded
 */
Authorization.prototype.atLeastOneAccessCheck = function (aAccessChecks) {
    return new Promise();
};