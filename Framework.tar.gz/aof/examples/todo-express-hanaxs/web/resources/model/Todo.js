sap.ui.define([
    "sap/aof/ApplicationObject",
    "sap/aof/ReadSource"
], function (ApplicationObject, ReadSource) {
    "use strict";

    return ApplicationObject.extend("sap.todo.aof.example.model.Todo", {
        objectName: "sap.todo.xs.rest.Todo",
        readSource: ReadSource.getDefaultAOFSource(),
        invalidation: {
            entitySets: ["Todo_Root"]
        },
        determinations: {
            onCreate: initSharing,
            onRead: initSharing,
            onNormalizeData: normalizeSharing
        },

        addItem: function (oTodoItem) {
            this.addChild(oTodoItem, "Items", 0);
        },

        removeItem: function (oTodoItem) {
            this.removeChild(oTodoItem);
        },

        addTag: function (oTodoItemTag, sItemPath) {
            this.addChild(oTodoItemTag, sItemPath + "/" + "Tags");
        },

        removeTag: function (oTodoItemTag) {
            this.removeChild(oTodoItemTag);
        },

        hasTag: function (sName, sItemPath) {
            var aTag = this.getProperty(sItemPath + "/" + "Tags");
            return jQuery.grep(aTag || [], function (oTag) {
                    return oTag.NAME === sName;
                }).length > 0;
        },

        addSharing: function (oSharing) {
            var that = this;
            var aSharing = this.getProperty("/Sharing");
            if (jQuery.grep(aSharing || [], function (oExistingSharing) {
                    return oExistingSharing.IDENTITY === oSharing.IDENTITY;
                }).length === 0) {
                oSharing.ID = that.getNextHandle();
                aSharing.push(oSharing);
                this.checkUpdate(true);
                return true;
            }
            return false;
        },

        removeSharing: function (oSharing) {
            this.removeChild(oSharing);
        }
    });

    function initSharing(oData, oTodo) {
        oData.Sharing = [].concat(oData.Readers || []).concat(oData.Writers || []);
        return oData;
    }

    function normalizeSharing(oData, oTodo) {
        var oBeforeData = oTodo.getBeforeData();
        oData.Readers = [];
        oData.Writers = [];
        jQuery.each(oData.Sharing || [], function (index, oSharing) {
            var iId = oSharing.ID;

            var aBeforeSharing = jQuery.grep(oBeforeData && oBeforeData.Sharing || [], function (oBeforeSharing) {
                return oBeforeSharing.IDENTITY === oSharing.IDENTITY;
            });
            if (aBeforeSharing.length > 0 && aBeforeSharing[0].ROLE_CODE !== oSharing.ROLE_CODE) {
                iId = oTodo.getNextHandle();
            }

            switch (oSharing.ROLE_CODE) {
                case "sap.todo.xs.object.todo.Todo.Reader" :
                    oData.Readers.push({
                        ID: iId,
                        IDENTITY: oSharing.IDENTITY
                    });
                    break;
                case "sap.todo.xs.object.todo.Todo.Writer" :
                    oData.Writers.push({
                        ID: iId,
                        IDENTITY: oSharing.IDENTITY
                    });
                    break;
            }
        });
        return oData;
    }
});