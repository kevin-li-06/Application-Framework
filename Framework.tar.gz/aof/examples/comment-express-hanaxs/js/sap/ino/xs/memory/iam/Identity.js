"use strict";

// dataType, maxLength, isPrimaryKey, required can be omitted when derived from table metadata
module.exports = {
    Root : {
        table : "sap.aof.example.db.iam::t_identity",
        readOnly : true,
        attributes : {
            USER_NAME : {
                dataType: "NVARCHAR",
                maxLength: 256,
                isPrimaryKey: false
            }
        }
    }
};