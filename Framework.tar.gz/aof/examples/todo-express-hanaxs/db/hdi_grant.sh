#!/usr/bin/env bash

export HDI__HOST=inno-next.mo.sap.corp
export HDI__PORT=30015
export HDI___SYS_DI__USER=SYSTEM
export HDI___SYS_DI__PASSWORD=Toor1234

export HDI__SAP_AOF_EXAMPLE_TODO__USER=DEPLOYMENT_USER
export HDI__SAP_AOF_EXAMPLE_TODO__PASSWORD=Test1234

hdi grant-container-schema-privilege SAP_AOF_EXAMPLE_TODO EXECUTE SAP_AOF_EXAMPLE_TODO_USER
hdi grant-container-schema-privilege SAP_AOF_EXAMPLE_TODO SELECT SAP_AOF_EXAMPLE_TODO_USER
hdi grant-container-schema-privilege SAP_AOF_EXAMPLE_TODO INSERT SAP_AOF_EXAMPLE_TODO_USER
hdi grant-container-schema-privilege SAP_AOF_EXAMPLE_TODO UPDATE SAP_AOF_EXAMPLE_TODO_USER
hdi grant-container-schema-privilege SAP_AOF_EXAMPLE_TODO DELETE SAP_AOF_EXAMPLE_TODO_USER
hdi grant-container-schema-privilege SAP_AOF_EXAMPLE_TODO "CREATE ANY" SAP_AOF_EXAMPLE_TODO_USER