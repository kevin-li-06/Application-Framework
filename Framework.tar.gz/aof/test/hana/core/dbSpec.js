"use strict";

require("jasmine-before-all");

var Promise = require("bluebird");
Promise.longStackTraces();

var Metadata = require("../../../lib/core/metadata");
var Message = require("../../../lib/core/message");
var StoreFactory = require("../../../lib/db/store-factory");
var HANAStore = require("../../../lib/db/hana/store");

var _ = require("../../../lib/util/underscore");

var oContext;

describe("SAP/AOF/CORE/DB", () => {

    var TEST_TABLE = 'sap.aof.test.db.test::t_test';
    var TEST_HISTORY_TABLE = 'sap.aof.test.db.test::t_test_h';
    var TEST_SEQUENCE = 'sap.aof.test.db.test::s_test';
    var TEST_TABLE_NODE_1 = 'sap.aof.test.db.test::t_test_node_1';
    var TEST_SEQUENCE_NODE_1 = 'sap.aof.test.db.test::s_test_node_1';
    var TEST_TABLE_NODE_2 = 'sap.aof.test.db.test::t_test_node_2';
    var TEST_SEQUENCE_NODE_2 = 'sap.aof.test.db.test::s_test_node_2';
    var TEST_TABLE_NODE_2_1 = 'sap.aof.test.db.test::t_test_node_2_1';
    var TEST_SEQUENCE_NODE_2_1 = 'sap.aof.test.db.test::s_test_node_2_1';
    var TEST_TABLE_NODE_3 = 'sap.aof.test.db.test::t_test_node_3';
    var TEST_SEQUENCE_NODE_3 = 'sap.aof.test.db.test::s_test_node_3';

    var fnNoCheck = () => {
    };

    var sTimestamp;

    function createTimestamp() {
        sTimestamp = new Date().toISOString();
    }

    var oDummyActions = {
        create: {
            authorizationCheck: fnNoCheck,
            historyEvent: "TEST_CREATED"
        },
        update: {
            authorizationCheck: fnNoCheck,
            historyEvent: "TEST_UPDATED"
        },
        del: {
            authorizationCheck: fnNoCheck,
            historyEvent: "TEST_DELETED"
        },
        read: {
            authorizationCheck: fnNoCheck
        }
    };

    beforeAll((done) => {
        oContext = {
            storeInfo: {
                hana: require("../../hana/js/default-services.json").hana
            }
        };
        HANAStore.createDB(oContext.storeInfo.hana)
            .then((oDB) => {
                oContext.db = oDB;
                return StoreFactory(oContext);
            })
            .then((oStore) => {
                oContext.store = oStore;
                done();
            });
    });

    afterAll((done) => {
        if (oContext.store) {
            oContext.store.rollback();
            oContext.store.close();
        }
        if (oContext.db) {
            oContext.db.close();
        }
        done();
    });

    it("get application user", (done) => {
        oContext.store.getApplicationUser().then((sAppUser) => {
            expect(sAppUser).toEqual(oContext.storeInfo.hana.user);
            done();
        });
    });

    it("reads a structured object", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);

            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            var fnSequenceNode1 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_1});
            var fnSequenceNode2 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2});
            var fnSequenceNode2_1 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2_1});

            var sRootId;
            var sNode1Id1;
            var sNode1Id2;
            var sNode2Id1;
            var sNode2Id2;
            var sNode2_1Id1;
            var sNode2_1Id2;
            var sNode2_1Id3;
            var sNode2_1Id4;

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                }]);
            }).then(() => {
                return fnSequenceNode1().then((_sNode1Id1) => {
                    sNode1Id1 = _sNode1Id1;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_1).insert([{
                        ID: sNode1Id1,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 1 of Node 1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode1().then((_sNode1Id2) => {
                    sNode1Id2 = _sNode1Id2;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_1).insert([{
                        ID: sNode1Id2,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 2 of Node 1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2().then((_sNode2Id1) => {
                    sNode2Id1 = _sNode2Id1;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_2).insert([{
                        ID: sNode2Id1,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 1 of Node 2'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2().then((_sNode2Id2) => {
                    sNode2Id2 = _sNode2Id2;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_2).insert([{
                        ID: sNode2Id2,
                        PARENT_ID: sRootId,
                        SOMETEXT: 'Instance 2 of Node 2'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id1) => {
                    sNode2_1Id1 = _sNode2_1Id1;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id1,
                        PARENT_ID: sNode2Id1,
                        SOMETEXT: 'Instance 1 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id2) => {
                    sNode2_1Id2 = _sNode2_1Id2;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id2,
                        PARENT_ID: sNode2Id1,
                        SOMETEXT: 'Instance 2 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id3) => {
                    sNode2_1Id3 = _sNode2_1Id3;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id3,
                        PARENT_ID: sNode2Id2,
                        SOMETEXT: 'Instance 3 of Node 2_1'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode2_1().then((_sNode2_1Id4) => {
                    sNode2_1Id4 = _sNode2_1Id4;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_2_1).insert([{
                        ID: sNode2_1Id4,
                        PARENT_ID: sNode2Id2,
                        SOMETEXT: 'Instance 4 of Node 2_1'
                    }]);
                });
            }).then(() => {
                oDBAccess.read(sRootId).then((oObject) => {
                    expect(oObject).toEqual({
                        ID: sRootId,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description',
                        Node1: [{
                            ID: sNode1Id1,
                            SOMETEXT: 'Instance 1 of Node 1'
                        }, {
                            ID: sNode1Id2,
                            SOMETEXT: 'Instance 2 of Node 1'
                        }],
                        Node2: [{
                            ID: sNode2Id1,
                            SOMETEXT: 'Instance 1 of Node 2',
                            Node21: [{
                                ID: sNode2_1Id1,
                                SOMETEXT: 'Instance 1 of Node 2_1',
                                ANOTHERONE: null
                            }, {
                                ID: sNode2_1Id2,
                                SOMETEXT: 'Instance 2 of Node 2_1',
                                ANOTHERONE: null
                            }]
                        }, {
                            ID: sNode2Id2,
                            SOMETEXT: 'Instance 2 of Node 2',
                            Node21: [{
                                ID: sNode2_1Id3,
                                SOMETEXT: 'Instance 3 of Node 2_1',
                                ANOTHERONE: null
                            }, {
                                ID: sNode2_1Id4,
                                SOMETEXT: 'Instance 4 of Node 2_1',
                                ANOTHERONE: null
                            }]
                        }]
                    });
                    done();
                });
            })
        });
    });

    it("reads objects bypassing the buffer and with virtual tables", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            fnSequenceRoot().then((sRootId) => {
                oContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                }]).then(() => {
                    return oDBAccess.read(sRootId, true).then((oObject) => {
                        expect(oObject).toEqual({
                            ID: sRootId,
                            TITLE: 'New node title',
                            DESCRIPTION: 'New node description'
                        });
                    });
                }).then(() => {
                    // this is necessary for configuration where the staging state needs to be considered
                    return oDBAccess.read(sRootId, true, {
                        "sap.aof.test.db.test::t_test": "(select id, 'Dummy' as title, 'ABC' as description from \""
                        + TEST_TABLE + '")'
                    }).then((oObject) => {
                        expect(oObject).toEqual({
                            ID: sRootId,
                            TITLE: "Dummy",
                            DESCRIPTION: "ABC"
                        });
                        done();
                    });
                });
            });
        });
    });

    it("reads objects defined with constant key", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        sequence: TEST_SEQUENCE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4712"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4711"
                            }
                        }
                    },
                    Node3b: {
                        table: TEST_TABLE_NODE_3,
                        sequence: TEST_SEQUENCE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4710"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4711"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);

            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            var fnSequenceNode3 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_3});

            var sRootId;
            var sNode3Id1;
            var sNode3bId1;
            var sNode3Id2;

            fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                }]);
            }).then(() => {
                // positive cases (which should be read)
                return fnSequenceNode3().then((_sNode3Id1) => {
                    sNode3Id1 = _sNode3Id1;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                        ID: sNode3Id1,
                        OBJECT_ID: sRootId,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 1 of Node 3'
                    }]);
                });
            }).then(() => {
                return fnSequenceNode3().then((_sNode3bId1) => {
                    sNode3bId1 = _sNode3bId1;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                        ID: sNode3bId1,
                        OBJECT_ID: sRootId,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4710",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 1 of Node 3b'
                    }]);
                });
            }).then(() => {
                // negative case (which should not be read)
                return fnSequenceNode3().then((_sNode3Id2) => {
                    sNode3Id2 = _sNode3Id2;
                    return oContext.store.getClient().table(TEST_TABLE_NODE_3).insert([{
                        ID: sNode3Id2,
                        OBJECT_ID: sRootId,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4713",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 3 in table 3'
                    }]);
                });
            }).then(() => {
                oDBAccess.read(sRootId).then((oObject) => {
                    expect(oObject).toEqual({
                        ID: sRootId,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description',
                        Node3: [{
                            ID: sNode3Id1,
                            OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                            ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                            SOMETEXT: 'Instance 1 of Node 3'
                        }],
                        Node3b: [{
                            ID: sNode3bId1,
                            OBJECT_TYPE_CODE: "TYPE_CODE_4710",
                            ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                            SOMETEXT: 'Instance 1 of Node 3b'
                        }]
                    });
                })
            }).then(() => {
                // Existence check should have the same behaviour as read
                return oDBAccess.exists(sNode3Id1, "Node3").then((bExists) => {
                    expect(bExists).toBe(true);
                    return oDBAccess.exists(sNode3bId1, "Node3b");
                }).then((bExists) => {
                    expect(bExists).toBe(true);
                    return oDBAccess.exists(sNode3Id2, "Node3");
                }).then((bExists) => {
                    expect(bExists).toBe(false);
                    return oDBAccess.exists(sNode3Id2, "Node3b");
                }).then((bExists) => {
                    expect(bExists).toBe(false);
                    done();
                });
            });
        });
    });

    it("writes objects defined with constant key", (done) => {

        var sRootId;
        var sNode31Id;
        var sNode32Id;

        var oDBAccess;
        var fnSequenceRoot;
        var fnSequenceNode3;

        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        sequence: TEST_SEQUENCE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4712"
                            },
                            ANOTHER_TYPE_CODE: {
                                constantKey: "TYPE_CODE_4711"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            fnSequenceNode3 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_3});
            return fnSequenceRoot();
        }).then((_sRootId) => {
            sRootId = _sRootId;
            return fnSequenceNode3();
        }).then((_sNode31Id) => {
            sNode31Id = _sNode31Id;
            return fnSequenceNode3();
        }).then((_sNode32Id) => {
            sNode32Id = _sNode32Id;
            return oDBAccess.create({
                ID: sRootId,
                TITLE: 'New node title',
                DESCRIPTION: 'New node description',
                Node3: [{
                    ID: sNode31Id,
                    SOMETEXT: 'Instance 1 of Node 3',
                }, {
                    ID: sNode32Id,
                    SOMETEXT: 'Instance 2 of Node 3',
                    OBJECT_TYPE_TYPE: 'ABC',
                    ANOTHER_TYPE_CODE: 'XYZ'
                }]
            }).then(() => {
                return oDBAccess.read(sRootId);
            }).then((oObject) => {
                expect(oObject).toEqual({
                    ID: sRootId,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description',
                    Node3: [{
                        ID: sNode31Id,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 1 of Node 3'
                    }, {
                        ID: sNode32Id,
                        OBJECT_TYPE_CODE: "TYPE_CODE_4712",
                        ANOTHER_TYPE_CODE: "TYPE_CODE_4711",
                        SOMETEXT: 'Instance 2 of Node 3'
                    }]
                });
                done();
            });
        });
    });

    it("creates updates and deletes a simple object", (done) => {

        function getLatestHistory(iKey) {
            return oContext.store.getClient().statement('select top 1 * from "' + TEST_HISTORY_TABLE + '" where id = ? order by history_at desc').execute(iKey);
        }

        createTimestamp();

        var oAction = {
            name: "create",
            historyEvent: "TEST_CREATED"
        };

        var oContextMock = {
            getAction: () => {
                return oAction;
            },
            getUser: () => {
                return Promise.resolve(oContext.storeInfo.hana.user);
            },
            getRequestTimestamp: () => {
                return sTimestamp;
            },
            getHistoryEvent: () => {
                return oAction.historyEvent;
            }
        };
        var fnMessageMock = () => {
        };

        var iKey;

        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                historyTable: TEST_HISTORY_TABLE
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequence = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            return fnSequence().then((_iKey) => {
                iKey = _iKey;
                var oCreateObject = {
                    ID: iKey,
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description'
                };
                return oDBAccess.create(oCreateObject, fnMessageMock, oContextMock).then((vResult) => {
                    expect(vResult).not.toBeDefined();
                    return oDBAccess.read(iKey);
                }).then((oReadObject) => {
                    expect(oCreateObject).toEqual(oReadObject);
                    return getLatestHistory(iKey);
                }).then((aCreateHistory) => {
                    expect(aCreateHistory.length).toBe(1);
                    expect(aCreateHistory[0]).toEqual({
                        HISTORY_DB_EVENT: "CREATED",
                        HISTORY_BIZ_EVENT: oContextMock.getAction().historyEvent,
                        HISTORY_AT: oContextMock.getRequestTimestamp(),
                        HISTORY_ACTOR: oContext.storeInfo.hana.user,
                        ID: iKey,
                        TITLE: 'New node title',
                        DESCRIPTION: 'New node description'
                    });
                }).then(() => {
                    createTimestamp();

                    oAction = {
                        name: 'update',
                        historyEvent: 'TEST_UPDATED'
                    };
                    var oUpdateObject = {
                        ID: iKey,
                        TITLE: 'Changed title',
                        DESCRIPTION: 'Changed description'
                    };
                    return oDBAccess.update(oUpdateObject, fnMessageMock, oContextMock).then((vResult) => {
                        expect(vResult).not.toBeDefined();
                        return getLatestHistory(iKey);
                    }).then((aUpdateHistory) => {
                        expect(aUpdateHistory.length).toBe(1);
                        expect(aUpdateHistory[0]).toEqual({
                            HISTORY_DB_EVENT: "UPDATED",
                            HISTORY_BIZ_EVENT: oContextMock.getAction().historyEvent,
                            HISTORY_AT: oContextMock.getRequestTimestamp(),
                            HISTORY_ACTOR: oContext.storeInfo.hana.user,
                            ID: iKey,
                            TITLE: 'Changed title',
                            DESCRIPTION: 'Changed description'
                        });
                        return oDBAccess.read(iKey);
                    }).then((oReadObject) => {
                        expect(oUpdateObject).toEqual(oReadObject);
                        createTimestamp();
                        var oDeleteObject = {
                            ID: iKey,
                            TITLE: 'Changed title',
                            DESCRIPTION: 'Changed description'
                        };
                        oAction = {
                            name: 'delete',
                            historyEvent: 'TEST_DELETED'
                        };
                        return oDBAccess.del(oDeleteObject, fnMessageMock, oContextMock);
                    }).then((vResult) => {
                        expect(vResult).not.toBeDefined();
                        return getLatestHistory(iKey);
                    }).then((aDeleteHistory) => {
                        expect(aDeleteHistory.length).toBe(1);
                        expect(aDeleteHistory[0]).toEqual({
                            HISTORY_DB_EVENT: "DELETED",
                            HISTORY_BIZ_EVENT: oContextMock.getAction().historyEvent,
                            HISTORY_AT: oContextMock.getRequestTimestamp(),
                            HISTORY_ACTOR: oContext.storeInfo.hana.user,
                            ID: iKey,
                            TITLE: 'Changed title',
                            DESCRIPTION: 'Changed description'
                        });
                        return oDBAccess.read(iKey);
                    }).then((oReadObject) => {
                        expect(oReadObject).toBe(null);
                        done();
                    }).catch((oException) => {
                        expect(oException).toBeUndefined();
                        done();
                    });
                });
            });
        });
    });

    it("creates a structured object", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            var fnSequenceNode1 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_1});
            var fnSequenceNode2 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2});
            var fnSequenceNode2_1 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2_1});

            return Promise.all([
                fnSequenceRoot(),
                fnSequenceNode1(),
                fnSequenceNode1(),
                fnSequenceNode2(),
                fnSequenceNode2_1(),
                fnSequenceNode2_1(),
                fnSequenceNode2(),
                fnSequenceNode2_1(),
                fnSequenceNode2_1()]).then((aId) => {
                var sRootId = aId[0];
                var oWriteObject = {
                    ID: aId[0],
                    TITLE: 'New node title',
                    DESCRIPTION: 'New node description',
                    Node1: [{
                        ID: aId[1],
                        SOMETEXT: 'Instance 1 of Node 1'
                    }, {
                        ID: aId[2],
                        SOMETEXT: 'Instance 2 of Node 1'
                    }],
                    Node2: [{
                        ID: aId[3],
                        SOMETEXT: 'Instance 1 of Node 2',
                        Node21: [{
                            ID: aId[4],
                            SOMETEXT: 'Instance 1 of Node 2_1',
                            ANOTHERONE: null
                        }, {
                            ID: aId[5],
                            SOMETEXT: 'Instance 2 of Node 2_1',
                            ANOTHERONE: null
                        }]
                    }, {
                        ID: aId[6],
                        SOMETEXT: 'Instance 2 of Node 2',
                        Node21: [{
                            ID: aId[7],
                            SOMETEXT: 'Instance 3 of Node 2_1',
                            ANOTHERONE: null
                        }, {
                            ID: aId[8],
                            SOMETEXT: 'Instance 4 of Node 2_1',
                            ANOTHERONE: null
                        }]
                    }]
                };
                return oDBAccess.create(oWriteObject).then((vResult) => {
                    expect(vResult).not.toBeDefined();
                    return oDBAccess.read(sRootId);
                }).then((oReadObject) => {
                    oReadObject.Node1 = _.sortBy(oReadObject.Node1, 'ID');
                    oReadObject.Node2[0].Node21 = _.sortBy(oReadObject.Node2[0].Node21, 'ID');
                    oReadObject.Node2[1].Node21 = _.sortBy(oReadObject.Node2[1].Node21, 'ID');
                    oReadObject.Node2 = _.sortBy(oReadObject.Node2, 'ID');
                    expect(oWriteObject).toEqual(oReadObject);
                    done();
                });
            });
        });
    });

    it("reads an object containing a transient field", (done) => {
        var sRootId;

        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                attributes: {
                    TRANSIENT_ATTRIBUTE_1: {}
                }
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});

            return fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oContext.store.getClient().table(TEST_TABLE).insert([{
                    ID: sRootId,
                    TITLE: "New node title",
                    DESCRIPTION: "New node description"
                }]);
            }).then(() => {
                return oDBAccess.read(sRootId).then((oObject) => {
                    expect(oObject).toEqual({
                        ID: sRootId,
                        TITLE: "New node title",
                        DESCRIPTION: "New node description",
                        TRANSIENT_ATTRIBUTE_1: null
                    });
                    done();
                });
            });
        });
    });

    it("writes an object containing a transient field", (done) => {
        var sRootId;

        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                attributes: {
                    TRANSIENT_ATTRIBUTE_1: {}
                }
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});

            fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oDBAccess.create({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF",
                    TRANSIENT_ATTRIBUTE_1: "XYZ"
                });
            }).then(() => {
                return oDBAccess.read(sRootId);
            }).then((oObject) => {
                expect(oObject).toEqual({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF",
                    TRANSIENT_ATTRIBUTE_1: null
                });
                done();
            });
        });
    });

    it("buffers read accesses", (done) => {
        var sRootId;

        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});

            fnSequenceRoot().then((_sRootId) => {
                sRootId = _sRootId;
                return oDBAccess.create({
                    ID: sRootId,
                    TITLE: "ABC",
                    DESCRIPTION: "DEF"
                });
            }).then(() => {
                return oDBAccess.read(sRootId);
            }).then((oObject) => {
                oDBAccess.read(sRootId).then((oObjectBuffered) => {
                    expect(oObjectBuffered).toBe(oObject);
                }).then(() => {
                    return oDBAccess.update({
                        ID: sRootId,
                        TITLE: "Change",
                        DESCRIPTION: "DEF"
                    });
                }).then(() => {
                    return oDBAccess.read(sRootId);
                }).then((oObjectAfterUpdate) => {
                    expect(oObjectAfterUpdate).not.toBe(oObject);
                    return oDBAccess.read(sRootId).then((oObjectAfterUpdateBuffered) => {
                        expect(oObjectAfterUpdateBuffered).toBe(oObjectAfterUpdate);
                        done();
                    });
                });
            });
        });
    });

    it("allows accessing keys by node from an object", (done) => {
        Metadata.getMetadata("sap.aof.test.db.test.TestAO", oContext, {
            actions: oDummyActions,
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                nodes: {
                    Node1: {
                        table: TEST_TABLE_NODE_1,
                        sequence: TEST_SEQUENCE_NODE_1,
                        parentKey: "PARENT_ID"
                    },
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            var oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);

            var oNodeKeys = oDBAccess.getNodeKeys({
                ID: 4711,
                Node1: [{
                    ID: 4712
                }, {
                    ID: 4713
                }],
                Node2: [{
                    ID: 4711,
                    Node21: [{
                        ID: 4711
                    }]
                }, {
                    ID: 4712,
                    Node21: [{
                        ID: 4712
                    }]
                }]
            });
            expect(oNodeKeys).toEqual({
                Root: [4711],
                Node1: [4712, 4713],
                Node2: [4711, 4712],
                Node21: [4711, 4712]
            });
            done();
        });
    });

    it("updates rows in bulk access", (done) => {
        var oDBAccess;
        var oMetadataAccess;
        var oTestContext;
        var fnSequenceRoot;

        Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkOneNode", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                historyTable: TEST_HISTORY_TABLE
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oContext.storeInfo.hana.user);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oContext.store;
                },
                getDB: () => {
                    return oContext.store.getDB();
                }
            };
        }).then(() => {
            return Promise.all([fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot()]).then((aKeys) => {
                var iBulkId = aKeys[0];
                return Promise.all([
                    oDBAccess.create({
                        ID: aKeys[0],
                        TITLE: "BULKCHANGE1_" + iBulkId,
                        DESCRIPTION: "A"
                    }, undefined, oTestContext),
                    oDBAccess.create({
                        ID: aKeys[1],
                        TITLE: "BULKCHANGE1_" + iBulkId,
                        DESCRIPTION: "B"
                    }, undefined, oTestContext),
                    oDBAccess.create({
                        ID: aKeys[2],
                        TITLE: "BULKCHANGE2_" + iBulkId,
                        DESCRIPTION: "C"
                    }, undefined, oTestContext)
                ]).then(() => {
                    createTimestamp();
                    oTestContext.getHistoryEvent = () => {
                        return "CHANGED_IN_BULK";
                    };
                    // Get bulk access which implicitely simulates everything, callers cannot decide any more
                    var oBulkAccess = oContext.store.getBulkAccess(oMetadataAccess, oTestContext, true, oDBAccess);
                    expect(oBulkAccess).toBeDefined();
                    return oBulkAccess.update({
                        Root: {
                            DESCRIPTION: "Bulk"
                        }
                    }, {
                        condition: "TITLE = ?",
                        conditionParameters: ["BULKCHANGE1_" + iBulkId]
                    }).then((oResponse) => {
                        expect(oResponse.messages).toEqual([]);
                        expect(oResponse.affectedNodes.Root).toBeDefined();
                        expect(oResponse.affectedNodes.Root.operation).toBe("update");
                        expect(oResponse.affectedNodes.Root.count).toBe(2);
                        return oDBAccess.read(aKeys[0]);
                    }).then((oObject) => {
                        // check that nothing has been changed
                        expect(oObject.DESCRIPTION).toBe("A");
                        return oDBAccess.read(aKeys[1]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).toBe("B");
                        return oDBAccess.read(aKeys[2]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).toBe("C");
                    });
                }).then(() => {
                    // Get bulk access which is allowed to update
                    var oBulkAccess = oContext.store.getBulkAccess(oMetadataAccess, oTestContext, false, oDBAccess);
                    expect(oBulkAccess).toBeDefined();
                    // Use simulation per call
                    return oBulkAccess.update({
                        Root: {
                            DESCRIPTION: "Bulk"
                        }
                    }, {
                        condition: "TITLE = ?",
                        conditionParameters: ["BULKCHANGE1_" + iBulkId]
                    }, true).then((oResponse) => {
                        expect(oResponse.messages).toEqual([]);
                        expect(oResponse.affectedNodes.Root).toBeDefined();
                        expect(oResponse.affectedNodes.Root.operation).toBe("update");
                        expect(oResponse.affectedNodes.Root.count).toBe(2);
                        // check that nothing has been changed
                        return oDBAccess.read(aKeys[0]);
                    }).then((oObject) => {
                        // check that nothing has been changed
                        expect(oObject.DESCRIPTION).toBe("A");
                        return oDBAccess.read(aKeys[1]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).toBe("B");
                        return oDBAccess.read(aKeys[2]);
                    }).then((oObject) => {
                        expect(oObject.DESCRIPTION).toBe("C");
                    }).then(() => {
                        // real update without simulation
                        return oBulkAccess.update({
                            Root: {
                                DESCRIPTION: "Bulk"
                            }
                        }, {
                            condition: "TITLE = ?",
                            conditionParameters: ["BULKCHANGE1_" + iBulkId]
                        }).then((oResponse) => {
                            expect(oResponse.messages).toEqual([]);
                            expect(oResponse.affectedNodes.Root).toBeDefined();
                            expect(oResponse.affectedNodes.Root.operation).toBe("update");
                            expect(oResponse.affectedNodes.Root.count).toBe(2);
                            return oDBAccess.read(aKeys[0]);
                        }).then((oObject) => {
                            // check that nothing has been changed
                            expect(oObject.DESCRIPTION).toBe("Bulk");
                            return oDBAccess.read(aKeys[1]);
                        }).then((oObject) => {
                            expect(oObject.DESCRIPTION).toBe("Bulk");
                            return oDBAccess.read(aKeys[2]);
                        }).then((oObject) => {
                            expect(oObject.DESCRIPTION).toBe("C");
                        });
                    }).then(() => {
                        return oContext.store.getClient().statement("select * from \"" + TEST_HISTORY_TABLE + "\" where history_biz_event = 'CHANGED_IN_BULK' and id in (?,?,?) order by id").execute(aKeys);
                    }).then((aHistory) => {
                        expect(aHistory.length).toBe(2);
                        expect(aHistory[0].ID).toBe(aKeys[0]);
                        expect(aHistory[0].DESCRIPTION).toBe("Bulk");
                        expect(aHistory[0].TITLE).toBe("BULKCHANGE1_" + iBulkId);
                        expect(aHistory[1].ID).toBe(aKeys[1]);
                        expect(aHistory[1].DESCRIPTION).toBe("Bulk");
                        expect(aHistory[1].TITLE).toBe("BULKCHANGE1_" + iBulkId);
                        done();
                    });
                });
            });
        });
    });

    it("updates parent nodes in bulk access", (done) => {
        var oDBAccess;
        var oTestContext;

        Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkParent", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                historyTable: TEST_HISTORY_TABLE,
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    },
                    Node3: {
                        table: TEST_TABLE_NODE_3,
                        sequence: TEST_SEQUENCE_NODE_3,
                        parentKey: "OBJECT_ID",
                        attributes: {
                            OBJECT_TYPE_CODE: {
                                constantKey: "A"
                            }
                        }
                    }
                }
            }
        }).then((oMetadataAccess) => {
            oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            var fnSequenceNode2 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2});
            var fnSequenceNode21 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2_1});
            var fnSequenceNode3 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_3});

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oContext.storeInfo.hana.user);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oContext.store;
                },
                getDB: () => {
                    return oContext.store.getDB();
                }
            };
            return Promise.all([
                fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot(),
                fnSequenceNode2(), fnSequenceNode2(),
                fnSequenceNode21(), fnSequenceNode21(),
                fnSequenceNode3(), fnSequenceNode3()
            ]).then((aKey) => {
                var iBulkId = aKey[0];

                var aRootKeys = [aKey[0], aKey[1], aKey[2]];
                var aNode2Keys = [aKey[3], aKey[4]];
                var aNode21Keys = [aKey[5], aKey[6]];
                var aNode3Keys = [aKey[7], aKey[8]];
                return Promise.all([
                    oDBAccess.create({
                        ID: aRootKeys[0],
                        TITLE: "A",
                        DESCRIPTION: "A",
                        Node2: [{
                            ID: aNode2Keys[0],
                            SOMETEXT: "A Node 2",
                            Node21: [{
                                ID: aNode21Keys[0],
                                SOMETEXT: "A Node 21",
                                ANOTHERONE: "A Node 21 - " + iBulkId
                            }]
                        }]
                    }, undefined, oTestContext),
                    oDBAccess.create({
                        ID: aRootKeys[1],
                        TITLE: "B",
                        DESCRIPTION: "B",
                        Node2: [{
                            ID: aNode2Keys[1],
                            SOMETEXT: "B Node 2",
                            Node21: [{
                                ID: aNode21Keys[1],
                                SOMETEXT: "B Node 21",
                                ANOTHERONE: "B Node 21 - " + iBulkId
                            }]
                        }]
                    }, undefined, oTestContext)
                ]).then(() => {
                    oTestContext.getHistoryEvent = () => {
                        return "CHANGED_IN_BULK";
                    };
                    var oBulkAccess = oContext.store.getBulkAccess(oMetadataAccess, oTestContext);
                    expect(oBulkAccess).toBeDefined();
                    oBulkAccess.update({
                        Node21: {
                            SOMETEXT: "BB Node 21",
                            Node2: {
                                Root: {
                                    DESCRIPTION: "BB"
                                }
                            }
                        }
                    }, {
                        // using the (optional) table alias "node"
                        condition: "xyz.ANOTHERONE = ?",
                        conditionParameters: ["B Node 21 - " + iBulkId],
                        conditionNodeAlias: "xyz"
                    }).then((oResponse) => {
                        expect(oResponse.messages).toEqual([]);
                        expect(oResponse.affectedNodes.Root.count).toBe(1);
                        expect(oResponse.affectedNodes.Node2.count).toBe(0);
                        expect(oResponse.affectedNodes.Node21.count).toBe(1);
                        return oDBAccess.read(aRootKeys[0]);
                    }).then((oObjectA) => {
                        expect(oObjectA.TITLE).toBe("A");
                        expect(oObjectA.DESCRIPTION).toBe("A");
                        expect(oObjectA.Node2[0].SOMETEXT).toBe("A Node 2");
                        expect(oObjectA.Node2[0].Node21[0].SOMETEXT).toBe("A Node 21");
                        expect(oObjectA.Node2[0].Node21[0].ANOTHERONE).toBe("A Node 21 - " + iBulkId);
                        return oDBAccess.read(aRootKeys[1]);
                    }).then((oObjectB) => {
                        expect(oObjectB.TITLE).toBe("B");
                        expect(oObjectB.DESCRIPTION).toBe("BB");
                        expect(oObjectB.Node2[0].SOMETEXT).toBe("B Node 2");
                        expect(oObjectB.Node2[0].Node21[0].SOMETEXT).toBe("BB Node 21");
                        expect(oObjectB.Node2[0].Node21[0].ANOTHERONE).toBe("B Node 21 - " + iBulkId);
                        return oContext.store.getClient().statement(
                            "select * from \"" + TEST_HISTORY_TABLE
                            + "\" where history_biz_event = 'CHANGED_IN_BULK' and id in (?) order by id").execute(
                            aRootKeys[1]);
                    }).then((aHistory) => {
                        expect(aHistory.length).toBe(1);
                        expect(aHistory[0].TITLE).toBe("B");
                        expect(aHistory[0].DESCRIPTION).toBe("BB");
                    }).then(() => {
                        oTestContext.getHistoryEvent = () => {
                            return "CREATED";
                        };
                        return oDBAccess.create({
                            ID: aRootKeys[2],
                            TITLE: "B",
                            DESCRIPTION: "B",
                            Node3: [{
                                ID: aNode3Keys[1],
                                SOMETEXT: "B Node 3",
                                ANOTHER_TYPE_CODE: "XYZ - " + iBulkId
                            }]
                        }, undefined, oTestContext);
                    }).then(() => {
                        return oBulkAccess.update({
                            Node3: {
                                SOMETEXT: "BB Node 3",
                                Root: {
                                    TITLE: "BB"
                                }
                            }
                        }, {
                            condition: "another_type_code = ?",
                            conditionParameters: ["XYZ - " + iBulkId]
                        });
                    }).then(() => {
                        return oDBAccess.read(aRootKeys[2]);
                    }).then((oObjectB) => {
                        expect(oObjectB.TITLE).toBe("BB");
                        expect(oObjectB.Node3[0].SOMETEXT).toBe("BB Node 3");
                        expect(oObjectB.Node3[0].ANOTHER_TYPE_CODE).toBe("XYZ - " + iBulkId);

                        done();
                    });
                });
            });
        });
    });

    it("updates nodes in bulk considering constant keys", (done) => {
        var oTestContext;
        var oDBAccessA;
        var oDBAccessB;
        var oMetadataA;
        var oMetadataB;
        var fnSequenceRoot;

        Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkA", oContext, {
            Root: {
                table: TEST_TABLE_NODE_3,
                sequence: TEST_SEQUENCE_NODE_3,
                attributes: {
                    OBJECT_TYPE_CODE: {
                        constantKey: "A"
                    }
                }
            }
        }).then((_oMetadataA) => {
            oMetadataA = _oMetadataA;
            oDBAccessA = oContext.store.getObjectAccess(oMetadataA);
            fnSequenceRoot = oDBAccessA.getSequence({sequence: TEST_SEQUENCE_NODE_3});

            return Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkB", oContext, {
                Root: {
                    table: TEST_TABLE_NODE_3,
                    sequence: TEST_SEQUENCE_NODE_3,
                    attributes: {
                        OBJECT_TYPE_CODE: {
                            constantKey: "B"
                        }
                    }
                }
            })
        }).then((_oMetadataB) => {
            oMetadataB = _oMetadataB;
            oDBAccessB = oContext.store.getObjectAccess(oMetadataB);
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oContext.storeInfo.hana.user);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oContext.store;
                },
                getDB: () => {
                    return oContext.store.getDB();
                }
            };
        }).then(() => {
            return Promise.all([
                fnSequenceRoot(), fnSequenceRoot()
            ]).then((aKeys) => {
                return Promise.all([
                    oDBAccessA.create({
                        ID: aKeys[0],
                        OBJECT_ID: 11,
                        ANOTHER_TYPE_CODE: "AA",
                        SOMETEXT: "Instance A"
                    }, undefined, oTestContext),
                    oDBAccessB.create({
                        ID: aKeys[1],
                        OBJECT_ID: 11,
                        ANOTHER_TYPE_CODE: "BB",
                        SOMETEXT: "Instance B"
                    }, undefined, oTestContext)
                ]).then(() => {
                    var oBulkAccess = oContext.store.getBulkAccess(oMetadataA, oTestContext);
                    return oBulkAccess.update({
                        Root: {
                            SOMETEXT: "Instance Bulk Change"
                        }
                    }, {
                        condition: "OBJECT_ID = ?",
                        conditionParameters: [11]
                    }).then((oResponse) => {
                        expect(oResponse.messages).toEqual([]);
                        return oDBAccessA.read(aKeys[0]);
                    }).then((oObjectA) => {
                        expect(oObjectA.SOMETEXT).toBe("Instance Bulk Change");
                        return oDBAccessB.read(aKeys[1]);
                    }).then((oObjectB) => {
                        expect(oObjectB.SOMETEXT).toBe("Instance B");
                        return oBulkAccess.update({
                            Root: {
                                ID: 37237
                            }
                        }, {
                            condition: "OBJECT_ID = ?",
                            conditionParameters: [11]
                        });
                    }).then((oResponse) => {
                        expect(oResponse.messages).toEqual([{
                            severity: Message.MessageSeverity.Fatal,
                            messageKey: 'MSG_AOF_BULK_PK_UPDATE_NOT_ALLOWED',
                            refObject: 'sap.aof.test.db.test.TestAOBulkA',
                            refKey: undefined,
                            refNode: 'Root',
                            refAttribute: undefined,
                            parameters: []
                        }]);
                        return oBulkAccess.update({
                            Root: {
                                OBJECT_TYPE_CODE: "X"
                            }
                        }, {
                            condition: "OBJECT_ID = ?",
                            conditionParameters: [11]
                        });
                    }).then((oResponse) => {
                        expect(oResponse.messages).toEqual([{
                            severity: Message.MessageSeverity.Fatal,
                            messageKey: 'MSG_AOF_BULK_CK_UPDATE_NOT_ALLOWED',
                            refObject: 'sap.aof.test.db.test.TestAOBulkA',
                            refKey: undefined,
                            refNode: 'Root',
                            refAttribute: undefined,
                            parameters: []
                        }]);
                        done();
                    });
                });
            });
        });
    });

    it("deletes nodes and their subnodes rows in bulk access", (done) => {
        var oMetadataAccess;
        var oDBAccess;
        var oTestContext;
        var fnSequenceRoot;
        var fnSequenceNode2;

        Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkOneNode", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                historyTable: TEST_HISTORY_TABLE,
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID"
                    }
                }
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            fnSequenceNode2 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2});

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oContext.storeInfo.hana.user);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oContext.store;
                },
                getDB: () => {
                    return oContext.store.getDB();
                }
            };
        }).then(() => {
            return Promise.all([
                fnSequenceRoot(), fnSequenceRoot(), fnSequenceRoot(),
                fnSequenceNode2(), fnSequenceNode2()
            ]).then((aKey) => {
                var aRootKeys = [aKey[0], aKey[1], aKey[2]];
                var aNode2Keys = [aKey[3], aKey[4]];
                return Promise.all([
                    oDBAccess.create({
                        ID: aRootKeys[0],
                        TITLE: "BULKCHANGE1",
                        DESCRIPTION: "A",
                        Node2: [{
                            ID: aNode2Keys[0],
                            SOMETEXT: "A Node 2"
                        }]
                    }, undefined, oTestContext),
                    oDBAccess.create({
                        ID: aRootKeys[1],
                        TITLE: "BULKCHANGE1",
                        DESCRIPTION: "B"
                    }, undefined, oTestContext),
                    oDBAccess.create({
                        ID: aRootKeys[2],
                        TITLE: "BULKCHANGE2",
                        DESCRIPTION: "C",
                        Node2: [{
                            ID: aNode2Keys[1],
                            SOMETEXT: "C Node 2"
                        }]
                    }, undefined, oTestContext)
                ]).then(() => {
                    oTestContext.getHistoryEvent = () => {
                        return "DELETED_IN_BULK";
                    };
                    var oBulkAccess = oContext.store.getBulkAccess(oMetadataAccess, oTestContext);
                    expect(oBulkAccess).toBeDefined();
                    return oBulkAccess.del({
                        Root: {}
                    }, {
                        condition: "title = ?",
                        conditionParameters: ["BULKCHANGE1"]
                    });
                }).then((oResponse) => {
                    expect(oResponse.messages).toEqual([]);
                    return oDBAccess.read(aRootKeys[0]);
                }).then((oObjectA) => {
                    expect(oObjectA).toBe(null);
                    return oDBAccess.read(aRootKeys[1]);
                }).then((oObjectB) => {
                    expect(oObjectB).toBe(null);
                    return oDBAccess.read(aRootKeys[2]);
                }).then((oObjectC) => {
                    expect(oObjectC.DESCRIPTION).toBe("C");
                }).then(() => {
                    return oContext.store.getClient().statement(
                        "select * from \"" + TEST_HISTORY_TABLE
                        + "\" where history_biz_event = 'DELETED_IN_BULK' and id in (?,?,?) order by id").execute(
                        aRootKeys);
                }).then((aHistory) => {
                    expect(aHistory.length).toBe(2);
                    expect(aHistory[0].ID).toBe(aRootKeys[0]);
                    expect(aHistory[0].HISTORY_DB_EVENT).toBe("DELETED");
                    expect(aHistory[0].DESCRIPTION).toBe("A");
                    expect(aHistory[1].ID).toBe(aRootKeys[1]);
                    expect(aHistory[1].HISTORY_DB_EVENT).toBe("DELETED");
                    expect(aHistory[1].DESCRIPTION).toBe("B");
                    return oContext.store.getClient().statement("select * from \"" + TEST_TABLE_NODE_2 + "\" where id in (?,?) order by id")
                        .execute(aNode2Keys);
                }).then((aNode2) => {
                    expect(aNode2.length).toBe(1);
                    expect(aNode2[0].ID).toBe(aNode2Keys[1]);
                    expect(aNode2[0].SOMETEXT).toBe("C Node 2");
                    done();
                });
            });
        });
    });

    it("deletes child nodes in bulk while updating parent nodes", (done) => {
        var oMetadataAccess;
        var oDBAccess;
        var oTestContext;

        Metadata.getMetadata("sap.aof.test.db.test.TestAOBulkParent", oContext, {
            Root: {
                table: TEST_TABLE,
                sequence: TEST_SEQUENCE,
                historyTable: TEST_HISTORY_TABLE,
                nodes: {
                    Node2: {
                        table: TEST_TABLE_NODE_2,
                        sequence: TEST_SEQUENCE_NODE_2,
                        parentKey: "PARENT_ID",
                        nodes: {
                            Node21: {
                                table: TEST_TABLE_NODE_2_1,
                                sequence: TEST_SEQUENCE_NODE_2_1,
                                parentKey: "PARENT_ID"
                            }
                        }
                    }
                }
            }
        }).then((_oMetadataAccess) => {
            oMetadataAccess = _oMetadataAccess;
            oDBAccess = oContext.store.getObjectAccess(oMetadataAccess);
            var fnSequenceRoot = oDBAccess.getSequence({sequence: TEST_SEQUENCE});
            var fnSequenceNode2 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2});
            var fnSequenceNode21 = oDBAccess.getSequence({sequence: TEST_SEQUENCE_NODE_2_1});

            createTimestamp();
            oTestContext = {
                getUser: () => {
                    return Promise.resolve(oContext.storeInfo.hana.user);
                },
                getHistoryEvent: () => {
                    return "CREATED";
                },
                getRequestTimestamp: () => {
                    return sTimestamp;
                },
                getStoreAccess: () => {
                    return oContext.store;
                },
                getDB: () => {
                    return oContext.store.getDB();
                }
            };

            return Promise.all([
                fnSequenceRoot(),
                fnSequenceNode2(), fnSequenceNode2(),
                fnSequenceNode21(), fnSequenceNode21()
            ]).then((aKey) => {
                var iBulkId = aKey[0];

                var aRootKeys = [aKey[0]];
                var aNode2Keys = [aKey[1], aKey[2]];
                var aNode21Keys = [aKey[3], aKey[4]];
                return oDBAccess.create({
                    ID: aRootKeys[0],
                    TITLE: "A",
                    DESCRIPTION: "A",
                    Node2: [{
                        ID: aNode2Keys[0],
                        SOMETEXT: "A Node 2.1 - " + iBulkId,
                        Node21: [{
                            ID: aNode21Keys[0],
                            SOMETEXT: "A Node 2.1 / 1",
                            ANOTHERONE: "X"
                        }]
                    }, {
                        ID: aNode2Keys[1],
                        SOMETEXT: "A Node 2.2 - " + iBulkId,
                        Node21: [{
                            ID: aNode21Keys[1],
                            SOMETEXT: "A Node 2.2 / 1",
                            ANOTHERONE: "X"
                        }]
                    }]
                }, undefined, oTestContext).then(() => {
                    oTestContext.getHistoryEvent = () => {
                        return "BULK_DELETE_AND_UPDATE";
                    };
                    var oBulkAccess = oContext.store.getBulkAccess(oMetadataAccess, oTestContext);
                    return oBulkAccess.del({
                        Node2: {
                            Root: {
                                DESCRIPTION: "After Delete Node 2.1"
                            }
                        }
                    }, {
                        condition: "sometext = ?",
                        conditionParameters: ["A Node 2.1 - " + iBulkId]
                    });
                }).then((oResponse) => {
                    expect(oResponse.messages).toEqual([]);
                    return oDBAccess.read(aRootKeys[0]);
                }).then((oObject) => {
                    expect(oObject.DESCRIPTION).toBe("After Delete Node 2.1");
                    expect(oObject.Node2.length).toBe(1);
                    expect(oObject.Node2[0].ID).toBe(aNode2Keys[1]);
                    expect(oObject.Node2[0].SOMETEXT).toBe("A Node 2.2 - " + iBulkId);
                    expect(oObject.Node2[0].Node21[0].ID).toBe(aNode21Keys[1]);
                    // Subnode of Node 2.1 needs to be gone as well
                    return oContext.store.getClient().statement("select * from \"" + TEST_TABLE_NODE_2_1 + "\" where id in (?,?) order by id")
                        .execute(aNode21Keys);
                }).then((aNode21) => {
                    expect(aNode21.length).toBe(1);
                    expect(aNode21[0].ID).toBe(aNode21Keys[1]);
                    done();
                });
            });
        });
    });

    it("deletes objects marked as 'cascading delete' when deleting root nodes in bulk", (done) => {
        var AOF = require("../../../lib/core/framework");
        var iKey;
        var iBulkId = new Date().getTime();

        AOF.getApplicationObject("test.object.TestAO", oContext).then((TestAO) => {
            expect(TestAO).toBeDefined();
            AOF.getApplicationObject("test.object.TestAOFK", oContext).then((TestAOFK) => {
                expect(TestAOFK).toBeDefined();
                return TestAO.create({
                    ID: -1,
                    TITLE: "A reference title",
                    DESCRIPTION: "A" + iBulkId
                }).then((oResponse) => {
                    iKey = oResponse.generatedKeys[-1];
                    return TestAOFK.create({
                        ID: -1,
                        OBJECT_ID: iKey,
                        OBJECT_TYPE_CODE: "ABC",
                        ANOTHER_TYPE_CODE: "ABC",
                        SOMETEXT: "Sometext"
                    });
                }).then((oResponse) => {
                    expect(oResponse).toBeDefined();
                    expect(oResponse.messages).toEqual([]);
                    createTimestamp();
                    var oTestContext = {
                        getUser: () => {
                            return Promise.resolve(oContext.storeInfo.hana.user);
                        },
                        getHistoryEvent: () => {
                            return "BULK_DELETE_CASCADE";
                        },
                        getRequestTimestamp: () => {
                            return sTimestamp;
                        },
                        getStoreAccess: () => {
                            return oContext.store;
                        },
                        getDB: () => {
                            return oContext.store.getDB();
                        },
                        getMetadata: (sObjectName) => {
                            return AOF.getMetadata(sObjectName, oContext);
                        }
                    };
                    var oBulkAccess = oContext.store.getBulkAccess(TestAO.getMetadata(), oTestContext);
                    return oBulkAccess.del({
                        Root: {}
                    }, {
                        condition: "description = ?",
                        conditionParameters: ["A" + iBulkId]
                    });
                }).then((oResponse) => {
                    expect(oResponse.messages).toEqual([]);
                    return oContext.store.getClient().statement(
                        'select * from "sap.aof.test.db.test::t_test_node_3" where object_id = ?').execute(iKey);
                }).then((aFKRefs) => {
                    expect(aFKRefs).toEqual([]);
                    TestAO.close();
                    TestAOFK.close();
                    done();
                });
            });
        });
    });
});