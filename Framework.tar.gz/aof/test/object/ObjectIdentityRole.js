"use strict";

module.exports.ObjectType = {
    Comment: "COMMENT"
};

module.exports.Role = {
    CommentOwner: "COMMENT_OWNER"
};

module.exports.node = (sObjectType, sRole) => {
    return {
        table: "sap.aof.test.db.iam::t_object_identity_role",
        sequence: "sap.aof.test.db.iam::s_object_identity_role",
        parentKey: "OBJECT_ID",
        attributes: {
            OBJECT_TYPE_CODE: {
                constantKey: sObjectType
            },
            ROLE_CODE: {
                constantKey: sRole
            }
        }
    };
};
