sap.ui.define([
    "sap/aof/ApplicationObject",
    "sap/aof/ReadSource"
], function (ApplicationObject, ReadSource) {
    "use strict";

    return ApplicationObject.extend("sap.todo.aof.example.model.User", {
        objectName: "sap.todo.xs.rest.User",
        readSource: ReadSource.getDefaultAOFSource(),
        invalidation: {
            entitySets: ["Todo_User"]
        }
    });
});