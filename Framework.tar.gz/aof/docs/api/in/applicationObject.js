"use strict";

/**
 * Application Object runtime facade for an Application Object
 * @example
 * var aof = require("@sap/aof");
 *
 * aof.getApplicationObject("object.Test", {storeInfo: oStoreInfo}).then(function (Object) {
 *   return Object.create({
 *       ID: -1,
 *       NAME: "Test"
 *   }).then(function (oResponse) {
 *     var iRootId = oResponse.generatedKeys[-1];
 *     return Object.read(iRootId).then(function (oObject) {
 *       return Object.update({
 *         ID: iRootId,
 *         NAME: "Test Update"
 *       }).then(function (oResponse) {
 *         return Object.del(iRootId);
 *       });
 *     });
 *   }).then(function () {
 *     Object.close();
 *   });
 * }).catch(function (oError) {
 * });
 * @namespace ApplicationObject
 */
function ApplicationObject() {
}

/**
 * Returns application object name
 * @returns {string} Name of application object
 */
ApplicationObject.prototype.getName = function () {
    return "";
};

/**
 * Creates an application object instance (including sub-structure)
 * @param oCreateRequest {Object} Javascript object of the application object instance. Handle keys have to be negative numbers and are replaced by generated keys
 * @returns oResponse {Promise.<Response>} Create response
 */
ApplicationObject.prototype.create = function (oCreateRequest) {
    return new Promise({messages: [], generatedKeys: {}});
};

/**
 * Creates a new application object instance by copying an existing one
 * @param vOriginalKey {*} Key of the original Application Object instance to be copied
 * @param oCopyRequest {Object} Javascript object containing data the copied object should get. Usually you would supply a handle for the Root key of the new object so that you are able to get the key of the copied object
 * @returns oResponse {Promise.<Response>} Copy response
 */
ApplicationObject.prototype.copy = function (vOriginalKey, oCopyRequest) {
    return new Promise({messages: [], generatedKeys: {}});
};

/**
 * Updates an application object instance (including sub-structure) using the root key
 * @param oUpdateRequest {Object} Javascript object of the application object instance. Object instance key is extracted from the root and needs to be a real key. Handle keys have to be negative numbers and are replaced by generated keys.
 * @param [sConcurrencyToken] {String} String which is used for concurrency control mechanisms (equivalent to the ETag in HTTP). It is optional, when not present no conflict detection will be done.
 * @returns oResponse {Promise.<Response>} Update response
 */
ApplicationObject.prototype.update = function (oUpdateRequest, sConcurrencyToken) {
    return new Promise({messages: [], generatedKeys: {}});
};

/**
 * Deletes an application object instance (including sub-structure) using passed key
 * @param vKey {*} Key value of the application object instance
 * @param [sConcurrencyToken] {String} String which is used for concurrency control mechanisms (equivalent to the ETag in HTTP). It is optional, when not present no conflict detection will be done.
 * @returns oResponse {Promise.<Response>} Delete response
 */
ApplicationObject.prototype.del = function (vKey, sConcurrencyToken) {
    return new Promise({messages: []});
};

/**
 * Checks existence of application object instance (node) using passed primary key
 * @param vKey {*} Key value of the application object instance
 * @param [sNodeName] {String} Existing check is performed for this node of the application object (default: Root)
 * @returns {Promise.<Boolean>} Promise resolving response boolean (true or false)
 */
ApplicationObject.prototype.exists = function (vKey, sNodeName) {
    return new Promise(true);
};

/**
 * Converts alternative key of application object instance into key. Null if alternative primary key is not existing.
 * @param vAlternativeKey {*} Alternative key value of the application object instance
 * @param bReturnRoot {boolean} Return root node data instead of just the primary key
 * @returns {Promise.<*>|null} Promise resolving response key/object or null if object is not found
 */
ApplicationObject.prototype.convertKey = function (vAlternativeKey, bReturnRoot) {
    return new Promise("");
};

/**
 * Reads the application object instance for the passed key. Returns null if no object is found
 * @param vKey {*} Key value of the application object instance
 * @param bLock {*} Lock application object instance in the session against parallel changes
 * @returns {Promise.<Object>} Promise resolving response data object: Application object (including sub structure) as Javascript/JSON object, null if object is not found
 */
ApplicationObject.prototype.read = function (vKey, bLock) {
    return new Promise(Object);
};

/**
 * Calculates the concurrency token for the pass key
 * @param vKey Key value of the application object instance
 * @param [oObject] {Object} Object data which clients might already have. If not given the current object will be read from the database to calculate the concurrency token.
 * @returns {String} String used as representation for the application object instance which is used for concurrency control means in update, delete and customActions
 */
ApplicationObject.prototype.calculateConcurrencyToken = function (vKey, oObject) {
    return "";
};

/**
 * Calls a custom action on an application object instance (including sub-structure) using the passed key and the passed parameters.
 * "_customAction_" stands for the real name of the action to be called.
 * @param vKey Key value of the application object instance the action is called on
 * @param [oParameters] {Object} Javascript object of action parameters passed into the action execution call
 * @param [sConcurrencyToken] {String} String which is used for concurrency control mechanisms (equivalent to the ETag in HTTP). It is optional, when not present no conflict detection will be done.
 * @returns oResponse {Promise.<Response>} Custom Action response
 */
ApplicationObject.prototype._customAction_ = function (vKey, oParameters, sConcurrencyToken) {
    return new Promise({messages: [], generatedKeys: {}});
};

/**
 * Calls a static custom action on an application object instance (including sub-structure) using the passed key and the passed parameters
 * "_staticCustomAction_" stands for the real name of the action to be called.
 * @param [oParameters] {Object} Javascript object of action parameters passed into the action execution call
 * @returns oResponse {Promise.<Response>} Static Custom Action response
 */
ApplicationObject.prototype._staticCustomAction_ = function (oParameters) {
    return new Promise({messages: []});
};

/**
 * Dynamic properties can be retrieved for an existing application object instance for actions, nodes and attributes
 * @param vKey Key value of the application object instance the action is called on
 * @param [oScope] {Object} Javascript object including an array of action names and/or an array of node names, defining the scope of reading the properties.
 * @param [oScope.actions] {(Array|Boolean)} Array of action names. "True" to retrieve properties for all actions. Action name provided as Object like {name : &lt;actionName&gt;, parameters : &lt;any&gt; } determines the parameters dependent properties
 * @param [oScope.nodes] {(Array.<String>|Boolean)} Array of node names. "True" to retrieve properties for all nodes.
 * @returns oResponse {Promise.<Object>} Promise resolving to the properties result object
 * @returns oResponse.actions {Object} Object including properties for each action represented as object { &lt;actionName&gt; : { enabled : &lt;boolean&gt;, messages : [] }, ... }
 * @returns oResponse.nodes {Object} Object including properties for each node instance and respective attributes represented as object { &lt;nodeName&gt; : { &lt;vKey&gt; : { readOnly : &lt;boolean&gt;, messages : [], attributes : { &lt;attributeName&gt; : { readOnly : &lt;boolean&gt;, messages : [] }, ... }, ... }, … }, … }
 */
ApplicationObject.prototype.properties = function (vKey, oScope) {
    return new Promise({actions: {}, nodes: {}});
};

/**
 * Static properties can be retrieved for an existing application object instance for actions, nodes and attributes
 * @param [oScope] {Object} Javascript object including an array of action and/or an array of node names, defining the scope of reading the properties.
 * @param [oScope.actions] {(Array.<Object>)} Array of object, containing a action name to action parameter mapping
 * @param [oScope.nodes] {(Array.<String>|Boolean)} Array of node names. "True" to retrieve static properties for all nodes
 * @returns oResponse {Promise.<Object>} Promise resolving to the static properties result object
 * @returns oResponse.actions {Object} Object including properties for each action represented as object { &lt;actionName&gt; : { enabled : &lt;boolean&gt;, messages : [] }, ... }
 * @returns oResponse.nodes {Object} Object including properties for each node instance and respective attributes represented as object { &lt;nodeName&gt; : { readOnly : &lt;boolean&gt;, attributes : { &lt;attributeName&gt; : { readOnly : &lt;boolean&gt; }, ... }, ... }, ... }
 */
ApplicationObject.prototype.staticProperties = function (oScope) {
    return new Promise({actions: {}, nodes: {}});
};

/**
 * Returns the Application Object metadata of the instance's Application Object type
 * @returns {Promise.<Metadata>} Promise resolving to the metadata object
 */
ApplicationObject.prototype.getMetadata = function () {
    return Promise;
};

/**
 * Commits the current active transaction. All Application Object instances changes for all Application Object types are committed
 * @returns {Promise} Resolved when committed
 */
ApplicationObject.prototype.commit = function () {
    return new Promise();
};

/**
 * Rollbacks the current active transaction. All Application Object instances changes for all Application Object types are rolled back
 * @returns {Promise} Resolved when rolled back
 */
ApplicationObject.prototype.rollback = function () {
    return new Promise();
};

/**
 * Closes the Application Object instance after the instance is not needed anymore.
 * The connection to the DB is closed and the instance shall not be used anymore.
 */
ApplicationObject.prototype.close = function () {
};

/**
 * Get the database object provided in the caller context
 * @returns {Object} DB object
 */
ApplicationObject.prototype.getDB = function () {
    return Object;
};

/**
 * Returns the user name of the current user
 * @returns {Promise.<String>} Promise resolving to current user name
 */
ApplicationObject.prototype.getUser = function () {
    return new Promise();
};
