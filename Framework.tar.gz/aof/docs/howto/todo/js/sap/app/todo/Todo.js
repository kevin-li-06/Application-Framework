"use strict";

var AOF = require("@sap/aof");
var Determine = AOF.Determination;
var _ = AOF._;

var Message = AOF.Message;

module.exports = {
    actions: {
        create: {
            authorizationCheck: false
        },
        update: {
            authorizationCheck: checkAuth
        },
        del: {
            authorizationCheck: checkAuth
        },
        read: {
            authorizationCheck: checkAuth
        },
        setToDone: {
            authorizationCheck: checkAuth,
            execute: setToDone,
            enabledCheck: setToDoneEnabled
        }
    },
    Root: {
        table: "sap.app.db.todo::t_todo",
        sequence: "sap.app.db.todo::s_todo",
        determinations: {
            onCreate: [initTodo],
            onModify: [Determine.systemAdminData, propagateItem]
        },
        consistencyChecks: [checkChangeable],
        nodes: {
            Owner: {
                table: "sap.app.db.todo::t_todo_owner",
                sequence: "sap.app.db.todo::s_todo_owner",
                parentKey: "PARENT_ID",
                readOnly: true,
                attributes: {
                    USERNAME: {
                        required: true,
                        isName: true,
                        isDescription: true
                    }
                }
            },
            Items: {
                table: "sap.app.db.todo::t_todo_item",
                sequence: "sap.app.db.todo::s_todo_item",
                parentKey: "PARENT_ID",
                attributes: {
                    NAME: {
                        required: true,
                        isName: true,
                        isDescription: true
                    }
                }
            }
        },
        attributes: {
            CREATED_AT: {
                readOnly: true
            },
            CREATED_BY: {
                readOnly: true
            },
            CHANGED_AT: {
                readOnly: true,
                concurrencyControl: true
            },
            CHANGED_BY: {
                readOnly: true
            },
            NAME: {
                required: true,
                isName: true,
                isDescription: true
            },
            IS_DONE: {
                readOnly: true
            }
        }
    }
};

function initTodo(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
    return oContext.getUser().then(function (sUser) {
        oWorkObject.Owner = [{
            USERNAME: sUser
        }];
    });
}

function propagateItem(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext) {
    if (!oPersistedObject || oWorkObject.NAME !== oPersistedObject.NAME || oWorkObject.IS_DONE !== oPersistedObject.IS_DONE) {
        oWorkObject.Items.push({
            NAME: oWorkObject.NAME,
            IS_DONE: oWorkObject.IS_DONE
        });
    }
}

function checkAuth(vKey, oPersistedObject, addMessage, oContext) {
    return oContext.getUser().then(function (sUser) {
        if (oPersistedObject.Owner[0].USERNAME !== sUser) {
            addMessage(Message.MessageSeverity.Error, "TODO_NO_AUTH", vKey, "Root");
        }
    });
}

function setToDone(vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) {
    oWorkObject.IS_DONE = 1;
}

function setToDoneEnabled(vKey, oPersistedObject, addMessage, oContext) {
    if (oPersistedObject.IS_DONE === 1) {
        addMessage(Message.MessageSeverity.Error, "TODO_IS_DONE", vKey, "Root", "IS_DONE");
    }
}

function checkChangeable(vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) {
    if (oWorkObjectNode.IS_DONE === 1 &&
        oContext.getAction().name !== "setToDone" && oContext.getAction().name !== "del") {
        addMessage(Message.MessageSeverity.Error, "TODO_NOT_CHANGEABLE", vKey, "Root");
    }
}
