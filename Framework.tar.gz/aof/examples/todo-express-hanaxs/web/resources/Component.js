sap.ui.define([
    "sap/todo/aof/example/Router",
    "sap/todo/aof/example/model/User",
    "sap/todo/aof/example/model/Todo",
    "sap/aof/ModelSynchronizer",
    "sap/aof/MetaModel",
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/MessageType",
    "sap/ui/model/BindingMode",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (Router, User, Todo, ModelSynchronizer, MetaModel, UIComponent, Device, ODataModel, JSONModel, MessageType, BindingMode, MessageBox, MessageToast) {
    "use strict";

    return UIComponent.extend("sap.todo.aof.example.Component", {

        metadata: {
            manifest: "json"
        },

        init: function () {
            UIComponent.prototype.init.apply(this, arguments);
            this.initModels();
            this.initRouter();
            this.initSockets();
        },

        initModels: function () {
            // Device Model
            var oDeviceModel = new JSONModel(Device);
            oDeviceModel.setDefaultBindingMode(BindingMode.OneWay);
            this.setModel(oDeviceModel, "device");

            // Message Model
            var oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();
            this.setModel(oMessageModel, "message");

            // Data Model
            var oDataModel = this.getModel("data");
            oDataModel.bDisableHeadRequestForToken = true;
            ModelSynchronizer.addODataModel(oDataModel);

            // Meta Model
            this.setModel(MetaModel, "meta");

            // User Model
            var that = this;
            User.login({}, {processSync: true}).done(function (oResponse) {
                var oUserModel = new JSONModel(oResponse.RESULT);
                that.setModel(oUserModel, "user");
            });
        },

        initRouter: function () {
            var that = this;
            var oRouter = this.getRouter();
            oRouter.setRoutingCallback(function (fnNavigate) {
                var vResult = that.hasPendingChanges();
                if (jQuery.type(vResult) === "boolean") {
                    if (vResult) {
                        that.showDataLossPopup(fnNavigate);
                    } else {
                        fnNavigate();
                    }
                } else if (jQuery.type(vResult.done) === "function") {
                    vResult.done(function (bResult) {
                        if (bResult) {
                            return that.showDataLossPopup(fnNavigate);
                        } else {
                            fnNavigate();
                        }
                    });
                } else {
                    fnNavigate();
                }
            });
            oRouter.setCloseCallback(function () {
                if (that.hasPendingChanges()) {
                    return that.getText("TODO_DATALOSS_MSG");
                }
            });
            oRouter.initialize();
        },

        initSockets: function () {
            var that = this;
            this.oTodoSocket = io("/sap/todo/xs/rest/Todo");
            this.oTodoSocket.on("create", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
                if (!Todo.isOwnSession(sSessionUUID)) {
                    var oRootMasterController = that.getCurrentMasterController();
                    if (oRootMasterController.isObjectRelevant(oObject)) {
                        oRootMasterController.updateBinding();
                        MessageToast.show(that.getText("MSG_TODO_SYNC_TODO_CREATED"));
                    }
                }
                Todo.clearSessions();
            });
            this.oTodoSocket.on("update", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
                if (!Todo.isOwnSession(sSessionUUID)) {
                    var oRootMasterController = that.getCurrentMasterController();
                    var oRootDetailController = that.getRootDetailController();
                    if (oRootMasterController && !oRootMasterController.isObjectRelevant(oObject)) {
                        oRootMasterController.updateBinding();
                        if (oRootDetailController && oRootDetailController.getObjectModel() && oRootDetailController.getObjectModel().getKey() === vKey) {
                            that.clearDetailView();
                        }
                        MessageToast.show(that.getText("MSG_TODO_SYNC_SHARING_CHANGED"));
                    } else {
                        if (oRootDetailController && oRootDetailController.getObjectModel() && oRootDetailController.getObjectModel().getKey() === vKey) {
                            oRootDetailController.handleConcurrentChanges(oObject);
                            ModelSynchronizer.update(oRootDetailController.getObjectModel(), "update", Todo, vKey, oObject);
                        } else {
                            ModelSynchronizer.update(null, "update", Todo, vKey, oObject);
                            MessageToast.show(that.getText("MSG_TODO_SYNC_TODO_UPDATED"));
                        }
                    }
                }
                Todo.clearSessions();
            });
            this.oTodoSocket.on("del", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
                if (!Todo.isOwnSession(sSessionUUID)) {
                    var oRootDetailController = that.getRootDetailController();
                    if (oRootDetailController && oRootDetailController.getObjectModel() && oRootDetailController.getObjectModel().getKey() === vKey) {
                        that.clearDetailView();
                    }
                    var oRootMasterController = that.getCurrentMasterController();
                    if (oRootMasterController && oRootMasterController.isObjectRelevant(oObject)) {
                        oRootMasterController.updateBinding();
                        MessageToast.show(that.getText("MSG_TODO_SYNC_TODO_DELETED"));
                    }
                }
                Todo.clearSessions();
            });
        },

        getRootView: function () {
            return this.getAggregation("rootControl");
        },

        getRootController: function () {
            return this.getRootView().getController();
        },

        getAppView: function () {
            return this.getRootView().getContent()[0];
        },

        getCurrentMasterView: function () {
            return this.getAppView().getCurrentMasterPage();
        },

        getCurrentMasterController: function () {
            return this.getCurrentMasterView() && this.getCurrentMasterView().getController();
        },

        getRootMasterView: function () {
            return (this.getAppView().getMasterPages().length > 0 && this.getAppView().getMasterPages()[0]) || null;
        },

        getRootMasterController: function () {
            return this.getRootMasterView() && this.getRootMasterView().getController();
        },

        getCurrentDetailView: function () {
            return this.getAppView().getCurrentDetailPage();
        },

        getCurrentDetailController: function () {
            return this.getCurrentDetailView() && this.getCurrentDetailView().getController();
        },

        getRootDetailView: function () {
            return (this.getAppView().getDetailPages().length > 0 && this.getAppView().getDetailPages()[0]) || null;
        },

        getRootDetailController: function () {
            return this.getRootDetailView() && this.getRootDetailView().getController();
        },

        clearMasterView: function () {
            return this.getAppView().removeAllMasterPages();
        },

        clearDetailView: function () {
            return this.getAppView().removeAllDetailPages();
        },

        hasPendingChanges: function () {
            if (this.getCurrentDetailController()) {
                if (jQuery.type(this.getCurrentDetailController().hasPendingChanges) === "function") {
                    return this.getCurrentDetailController().hasPendingChanges();
                }
            }
            return false;
        },

        resetPendingChanges: function () {
            if (this.getCurrentDetailController() && jQuery.type(this.getCurrentDetailController().resetPendingChanges) === "function") {
                this.getCurrentDetailController().resetPendingChanges();
            }
        },

        showDataLossPopup: function (fnNavigate) {
            var that = this;
            if (this.getCurrentDetailController()) {
                this.getCurrentDetailController().showConfirmation(MessageType.QUESTION, this.getText("TODO_DATALOSS_MSG"), this.getText("TODO_DATALOSS_TITLE"), function (oAction) {
                    if (oAction === MessageBox.Action.OK) {
                        that.resetPendingChanges();
                        fnNavigate();
                    }
                });
            } else {
                fnNavigate();
            }
        },

        getTextModel: function () {
            return this.getModel("i18n");
        },

        getText: function (sText, aParameters) {
            return this.getTextModel().getResourceBundle().getText(sText, aParameters);
        },

        navigateTo: function (sTarget, oData, bNoHistory, bNoBusy) {
            this.getRouter().navTo(sTarget, oData, bNoHistory, bNoBusy);
        },

        navigateToExternal: function (sTarget, oData) {
            var sURL = this.getRouter().getURL(sTarget, oData);
            window.open(sURL);
        },

        navigateToByURL: function (sURL) {
            window.location.href = sURL;
        },

        navigateToInNewWindow: function (sTarget, oData) {
            window.open("#/" + this.getRouter().getURL(sTarget, oData), "_blank");
        },

        navigateToByURLInNewWindow: function (sURL) {
            window.open(sURL, "_blank");
        },

        getNavigationLink: function (sTarget, oData) {
            return "#/" + this.getRouter().getURL(sTarget, oData);
        }
    });
});