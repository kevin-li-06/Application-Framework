"use strict";

var AOF = require("@sap/aof");
var Message = AOF.Message;
var TagMessage = require("./message");

var Check = AOF.Check;
var _ = AOF._;

module.exports.ObjectType = {
    Todo: "sap.todo.xs.object.todo.Todo",
    TodoItem: "sap.todo.xs.object.todo.Todo.Item"
};

module.exports.node = function (sObjectType, bReadOnly) {
    return {
        table: "sap.aof.example.db.tag::t_tag_assign",
        historyTable: "sap.aof.example.db.tag::t_tag_assign_h",
        sequence: "sap.aof.example.db.tag::s_tag",
        view: "sap.aof.example.db.tag::v_tag_assign",
        parentKey: "OBJECT_ID",
        readOnly: bReadOnly,
        consistencyChecks: [Check.duplicateCheck("TAG_ID", TagMessage.DUPLICATE_TAG)],
        attributes: {
            OBJECT_TYPE_CODE: {
                constantKey: sObjectType
            },
            TAG_ID: {
                foreignKeyTo: "sap.todo.xs.object.tag.Tag.Root"
            }
        }
    };
};

module.exports.createTags = function (vKey, oWorkObject, oPersistedObject, addMessage, addNextHandle, oContext) {
    var oHQ = oContext.getDBClient();
    return oContext.getApplicationObject("sap.todo.xs.object.tag.Tag").then(function (Tag) {
        var aPromise = [];
        _.each(oWorkObject.Items || [], function (oItem) {
            if (oItem.Tags === undefined) {
                return;
            }
            var aNewTag = [];
            var aSelectPromise = [];
            _.each(oItem.Tags || [], function (oTag) {
                aSelectPromise.push(Promise.resolve().then(function () {
                    if (oTag.TAG_ID >= 0) {
                        return oHQ.statement("select id, name from \"sap.aof.example.db.tag::t_tag\" where id = ?").execute(oTag.TAG_ID).then(function (aExistingTag) {
                            if (aExistingTag.length >= 1) {
                                oTag.NAME = aExistingTag[0].NAME;
                            }
                        });
                    }
                }).then(function () {
                    if (oTag.NAME) {
                        return oHQ.statement("select id from \"sap.aof.example.db.tag::t_tag\" where UPPER(name) = UPPER(?)").execute(oTag.NAME).then(function (aExistingTag) {
                            if (aExistingTag.length >= 1) {
                                oTag.TAG_ID = aExistingTag[0].ID;
                            } else {
                                aNewTag.push(oTag);
                            }
                        });
                    }
                }));
            });
            aPromise.push(_.promiseAllInclusive(aSelectPromise).then(function () {
                var aDuplicate = Check.containsDuplicates("NAME", true, oItem.Tags);
                if (aDuplicate && aDuplicate.length > 0) {
                    _.each(aDuplicate, function (oTag) {
                        addMessage(Message.MessageSeverity.Error, TagMessage.DUPLICATE_TAG_ASSIGN, vKey, "Tags", "NAME", oTag.NAME);
                    });
                    aNewTag = _.difference(aNewTag, aDuplicate);
                }
                if (_.size(aNewTag) === 0) {
                    return;
                }
                var aCreatePromise = [];
                _.each(aNewTag, function (oNewTag) {
                    var iTagId = oNewTag.TAG_ID < 0 ? oNewTag.TAG_ID : oNewTag.ID;
                    aCreatePromise.push(Tag.create({
                        ID: iTagId,
                        NAME: oNewTag.NAME
                    }).then(function (oCreateResponse) {
                        oNewTag.TAG_ID = oCreateResponse.generatedKeys && oCreateResponse.generatedKeys[iTagId];
                        addMessage(oCreateResponse.messages);
                    }));
                });
                return _.promiseAllInclusive(aCreatePromise);
            }));
        });
        return _.promiseAllInclusive(aPromise).then(function () {
            Tag.close();
        });
    });
};