### AOF Documentation

The **Application Object Framework (AOF) is a persistency framework for Javascript/JSON objects** based on **Node.js** supporting **SAP HANA XS Advanced** and **SAP UI5** technology. 
It provides the runtime for an object declaration file to model business objects as aggregation of hierarchical nodes, mapped to HANA CDS entities resp. HANA database tables. 
The business logic of that application objects can be described defining so called determinations, checks and actions to express the semantic of it and the metadata and properties describe the structural representation.

### General Architecture

The Application Object Framework (AOF) architecture is as follows:

![AOF Architecture](assets/aof.png)

Central entry point for the Application Object Framework is the framework factory. It provides a application object runtime façade for each application object based on the buffered application object metadata, allowing to access the runtime representation of the object. 
The object runtime is the central module, executing the application object operations (CRUD methods, custom actions and properties). During the creation of the runtime façade, the application object definition is loaded from a Javascript library file which holds the metadata definition, that is enriched with HANA table metadata. 
By convention each object resides in a Javascript file with the same name loaded via a require.

### Features
- Node.js module
- Pure Javascript only
- Asynchronous programming using Promises
- Transaction support
- Authentication support
- Supports HANA XS Advanced (AppRouter, HDB, Security, CDS, HDI, XSOData, XSEnv)
- Supports PostgreSQL and SQLite
- Persistence store supports out-of-the-box HANA and SQL DBs
    - Open for additional store implementations
- Case-sensitivity for DB artifacts 
- Object structure and application logic definition
    - Plain Javascript file
    - Metadata driven 
    - Deep node structure
    - Dependent node support
    - Attributes (persistent, transient, read-only, required, constant)
    - Constant Keys
    - Build-in CRUD actions (Create, Copy, Read, Update, Delete, Exists)
    - Custom actions (instance, static, internal, mass actions, not exposed)
    - Read-only query actions (GET)
    - Determinations (on CRUD, after persist)
    - Checks (authorization, input, consistency, enabled, read-only, execution)
    - Properties (static, dynamic) 
    - Custom Properties
    - Foreign keys
    - History tables
    - Reuse checks and determinations
    - Label support
- Key handle support
- JSON attribute type support
- JSON Validation (ajv)
- Enum validation
- Caller Context
- Runtime Context
- Listener notifications (before/after commit)
- Extensibility features (multi-layered extensions)
    - Node, Attribute, Determination, Checks
- Cascade delete
- Concurrent edit
- Metadata schema validation 
- Bulk access to store
- Local client access
    - Recursive client instantiation
- JSON object enabled RESTFul-Services based on Express 
- Build-in OData v2 (XSOData) integration including additional fuzzy search and named filters extensions
- Build-in WebSocket integration (Socket.io, WS Node.js)
- Build-in client side UI5 library seamlessly working with application objects
- Multi-Tenancy Support (Schema Awareness)
- Application Object Registry
- Module Loading and Facade instantiation
- Tracing support
- Node 6 support
- CAP/CDS support (https://github.wdf.sap.corp/pages/cap/home/)
- Examples and documentation

### Processing Sequence

Once the **Metadata** definition for the **Application Object** is completely loaded, the **Framework** returns a **Runtime** access façade to the caller, including the metadata definition provided by a metadata accessor. Application object operations are executed by the **Runtime**. Requests trigger the following processing sequence:

- Extract the object key
- Check existence of object instances by key
- Read persistent objects by key
    - Transform database table content to Javascript object representations
- Call **Authorizations** check (instance based)
- Stop if error has been added to **Message Buffer**
- Call check for operation
- Stop if error has been added to **Message Buffer**
- Merge request object of operation and persistent object using the primary key
    - Properly process read only information and constant values
    - Register used handle keys to initialize **getNextHandle** sequence function
- Call input **Checks** for all nodes and attributes according to metadata definition
- Call operation logic **CRUD (Create, Update, delete or custom action)
- Execute **Determinations** according to metadata definition
- Stop if error has been added to **Message Buffer**
- Call consistency **Checks** for all nodes and attributes according to metadata definition
- Generate keys for newly created nodes and sub-nodes
- Perform **DB** updates (Insert, Upsert, Delete) with current object data into the **HANA** database
    - Transform Javascript object representation to relational table modifications representation
- Commit otherwise rollback (in case of errors in **Message Buffer**)

The following sequence diagram depicts the request processing step sequences in AOF. 

![AOF Request Processing Sequence](assets/aof_sequence.png)

This sequence mainly describes the processing of Update and Actions. Create and Delete operations are handled in a similar fashion but some (redundant) steps are skipped. For example delete operations will typically omit input/consistency checks. The metadata definition of an application object can be validated against the **Schema** of the application object framework. Due to performance reasons these check are not processed implicitly but must be triggered explicitly.

A **Context** object holds the current context, such as Store (DB-Connection), current application user, current operation and request timestamp. The application object framework is exposed canonically via RESTFul protocol using the **Rest Adapter**.

### Metadata Definition
 
The application object is loaded using a definition. The definition is stored in a separated Javascript file that is addressed by the application object name. The application object name is split up into folder path and object name. The loaded library file exports the object definition using and specifying the metadata definition for the application object: 
 
    module.exports = {
        // object definition
    }
 
 A simple definition for the example application object "Comment.js" looks as follows:

    var auth = require("@sap/aof").Authorization;
    var determine = require("@sap/aof").Determination;
    
    var IdentityRole = require("../iam/ObjectIdentityRole"); 

    module.exports = {
        actions : {
            create : {
                authorizationCheck : auth.parentInstanceAccessCheck("sap.ino.db.idea::v_auth_comment_create", "IDEA_ID",
                        "IDENTITY_ID", "IDEA_ID", Message.AUTH_MISSING_COMMENT_CREATE),
                historyEvent : "COMMENT_CREATED"
            },
            update : {
                authorizationCheck : auth.instanceAccessCheck("sap.ino.db.idea::v_auth_comment_update", "COMMENT_ID", "IDENTITY_ID",
                        Message.AUTH_MISSING_COMMENT_UPDATE),
                historyEvent : "COMMENT_UPDATED"
            },
            del : {
                authorizationCheck : auth.instanceAccessCheck("sap.ino.db.idea::v_auth_comment_delete", "COMMENT_ID", "IDENTITY_ID",
                        Message.AUTH_MISSING_COMMENT_DELETE),
                historyEvent : "COMMENT_DELETED"
            },
            read : {
                authorizationCheck : false
            }
        },
        Root : {
            table : "sap.ino.db.idea::t_comment",
            historyTable : "sap.ino.db.idea::t_comment_h",
            sequence : "sap.ino.db.idea::s_comment",
            determinations : {
                onCreate : [createOwner],
                onModify : [determine.systemAdminData]
            },
            nodes : {
                Owner : IdentityRole.node(IdentityRole.ObjectType.Comment, IdentityRole.Role.CommentOwner, true)
            },
            attributes : {
                IDEA_ID : {
                    foreignKeyTo : "sap.ino.xs.idea.Idea"
                },
                CREATED_AT : {
                    readOnly : true
                },
                CREATED_BY : {
                    readOnly : true
                },
                CHANGED_AT : {
                    readOnly : true
                },
                CHANGED_BY : {
                    readOnly : true
                }
            }
        }
    };

#### Core Metadata Schema

The application object definition follows a strict Application Object Framework schema, which is explained in an annotated style as follows:

- Object (top level of the application object definition)
    - Type : Structure (corresponds to Javascript object)
    - Definition
        - **schemaScope:** (allows to define the schena scioope of the application object definition)
            - Type: String (allowed values: '', 'sql', 'cds')
        - **type:** (allows to define the type of the application object)
            - Type: String (allowed values: 'STANDARD', 'CONFIGURATION', 'STAGE')
        - **name:** (Name of the Application Object. Used to instantiate the Application Object Facade.)
            - Type: String
        - **isExtensible** (allows to define an extension to the definition)
            - Type: Boolean
        - **cascadeDelete** (allows to define other application objects to which deletion of this object should be cascaded) 
            - Type: Array of object names
        - **label** (specifies the describing label)
            - Type : String
        - **Root** (definition of the application object root)
            - Required : true (property is mandatory in definition)
            - Type : RootNode (definition check is performed against schema RootNode)
        - **actions** (definition of the application object actions)
            - Required : false
            - Type : Structure 
            - Constraints (definition follows the listed constraints)
                - Required (listed properties are mandatory)
                - Optional (listed properties are optional)
                    - **create** (create operation of the application object)
                        - Type : Action (definition check is performed against schema Action)
                    - **copy** (create operation of the application object)
                        - Type : Action
                    - **update** (update operation of the application object) 
                        - Type : Action
                    - **del** (delete operation of the application object)  
                        - Type : Action
                    - **read** (read operation of the application object)  
                        - Type : Action
                - Forbidden (listed properties are not allowed, as keyword is protected)  
                    - **exists** (exists operation of the application object)
                    - **properties** (properties operation of the application object)
                    - **staticProperties** (staticProperties operation of the application object)
                - Generic (generic property definitions are allowed, defined by an unknown name)
                    - Type : CustomAction (definition check is performed against schema CustomAction)  
- Node (definition of an application object node)
    - Type : Structure
    - Definition
        - **table** (specifies the persistence table for the application object node)  
            - Required : true
            - Type : String (definition check is performed against String)
            - Scopes : ["", "sql"] (only valid in SQL (= default) context)
        - **sequence** (specifies the sequence for the application object node)
            - Type : String
            - Scopes : ["", "sql"] (only valid in SQL (= default) context)
        - **historyTable** (specifies the persistence history table for the application object node)  
            - Type : String
            - Scopes : ["", "sql"] (only valid in SQL (= default) context)
        - **view** (specifies the read view (must join the persistence table and select all attributes of the application object node)  
            - Required : false
            - Type : String (definition check is performed against String)
            - Scopes : ["", "sql"] (only valid in SQL (= default) context)
        - **externalKey** (specifies that the node primary key is not determined internally, but needs to be passed from external)
            - Type : Boolean
        - **parentKey** (specifies the parent key table field for sub-nodes)
            - Required : true
            - Type : String
        - **readOnly** (specifies if the node (incl. attributes is modifiable from outside)
            - Types : Boolean, Function (definition check is performed against Boolean or Function)
        - **explicitAttributeDefinition** (specifies if the attributes need to be explicitly defined instead of implicit derivation from the table definition)
            - Type: Boolean
        - **consistencyChecks** (specifies consistency checks on node after modifications)
            - Type:  Array&lt;Function&gt; (definition check is performed against an Array of Function)
        - **inputChecks** (specifies input checks on node before modifications)
            - Type:  Array&lt;Function&gt; (definition check is performed against an Array of Function)
        - **attributes** (specifies attribute properties merged with the metadata derived from the table definition)
            - Type: Structure&lt;Attribute&gt; (definition check is performed against a Structure of Attribute)
        - **customProperties** (specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients)
            - Type : Object, Function
        - **label** (specifies the describing label)
            - Type : String
        - **nodes** (specifies sub-nodes of the current node)
            - Type: Structure&lt;Node&gt; (definition check is performed against a Structure of Node)  
- RootNode (definition of an application object root node)
    - Type : Structure
    - Template: Node (get the template definition from Node and merge with RootNode definition )
    - Definition
        - **parentKey**
            - Ignore : true (parentKey is not allowed in definition of root node)
        - **determinations** (specifies determinations executed after application object modifications)
            - Type: Structure
            - Constraints 
                - Optional
                    - **onCreate** (specifies determinations executed at application object creation)
                        - Type : Array&lt;Function&gt;
                    - **onPrepareCopy** (specifies determinations executed before application object copy)
                        - Type : Array&lt;Function&gt;
                    - **onCopy** (specifies determinations executed at application object copy)  
                        - Type : Array&lt;Function&gt;
                    - **onUpdate** (specifies determinations executed at application object updates, custom actions)
                        - Type : Array&lt;Function&gt;
                    - **onModify** (specifies determinations executed at application object creation, copy, update, customAction - executed after create/update/copy)
                        - Type : Array&lt;Function&gt;
                    - **onDelete** (specifies determinations executed at application object deletion)
                        - Type : Array&lt;Function&gt;
                    - **onPersist** (specifies determinations executed at after changes have been persisted in the database)
                        - Type : Array&lt;Function&gt;
                    - **onRead** (specifies determinations executed at application object creation read)
                        - Type : Array&lt;Function&gt;
        - **activationCheck** (only for configuration staging objects, is called when staging content is activated)
            - Type: Function
- Attribute (definition of an application object node attribute)
    - Type : Structure
    - Definition
        - **dataType** (specifies the data type of the attribute - is normally derived from database metadata, if available)
            - Type : String
        - **required** (specifies that the attribute is mandatory)
            - Type : Boolean (definition check is performed against Boolean)
        - **isPrimaryKey:** (specifies that the attribute is the primary key)
            - Type : Boolean
        - **foreignKeyTo** (specifies the application object name, the attribute value is a foreign key)
            - Type : String
        - **foreignKeyIntraObject** (specifies that the foreign key to reference is an intra-object instance) 
            - Type : Boolean
        - **constantKey** (specifies a constant key the attribute is default with and which is used during read for selection)  
            - Type : String
        - **readOnly** (specifies that the attribute is read only and not modifiable from outside)  
            - Type : Boolean, Function 
        - **isName** (specifies that the attribute is the (one and only) name attribute usable for human-readable display and fuzzy search purposes of an object (node) instance  
            - Type : Boolean
	    - **isDescription** (specifies that the attribute is a description attribute usable for human-readable fuzzy search purposes of an object (node) instance  
            - Type : Boolean
        - **concurrencyControl** (specifies that the attribute is part of the concurrency token, which might consist of multiple attributes)
            - Type: Boolean
        - **minValue** (specifies that the min value of the attribute value if it has type Number (Integer or Double))  
            - Type : Number
        - **maxValue** (specifies that the max value of the attribute value if it has type Number (Integer or Double)) 
            - Type : Number
        - **maxLength** (specifies that the max length of the attribute value if it has type String)  
            - Type : Number
        - **enum** (specifies the enumeration values which will be used for validation)   
            - Type : Array, Object 
        - **jsonSchema** (Specifies a json schema which will be used for validation. Note: ensure to use the respective json data type.)   
             - Type : Object 
        - **consistencyChecks** (specifies consistency checks on attribute after modifications)
            - Type : Array&lt;Function&gt;
        - **inputChecks** (specifies input checks on attribute before modifications)
            - Type : Array&lt;Function&gt;
        - **customProperties** (specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients)
            - Type : Object, Function
        - **label** (specifies the describing label)
            - Type : String
        - **isConstant** (specifies that attribute is constant (not changeable after node creation))
            - Type : Boolean
Action (definition of an application object action)
    - Type : Structure
    - Definition
        - **authorizationCheck** (specifies the authorization check for the action)
            - Required : true
            - Type : Function, None (definition check is performed against Function, None)
        - **enabledCheck** (specifies the enabled check for the action)
            - Type : Function
        - **executionCheck** (specifies the execution check for the action for create, update, del action)
            - Type : Function
        - **persist** (optional function to redefine persist behavior)
            - Type: Function
        - **historyEvent** (specifies history event name for the history table entry)
            - Type : String
        - **customProperties** (specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients)
            - Type : Object, Function
        - **isInternal** (specifies that the action may only be called in application object implementations)
            - Type: Boolean
            - Default: false
        - **label** (specifies the describing label)
            - Type : String
        - **isExposed** (specifies if action is exposed to outside consumers (e.g. Rest, WS), default is true (exposed) for non-internal actions)
            - Type : Boolean
- CustomAction (definition of an application object action with no execution check)
    - Type : Structure
    - Template: Action (get the template definition from Action and merge with CustomAction definition )
    - Definition
        - **executionCheck**
            - Ignore : true (executeCheck is not allowed in definition of custom action)
        - **execute** (specifies the execution logic of the custom action including checks)
            - Required : true
            - Type : Function
        - **isStatic** (specifies whether this is a static action)
            - Type: Boolean
            - Default: false
        - **massActionName** (specifies the name of the mass enabled action. A new static action with this name is generated accepting a parameter, containing the action keys as array on the parameter object, i.e. 
            { keys : [...], ... }
            - Type : String
        - **impacts** (specifies other application objects that are impacted by action execution)
            - Type: Array of object names
        - **readOnly** (specifies if the custom action execution can have side effects)
            - Type : Boolean, Function
            
#### Extension Metadata Schema

The application object definition follows a strict Application Object Framework extension schema, which is explained in an annotated style as follows: 

- Object (top level of the application object definition)
    - Type : Structure (corresponds to Javascript object)
    - Definition
        - **Root** (definition of the application object root)
            - Type : RootNode (definition check is performed against schema RootNode)
        - **actions** (definition of the application object actions)
            - Type : Structure 
            - Constraints (definition follows the listed constraints)
                - Required (listed properties are mandatory)
                - Optional (listed properties are optional)
                    - **create** (create operation of the application object)
                        - Type : Action (definition check is performed against schema Action)
                    - **copy** (copy operation of the application object) 
                        - Type : Action
                    - **update** (update operation of the application object) 
                        - Type : Action
                    - **del** (delete operation of the application object)  
                        - Type : Action
                    - **read** (read operation of the application object)  
                        - Type : Action
                - Forbidden (listed properties are not allowed, as keyword is protected)  
                    - **exists** (exists operation of the application object)
                    - **properties** (properties operation of the application object)
                    - **staticProperties** (staticProperties operation of the application object)
                - Generic (generic property definitions are allowed, defined by an unknown name)
                    - Type : CustomAction (definition check is performed against schema CustomAction)
- Node (definition of an application object node)
    - Type : Structure
    - Definition
        - **readOnly** (specifies if the node (incl. attributes is modifiable from outside)
            - Types : Boolean, Function (definition check is performed against Boolean or Function)
        - **consistencyChecks** (specifies consistency checks on node after modifications)  
            - Type:  Array&lt;Function&gt; (definition check is performed against an Array of Function)
        - **inputChecks** (specifies input checks on node before modifications)  
            - Type:  Array&lt;Function&gt; (definition check is performed against an Array of Function)
        - **attributes** (specifies attribute properties merged with the metadata derived from the table definition)
            - Type: Structure&lt;Attribute&gt; (definition check is performed against a Structure of Attribute)
        - **customProperties** (specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients)
            - Type : Object, Function
        - **label** (specifies the describing label)
            - Type : String
        - **nodes** (specifies sub-nodes of the current node)
            - Type: Structure&lt;Node&gt; (definition check is performed against a Structure of Node)  
- RootNode (definition of an application object root node)
    - Type : Structure
    - Template: Node (get the template definition from Node and merge with RootNode definition )
    - Definition
        - **determinations** (specifies determinations executed after application object modifications)  
            - Type: Structure
            - Constraints 
                - Optional
                    - **onCreate** (specifies determinations executed at application object creation)
                        - Type : Array&lt;Function&gt;
                    - **onPrepareCopy** (specifies determinations executed before application object copy)
                        - Type : Array&lt;Function&gt;
                    - **onCopy** (specifies determinations executed at application object copy)  
                        - Type : Array&lt;Function&gt;
                    - **onUpdate** (specifies determinations executed at application object updates)
                        - Type : Array&lt;Function&gt;
                    - **onModify** (specifies determinations executed at application object creation or update)
                        - Type : Array&lt;Function&gt;
                    - **onDelete** (specifies determinations executed at application object deletion)
                        - Type : Array&lt;Function&gt;
                    - **onPersist** (specifies determinations executed at after changes have been persisted in the database)
                        - Type : Array&lt;Function&gt;
                    - **onRead** (specifies determinations executed at application object creation read)
                        - Type : Array&lt;Function&gt;
- Attribute (definition of an application object node attribute)
    - Type : Structure
    - Definition
        - **dataType** (specifies the data type of the attribute - is normally derived from database metadata, if available)
            - Type : String
        - **required** (specifies that the attribute is mandatory)
            - Type : Boolean (definition check is performed against Boolean)
        - **foreignKeyTo** (specifies the application object name, the attribute value is a foreign key)  
            - Type : String
        - **readOnly** (specifies that the attribute is read only and not modifiable from outside)  
            - Type : Boolean, Function 
        - **isName** (specifies that the attribute is the (one and only) name attribute usable for human-readable display and fuzzy search purposes of an object (node) instance  
            - Type : Boolean
	    - **isDescription** (specifies that the attribute is a description attribute usable for human-readable fuzzy search purposes of an object (node) instance  
            - Type : Boolean
        - **minValue** (specifies that the min value of the attribute value if it has type Number (Integer or Double)  
            - Type : Number
        - **maxValue** (specifies that the max value of the attribute value if it has type Number (Integer or Double)  
            - Type : Number
        - **maxLength** (specifies that the max length of the attribute value if it has type String  
            - Type : Number  
        - **enum** (specifies the enumeration values which will be used for validation) 
            - Type : Array, Object 
        - **jsonSchema** (Specifies a json schema which will be used for validation. Note: ensure to use the respective json data type.)   
            - Type : Object 
        - **consistencyChecks** (specifies consistency checks on attribute after modifications)
            - Type : Array&lt;Function&gt;
        - **inputChecks** (specifies input checks on attribute before modifications)
            - Type : Array&lt;Function&gt;
        - **customProperties** (specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients)
            - Type : Object, Function
        - **label** (specifies the describing label)
            - Type : String
        - **isConstant** (specifies that attribute is constant (not changeable after node creation))
            - Type : Boolean
Action (definition of an application object action)
    - Type : Structure
    - Definition
        - **enabledCheck** (specifies the enabled check for the action)  
            - Type : Function
        - **executionCheck** (specifies the execution check for the action for create, update, del action)
            - Type : Function
        - **customProperties** (specifies static custom properties or a function which determines custom properties, custom properties are not part of runtime processing but interesting for clients)  
            - Type : Object, Function
        - **label** (specifies the describing label)
            - Type : String
        - **isExposed** (specifies if action is exposed to outside consumers (e.g. Rest, WS), default is true (exposed) for non-internal actions)
            - Type : Boolean
- CustomAction (definition of an application object action with no authorization check)
    - Type : Structure
    - Template: Action (get the template definition from Action and merge with CustomAction definition )
    - Definition
        - **executionCheck**
            - Ignore : true (executeCheck is not allowed in definition of custom action)
        - **execute** (specifies the execution logic of the custom action including checks)
            - Type : Function
        - **impacts** (specifies other application objects that are impacted by action execution)
            - Type: Array of object names
        - **readOnly** (specifies if the custom action extension execution can have side effects)
            - Type : Boolean, Function

The core and extension schema definitions use the following primitive Javascript types:

- **Structure** : "Javascript Object",
- **Array** : "Javascript Array",
- **Function** : "Javascript Function",
- **String** : "String",
- **Boolean** : "Boolean",
- **Number** : "Number",
- **None** : "Null or false"

Currently the following application object type exist:

- **STANDARD:**  A standard application object
- **CONFIGURATION:**  A configuration application object, representing runtime configuration tables
- **STAGE:**  A stage application object, representing a maintainable staging design time representation of runtime configuration tables 

The framework defines constants for the application object types in the following way: 

- **ObjectType.Standard:**  "STANDARD"
- **ObjectType.Configuration:**  "CONFIGURATION"
- **ObjectType.Stage:**  "STAGE"  

The metadata definition from the Library file for the application logic is read and interpreted.
A majority of metadata information can automatically be derived from the underlying database tables specified at object node definition.
As it can be seen. All attributes defined in the table for a node definition are automatically defined according to the table specification. 
The column name corresponds to the attribute name. Additionally the attribute type, optionally the length, scale and if it is mandatory can be derived. 
The node primary key is derived from this information as well. The application object definition in the library file only needs to maintain the additional metadata, 
that cannot be derived from the database tables. Both metadata information are merged at runtime and provided as metadata access to the runtime module.

#### Public Framework Interface

The Application object framework (AOF) exposes the public interface via the **exports** mechanism:

    var AOF = require("@sap/aof");

The **AOF** object offers the following public interface:

- **AOF.dispatcher:**
    - **middleware**: Middleware to be registered with the Node.js express framework
    - **dispatch**: Dispatch request to application object based on path mapping
    - **dispatchDefault**: Dispatch request to default target (Metadata, Rest, OData)
    - **dispatchMetadata**: Dispatch an Metadata request
    - **dispatchRest**: Dispatch an Rest request
    - **dispatchOData**: Dispatch an OData request
    - **dispatchExtension**: Dispatch request to extension implementation
    - **mapPath**: Register mapping from request path to application object path (used in dispatch) 
    
- **AOF.middleware:**
    - Middleware to be registered with the Node.js express framework  
    
- **AOF.DataType**
    - Known core data types
    
- **AOF.Node**
    - **Root**: Root node constant

- **AOF.Action**: Core action constants
    - **Create**: create
    - **Update**: update
    - **Del**: del
    - **Copy**: copy
    - **Exists**: exists
    - **Read**: read
    - **CalculateConcurrencyToken**: calculateConcurrencyToken
    - **Properties**: properties
    - **StaticProperties**: staticProperties

- **AOF.MessageSeverity**
    - **Success**: 6
    - **Debug**: 5
    - **Info**: 4
    - **Warning**: 3
    - **Error**: 2
    - **Fatal**: 1
    
- **AOF.CoreMessages**
    - Framework core message constants
    
- **AOF.getMetadata**
    - Retrieve metadata for an application object 

- **AOF.getApplicationObject**
    - Retrieve runtime for an application object

- **AOF.setObjectExtension**
    - Register an extension application object for an extension application  

- **AOF.removeObjectExtension**
    - Deregisters an extension application object for an extension application

- **AOF.disableExtensions**
    - Disables extension features for all application objects 

- **AOF.Message**
    - Core AOF message constants

- **AOF.Schema**
    - **validateMetadataDefinition**: Validate an application object metadata definition
    - **validateExtensionMetadataDefinition**: Validate an application object extension metadata definition
    
- **AOF.Authorization**
    - **instanceAccessCheck**: Authorization check for an instance (e.g. select no view with object key)
    - **parentInstanceAccessCheck**: Authorization check for an instance based on parent attribute (e.g. select on view with context attribute)
    - **compositeAccessCheck**: Composite authorization check, where all authorization checks need to succeed 
    - **atLeastOneAccessCheck**: Composite authorization check, where at least one authorization check need to succeed
    - **privilegeCheck**: Privilege authorization check, checking for an assigned scope for the user   
    - **conditionCheck**: Authorization check for an instance with an additional condition check
    
- **AOF.Check**
    - **duplicatePrimaryKeyCheck**: Checks on duplicate primary key 
    - **duplicateCheck**: Checks duplicate node instances on node level, based on an attribute 
    - **duplicateAlternativeKeyCheck**: Checks an duplicate alternative key on node level, across all application object instances
    - **duplicatePrimaryKeyCheck**: Checks an duplicate primary key on node level, across all application object instances (for create and copy actions)
    - **dbForeignKeyCheck**: Checks a foreign key on node level via DB layer
    - **readOnlyAfterCreateCheck**: Checks that an attribute is not changed after creation of the object instance on attribute level 
    - **cardinalityOneCheck**: Checks an at most to 1-cardinality on node level for a sub-node  
    - **objectReferenceCheck**: Generic object reference check based on an attribute containing the referenced object name and another attribute containing the referenced object key
    - **attributeCheck**: Generic check on an attribute level by a check function
    - **booleanCheck**: Check for boolean value in case of boolean type (i.e. boolean, true or false)
    - **intBooleanCheck**: Check for boolean value in case of boolean like integer type (i.e. integer, where 1 is interpreted as true and 0 as false)
    - **stringBooleanCheck**: Check for boolean value in case of boolean like string type (i.e. string, 'true' or 'X' are interpreted as true, 'false' and '' as false)
    - **Messages**: Core checks message constants
    - **containsDuplicates**: No check itself, but calculation of duplicates in a node instance array for re-use (used in **duplicateCheck**) 
     
    - Automatically assigned checks based on attributed annotations:
        - **integerCheck**: Checks for an integer value on attribute level (in case of integer-like DB type) 
        - **floatCheck**: Checks for a float value on attribute level (in case of float-like DB type)
        - **stringCheck**: Checks for a string value on attribute level (in case of string-like DB type) 
        - **dateCheck**: Checks for a date value on attribute level (in case of date-like DB type) 
        - **minValueCheck**: Checks for min-value on attribute level (in case of number-like DB type) when attribute is annotated with "minValue"
        - **maxValueCheck**: Checks for max-value on attribute level (in case of number-like DB type) when attribute is annotated with "maxValue"
        - **maxLengthCheck**: Checks for max-length value on attribute level (in case of string-like DB type) when attribute is annotated with "maxLength"
        - **interObjectForeignKeyCheck**: Checks inter object foreign keys on attribute level via AOF framework when attribute is annotated with "foreignKeyTo" 

- **AOF.Determination**
    - **systemAdminData**: Re-use determination to fill system administrative data (CREATED_AT, CREATED_BY, CHANGED_AT, CHANGED_BY)
    
- **AOF._**
    - Underscore.js access + AOF util mixins 
    
#### Local Client Access (Client API)

The local client access to the AOF framework is provided by a Javascript-API. A reference to the object façade for a specific application object can be obtained using the following code (caller context is optional):

    var AOF = require("@sap/aof");
    AOF.getApplicationObject("<objectPath>", <oCallerContext>).then(function (<Object>) {
        return <Object>.create({
            ID: -1
        }).then(function (oResponse) {
            var id = oResponse.generatedKeys[-1];
            return <Object>.read(id);
        }).then(function (oObject) {
            // ... result handling
        });
    }).catch(function (oError) {
        // ... error handling
    });

#### Application Interface 

First the Application object framework (AOF) library needs to be imported using **require**, providing the application object name. An object façade is returned using the factory method **getApplicationObject**. The object runtime façade is exposing the following **CRUD** services and **business actions:**

- **Create:** 
    - **Signature:**
    
        ````
        create(oCreateRequest : {}) : oResponse : { messages : [], generatedKeys : {} }
        ````
    
    - **Parameters:** oCreateRequest: Javascript object of the application object instance. Handle keys have to be negative numbers and are replaced by generated keys
    - **Returns:** 
        - Promise resolving the response object:  
            - messages: array of messages  
            - generatedKeys: map of generated keys to key handles, e.g. generatedKeys[-1] = 1. Handles are represented by negative numbers and replaced by unique keys (e.g. positive numbers) during processing  
    - **Description:**  Creates an application object instance (including sub-structure)
    - **Example:**  Creation of an application object instance (root node, with a sub-node Item and for each an attribute)

        ````
        oRuntimeFacade.create({  
            ID : -1,  
            TITLE : 'Node title',
            Items : [{  
                ID: -2,  
                TEXT: 'Test'  
            }]  
        }).then(function(oResponse) {
        });
        ````
        
- **Copy:** 
    - **Signature:**  
    
        ````
        oRuntimeFacade.copy(vOriginalKey : ?, oCopyRequest) : {}, oResponse : { messages : [], generatedKeys : {} }
        ````
        
    - **Parameters:**  
        - vOriginalKey:  
        - oCopyRequest: Javascript object containing data the copied object should get. Usually you would supply a handle for the Root key of the new object so that you are able to get the key of the copied object
    - **Returns:**  
        - Promise resolving the response object 
            - messages: array of messages  
            - generatedKeys: map of generated keys to key handles, e.g. generatedKeys[-1] = 1. Handles are represented by negative numbers and replaced by unique keys (e.g. positive numbers) during processing  
    - **Description:**  Creates a new application object instance by copying an existing one.
    - **Example:**  

        ````
        oRuntimeFacade.copy(4711, {  
            ID : -1,
            TITLE : 'Node title'
        }).then(function(oResponse) {
        });
        ````

- **Update:** 
    - **Signature:** 
    
        ````
        oRuntimeFacade.update(oUpdateRequest : {}, [sConcurrencyToken]) : oResponse : { messages : [], generatedKeys : {} }
        ````
                
    - **Parameters:** 
        - oUpdateRequest: Javascript object of the application object instance. Object instance key is extracted from the root and needs to be a real key. Handle keys have to be negative numbers and are replaced by generated keys.
        - sConcurrencyToken: String which is used for concurrency control mechanisms (equivalent to the ETag in HTTP). It is optional, when not present no conflict detection will be done.

    - **Returns:** 
        - Promise resolving the response object:
            - messages: array of messages  
            - generatedKeys: map of generated keys of sub nodes to key handles, e.g. generatedKeys[-1] = 1  
    - **Description:** Updates an application object instance (including sub-structure) using the root key
    - **Example:** Update of an application object instance (only root node)  

        ````
        oRuntimeFacade.update({  
            ID : 1,
            TITLE : 'New node title'
        }).then(function(oResponse) {
        });
        ````

- **Delete:** 
    - **Signature:**
     
        ````
        oRuntimeFacade.del(vKey : ?, [sConcurrencyToken]) : oResponse : { messages : [] }
        ````
        
    - **Parameters:**
        - vKey: Key value of the application object instance
        - sConcurrencyToken: String which is used for concurrency control mechanisms (equivalent to the ETag in HTTP). It is optional, when not present no conflict detection will be done.
    - **Returns:** 
        - Promise resolving response object:
            - messages: array of messages  
    - **Description:** Deletes an application object instance (including sub-structure) using passed key
    - **Example:** Deletion of an application object instance (including sub nodes)  

        ````
        oRuntimeFacade.del(1)}).then(function(oResponse) {
        });
        ````

- **Exists:** 
    - **Signature:** 
    
        ````
        oRuntimeFacade.exists(vKey : ?) : boolean
        ````
        
    - **Parameters:** vKey: Key value of the application object instance
    - **Returns:** 
        - Promise resolving response boolean (true or false)
    - **Description:** Checks existence of application object instance using passed key
    - **Example:** Checking existence of an application object instance  
   
        ````
        oRuntimeFacade.exists(1)}).then(function(bExists) {
        });
        ````

- **Read:** 
    - **Signature:**

        ````
        oRuntimeFacade.read(vKey : ?) : oObject : {}
        ````

    - **Parameters:** vKey: Key value of the application object instance
    - **Returns:** 
        - Promise resolving response data object: Application object (including sub structure) as Javascript/JSON object, **null** if object is not found
    - **Description:** Reads the application object instance for the passed key. Returns **null** if no object is found
    - **Example:** Reading instance of an application object  

        ````
        oRuntimeFacade.read(1)}).then(function(oObject) {
        });
        ````

- **CalculateConcurrencyToken**
    - **Signature:** 
    
        ````
        oRuntimeFacade.calculateConcurrencyToken(vKey : ?, [oObject]) : sConcurrencyToken: String
        ````
        
    - **Parameters:** 
       - vKey: Key value of the application object instance
       - oObject: Optional object data which clients might already have. If not given the current object will be read from the database to calculate the concurrency token.
    - **Returns:** 
        - String used as representation for the application object instance which is used for concurrency control means in update, delete and customActions
    - **Example:**  

        ````
        var sConcurrencyToken = oRuntimeFacade.calculateConcurrencyToken(1232);
        ````

- **Custom Actions:** 
    - **Signature:** 

        ````
        oRuntimeFacade.<actionName>(vKey : ?, oParameters : {}, [sConcurrencyToken]) : oResponse : { messages : [], generatedKeys : {} }
        ````
     
    - **Parameters:**
        - vKey: Key value of the application object instance the action is called on
        - oParameters: Javascript object of action parameters passed into the action execution call
        - sConcurrencyToken: String which is used for concurrency control mechanisms (equivalent to the ETag in HTTP). It is optional, when not present no conflict detection will be done.
    - **Returns:** 
        - Promise resolving the response object:
            - messages: array of messages  
            - generatedKeys: map of generated keys of sub nodes to key handles, e.g. generatedKeys[-1] = 1  
            - result: optional result of action call  
    - **Description:** Calls a custom action on an application object instance (including sub-structure) using the passed key and the passed parameters
    - **Example:** Execution of an custom action 'submit' of an application object instance  

        ````
        oRuntimeFacade.submit(1).then(function(oResponse) {
        });
        ````

- **Static Custom Actions:** 
    - **Signature:** 
    
        ````
        oRuntimeFacade.<actionName>(oParameters : {}) : oResponse : { messages : []}
        ````
        
    - **Parameters:** 
        - oParameters: Javascript object of action parameters passed into the action execution call
    - **Returns:** 
        - Promise resolving the response object:
            - messages: array of messages,  
            - result: optional result of action call  
    - **Description:** Calls a static custom action on an application object instance (including sub-structure) using the passed key and the passed parameters
    - **Example:** Execution of an static custom action 'replacePhaseCode'  

        ````
        oRuntimeFacade.replacePhaseCode({CAMPAIGN_ID: 1, OLD_PHASE_CODE: 'a', NEW_PHASE_CODE: 'b'}).then(function(oResponse) {
        }); 
        ````

- **Properties:** 
    - **Signature:** 
    
        ````
        oRuntimeFacade.properties(vKey : ?, oScope : { actions : [], nodes : [] }) : oResponse : { actions : {}, nodes : {} }
        ````
    
    - **Parameters:** 
        - vKey: Key value of the application object instance the action is called on
        - oScope: Javascript object including an array of action names and/or an array of node names, defining the scope of reading the properties.
            - If the **actions** property is not defined in oScope, no action properties are retrieved 
            - If the **actions** property array in oScope is set to **true**, properties for all actions are retrieved 
            - If the **actions** property contains not the name, but an object {name : &lt;actionName&gt;, parameters : &lt;any&gt; } parameter dependent properties are determined
            - If the **nodes** property is not defined in oScope, no node properties are retrieved 
            - If the **nodes** property array in oScope is set to **true**, properties for all nodes (including all attributes) are retrieved 
    - **Returns:** 
        - Promise resolving the response object
            - actions: object including properties for each action represented as object { &lt;actionName&gt; : { enabled : &lt;boolean&gt;, messages : [] }, ... }  
            - nodes: object including properties for each node instance and respective attributes represented as object { &lt;nodeName&gt; : { &lt;vKey&gt; : { readOnly : &lt;boolean&gt;, messages : [], attributes : { &lt;attributeName&gt; : { readOnly : &lt;boolean&gt;, messages : [] }, ... }, ... }, … }, … }  
    - **Description:** Dynamic properties can be retrieved for an existing application object instance for actions, nodes and attributes
    - **Example:** Retrieving dynamic properties of an application object instance  
        
        ````
        oRuntimeFacade.properties(1, { actions : ["Update", "Submit"], nodes : ["Root", "Items"]).then(function(oProperties) {
        });
        ````

- **Static Properties:** 
    - **Signature:** 
    
        ````
        oRuntimeFacade.staticProperties(oScope : { actions : {}, nodes : [] }) : oResponse : { actions : {}, nodes : {} }
        ````

    - **Parameters:** 
        - oScope: Javascript object including an array of action and/or an array of node names, defining the scope of reading the properties.
            - If the **actions** property is not defined in oScope, no action properties are retrieved 
            - Setting to **true** is not an allowed value for the **actions** property, as for each action needs to be passed a parameter structure 
            - The **actions** property is an array of objects containing the properties
                - name: Action name
                - parameters: Action parameters
            - If the **nodes** property is not defined in oScope, no node properties are retrieved 
            - If the **nodes** property array in oScope is set to **true**, properties for all nodes (including all attributes) are retrieved 
    - **Returns:** 
        - Promise resolving the response object:
            - actions: object including properties for each action represented as object { &lt;actionName&gt; : { enabled : &lt;boolean&gt;, messages : [] }, ... }  
            - nodes: object including properties for each node instance and respective attributes represented as object { &lt;nodeName&gt; : { readOnly : &lt;boolean&gt;, attributes : { &lt;attributeName&gt; : { readOnly : &lt;boolean&gt; }, ... }, ... }, ... }  
    - **Description:** Static properties can be retrieved for an existing application object instance for actions, nodes and attributes
    - **Example:** Retrieving static properties of an application object instance  
        
        ````
        oRuntimeFacade.staticProperties({ actions : "create" : { REF_ID : 1 } }, nodes : ["Root", "Items"]).then(function(oProperties) {
        });
        ````

#### Update Behavior

Modifications of application object instance always work in full transmission. That means, that the application object instance has to be passed completely. The following rules apply:

- Attribute level:
    - If an attribute property is NOT provided in the object structure, the persisted value is NOT overwritten
    - If an attribute property is provided in the object structure, the new value overwrites the persisted value

- Node level:
    - If a node property is NOT provided in the object structure, all instances of the node are NOT overwritten
    - If a node property is provided in the object structure, the following merge logic is applied (equality of two node instances is determined using the defined node key):
        - Node instances provided and already existing are **updated**
        - Node instances provided and not already existing are **created**
        - Node instances **NOT** provided and already existing are **deleted**

#### Messages

Messages returned by the runtime facade calls, have the following structure:

- **severity : int**
    1. Fatal: Immediately cancel processing 
    2. Error: Cancel processing of specific steps 
    3. Warning:
    4. Info:
    5. Debug: not intended for end users - these messages shall not be visible in the user interface - they may be written to the application log though 

- **messageKey : string**
    - User defined string, identifying a text key in the text bundle

- **refKey : any**
    - Reference primary key of the message reference node

- **refNode : string**
    - Reference node in the application object instance

- **refAttribute : string**
    - Reference attribute in the reference node of the application object instance

- **parameters : []**
    - Array of parameter values. Index is used to replace placeholders with the value for the index

Therefore the add message function, used in the following section has the signature as follows:

    addMessage(severity : 0, messageKey : "", refKey : ?, refNode : "", refAttribute : "", 
               parameter1 : "", ..., parameter4 : "") : void

Additionally an already existing message or an array of messages can be repeated into a new message buffer by:

    addMessage(oMessage);
    addMessage(aMessage);


### Processing Logic (Server API)

During processing of the object façade call, there exist several exit points, where custom defined processing logic can be defined:

- **Authorization Check (single): (called for Create, Update, Delete, Read, Custom Actions)**
    - **Signature:** 
    
        ````
        (vKey : ?, oPersistedObject: {}, addMessage : function, oContext : object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be checked for authorization, undefined if in Create
        - oPersistedObject: Javascript object of the application object instance before executing the façade service (action) call. In Create case the oCreateRequest object is passed in.
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Authorization is checked for the passed object instance and determines if the caller is authorized to execute the action
    - **Template:** 
    
        ````
        function authorizationCheck(vKey, oPersistedObject, addMessage, oContext) { }
        ````

- **Static Authorization Check (single): (called for Static Custom Actions)**
    - **Signature:** 
         
        ````
        (oParameters: {}, addMessage : function, oContext : object) : Promise/void
        ````
        
    - **Parameters:**
        - oParameters: Javascript object of action parameters passed into the action execution call
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Authorization is checked for the passed parameters and determines if the caller is authorized to execute the action
    - **Template:** 
    
        ````
        function authorizationCheck(oParameters, addMessage, oContext) { }
        ````

- **Enabled Check (single): (called for Create, Update, Custom Actions)**
    - **Signature:** 
    
        ````
        (vKey : ?, oPersistedObject : {}, addMessage : function, oContext : object) : Promise/void
        ````
        
    - **Parameters:**
        - vKey: Key of the object instance to be checked for execution, undefined if in Create
        - oPersistedObject: Javascript object of the application object instance before executing the façade service (action) call. In Create case the oCreateRequest object is passed in.
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Check is called before execution for the passed object instance and determines if the action is enabled
    - **Template:**
    
        ````
        function enabledCheck(vKey, oPersistedObject, addMessage, oContext) { }
        ````

- **Static Enabled Check (single): (called for Create, Update, Static Custom Actions)**
    - **Signature:** 
    
        ````
        (oParameters : {}, oReadOnlyBulkAccess, addMessage : function, oContext : object) : Promise/void
        ````
            
    - **Parameters:**
        - oParameters: Javascript object of action parameters passed into the action execution call
        - oReadOnlyBulkAccess: Bulk access providing direct node update capabilities on DB. Only simulation possible in this context.
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Check is called before execution for given parameters and determines if the action is enabled
    - **Template:**
        
        ````
        function enabledCheck(oParameters, oReadOnlyBulkAccess, addMessage, oContext) { }
        ````

- **Execution Check (single): (called for Create, Update, Delete)**
    - **Signature:** 
    
        ````
        (vKey : ?, oRequestObject : {}, oWorkObject : {}, oPersistedObject : {}, addMessage : function, oContext : object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be checked for execution, undefined if in Create
        - oRequestObject: Request object passed into the call as parameter for the action execution. Undefined if in Delete
        - oWorkObject: Javascript object of the application object instance the façade service call is currently working on.
        - oPersistedObject: Javascript object of the application object instance persisted on the database
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Check is called before execution for the passed object instance and determines, if the action can be executed with the request object
    - **Template:**
    
        ````
        function executionCheck(vKey, oRequestObject, oWorkObject, oPersistedObject, addMessage, oContext) { }
        ````
  
- **Action Persist (single): (called for Create, Update, Delete, Custom Actions)**
    - **Signature:**

        ````
        (vKey : ?, oWorkObject: {}, oDB : object, addMessage, oContext: object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be checked for execution, undefined if in Create
        - oWorkObject: Javascript object of the application object instance to be persisted
        - oDBAction: Wrapper object around AOF DB layer. Signature is
            - create (oObject)
            - update (oObject)
            - del (oObject)
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp

- **Action Execute (single): (called for Custom Actions)**  
    - **Signature:** 
    
        ````
        (vKey : ?, oParameters: {}, oWorkObject : {}, addMessage : function, getNextHandle : function, oContext : object, oMetadata : object) : Promise/object
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be checked for execution, undefined if in Create
        - oParameters: Javascript object of action parameters passed into the action execution call oWorkObject: Javascript object of the application object instance the façade service call is currently working on. Modifications shall be performed on this object.
        - oWorkObject: Javascript object of the application object instance the façade service call is currently working on.
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - getNextHandle: The get next handle function can be used to determine a handle key for the creation of a object instance
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oMetadata: Metadata for object where action is attached to

    - **Returns:** object: Promise or result of action call
    - **Description:** Execution is called for the custom action, to execute the custom action logic
    - **Template:**
    
        ````
        function execute(vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext, oMetadata) { }
        ````

- **Static Action Execute (single): (called for Static Custom Actions)**  
    - **Signature:** 
    
        ````
        (oParameters: {}, oBulkAccess : object, addMessage : function, getNextHandle : function, oContext : object, oMetadata : object) : Promise/object
        ````
            
    - **Parameters:**
        - oParameters: Javascript object of action parameters passed into the action execution call
        - oBulkAccess: Bulk access providing direct node update on DB.
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oMetadata: Metadata for object where action is attached to
    - **Returns:** object: Promise or result of action call
    - **Description:** Execution is called for static custom action, to execute the static custom action logic
    - **Template:**
    
        ````
        function execute(oParameters, oBulkAccess, addMessage, oContext, oMetadata) { }
        ````

- **Custom Properties (single): (called for Actions, Node, Attribute)**
    - **Node/Attribute Context**
    - **Signature:** 
        
        ````
        (vKey : ?, oPersistedObject : {}, addMessage : function, oContext : object, oNodeMetadata : object) : oCustomProperties : Promise/{}
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be properties to be retrieved from. Key must be valid for an object instance.
        - oPersistedObject: Javascript object of the application object instance persisted on the database
        - addMessage: Error messages have to be added via the add message function 
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node
    - **Returns:** oCustomProperties : Promise or {}
    - **Description:** Called to retrieve the custom properties for the node instance
    - **Template:**
        
        ````
        function customProperties(vKey, oPersistedObject, addMessage, oContext, oNodeMetadata) { }
        ````

    - **Action Context**
    - **Signature:** 
        
        ````
        (vKey : ?, oParameters, oPersistedObject : {}, addMessage : function, oContext : object, oActionMetadata : object, oMetadata : object) : oCustomProperties : Promise/{}
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be properties to be retrieved from. Key must be valid for an object instance.
        - oParameters: Javascript object of action parameters passed into the action execution call. Might be null if properties are requested without parameters.
        - oPersistedObject: Javascript object of the application object instance persisted on the database
        - addMessage: Error messages have to be added via the add message function 
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oActionMetadata: Metadata object for the current action
        - oMetadata: Metadata for object where action is attached to
    - **Returns:** oCustomProperties : Promise or {}
    - **Description:** Called to retrieve the custom properties for the node instance
    - **Template:**
        
        ````
        function customProperties(vKey, oParameters, oPersistedObject, addMessage, oContext, oActionMetadata, oMetadata) { }
        ````

    - **Static Action Context**
    - **Signature:** 
        
        ````
        (oParameters : {}, addMessage : function, oReadOnlyBulkAccess, oContext : object, oActionMetadata : object, oMetadata: object) : oCustomProperties : Promise/{}
        ````
            
    - **Parameters:**
        - oParameters: Javascript object of action parameters passed into the action execution call
        - oReadOnlyBulkAccess: Bulk access providing direct node update capabilities on DB. Only simulation possible in this context.
        - addMessage: Error messages have to be added via the add message function 
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oActionMetadata: Metadata object for the current action
        - oMetadata: Metadata for object where action is attached to
    - **Returns:** oCustomProperties : Promise or {}
    - **Description:** Called to retrieve the custom properties for the passed parameters
    - **Template:**
        
        ````
        function customProperties(oParameters, oReadOnlyBulkAccess, addMessage, oContext, oActionMetadata, oMetadata) { }
        ````

- **Determination (only Root) (multiple): (called for Create, PrepareCopy, Copy, Update, Delete, Persist, Custom Actions)**
    - **Signature:** 
    
        ````
        (vKey : ?, oWorkObject : {}, oPersistedObject : {}, addMessage : function, getNextHandle : function, oContext : object, oNodeMetadata : object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be checked for execution, undefined if in Create
        - oWorkObject: Javascript object of the application object instance the façade service call is currently working on. Modifications shall be performed on this object (current image). Object is undefined if in Delete.
        - oPersistedObject: Javascript object of the application object instance before executing the façade service (action) call. 
            - Object is undefined if in Create case (before image) 
            - Object is original copy source for Copy case
        - addMessage: In case of authorization violation an error message has to be added via the add message function to stop the processing
        - getNextHandle: The get next handle function can be used to determine a handle key for the creation of a object instance
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node, in determinations always the Root node
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Check is called before execution for the passed object instance
    - **Template:**
           
        ````
        function determination(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) { }
        ````
 
- **Read Determination (only Root) (multiple): (called for Read)**
    - **Signature:** 
    
        ````
        (vKey : ?, oReadObject : {}, oNodeMetadata : object, oContext : object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object instance to be checked for execution, undefined if in Create
        - oReadObject: Javascript object of the application object instance read for the key. Modifications can be performed on the object especially to calculate transient fields.
        - oNodeMetadata: Metadata object for the current node, in read determinations always the Root node
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Determinations are called after action execution for the passed object instance
    - **Template:**
    
        ````
        function determination(vKey, oReadObject, oNodeMetadata, oContext) { }
        ````        
        
 
- **Consistency Check: (called for Create, Update, Custom Actions)**
    - **Node context (multiple):**
    - **Signature:** 
        
        ````
        (vKey : ?, oWorkObjectNode : {}, addMessage : function, oContext : object, oNodeMetadata : object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object root instance to be checked for consistency after execution, node key needs to be retrieved from oWorkObjectNode (which can be an array)
        - oWorkObjectNode: Javascript object of the application object node instance the façade service call is currently working on. If check is executed on Root node, oWorkObjectNode is a object, if check is executed on a sub-node, oWorkObjectNode is an array of objects, to allow for example a duplicate check on node instances
        - oPersistedObjectNode: Javascript object of the corresponding application object nodes currently persisted. Only available for updated nodes, otherwise 'null'
        - addMessage: In case of consistency violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node the consistency check is executed against
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Consistency checks are called after execution for the passed object instance including sub-structure
    - **Template**
    
        ````
        function consistencyCheck(vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````
  
    - **Attribute context (multiple)**
    - **Signature:** 
        
        ````
        (vKey : ?, oAttribute : {}, addMessage : function, oContext : object, oNodeMetadata : object) : Promise/void
        ````
           
    - **Parameters:**
        - vKey: Key of the object node instance to be checked for consistency after execution
        - oAttribute: {  
            name : string - Name of the currently checked attribute  
            value : ? - Current value of the checked attribute  
        - addMessage: In case of consistency violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node the consistency check is executed against
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Consistency checks are called after execution for the passed object on attributes
    - **Template:**
        
        ````
        function consistencyCheck(vKey, oAttribute, addMessage, oContext, oNodeMetadata) { }
        ````

- **Input Check: (called for Create, Update)**
    - **Node context (multiple):**
    - **Signature:** 
        
        ````
        (vKey : ?, oWorkObjectNode : {}, addMessage : function, oContext : object, oNodeMetadata : object) : Promise/void
        ````
            
    - **Parameters:**
        - vKey: Key of the object root instance to be checked for input before execution, node key needs to be retrieved from oWorkObjectNode (which can be an array)
        - oWorkObjectNode: Javascript object of the application object node instance the façade service call is currently working on. If check is executed on Root node, oWorkObjectNode is a object, if check is executed on a sub-node, oWorkObjectNode is an array of objects, to allow for example a duplicate check on node instances
        - oPersistedObjectNode: Javascript object of the corresponding application object nodes currently persisted. Only available for updated nodes, otherwise 'null'
        - addMessage: In case of input check violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node the input check is executed against
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Input checks are called before execution for the passed object instance including sub-structure
    - **Template**
    
        ````
        function inputCheck(vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````
  
    - **Attribute context (multiple)**
    - **Signature:** 
        
        ````
        (vKey : ?, oAttribute : {}, addMessage : function, oContext : object, oNodeMetadata : object) : Promise/void
        ````
           
    - **Parameters:**
        - vKey: Key of the object node instance to be checked for input before execution
        - oAttribute: {  
            name : string - Name of the currently checked attribute  
            value : ? - Current value of the checked attribute  
        - addMessage: In case of input violation an error message has to be added via the add message function to stop the processing
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node the input check is executed against
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Input checks are called before execution for the passed object on attributes
    - **Template:**
        
        ````
        function inputCheck(vKey, oAttribute, addMessage, oContext, oNodeMetadata) { }
        ````
  
- **Read Only Check: (called for Create, Update, Custom Actions)**
    - **Node context (single):**
    - **Signature:** 
        
        ````
        (vKey : ?, oPersistedObjectNode : {}, addMessage : function, oContext : object, oNodeMetadata : object) : Promise/boolean
        ````
            
    - **Parameters:**
        - vKey: Key of the object node instance to be checked for read only check before execution (undefined in Create node case)
        - oPersistedObject: Javascript object of the application object instance before executing the façade service call (empty object '{}' in Create node case)
        - addMessage: The reason why a node is read-only can be expressed by adding a message
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node the read only check is executed against
    - **Returns:** Promise or boolean (true, if attribute is read only, otherwise false)
    - **Description:** Read only check of node is called during merge of request and persisted object
    - **Template:**
        
        ````
        function readOnlyCheck(vKey, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````
  
    - **Attribute context (single)**
    - **Signature:** 
    
        ````
        (vKey : ?, oPersistedObjectNode : {}, addMessage : function, oContext : object, oNodeMetadata : object) : Promise/boolean
        ````
        
    - **Parameters:**
        - vKey: Key of the object node instance to be checked for read only check before execution (undefined in Create node case)
        - oPersistedObject: Javascript object of the application object instance before executing the façade service call (empty object '{}' in **Create** node case)
        - addMessage: The reason why an attribute is read-only can be expressed by adding a message
        - oContext: Context object for getting hQuery instance, current users, current action and request timestamp
        - oNodeMetadata: Metadata object for the current node the read only check is executed against its attribute
    - **Returns:** Promise or boolean (true, if attribute is read only, otherwise false)
    - **Description:** Read only check of attributes is called during merge of request and persisted object
    - **Template:**
    
        ````
        function readOnlyCheck(vKey, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````          

- **Activation Check: (called for configuration staging objects on root node level before activating configuration content)**
    - **Signature:** 
    
        ````
        (oConfiguration : {}, oStage: {}, addMessage : function, oContext : object) : Promise/void
        ````
            
    - **Parameters:**
        - oConfiguration: Javascript object of the currently active configuration. It is undefined for initial activation. The object is structured like the corresponding configuration object of the staging object.
        - oStage: Javascript object of the configuration which will be activated in activation. The object is structured like the corresponding configuration object of the staging object.
        - addMessage: For avoiding activation an error message has to be added via the add message function.
        - oContext: Context object for getting DB access
    - **Returns:** Promise (async) or void (sync)
    - **Description:** Activation check before configuration content is activated, i.e. inserted into the configuration runtime table
    - **Template:**
    
        ````
        function activationCheck(oConfiguration, oStage, addMessage, oContext) { }
        ````

#### Bulk Access (Server API)

Implementation of static actions which change multiple object instances via the default AOF object facade might be too slow for an interactive response. 
AOF bulk access provides a means to directly update a number of node instances on the database resulting in much faster response times.

Bulk access methods do not process any determinations, input checks, consistency checks, authorization checks, read-only checks, customer logic whatsoever. 
So it should only be used with care as possibly determination logic will need to be doubled. Therefore bulk access is only available within static actions of the same object.

The object passed as oBulkAccess into execution of static actions provides the following methods:

- **update:** Updates all node instances on database which satisfy the filter condition. It optionally updates parent node instances. History tables will be written automatically as specified in AOF object. Does not commit.
    - **Signature:** 
    
        ````
        (oBulkChange: {}, oFilter: { condition: String, conditionParameters: [] }, bSimulate : Boolean): oResponse : { messages : [], affectedNodes : {} }
        ````
        
    - **Parameters:**
        - oBulkChange: Javascript object containing the node name and attributes and parent nodes which should be updated. Parent nodes are included in reverse order of the hierarchy. Only one leading node may be used.
        - oFilter: Javascript object containing
            - condition: SQL where condition as string. Attributes refer to the leading node of this bulk change. But in principle arbitrary SQL conditions and sub-selects can be used.
            - conditionParameters: Array of prepared parameters contained as "?" in condition. For each "?" in condition a value is expected here
            - conditionNodeAlias: Optional name of node to be used as table alias in where condition, especially in correlated sub-queries.
        - bSimulate: Optional indicator whether to only simulate the bulk change or not. Default is false. In simulation mode affected nodes in the response are populated.
    - **Returns:** Response object containing
        - messages: Array of messages which occurred during execution
        - affectedNodes: Object of node names containing per node the following information, e.g. { Root: { operation : "update", count: 121 } }
            - operation: Bulk operation on node ("update" or "del")
            - count: Number of node instances affected by the operation  
  
- **del:** Deletes all nodes and their child nodes on database level. In addition it optionally updates parent node instances. History tables will be written automatically as specified in AOF object. Does not commit.
    - See update

- **Examples**
    
````
function executeMyStaticUpdateAction(oParameters, oBulkAccess, addMessage, oContext) {
    // The following changes the tag id from OLD_TAG_ID to NEW_TAG_ID
    // For all affected Tags the field CHANGED_BY of the root node is updated as well
    return oContext.getUser().then(function(sUser) {
        return oBulkAccess.update({
            Tags : {
                TAG_ID : oParameters.NEW_TAG_ID
                Root : {
                    CHANGED_BY : sUser
                }
            }
        }, {
            condition : "TAG_ID = ?",
            conditionParameters : [oParameters.OLD_TAG_ID]
        }).then(function(oResponse) {
            addMessage(oResponse.messages);
        });
    });
}
````

````
function executeMyStaticDeleteAction(iTagID, oBulkAccess, addMessage, oContext) {
    // The following deletes the tags nodes with a specific tag id
    // For all affected tag nodes the field CHANGED_BY of the root node is updated as well
    return oContext.getUser().then(function(sUser) {
        return oBulkAccess.del({
            Tags : {
                Root : {
                    CHANGED_BY : sUser
                }
            }
        }, {
            condition : "tag_id = ? and id not in ( select ... from ... where id = tags.id) ",
            conditionParameters : [iTagID],
            conditionNodeAlias : "tags"
        }).then(function(oResponse) {
            addMessage(oResponse.messages);
        });
    });
}
````
    
### Function Templates

- **Authorization Check:**

    ````
    function authorizationCheck(vKey, oPersistedObject, addMessage, oContext) { }
    ````

- **Static Authorization Check:**

    ````
    function authorizationCheck(oParameters, addMessage, oContext) { }
    ````

- **Enabled Check:**

    ````
    function enabledCheck(vKey, oPersistedObject, addMessage, oContext) { }
    ````

- **Static Enabled Check:**

    ````
    function enabledCheck(oParameters, oReadOnlyBulkAccess, addMessage, oContext) { }
    ````

- **Execution Check:**

    ````
    function executionCheck(vKey, oRequestObject, oWorkObject, oPersistedObject, addMessage, oContext) { }
    ````

- **Action Execute:**

    ````
    function execute(vKey, oParameters, oWorkObject, addMessage, getNextHandle, oContext) { }
    ````

- **Static Action Execute:**

    ````
    function execute(oParameters, oBulkAccess, addMessage, getNextHandle, oContext, oMetadata) { }
    ````

- **Custom Properties:**
    - **Node/Attribute**
    
        ````
        function customProperties(vKey, oPersistedObject, addMessage, oContext, oNodeMetadata) { }
        ````

    - **Action:**
    
        ````
        function customProperties(vKey, oParameters, oPersistedObject, addMessage, oContext, oActionMetadata, oMetadata) { }
        ````

    - **Static Action:**
    
        ````
        function customProperties(oParameters, oReadOnlyBulkAccess, addMessage, oContext, oActionMetadata, oMetadata) { }
        ````

- **Determination:**

    ````
    function determination(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata) { }
    ````

- **OnPersist Determination:**

    ````
    function determination(vKey, oWorkObject, oPersistedObject, addMessage, getNextHandle, oContext, oNodeMetadata, oActionInfo) { }
    oActionInfo.originalKey = ...
    ````

- **Read Determination**

    ````
    function determination(vKey, oReadObject, oNodeMetadata, oContext) { }
    ````

- **ConsistencyCheck:**
    - **Node:**
    
        ````
        function consistencyCheck(vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````

    - **Attribute:**
    
        ````
        function consistencyCheck(vKey, oAttribute, addMessage, oContext, oNodeMetadata) { }
        ````

- **InputCheck:**
    - **Node:**
    
        ````
        function inputCheck(vKey, oWorkObjectNode, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````

    - **Attribute:**
    
        ````
        function inputCheck(vKey, oAttribute, addMessage, oContext, oNodeMetadata) { }
        ````

- **Read Only Check:**
    - **Node:**
    
        ````
        function readOnlyCheck(vKey, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````

    - **Attribute:**
    
        ````
        function readOnlyCheck(vKey, oPersistedObjectNode, addMessage, oContext, oNodeMetadata) { }
        ````

- **Activation Check:**

    ````
    function activationCheck(oConfiguration, oStage, addMessage, oContext) { }
    ````

- **Add Message:**

    ````
    function addMessage(severity, messageKey, refKey, refNode, refAttribute, parameter1 ... parameter4) { }
    function addMessage(oMessage) { }
    function addMessage(aMessage) { }
    ````

### Runtime Context

The context object that is passed in as parameters has the following functionality:

- **getCallerContext() : Object** 
    - Returns the caller context passed in, when creating a runtime facade for an application object
- **getStoreAccess() : Object** 
    - Get access to the Store implementation class
- **getDB() : DB** 
    - Get access to the current DB instance
- **getDBClient() : DBClient** 
    - Get access to a common wrapper for the current DB instance
- **getUser() : Promise** 
    - Retrieve current application user (is returned as parameter of resolved Promise)
- **getUserInfo : Object** 
    - Get access to the user information available from the JWT token
- **getAuthInfo : Object** 
    - Get access to the authentication information available from the JWT token
- **getAction() : String** 
    - Get current called action metadata object. getAction().name allows to check the action name.
- **getRequestTimestamp() : Date** 
    - Get current request timestamp (unique for transaction)
- **getHistoryEvent() : String** 
    - Get the history event name for the current action
- **setHistoryEvent(sNewHistoryEvent) : void**
    - Set new history event name for the current action
- **getProcessedObject() : Object** 
    - Access to the object currently processed (only for read-only access!)
- **getMetadata(sObjectName) : Promise** 
    - Get access to the metadata of another application object (is returned as parameter of resolved Promise)
- **getApplicationObject(sObjectName, bPrivilegedAuthMode) : Promise** 
    - Get runtime access to another application object (is returned as parameter of resolved Promise). Parameter bPrivilegedAuthMode allows to access the object in privileged mode, so that no authorization checks are performed.
  
### Express Middleware

The Application Object Framework provides an express middleware, to configure the implementation routing.
  
**Example**


    var express = require("express");
    var http = require("http");
    var aof = require("@sap/aof");
    
    var app = express();
    var server = http.Server(app);
    
    aof.middleware(app, {
        metadata: "<url_to_metadata>",
        applicationObjects: {
            "<application_object_name>": "url_to_application_object",
            ...
        }
    });  
      
    server.listen(PORT, function () {
    });
    
### REST Binding

By exposing the application object and its services as restful operations, when accessing the URL to Application Object with the
suffix **".js"** the following HTTP method binding applies:

- POST: 
    - Default: **Create**
    - **Copy**
    - Action name at URL end: **Custom Action**

- PUT: **Update**
- DELETE: **Delete**
- GET: 
    - Default: **Read**
    - properties at URL end: **Properties**
    - staticProperties at URL end: **Static Properties**  
  
The key of the application object instance is extracted out of the URL parameters if existing. 
Otherwise the key is derived from the root node of the REST body structure (JSON structure). Returned generated keys and messages are mapped to the Rest return structure. 
The errors in the Message Buffer define the HTTP return code:

- No errors: HTTP.OK, HTTP.CREATED
- Errors: HTTP.BAD_REQUEST
- Not existing: HTTP.NOT_FOUND
- Invalid Action: HTTP.METHOD_NOT_ALLOWED

Additionally all rest call are wrapped with a trace wrapper, allowing to return the traces by including the $trace statement as part of the request URL.

By the exposing of the application object via REST, it can be accessed via HTTP REST using HTTP methods (GET, POST, PUT, DELETE) following the URL scheme:


#### Application Object URL Convention:

    http(s)://<domain>:<port>/<url_to_application_object>.js

The extension ".js" is the default extension dispatching to the REST adapter and can therefore also omitted for all REST URLs.

##### Metadata URL Convention

Metadata can be retrieved also using the REST adapter. The metadata of an application object is mapped to the following URL scheme:

    http(s)://<domain>:<port>/<url_to_application_object>.js/metadata

The metadata REST call is mapped to the metadata access of the application object framework runtime facade. 

Metadata can also be retrieved by the metadata url specified in the AOF middleware:
 
    aof.middleware(app, {
         metadata: "<url_to_metadata>",
         applicationObjects: {
             "<application_object_name>": "url_to_application_object",
             ...
         }
     });

All available Application Objects with their respective URL path can be retrieved via the Metadata URL like this:

    http(s)://<domain>:<port>/<url_to_metadata>.js
    
If in addition to the Application Object listing also the complete metadata shall be loaded the URL parameter "includeMetadata" can be used like this:

    http(s)://<domain>:<port>/<url_to_metadata>.js?includeMetadata
    
Metadata for a single Application Object can also be retrieved as alternative to the possibility described above using the following URL scheme:

    http(s)://<domain>:<port>/<url_to_metadata>.js/<url_to_application_object>

##### Properties REST Action URL

An Application Object instance action can be called by triggering POST call to URL:

    http(s)://<domain>:<port>/<url_to_application_object>.js/<vKey>/<actionName>
    
The action parameter can be passed as json object into the POST request body.

An Application Object static action can be called by triggering POST call to URL:

    http(s)://<domain>:<port>/<url_to_application_object>.js/<actionName>
    
The action parameter can be passed as json object into the POST request body.

##### Properties REST URL Convention

Dynamic properties for one or many application object instances can be retrieved using the following URL scheme:

    // Single Instance
    http(s)://<domain>:<port>/<url_to_application_object>.js/<vKey>/properties?(node=<nodeName|all>&action=<actionName|all>)*
    // Multiple Instances
    http(s)://<domain>:<port>/<url_to_application_object>.js/properties?(node=<nodeName|all>&action=<actionName|all>&key=<vKey>)*
    
Dynamic properties can be retrieved for a single instance specifying the key in the URL before the **properties** URL path keyword, 
or for multiple instances, specifying the URL parameter key multiple times. The scope for property retrieval can be stated using the action URL parameter and the node URL parameter. 
Again both parameters can be repeated multiple times. Either actions and nodes can be listed by their name or the reserved keyword **all** can be used to retrieve properties for all actions 
or for all nodes.

##### Static Properties REST

Static properties can be retrieved for an application object using the following URL scheme:

    http(s)://<domain>:<port>/<url_to_application_object>.js/staticProperties?(node=<nodeName|all>&action=<actionDefinition>)*

Static properties can be retrieved using the **staticProperties** URL path keyword. The scope for property retrieval can be stated using the action URL parameter and the node URL parameter. 
Both parameters can be repeated multiple times. Nodes can be listed by their name or the reserved keyword **all** can be used to retrieve static properties for all nodes. 
Actions need to be listed as JSON objects in the following structure:   

    { 
        "<actionName>" : { <parameters> } 
    }
  
Parameters can be again an arbitrary JSON object, which is passed into the **staticProperty** evaluation for the corresponding action. 
Reserved keyword **all** is not permitted for action. As the URL can contain JSON strings, the URL needs to be URL encoded to escape not allowed URL characters.


### OData Extension 

AOF can be configured to work out of the box with the HANA XS Advanced XSOData module, by exposing the application object and its services as OData service, 
when accessing the URL to Application Object with the suffix **".odata"** or **".xsodata"**.    
The OData Protocol V2 binding apply as described here [URI Conventions (OData Version 2.0)](http://www.odata.org/documentation/odata-version-2-0/uri-conventions).

The OData extension can be activated like this:

    var express = require("express");
    var xsodata = require("@sap/xsodata");
    var aof = require("@sap/aof");
    
    var app = express();
    aof.middleware(app, {
        applicationObjects: {
            "<application_object_name>": "url_to_application_object",
            ...
        },
        extensions : {
            odata : {
                name : "@sap/xsodata",
                lib : xsodata
            }
        }
    });

Furthermore all specified application objects can be exposed by one single OData service by specyfing the **odata** path in the AOF middleware like this:
 
     aof.middleware(app, {
         odata: "/sap/test/xs/rest/aof",
         applicationObjects: {
            "<application_object_name>": "url_to_application_object",
            ...
         },
         extensions : {
             odata : {
                 name : "@sap/xsodata",
                 lib : xsodata
             }
         }
     });

The OData service can the be accessed via **/sap/test/xs/rest/aof.odata** or **/sap/test/xs/rest/aof.xsodata**.

**Fuzzy Search Extension**

The OData extension provides an out-of-the-box fuzzy search, that can be enabled e.g. likes this via the odata extension parameters:

    extensions: {
        odata: {
            name: "@sap/xsodata",
            lib: xsodata,
            parameters: {
                search: {
                    name: "searchText",
                    fuzzy: 0.8
                }
            }
        }
    }

In this example the parameter **name** is set to **searchText** and represents the custom query URL parameter 
(name always without "$", as not OData standard), with which the search string can be encoded, 
e.g. by using UI5 **jQuery.sap.encodeURL()** function.  

The **fuzzy** parameter defines the fuzziness of the search, which can be a number between **0.0** and **1.0** or the string **"EXACT"**
for an exact search.

The rules of the SQL **contains** predicate apply for the fuzzy search.

For fuzzy search on attributes with type **CLOB/NCLOB** or **CDS LargeString**, a full-text index is necessary to perform the operation, 
otherwise a respective error message is displayed during query execution.

Searchable are all attributes of the target application object node, that are annotated with **isName : true** or **isDescription : true**.
 
If an specific ordering is omitted for the search request, the search result is sorted by the fuzzy **search score** descending, so that 
the most relevant search result is on top of the result set.
 
The calculation of the **search score** can be disabled **(default: enabled)** by setting the parameter **searchScore = false** for the search configuration.

**Named Filters Extension**

The OData extension provides a possibility to defined named filters that can be distinguished into the following three categories

- Static named filters
    - A static named filter can be defined like this:
    
        filters: {
            <queryFilterName>: {
                <staticFilterName>: {
                    condition: "<sql view>",
                    nodes: ["<application object node>"]
                }
            },
            ...
        }
        
    - The <queryFilterName> defines the URL query parameter (name always without "$", as not OData standard)
    - The condition needs to be a SQL(-like) view having a single column named **"key"**.
        - **"key"** represents the key of the application object node
    - A static filter is added to the url as query parameter like this: 
        
        <queryFilterName>=<staticFilterName>
        
    - Multiple static filters can be defined
    
- Single value filters
    - A single value filter can be defined like this:
    
        filters: {
            <queryFilterName>: {
                condition: "<sql view>",
                nodes: ["<application object node>"],
                compare : ">="
            },
            ...
        }
 
    - The <queryFilterName> defines the URL query parameter (name always without "$", as not OData standard)
    - The condition needs to be a SQL(-like) view having two columns named **"key"** and **"value"**.
        - **"key"** represents the key of the application object node
        - **"value"** represents the value that is checked against the passed single value filter
    - The following comparison operators are allowed:
        
        "=", "!=", "<", ">", "<=", ">=", "like", "not like"
        
    - The special comparison operator "search" allows to express a single value filter search like this:
    
        filters: {
            <queryFilterName>: {
                condition: "<sql view>",
                nodes: ["<application object node>"],
                compare: "search",
                fuzzy: 0.2
            }
        }
    
    - Like for the fuzzy search the fuzzy parameter defines the fuzziness of the search, which can be a number between **0.0** and **1.0** or the string **"EXACT"** for an exact search.
    - A single value filter is added to the url as query parameter like this:
    
        <queryFilterName>:<searchValue>
    
    - The calculation of the **search score** can be enabled **(default: disabled)** by setting the parameter **searchScore = true** for the search configuration.
    - If an specific ordering is omitted for the search request, the search result is sorted by the fuzzy **search score** descending, so that 
      the most relevant search result is on top of the result set.
    - **Limitation**: 
        - The SAP HANA database does not support the calculation of the **search score** for named filters. 
        - The result set of a named filtering via search comparison operator cannot be sorted by the fuzzy search score, like it can be done for the fuzzy search extension above.
        - **Reason**: The use of **SCORE()** in more than one subqueries is not supported.
    
- Multi-value filters
    - A multi-value filter can be defined like this:
    
        filters: {
            <queryFilterName>: {
                condition: "<sql view>",
                nodes: ["<application object node>"],
                separator: ",",
                compare : "in",
                match : "all"
            }
        }
        
    - The <queryFilterName> defines the URL query parameter (name always without "$", as not OData standard)
    - A multi-value filter is indicated by specifying the separator sign, e.g. ","
    - The condition needs to be a SQL(-like) view having two columns named **"key"** and **"value"**.
        - **"key"** represents the key of the application object node
        - **"value"** represents the value that is checked against the passed multi-values filters (split by the separator)
    - The following comparison operators can be performed
        - **in**: Check that search value is in the filter condition **(default)**
        - **not in**: Check that search value is **NOT** in the filter condition 
    - A match parameter can be specified 
        - **any**: Returns the filter instance of the condition if **any** of the search values matches **(default)**
        - **all**: Returns the filter instance of the condition if **all** of the search values matches 
    - A multi-value filter is added to the url as query parameter like this:
        
        <queryFilterName>:<searchValue1>,...,<searchValueN>

All filters can be restricted to certain application object nodes using the **nodes** array in each filter definition. 
Application object name and node are connected with "." to build up the application object node used to be defined in the **nodes** array, e.g.

    sap.ino.xs.object.Comment.Root

**Current Limitations**
    
- OData write is not yet supported  

### Socket.io Extension (preferred WebSocket implementation)

AOF can be configured to work out of the box with WebSocket module **Socket.io**, by exposing the application object and its services as web sockets for their namespace path. 
The web sockets protocol apply as described here [Socket.io](http://socket.io).  

The **Socket.io** extension can be activated like this:

    var express = require("express");
    var http = require("http");
    var socketio = require("socket.io");
    var aof = require("@sap/aof");
    
    var app = express();
    var server = http.Server(app);
    var io = socketio(server);
    aof.middleware(app, {
        applicationObjects: {
            "<application_object_name>": "url_to_application_object",
            ...
        },
        extensions: {
            websocket: {
                name: "socket.io",
                lib: io
            }
        }
    });

A web socket connection request can be enhanced by express middleware calls like this:
 
    var passport = require("passport");
    
    aof.middleware(app, {
        extensions: {
            websocket: {
                name: "socket.io",
                lib: io,
                middleware: [
                    passport.authenticate("JWT", {session: false})
                ]
            }
        }
    }

In this example a web socket request can be authenticated using the **passport** module.

Each published application object configured in the AOF middleware is accessible via web socket channel based on the object's URL as namespace.
The application objects core actions (CUD) and the custom actions are mapped to the socket.io **emit** and **on** functions. The action name corresponds to 
the **emit** event name, and the request data are mapped to the **emit** parameters.

The corresponding namespace specific **Socket.io** object can be accessed within an application object implementation from the caller context like this:
  
    var io = oContext.getCallerContext().getSocketIO();
    io.emit("create", { "ID": -1, ... });

The global **Socket.io** library can be accessed via:
  
    var io = oContext.getCallerContext().socketio;

A namespace specific socket for another application object can be retrieved via:
  
    var io = oContext.getCallerContext().getSocketIO(<ApplicationObjectName>);

Application objects exposing static actions called **wsConnect** and **wsDisconnect** are automatically called with the respective action upon **Socket.io** connection
or disconnection of a client web socket. 

Application object's core actions (CUD) and instance custom actions are automatically published to all connected socket listener, publishing 
the **action** name as **Socket.io** event and the object instance data as **event parameters**. Socket listeners can register to action executions via the 
Socket.io **on** function, specifying the action name as socket event. Each socket listener is called with the object data and additional parameters, e.g.
 
    io.on("create", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
        var iId = oResponse.generatedKeys[-1];
        // ...
    });

The parameters consist of information about **key**, **object**, **objectBefore**, **response** and **sessionUUID**.
Custom actions do not publish separate events, but an generic "update" event is emitted, and the response object contains an attribute **customAction**, 
containing the real executed custom action. In case of an "update" action, the **customAction** attribute is undefined.

By default an application object notification is not checked for instance authorization and published to all connected clients.
To enabled instance authentication the following configuration can be used:

    var passport = require("passport");
    
    aof.middleware(app, {
        extensions: {
            websocket: {
                name: "socket.io",
                lib: io,
                checkAuth: true,
                middleware: [
                    passport.authenticate("JWT", {session: false})
                ]
            }
        }
    }

When enabling instance authentication the instance check for deleted instances cannot be checked, as they do not exist anymore. 
Therefore no notifications for instance deletions would be published. To enable publication of delete events for all instances,
without authentication check, the flag **checkAuthDelete** can be set to the following values to control data visibility:
  
**checkAuthDelete:**
- **"none"**: Do not publish delete events at all
- **"key"**: Do publish **key** of deleted application object instance without object data
- **"all"**: Do publish complete event data including application object data

WebSockets based on **Socket.io** module can be enabled to support **groups**. Groups are **Socket.io Rooms**, where socket clients only
receive messages when joining the group. Using the following configuration **groups** can be enabled like this:
 
    var passport = require("passport");
     
    aof.middleware(app, {
        extensions: {
            websocket: {
                name: "socket.io",
                lib: io,
                groups : {
                    <ApplicationObjectName> : <GroupKeyAttribute>
                }
                middleware: [
                    passport.authenticate("JWT", {session: false})
                ]
            }
        }
    }

A group can be defined for an Application Object, by specifying the group key attribute, to be used
to determine the group key value from the Application Object root node data during event emitting.

Two events can be triggered by the socket client to control the group membership:

- **wsSubscribe**: Subscribe to a group, e.g. oSocket.emit("wsSubscribe", <GroupKey>);
- **wsUnsubscribe**: Unsubscribe from a group, e.g. oSocket.emit("wsUnsubscribe", <GroupKey>);

The **group key** needs to be a value valid to the group key attribute definition of the Application Object.
In case the group key attribute specifies the primary key of the Application Object root node, the events
corresponding to the group representing a Application Object instance are emitted to the group, **after** the
creation of the object, as only then the instance key is known, and a client can register to this key. 
I.e. the **create** event is published globally to the Application Object namespace, and contains the instance 
key which in this case is then the group key for subscription.


A browser client can connect to the Socket.io library like this:
    
    <script src="/socket.io/socket.io.js"></script>
    
A connection to a application object is established by passing the application object URL path as Socket.io namespace, e.g.

    var io = io("<url_to_application_object>");

Application Object actions (including CUD actions) can then be called using **emit**, e.g. for action "create"
    
    io.emit("create", { "ID": -1, ... });

Listener registration to an application object action execution is done with **on** as follows, e.g. for action "create"

    io.on("create", function (vKey, oObject, oObjectBefore, oResponse, sSessionUUID) {
        var iId = oResponse.generatedKeys[-1];
        // ...
    });

The session UUID identifies globally (across all browser sessions) an application object instance, and especially helps to identify, 
that changes performed were not initiated self-kindled. 
The session UUID of an application object instance to be compared can be fetched using the **getSessionUUID** function. 

### WS Extension (alternative WebSocket implementation)

AOF can be configured to work out of the box with WebSocket Node.js module **WS**, by exposing the application object and its services as web sockets for their namespace path. 
The web sockets protocol apply as described here [WS](https://github.com/websockets/ws).  

The **WS** extension can be activated like this:

    var express = require("express");
    var http = require("http");
    var ws = require("ws");
    var aof = require("@sap/aof");
    
    var app = express();
    var server = http.Server(app);
    var WebSocketServer = ws.Server;
    var wss = new WebSocketServer({ server: server });
    
    aof.middleware(app, {
        applicationObjects: {
            "<application_object_name>": "url_to_application_object",
            ...
        },
        extensions: {
            websocket: {
                name: "ws",
                lib: wss
            }
        }
    });

A web socket connection request can be enhanced by express middleware calls like this:
 
    var passport = require("passport");
    
    aof.middleware(app, {
        extensions: {
            websocket: {
                name: "ws",
                lib: wss,
                middleware: [
                    passport.authenticate("JWT", {session: false})
                ]
            }
        }
    }

In this example a web socket request can be authenticated using the **passport** module. 

Each published application object configured in the AOF middleware is accessible via web socket channel based on the object's URL.
The application objects core actions (CUD) and the custom actions are mapped to the WS **send** and **on** functions. The message
is a serialized JSON object consisting information about **action**, **key**, **object**, **objectBefore**, **response** and **sessionUUID**.

The **WS** object can be accessed within an application object implementation from the caller context like this:
  
    var ws = oContext.getCallerContext().ws;
    ws.broadcast(JSON.stringify({
        action: "create",
        key: 1,
        object: {"ID": -1, ... }
    }));

Application objects exposing static actions called **wsConnect** and **wsDisconnect** are automatically called with the respective action upon **WS** connection
or disconnection of a client web socket. 

Application object's core actions (CUD) and instance custom actions are automatically published to all connected socket listener, publishing event
with a message as serialized JSON object containing the action name and action response. Socket listeners can register to action executions via the 
WS **.on("message")** function, passing the result, e.g.
 
    ws.on("message", function (sMessage) {
        try {
            var oMessage = JSON.parse(sMessage);
            if (oMessage.action == "create") {
                var oObject = oMessage.object;
                var oObjectBefore = oMessage.objectBefore;
                var iId = oMessage.response.generatedKeys[-1];
                iId = oMessage.key
            }
        } catch (e) {
        }
    });

Custom actions do not publish separate events, but an generic "update" event is emitted, and the response object contains an attribute **customAction**, 
containing the real executed custom action. In case of an "update" action, the **customAction** attribute is undefined.

By default an application object notification is not checked for instance authorization and published to all connected clients.
To enabled instance authentication the following configuration can be used:

    var passport = require("passport");
    
    aof.middleware(app, {
        extensions: {
            websocket: {
                name: "ws",
                lib: wss,
                checkAuth: true,
                middleware: [
                    passport.authenticate("JWT", {session: false})
                ]
            }
        }
    }

When enabling instance authentication the instance check for deleted instances cannot be checked, as they do not exist anymore. 
Therefore no notifications for instance deletions would be published. To enable publication of delete events for all instances,
without authentication check, the flag **checkAuthDelete** can be set to the following values to control data visibility:
  
**checkAuthDelete:**
- **"none"**: Do not publish delete events at all
- **"key"**: Do publish **key** of deleted application object instance without object data
- **"all"**: Do publish complete event data including application object data

A browser client can connect to the WS library using standard WebSockets technology.
A connection to a application object is established by passing the application object URL path as WS path, e.g.

    var oSocket = new WebSocket("ws://" + window.location.host + "<url_to_application_object>");

Application Object actions (including CUD actions) can then be called using **send**, e.g. for action "create" and 
parameter array:
    
    oSocket.send(JSON.stringify({
        action: "create",
        parameters: [{ 
            "ID": -1, 
            ... 
        }]
    }));

Listener registration to an application object action execution is done with **onmessage** as follows, e.g. for action "create"

    oSocket.onmessage = function (oEvent) {
        var oMessage = JSON.parse(oEvent.data);
        switch (oMessage.action) {
            case "create":
                var oObject = oMessage.object;
                var oObjectBefore = oMessage.objectBefore;
                var iId = oMessage.response.generatedKeys[-1];
                //iId = oMessage.key;
                var sSessionUUID = oMessage.sessionUUID;
                break;
        }
    };

The session UUID identifies globally (across all browser sessions) an application object instance, and especially helps to identify, 
that changes performed were not initiated self-kindled. 
The session UUID of an application object instance to be compared can be fetched using the **getSessionUUID** function. 

### Schema Validation

Application object metadata must follow the schema definition described above.  
Schema validation can be performed by means of the function validateMetadataDefinition. 
The function will return a list of schema validation error messages. 
If the metadata is schema compliant the error list is empty. The schema validation can be used in unit-test 
using the following pattern:

    var AOF = require("@sap/aof");
    var Schema = AOF.Schema;

    var oObjectDefinition = require("<ObjectPath>");
    var aMessage = Schema.validateMetadataDefinition(oObjectDefinition);
    expect(aMessage).toEqual([]);
    done();

Application Object extension definition can be validated against the extension schema like this:

    var AOF = require("@sap/aof");
    var Schema = AOF.Schema;

    var oExtensionObjectDefinition = require("<ExtensionObjectPath>");
    var aMessage = Schema.validateExtensionMetadataDefinition(oExtensionObjectDefinition);
    expect(aMessage).toEqual([]);
    done();


### UI Application Object Model

The Application Model has also an representation in the UI layer of the application. To support it, a base class ApplicationObject.js was introduced. An UI Application Object Model
can inherit from the base class ApplicationObject.js, and define additional UI model related properties

The UI Application Object Model is based on the SAPUI5 JSONModel, and therefore can be assigned as model to any controls and used in property and list bindings.

The UI Application Object Model definition is specified by the following properties:

- **objectName:** Application Object Name in the AOF framework
- **readSource:** Function that reads the before image to fill the UI Application Object Model
    - ReadSource.getDefaultAOFSource(): 
        - Data is read from the Application Object instance using a GET REST-Request to the AOF framework 
        - Additional Settings can be specified:
            - **cache**: Specifies the AJAX cache settings
            - **headers**: Specifies the AJAX header parameters 
    - ReadSource.getDefaultODataSource("&lt;EntitySet&gt;", oSettings?): 
        - Data is read from the specified OData Entity Set and associated sub-entities
        - Additional Settings can be specified:
            - **excludeNodes:** \[\]: Array of nodes, that shall not be read via associations can be excluded
                - e.g. oSettings.excludeNode = \[ "<Node>" \];
            - **deepChildPaths:** {}: Map of nodes to a child path, that is used instead of the standard hierarchy as specified according to the AOF node model 
                - Direct child data is read via separate OData read calls, in addition to the Root OData read call
                - Deep child data (level &gt; 2) is read directly with the Root OData call using listing all deep child paths in the OData expand parameter
                - e.g. oSettings.deepChildPaths = : { <Node> : "<DeepPath>" }
            - **includeNodes:** \[\]: Array of nodes to extra include into the OData read, as objects in the following format: { name : "&lt;NodeName&gt;", parentNode : "&lt;ParentNodeName&gt;" }
                - Can be combined with deep child paths as well
            - **projection:** \[\]: Array of attributes read for root node
            - **onlyRoot**: boolean: Specifies that only the root node is read
            - **model:** ODataModel: Specifies the OData model from which the data is read
- **invalidation:**
    - OData entity Sets that needs to be invalidated by the Model Synchronizer can be listed using the following structure:
        - entitySets : \["&lt;EntitySet1&gt;", "&lt;EntitySet2&gt;"\]
- **actions:**
    - &lt;actionName&gt;: For each action available in the Application Object or define in the UI model as UI action
        - **initParameter:**  Callback function to determine the default action parameters, when retrieving the action parameter model
            - **oParameter:** First parameter is an empty parameter object, that can be modified to initialize the parameter JSON Model
            - **<var args>:** The passed arguments of the call to retrieve the action parameter model are passed to the **initParameter** function to provide context information 
        - **impacts:** An array of impact definitions for other application objects that can be specified using the following structure:
            - **objectName**: name of the impacted application object
            - **objectKey**: foreign key attribute in the application object matching the impacted application object's primary key
            - **impactedAttributes:** array of attributes, that are impacted by the application object change (used for selective read)
        - **execute:**  For UI actions a execute method can be implemented to process the logic
- **determinations:**
    - **onCreate:** Called on creation of a new UI Application Object Model instance (no key, but default data is passed in the constructor)
        - Return a value or a deferred object promise
    - **onRead:** Called after reading the before data from the data source, to alter the default data before setting the before image. Sub-nodes may not be available at all time.
        - Return a value or a deferred object promise
    - **onPersist:** Called after every successful call to the AOF backend (Create, Update, Delete, Custom Actions)
    - **onNormalizeData:** Called for normalizing a structurally different model in binding to the data model used in backend. Called before sending changes to the backend or when pending changes are calculated. Returns the normalized data.
    - **onUpdateHandles:** When data structure differs (see onNormalizeData) the updating handles in the model has to be done in this determination. Returns the data where the temporary handles have been replaced by generated keys.

#### Library Usage

The AOF UI5 library of the Application Object Framework is accessible via the server path **/sap/aof/**. 
It can be made available via the UI5 bootstrap parameter **data-sap-ui-resourceroots**:  
    
    data-sap-ui-resourceroots='{ "sap.aof": "/sap/aof" }'

and loaded in one request as build UI5 library using **data-sap-ui-libs**: 

    data-sap-ui-libs="sap.aof"
    
An UI5 bootstrap example using the AOF UI5 library looks like this:

    <script
            id="sap-ui-bootstrap"
            src="/sap/ui5/1/sap-ui-core.js"
            data-sap-ui-theme="sap_bluecrystal"
            data-sap-ui-libs="sap.m,sap.aof"
            data-sap-ui-bindingSyntax="complex"
            data-sap-ui-compatVersion="edge"
            data-sap-ui-preload="async"
            data-sap-ui-resourceroots='{ "sap.aof": "/sap/aof" }'>
    </script>
    
The AOF UI files then can be used using the UI5 require mechanism or by defining dependencies during file declaration like this

    sap.ui.define([
        "sap/aof/ApplicationObject",
        "sap/aof/ReadSource"
    ], function (ApplicationObject, ReadSource) {
        "use strict";
    
        return ApplicationObject.extend("<application_object_ui_name>", {
            objectName: "<application_object_backend_name>",
            readSource: ReadSource.getDefaultAOFSource(),
            invalidation: {
                entitySets: ["Root"]
            }
        });
    });

    
The created Application Object can the be instantiated like this:
 
    sap.ui.require([
        "<application_object_ui_name>",
    ], function (<ApplicationObject>) {
        var <oApplicationObject> = new <ApplicationObject>(-1);
        <oApplicationObject>.save();
    });
 
#### Constructor Parameters 

- **First Parameter**
    - Object key for creating a model for an existing instance
    - or Handle key, e.g. **-1**: For creating a new instance
    - or Default data object:
        - Used to initialize the model for create mode 
        - Used as context for static action properties
- **Second Parameter**
    - **Options** (default is false or null)
        - **continuousUse** 
            - The model is continuously used for several modifications and data re-read after backend call
        - **readSource**
            - Read Source settings propagated to read source implementation as additional settings
        - **concurrencyEnabled**
            - Specifies if concurrency mode is enabled, so that the concurrency token is retrieved and checked for each modifying backend communication
            - Backend Application Object must be concurrency enabled by flagging at least one attribute on Root node with "concurrencyControl = true" 
        - **deriveBindingType**
            - Automatically derives the data type during establishing of a property binding from the application object metadata (if no type was specified explicitly)
            - **Attention**
                - This could lead to unexpected behaviour when specifying a formatter, which changes the type (e.g. formatter converting a integer to a boolean)
                - Use explicit 'type = null' for property binding, to prevent automatic type derivation for this specific binding  
        - **actions**
            - Actions for which properties are read during model initialization and model sync for the current specified instance key 
        - **nodes**
            - Nodes for which properties are read during model initialization and model sync for the current specified instance key
        - **staticActions**
            - StaticActions for which staticProperties are read during model initialization and model sync for the specified default data object (3rd option of first constructor parameter)
        - **textModel** 
            - Text model used to map the message keys to message texts
        - **changeDetectionProperty** 
            - Enables a change detection property, which can be bound, to be notified when model data is touched. Use **hasPendingChanges** to detect if data was changed compared to data read before.
        
#### AOF UI messages

The AOF framework returns messages containing text keys. The default texts for these AOF message text keys, prefixed with **MSG_AOF_**, can be read via the following property file

    /sap/aof/text/messages.properties

A UI5 text bundle can be instantiated based on this property file and texts can be made available via the UI5 text model.  

#### Function Templates

- **Read Source: **


    ````  
    function readSource(vKey, sObjectName, oMetadata) { } : Promise
    ````
    
- **Parameter Initialization:**


    ````
    function initParameter(oParameter, <Parameter1>, ..., <ParameterN>) { } : void
    ````
    
- **Determination:**

    - **onCreate:**
    
        ````
        function onCreate(oDefaultData, oObjectInstance) { } : Promise/Object
        ````
        
    - **onRead:**
    
        ````
        function onRead(oData, oObjectInstance, bBeforeImage) { } : Promise/Object
        ````
        
    - **onPersist:**
    
        ````
        function onPersist(vKey, oChangeRequest, oData, oAction, oObjectInstance) { } : void
        ````
        
    - **onNormalizeData:**
    
        ````
        function onNormalizeData(oData, oObjectInstance, bBeforeImage) { } : Promise/Object
        ````
        
    - **onUpdateHandles:**
    
        ````
        function onUpdateHandles(oData, mGeneratedKeys) { } : Object
        ````
         
- **UI Application Object Model Constructor**
    - vKey > 0: Edit existing instance
        - A scope can be specified, which is used to instantiate a property model which is bound to the application object data path applicationObject>/property

        ````
        new <ApplicationObject>(vKey, oScope) : Object
        ````

    - vKey < 0: Creates a new instance with optional context, if the primary key is of type integer in the application object definition
            
        ````
        new <ApplicationObject>(oDefaultData?, oScope) : Object
        ````


- **Get Parameter Model**


    ````
    <ApplicationObject>.<action>Model(<Parameter1>, ..., <ParameterN>) : JSONModel
    ````


- **Instance CRUD Functions**

    - Instance CRUD function can be called on the instantiated application object model for a key or handle key. 
    - The instance CRUD functions take a settings parameter "oSettings" allowing to define the following behaviour:
        - **suppressBackendSync** 
            - Suppress a sync with backend, e.g., when the object is not read by UI after the custom action 
        - **processSync**
            - Calls the backend communication synchronously, as opposed to standard asynchronously
        - **ignoreConcurrencyConflict**
            - Ignores the concurrency conflict and forces the backend to update, although the read before state of the object has changed meanwhile
        - **headers**
            - Additional headers for AJAX call
    - Each request is returning a result object containing:
        - **GENERATED_KEYS**
            - The generated keys for the handle keys
        - **MESSAGES**
            - The messages occurred during processing of the request 

- **Instance CRUD Functions usage**

    - **Create**
    
        ````
        create(oSettings) : Promise
        ````
        
    - **Copy **
        - returns a new instance for the copied object having the same settings like the copied one
        - Copy can only be called on persisted objects
        - oCopyData is a data object that is merged with the copied data to make additional changes to the copy before save 
        - oCopyData can contain a handle key, to retrieve the copy afterwards
   
        ````
        copy(oCopyData, oSettings) : Promise
        ````
       
    - **Update**
    
        ````
        update(oSettings) : Promise
        ````
        
    - **Delete**
    
        ```` 
        del(bIgnoreConcurrencyConflict, oSettings) : Promise
        ````
        
    - **Modify/Save**
        - Creates or updates instance
        - See Create or update        
    
        ````
        modify(oSettings) : Promise
        save(oSettings) : Promise
        ````

    - **Action**
        - oParameter is the data object passed as action parameter
        
        ````
        <action>(oParameter, oSettings) : Promise
        ````

    - **Action Model**
        - An action JSON Model is returned, to be bound against an action dialog
        - Arbitrary arguments, passed as parameters to the **initParameter** function after the **oParameter** argument   
        
        ````
        <action>Model(<Parameter1>, ..., <ParameterN>) : JSONModel
        ````


- **Static CRUD Functions**

    - Static CRUD function can be called on the static application object model
    - The instance key is passed as parameter
    - The static CRUD functions take a settings parameter "oSettings" allowing to define the following behaviour:
        - **processSync**
            - Calls the backend communication synchronously, as opposed to standard asynchronously
        - **headers**
            - Additional headers for AJAX call
    - Each request is returning a result object containing:
        - **GENERATED_KEYS**
            - The generated keys for the handle keys
        - **MESSAGES**
            - The messages occurred during processing of the request 

- **Static CRUD Functions usage**

    - **Create**
        - oCreateRequest is the data object to be created and can contain a handle key
        
        ````
        create(oCreateRequest, oSettings) : Promise
        ````
        
    - **Copy**
        - Copy can only be called on persisted objects
        - vKey the object instance to be copied
        - oCopyData is a data object that is merged with the copied data to make additional changes to the copy before save 
        - oCopyData can contain a handle key, to retrieve the copy afterwards
    
        ````
        copy(vKey, oCopyData, oSettings) : Promise
        ````
        
    - **Update**
        - vKey the object instance to be updated
        - oChangeRequest is the data object to be send to the backend for update
    
        ````
        update(vKey, oChangeRequest, oSettings) : Promise
        ````
        
    - **Delete**
        - vKey the object instance to be deleted
    
        ````
        del(vKey, oSettings) : Promise
        ````
        
    - **Modify/Save**
        - Creates or updates instance
        - See Create or update
    
        ````
        modify(vKey, oChangeRequest, oSettings) : Promise
        save(vKey, oChangeRequest, oSettings) : Promise
        ````
        
    - **Action**
        - vKey the object instance to be called the action upon
        - oParameter is the data object passed as action parameter
        
        ````
        <action>(vKey, oParameter, oSettings) : Promise
        ````

    - **Action Model**
        - An action JSON Model is returned, to be bound against an action dialog
        - Arbitrary arguments, passed as parameters to the **initParameter** function after the **oParameter** argument   
        
        ````
        <action>Model(<Parameter1>, ..., <ParameterN>) : JSONModel
        ````

- **Additional Functions**

    - **getProperty(sPath, oContext) : Object**
    - **setProperty(sPath, vValue, oContext) : Object**
        - The UI application object model is a normal UI5 JSONModel, which holds the current data
        - Binding and getProperty/setProperty can be used like normal preserving the signature

    - **getDataInitializedPromise() : Promise**
        - Returns a promise, which is resolved, when the application object has been initialized 
            - Data was read and set as before image
            - Properties as specified in the settings are read and set in the model

    - **getPropertyModelInitializedPromise() : Promise**
        - Returns a promise, which is resolved, when the property model of the application object has been initialized
        
    - **readData(oSettings) : Object**
        - Explicitly read data wih the current key from the read source
        - Pass the read settings as parameter as specified for the read source definition above

    - **getLastReadDate() : Date**
        - Get the date of the time, the model did last read

    - **getSessionUUID() : String**
        - Returns a global unique session UUID of the application object instance

    - **getKey() : Any**
        - Returns the current specified key and after a successful create, the specified handle key is replaced by the backend key and return by this function

    - **getInitKey() : Any**
        - Returns the key or handle key the model was initialized 

    - **isNew() : Boolean**
        - Returns true, if the application object instance does not yet exist in the backend

    - **getApplicationObjectMetadata() : MetaModel**
        - Get the Metadata model of the application object instance
        - Is also a normal UI5 JSONModel which can be bound
        
    - **getObjectName() : String**
        - Return the application object name
        
    - **hasPendingChanges() : Boolean**
        - Returns boolean, if the current application object model has pending changes, i.e. current data deviate from previously read data (before image)
        - Pending changes are reset after a successful backend communication (create, update, modify...)
        
    - **getChangeRequest(bComplete) : Object**
        - Returns the change request that would be send to the backend, based on the current object data
        - bComplete indicates to returns the complete changes instead of the delta changes to the before read data
        
    - **getUserChanges() : Object**
        - Returns the changes that have been performed to the model after the model initialization (excluding the default data initialization)
             
    - **revertChanges() : void**
        - Reverts all changes currently performed to the model, and sets the current state back to before data
        
    - **sync() : void**
        - Syncs the model by reading the actual data from the backend and updating the model accordingly (is performed automatically after each backend modification in case of continuous use)
        - A new data initialize promise is created, which can be obtained using getDataInitializedPromise function to detect when the re-read is complete
        
    - **resolveConflictManually() : void**
        - Resolve a conflict manually, so that the next backend request will succeed 

    - **updateNode(oNode, sNodeName) : void**
        - Update the node with the specified key in oNode with the data in oNode
        - oNode specifies the node instance and the data to be updated
        - sNodeName specifies the name of the node

    - **addChild(oChild, sNodeName, iIndex) : Integer**
        - Adds a child to a object sub-node aggregation array
        - oChild specifies the child data
        - sNodeName specifies the name or the deep name path (e.g. /Item/1/Lines) of the child node array 
        - iIndex specifies the index of the child to be added (if not specified the child is appended)
        - Returns the handle key of the newly added node 
    
    - **removeChild(oChild) : void**
        - Removes a child from the object tree structure
        - oChild specifies the child data instance to be removed, 
        - The Javascript object identity is used to identify the child node in the node hierarchy
        
    - **getNextHandle() : Integer**
        - Generates the next handle key, based on the already taken handle keys (in this case keys must be of type integer)
        
    - **getBeforeData() : Object**
        - Returns the before image data of the model
        
    - **releaseFromSync() : void**
        - Release object from Model Synchronizer. Application object instances are registered at creation at Model Synchronizer.

    - **getReadSourceModel() : Object**
        - Returns the read source of the application object

    - **getXCSRFToken() : String**
        - Get current X-CSRF-Token

    - **isOwnSession(sSessionUUID) : Boolean**
        - Returns **true**, if the session is existing in the context, else **false**
        
    - **getSessionDate(sSessionUUID) : Date**
        - Returns the last session date of the application object session, identified by the global unique **sSessionUUID** 
        - Returns null, if the session is not existing in the context

    - **clearSessions(oDate) : void**
        - Clears application object sessions that are older than or equal to the passed date. If not date is provided, date is defaulted to now.
        - Clears all sessions if null is passed as date

#### Meta Model

A Meta Model can be made globally available, like this.

    sap.ui.require([
        "sap/aof/MetaModel",
    ], function (MetaModel) {
        this.setModel(MetaModel, "meta"); 
    });

That allows to bind the Application Object metadata information statically in the following manner:

    {meta>/<application_object_backend_name></nodes/Root/attributes/<Attribute>/maxLength}
    
Additionally the Meta Model of an Application Object instance is made available using the following binding (where **instance** is the model name of the UI Application Object)

    {instance>/meta/nodes/Root/attributes/<Attribute>/maxLength}

#### Property Model


The property model can be used to read properties of an application object instance for nodes and actions and static properties of an application object for static actions.
The Property Model constructor takes the following parameters:

- **sApplicationObjectName**
    - name of the application object
- **vKey**
    - key of the application object instance
- **oScope**
    - scope object definition, e.g.
         
        { nodes : ["Root"], actions : ["update", { "customAction" : { "A" : 1 } }], staticActions : [ { "create" : { "OBJECT_ID" : 1 } } } ]
        
- **bSync**
    - properties are fetched synchronously
- **fnModelInitialized**
    - event triggered after model initialization
- **oPropertyDefault**
    - default data for properties used to initialized the property model before the async backend requests

The Property Model can be automatically instantiated as part of a Application Object model instantiation. 
A Property Model can manually be instantiated for an Application Object instance to retrieve property information like this:

    sap.ui.require([
        "sap/aof/PropertyModel",
    ], function (PropertyModel) {
        var oPropertyModel = PropertyModel(<application_object_name>, <key>, {
            nodes : ["Root", "<node2>"],
            actions : ["<action1>", "<action2>"]
        });         
    });


The properties of the property model can be bound in the following manner (where properties is the model name of the instantiated Property Model):
 
    var oText = new sap.m.Text();
    oText.setModel(oPropertyModel, "properties");
    oText.setRequired("{properties>/nodes/Root/attributes/<Attribute1>/readOnly}");


Also static property information, especially for the Create action can be retrieved as follows and used in a binding:


    var oPropertyModel = new PropertyModel("sap.ino.xs.object.idea.Comment", 1, {
        staticActions : {
            "<static_action>" : {
                <Attribute> : <Value>
            }
        }
    });
     
    var oText = new sap.m.Text();
    oText.setModel(oPropertyModel, "properties");
    oText.setRequired("{properties>/actions/<static_action>/enabled}");


The Property Model of an Application Object instance is made available using the following binding, if the application object was instantiated with a properties scope (as explained above):

    {instance>/property/actions/<action>/enabled}

Additionally to the possibility for direct binding of the instantiated Property Model, it also offers Formatter for instance but also for static access:

**- Instance Formatter (Property Model instance required):**  

- **getNodeReadOnlyFormatter** (sNodeName): 
    - Get formatter to use in binding for object instance, to determined the read-only state of a node
- **getNodeChangeableFormatter** (sNodeName): 
    - Get formatter to use in binding for object instance, to determined the changeable state of a node
- **getAttributeReadOnlyFormatter** (sNodeName, sAttributeName): 
    - Get formatter to use in binding for object instance, to determined the read-only state of a node attribute
- **getAttributeChangeableFormatter** (sNodeName, sAttributeName): 
    - Get formatter to use in binding for object instance, to determined the changeable state of a node attribute
- **getActionEnabledFormatter** (sActionName): 
    - Get formatter to use in binding for object instance, to determined the enabled state of an action
- **getStaticActionEnabledFormatter** (sActionName): 
    - Get formatter to use in binding for object instance, to determined the enabled state of a static action  

**- Static Formatter (No Property Model instance required):**
  
- **getNodeReadOnlyStaticFormatter** (sObjectName, sNodeName): 
    - Get static formatter to use in binding against the key of the object instance, to determined the read-only state of a node
- **getNodeChangeableStaticFormatter** (sObjectName, sNodeName): 
    - Get static formatter to use in binding against the key of the object instance, to determined the changeable state of a node
- **getAttributeReadOnlyStaticFormatter** (sObjectName, sNodeName, sAttributeName): 
    - Get static formatter to use in binding against the key of the object instance, to determined the read-only state of a node attribute
- **getAttributeChangeableStaticFormatter** (sObjectName, sNodeName, sAttributeName): 
    - Get static formatter to use in binding against the key of the object instance, to determined the changeable state of a node attribute
- **getActionEnabledStaticFormatter** (sObjectName, sActionName): 
    - Get static formatter to use in binding against the key of the object instance, to determined the enabled state of an action
- **getStaticActionEnabledStaticFormatter** (sObjectName, sActionName, oParameter): 
    - Get static formatter to use in binding against the key of the object instance, to determined the enabled state of a static action
    
### Extensibility

Customers can enhance SAP application objects by defining an extension package and placing their own definition in that library with the same name. 
Only application objects may be enhanced which are marked as **extensible** by SAP.  An application object extension may only be done once per application object.
Customers can override the following parts of SAP application objects:
 
**Actions**

- enabledCheck
- executionCheck
- execute
- customProperties: are merged
- Not possible: authorizationCheck has been currently excluded and might be included in future once there are specific use cases for it

**Determinations**

- Additional determinations can be defined for all events. They are executed in addition after SAP determinations

**Node/Attribute**

- consistencyChecks: Additional consistency checks may be defined on node and attribute level. They are executed in addition after SAP consistency checks.
- inputChecks: Additional input checks may be defined on node and attribute level. They are executed in addition after SAP input checks.
- readOnly: Can be overwritten to true on node and attribute level. Executed in addition to the SAP implementation
- customProperties: are merged

**Attribute**

- required: May be overwritten to true by customer (an SAP required field may not be set to not required)
- customProperties: are merged

At runtime for extensible application objects a lookup is performed for extensions. These extensions are merged to metadata being processed by the AOF. 
For error analysis customer extension can be switched off. Those logic changes are automatically reflected on the user interface which accesses the properties dynamically.
Extensibility can be switched globally off in AOF by calling **disableExtensions** on the AOF framework.

An **isExtensible** flag on object level denotes whether extensibility is switched on and causes the extended object definition to be read
A flag called **explicitAttributeDefinition** on node level that states whether attributes of a table need to be listed explicitly.
Custom properties for actions, nodes and attributes, which is opaque to AOF, but is interpreted by the client. Property bags can also be determined by functions per object instance.
    
### Debug & Logging

Debug authorization (which enables the **?trace** option in HTTP request URLs) can be set via environment variable:

    process.env.AOF_DEBUG_AUTHORIZATION = true

Winston logging level can be set via environment variable, e.g. to logging level "error"

    process.env.LOGLEVEL = "error"

OData "development" mode can be set via environment variable:

    process.env.XSODATA_NODE_ENV = "development"

### Examples & Tests

Check out the examples in the **examples** or **test** folder of the AOF library.

**- HDI DB Test Container**

- /test/db : DB test entities 

    ````
    ./hdi_create_container.sh
    ````
    
    ````
    ./hdi_grant.sh
    ````
    
    ````
    ./hdi_sync.sh
    ````
    
**- Unit-Tests**

- ./ : Unit Tests (in /test/mocha) 

    ````
    npm install
    ````
    
    ````
    npm test
    ````

- ./ : HANA Unit Tests (in /test/hana) 

    ````
    npm install
    ````
    
    ````
    npm run test-hana
    ````

- /test/js : Node.js server

    ````
    cd test/js
    ````

    ````
    npm install
    ````
    
    ````
    node testServer.js
    ````


- Open browser

    ````
    localhost:3000   
    GET: localhost:3000/test/object/TestAO.js/1
    GET: localhost:3000/test/object/TestAO.odata
    ````
