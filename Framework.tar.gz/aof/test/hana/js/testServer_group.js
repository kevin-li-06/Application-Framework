"use strict";

var http = require("http");
var express = require("express");
var socketio = require("socket.io");
var aof = require("../../../");

var PORT = process.env.PORT || 3000;
var oOptions = require("./default-services.json").hana;

var app = express();
var server = http.Server(app);
var io = socketio(server);

aof.middleware(app, {
    applicationObjects: {
        "test.object.TestAO": "/test/object/TestAO"
    },
    extensions: {
        websocket: {
            name: "socket.io",
            lib: io,
            group: {
                "test.object.TestAO": "ID"
            }
        }
    }
}, {hana: oOptions});

/*server.listen(PORT, function () {
    console.log("Test server running on http://localhost:" + PORT);
});*/

process.on('unhandledRejection', r => console.log(r));

module.exports = server;