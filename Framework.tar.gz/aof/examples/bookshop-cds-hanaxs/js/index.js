"use strict";

const winston = require("winston");
const express = require("express");
const passport = require("passport");
const http = require("http");
const hdbext = require("@sap/hdbext");
const xs2sec = require("@sap/xssec");
const xsenv = require("@sap/xsenv");
const aof = require("../../../"); // require("@sap/aof");
const cds = require("@sap/cds");

const PORT = process.env.PORT || 3000;
winston.level = process.env.winston_level || "error";

const app = express();
const server = http.Server(app);

// passport.use("JWT", new xs2sec.JWTStrategy(xsenv.getServices({uaa: {tag: 'xsuaa'}}).uaa));
// app.use(passport.initialize());

var oConfig = xsenv.getServices({hana: {tag: 'hana'}});

app.use("/",
    hdbext.middleware(oConfig.hana)
    // passport.authenticate("JWT", {session: false})
);

aof.middleware(app, {
    schemaScope: aof.Schema.Scope.Cds,
    autoRegister: true,
    metadata: "/my/bookshop/metadata",
    applicationObjects: {
        "my.bookshop.Books": "/my/bookshop/Books",
        "my.bookshop.Orders": "/my/bookshop/Orders",
        "my.test.TestObject": "/my/test/TestObject"
    },
    extensions: {
        cds: {
            name: "@sap/cds",
            lib: cds,
            services: {
                "/catalog": "../srv/cat-service"
            }
        }
    }
});

cds.connect("hana", oConfig.hana);

server.listen(PORT, function () {
    console.log("Server running on http://localhost:" + PORT);
});
